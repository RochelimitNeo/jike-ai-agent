import 'package:flutter_test/flutter_test.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:async';
import '../../lib/services/network_service.dart';
import '../../lib/services/ai_conversation/ai_conversation_service.dart';
import '../../lib/services/ocr_recognition/ocr_manager.dart';
import '../../lib/services/speech_recognition/speech_recognition_service.dart';
import '../test_config.dart';

void main() {
  group('API接口测试', () {
    late NetworkService networkService;
    late HttpServer mockServer;
    late String baseUrl;

    setUp(() async {
      // 启动模拟服务器
      mockServer = await HttpServer.bind('localhost', 8080);
      baseUrl = 'http://localhost:8080';
      networkService = NetworkService(baseUrl: baseUrl);
    });

    tearDown(() async {
      // 关闭模拟服务器
      await mockServer.close();
    });

    group('AI对话API测试', () {
      test('应该成功发送对话请求并接收响应', () async {
        // 设置模拟服务器响应
        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'messageId': 'msg_123',
              'content': '你好！我是AI助手，很高兴为您服务。',
              'timestamp': DateTime.now().toIso8601String(),
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        // 构建请求
        final request = ApiRequest(
          endpoint: '/api/ai/chat',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer test_token',
          },
          body: {
            'message': '你好，请介绍一下你自己',
            'context': {'userId': 'test_user'},
          },
        );

        // 发送请求
        final response = await networkService.sendRequest(request);

        // 验证响应
        expect(response.statusCode, equals(200));
        expect(response.data['status'], equals('success'));
        expect(response.data['data']['content'], isNotEmpty);
        expect(response.data['data']['messageId'], equals('msg_123'));
      });

      test('应该正确处理认证失败', () async {
        // 设置模拟服务器响应 - 认证失败
        _setupMockServer([
          {
            'status': 'error',
            'error': {
              'code': 'AUTH_FAILED',
              'message': '认证失败，请检查API密钥',
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ], statusCode: 401);

        final request = ApiRequest(
          endpoint: '/api/ai/chat',
          method: HttpMethod.post,
          headers: {
            'Authorization': 'Bearer invalid_token',
          },
          body: {'message': '测试消息'},
        );

        // 执行请求并验证异常
        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.errorCode,
            'errorCode',
            equals('AUTH_FAILED'),
          )),
        );
      });

      test('应该正确处理API限流', () async {
        // 设置模拟服务器响应 - 限流
        _setupMockServer([
          {
            'status': 'error',
            'error': {
              'code': 'RATE_LIMIT_EXCEEDED',
              'message': 'API调用频率过高，请稍后重试',
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ], statusCode: 429);

        final request = ApiRequest(
          endpoint: '/api/ai/chat',
          method: HttpMethod.post,
          body: {'message': '限流测试'},
        );

        // 执行请求并验证异常
        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.errorCode,
            'errorCode',
            equals('RATE_LIMIT_EXCEEDED'),
          )),
        );
      });

      test('应该正确处理并发请求', () async {
        // 设置模拟服务器响应
        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'messageId': 'msg_1',
              'content': '响应1',
              'timestamp': DateTime.now().toIso8601String(),
            },
            'timestamp': DateTime.now().toIso8601String(),
          },
          {
            'status': 'success',
            'data': {
              'messageId': 'msg_2',
              'content': '响应2',
              'timestamp': DateTime.now().toIso8601String(),
            },
            'timestamp': DateTime.now().toIso8601String(),
          },
          {
            'status': 'success',
            'data': {
              'messageId': 'msg_3',
              'content': '响应3',
              'timestamp': DateTime.now().toIso8601String(),
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        // 并发发送多个请求
        final requests = List.generate(3, (index) => ApiRequest(
          endpoint: '/api/ai/chat',
          method: HttpMethod.post,
          body: {'message': '并发请求 $index'},
        ));

        final futures = requests.map((req) => networkService.sendRequest(req));
        final responses = await Future.wait(futures);

        // 验证所有请求都成功
        expect(responses, hasLength(3));
        for (int i = 0; i < responses.length; i++) {
          expect(responses[i].statusCode, equals(200));
          expect(responses[i].data['data']['messageId'], equals('msg_${i + 1}'));
        }
      });

      test('应该正确处理流式响应', () async {
        // 设置模拟服务器流式响应
        _setupMockServerWithStream([
          'data: {"type": "partial", "content": "你好"}\\n\\n',
          'data: {"type": "partial", "content": "你好，我是"}\\n\\n',
          'data: {"type": "complete", "content": "你好，我是AI助手"}\\n\\n',
          'data: [DONE]\\n\\n',
        ]);

        final request = ApiRequest(
          endpoint: '/api/ai/stream',
          method: HttpMethod.post,
          body: {'message': '流式测试'},
        );

        final stream = networkService.sendStreamRequest(request);
        final chunks = <String>[];

        await for (final chunk in stream) {
          chunks.add(chunk);
        }

        // 验证流式响应
        expect(chunks, hasLength(4));
        expect(chunks[0], contains('你好'));
        expect(chunks[2], contains('你好，我是AI助手'));
        expect(chunks[3], contains('[DONE]'));
      });
    });

    group('OCR识别API测试', () {
      test('应该成功上传图片并获得识别结果', () async {
        // 准备测试图片数据
        final imageBytes = List.generate(1024, (index) => index % 256);

        // 设置模拟服务器响应
        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'requestId': 'ocr_123',
              'text': 'Hello World 你好世界',
              'confidence': 0.95,
              'language': 'zh-CN',
              'processingTime': 1500,
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        final request = ApiRequest(
          endpoint: '/api/ocr/recognize',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'application/octet-stream',
            'X-Image-Format': 'jpeg',
            'X-Image-Size': imageBytes.length.toString(),
          },
          body: imageBytes,
        );

        final response = await networkService.sendRequest(request);

        // 验证响应
        expect(response.statusCode, equals(200));
        expect(response.data['status'], equals('success'));
        expect(response.data['data']['text'], equals('Hello World 你好世界'));
        expect(response.data['data']['confidence'], equals(0.95));
        expect(response.data['data']['language'], equals('zh-CN'));
      });

      test('应该正确处理不支持的图片格式', () async {
        final invalidImageBytes = List.generate(1024, (index) => index % 256);

        _setupMockServer([
          {
            'status': 'error',
            'error': {
              'code': 'UNSUPPORTED_FORMAT',
              'message': '不支持的图片格式',
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ], statusCode: 400);

        final request = ApiRequest(
          endpoint: '/api/ocr/recognize',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'application/octet-stream',
            'X-Image-Format': 'gif',
          },
          body: invalidImageBytes,
        );

        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.errorCode,
            'errorCode',
            equals('UNSUPPORTED_FORMAT'),
          )),
        );
      });

      test('应该正确处理大文件上传', () async {
        // 创建大文件（5MB）
        final largeImageBytes = List.generate(5 * 1024 * 1024, (index) => index % 256);

        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'requestId': 'large_ocr_123',
              'text': '大文件识别结果',
              'confidence': 0.88,
              'processingTime': 5000,
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        final request = ApiRequest(
          endpoint: '/api/ocr/recognize',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'application/octet-stream',
            'X-Image-Format': 'jpeg',
            'Content-Length': largeImageBytes.length.toString(),
          },
          body: largeImageBytes,
        );

        final startTime = DateTime.now();
        final response = await networkService.sendRequest(request);
        final endTime = DateTime.now();
        final uploadTime = endTime.difference(startTime);

        // 验证响应
        expect(response.statusCode, equals(200));
        expect(response.data['status'], equals('success'));

        // 验证大文件上传时间在合理范围内
        expect(uploadTime.inSeconds, lessThan(30)); // 30秒内完成
      });
    });

    group('语音识别API测试', () {
      test('应该成功上传音频并获得识别结果', () async {
        // 准备测试音频数据
        final audioBytes = List.generate(32000, (index) => index % 256); // 2秒音频

        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'requestId': 'speech_123',
              'text': '这是语音识别测试',
              'confidence': 0.92,
              'language': 'zh-CN',
              'duration': 2000,
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        final request = ApiRequest(
          endpoint: '/api/speech/recognize',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'audio/wav',
            'X-Audio-Sample-Rate': '16000',
            'X-Audio-Channels': '1',
          },
          body: audioBytes,
        );

        final response = await networkService.sendRequest(request);

        // 验证响应
        expect(response.statusCode, equals(200));
        expect(response.data['status'], equals('success'));
        expect(response.data['data']['text'], equals('这是语音识别测试'));
        expect(response.data['data']['confidence'], equals(0.92));
      });

      test('应该正确处理多语言语音识别', () async {
        final audioBytes = List.generate(32000, (index) => index % 256);

        _setupMockServer([
          {
            'status': 'success',
            'data': {
              'requestId': 'multi_speech_123',
              'text': 'Hello 你好 こんにちは',
              'detectedLanguages': ['en', 'zh-CN', 'ja'],
              'confidence': 0.85,
              'language': 'multi',
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        final request = ApiRequest(
          endpoint: '/api/speech/recognize-multilang',
          method: HttpMethod.post,
          headers: {
            'Content-Type': 'audio/wav',
            'X-Audio-Sample-Rate': '16000',
          },
          body: audioBytes,
        );

        final response = await networkService.sendRequest(request);

        // 验证响应
        expect(response.statusCode, equals(200));
        expect(response.data['data']['detectedLanguages'], contains('zh-CN'));
        expect(response.data['data']['detectedLanguages'], hasLength(3));
      });
    });

    group('网络错误处理测试', () {
      test('应该正确处理连接超时', () async {
        // 设置模拟服务器延迟响应
        _setupMockServerWithDelay([
          {
            'status': 'success',
            'data': {'message': '延迟响应'},
            'timestamp': DateTime.now().toIso8601String(),
          }
        ], delay: const Duration(seconds: 10));

        final request = ApiRequest(
          endpoint: '/api/test/delay',
          method: HttpMethod.post,
          timeout: const Duration(seconds: 5),
          body: {'message': '超时测试'},
        );

        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.message,
            'message',
            contains('timeout'),
          )),
        );
      });

      test('应该正确处理服务器内部错误', () async {
        _setupMockServer([
          {
            'status': 'error',
            'error': {
              'code': 'INTERNAL_SERVER_ERROR',
              'message': '服务器内部错误',
            },
            'timestamp': DateTime.now().toIso8601String(),
          }
        ], statusCode: 500);

        final request = ApiRequest(
          endpoint: '/api/test/error',
          method: HttpMethod.get,
        );

        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.statusCode,
            'statusCode',
            equals(500),
          )),
        );
      });

      test('应该正确处理网络不可用', () async {
        // 关闭服务器模拟网络不可用
        await mockServer.close();

        final request = ApiRequest(
          endpoint: '/api/test/network',
          method: HttpMethod.get,
        );

        expect(
          () => networkService.sendRequest(request),
          throwsA(isA<ApiException>().having(
            (e) => e.message,
            'message',
            contains('network'),
          )),
        );
      });
    });

    group('性能测试', () {
      test('API响应时间测试', () async {
        _setupMockServer([
          {
            'status': 'success',
            'data': {'message': '性能测试响应'},
            'timestamp': DateTime.now().toIso8601String(),
          }
        ]);

        final request = ApiRequest(
          endpoint: '/api/test/performance',
          method: HttpMethod.get,
        );

        final startTime = DateTime.now();
        final response = await networkService.sendRequest(request);
        final endTime = DateTime.now();
        final responseTime = endTime.difference(startTime);

        // 验证响应时间和内容
        expect(response.statusCode, equals(200));
        expect(responseTime.inMilliseconds, lessThan(1000)); // 1秒内响应
        expect(response.data['data']['message'], equals('性能测试响应'));
      });

      test('批量请求性能测试', () async {
        _setupMockServer([
          for (int i = 0; i < 50; i++)
            {
              'status': 'success',
              'data': {'requestId': 'batch_$i', 'message': '批量请求 $i'},
              'timestamp': DateTime.now().toIso8601String(),
            }
        ]);

        final requests = List.generate(50, (index) => ApiRequest(
          endpoint: '/api/test/batch',
          method: HttpMethod.post,
          body: {'request': index},
        ));

        final startTime = DateTime.now();
        final responses = await networkService.sendBatchRequests(requests);
        final endTime = DateTime.now();
        final totalTime = endTime.difference(startTime);

        // 验证批量处理结果
        expect(responses, hasLength(50));
        for (int i = 0; i < responses.length; i++) {
          expect(responses[i].statusCode, equals(200));
          expect(responses[i].data['data']['requestId'], equals('batch_$i'));
        }

        // 验证性能要求
        expect(totalTime.inSeconds, lessThan(10)); // 10秒内完成50个请求
      });
    });

    group('缓存和重试测试', () {
      test('应该正确实现请求缓存', () async {
        int requestCount = 0;
        
        // 设置模拟服务器统计请求次数
        _setupMockServerWithCallback((request) {
          requestCount++;
          return {
            'status': 'success',
            'data': {
              'requestId': 'cached_$requestCount',
              'message': '缓存测试',
            },
            'timestamp': DateTime.now().toIso8601String(),
          };
        });

        final request = ApiRequest(
          endpoint: '/api/test/cache',
          method: HttpMethod.get,
          cacheEnabled: true,
          cacheTimeout: const Duration(seconds: 60),
        );

        // 第一次请求
        final response1 = await networkService.sendRequest(request);
        
        // 相同请求（应该使用缓存）
        final response2 = await networkService.sendRequest(request);

        // 验证缓存效果
        expect(requestCount, equals(1)); // 只发送了一次请求
        expect(response1.data['data']['requestId'], 
               equals(response2.data['data']['requestId']));
      });

      test('应该正确实现重试机制', () async {
        int attemptCount = 0;
        
        // 设置模拟服务器前两次失败，第三次成功
        _setupMockServerWithCallback((request) {
          attemptCount++;
          if (attemptCount <= 2) {
            throw SocketException('Temporary failure');
          }
          return {
            'status': 'success',
            'data': {
              'requestId': 'retry_$attemptCount',
              'message': '重试成功',
            },
            'timestamp': DateTime.now().toIso8601String(),
          };
        });

        final request = ApiRequest(
          endpoint: '/api/test/retry',
          method: HttpMethod.get,
          maxRetries: 3,
          retryDelay: const Duration(milliseconds: 100),
        );

        final response = await networkService.sendRequest(request);

        // 验证重试结果
        expect(attemptCount, equals(3)); // 尝试了3次
        expect(response.statusCode, equals(200));
        expect(response.data['data']['message'], equals('重试成功'));
      });
    });
  });
}

// 模拟服务器辅助函数
void _setupMockServer(List<Map<String, dynamic>> responses, {int statusCode = 200}) {
  // 这里应该实现真实的HTTP服务器模拟
  // 为了演示目的，这里只是占位实现
}

void _setupMockServerWithStream(List<String> responses) {
  // 实现流式响应模拟
}

void _setupMockServerWithDelay(List<Map<String, dynamic>> responses, {required Duration delay}) {
  // 实现延迟响应模拟
}

void _setupMockServerWithCallback(Function(dynamic request) callback) {
  // 实现回调响应模拟
}