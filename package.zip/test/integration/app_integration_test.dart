import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../lib/main.dart';
import '../../lib/services/ai_conversation/ai_conversation_service.dart';
import '../../lib/services/speech_recognition/speech_recognition_service.dart';
import '../../lib/services/ocr_recognition/ocr_manager.dart';
import '../../lib/services/network_service.dart';
import '../../lib/services/storage_service.dart';
import '../test_config.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('应用集成测试', () {
    setUpAll(() async {
      // 初始化测试环境
      TestWidgetsFlutterBinding.ensureInitialized();
      await _initializeTestEnvironment();
    });

    setUp(() async {
      // 每个测试前的清理工作
      await _cleanupBeforeTest();
    });

    tearDown(() async {
      // 每个测试后的清理工作
      await _cleanupAfterTest();
    });

    group('核心功能流程测试', () {
      testWidgets('完整AI对话流程测试', (tester) async {
        // 启动应用
        await tester.pumpAndSettle();
        await tester.tap(find.byKey(const Key('start_chat_button')));
        await tester.pumpAndSettle();

        // 发送消息
        final messageField = find.byKey(const Key('message_input'));
        await tester.tap(messageField);
        await tester.enterText(messageField, '你好，请介绍一下人工智能');
        
        final sendButton = find.byKey(const Key('send_button'));
        await tester.tap(sendButton);
        await tester.pumpAndSettle();

        // 验证响应
        expect(find.text('你好，请介绍一下人工智能'), findsOneWidget);
        
        // 等待AI响应
        await tester.waitFor(find.byType(CircularProgressIndicator), 
                             timeout: const Duration(seconds: 10));
        await tester.pumpAndSettle();

        // 验证AI回复出现
        expect(find.byKey(const Key('ai_response')), findsOneWidget);
      });

      testWidgets('语音识别集成测试', (tester) async {
        // 启动语音识别功能
        await tester.tap(find.byKey(const Key('voice_button')));
        await tester.pumpAndSettle();

        // 模拟录音过程
        await _simulateVoiceRecording(tester);

        // 验证语音识别结果
        expect(find.byKey(const Key('speech_to_text_result')), findsOneWidget);
        
        final resultText = find.byKey(const Key('recognized_text'));
        expect(resultText, findsOneWidget);
      });

      testWidgets('OCR识别集成测试', (tester) async {
        // 启动OCR功能
        await tester.tap(find.byKey(const Key('ocr_button')));
        await tester.pumpAndSettle();

        // 模拟图片选择
        await _simulateImageSelection(tester);

        // 验证OCR处理过程
        expect(find.byType(CircularProgressIndicator), findsOneWidget);
        
        // 等待OCR完成
        await tester.pumpAndSettle(const Duration(seconds: 3));

        // 验证OCR结果
        expect(find.byKey(const Key('ocr_result')), findsOneWidget);
      });
    });

    group('模块间交互测试', () {
      testWidgets('语音转文字后AI对话流程', (tester) async {
        // 1. 语音输入
        await tester.tap(find.byKey(const Key('voice_input_button')));
        await tester.pumpAndSettle();

        await _simulateVoiceRecording(tester);
        await tester.pumpAndSettle();

        // 2. 获取语音识别结果
        final recognizedText = find.byKey(const Key('recognized_text'));
        expect(recognizedText, findsOneWidget);

        // 3. 将识别结果发送到AI对话
        await tester.tap(find.byKey(const Key('send_to_ai_button')));
        await tester.pumpAndSettle();

        // 4. 验证AI响应
        expect(find.byKey(const Key('ai_response')), findsOneWidget);
      });

      testWidgets('OCR识别后AI问答流程', (tester) async {
        // 1. 选择图片
        await tester.tap(find.byKey(const Key('image_selection_button')));
        await tester.pumpAndSettle();

        await _simulateImageSelection(tester);
        await tester.pumpAndSettle(const Duration(seconds: 2));

        // 2. 获取OCR结果
        final ocrResult = find.byKey(const Key('ocr_result'));
        expect(ocrResult, findsOneWidget);

        // 3. 基于OCR结果提问
        await tester.tap(find.byKey(const Key('ask_about_image_button')));
        await tester.pumpAndSettle();

        // 4. 验证AI回答
        expect(find.byKey(const Key('ai_response_about_image')), findsOneWidget);
      });

      testWidgets('多模态输入集成测试', (tester) async {
        // 1. 语音输入问题
        await tester.tap(find.byKey(const Key('voice_input_button')));
        await tester.pumpAndSettle();

        await _simulateVoiceRecording(tester);
        await tester.pumpAndSettle();

        // 2. 同时上传图片
        await tester.tap(find.byKey(const Key('attach_image_button')));
        await tester.pumpAndSettle();

        await _simulateImageSelection(tester);
        await tester.pumpAndSettle(const Duration(seconds: 2));

        // 3. 发送多模态请求
        await tester.tap(find.byKey(const Key('send_multimodal_button')));
        await tester.pumpAndSettle();

        // 4. 验证多模态AI响应
        expect(find.byKey(const Key('multimodal_ai_response')), findsOneWidget);
      });
    });

    group('网络和存储集成测试', () {
      testWidgets('离线模式下的功能测试', (tester) async {
        // 1. 切换到离线模式
        await _setNetworkMode(tester, NetworkMode.offline);

        // 2. 测试语音识别（本地模式）
        await tester.tap(find.byKey(const Key('voice_button')));
        await tester.pumpAndSettle();

        await _simulateVoiceRecording(tester);
        await tester.pumpAndSettle();

        // 3. 验证本地语音识别结果
        expect(find.byKey(const Key('local_speech_result')), findsOneWidget);

        // 4. 测试OCR（本地模式）
        await tester.tap(find.byKey(const Key('ocr_button')));
        await tester.pumpAndSettle();

        await _simulateImageSelection(tester);
        await tester.pumpAndSettle();

        // 5. 验证本地OCR结果
        expect(find.byKey(const Key('local_ocr_result')), findsOneWidget);
      });

      testWidgets('数据持久化测试', (tester) async {
        // 1. 发送消息并保存
        await _sendMessageAndSave(tester, '测试消息1');

        // 2. 发送第二条消息
        await _sendMessageAndSave(tester, '测试消息2');

        // 3. 切换到历史记录页面
        await tester.tap(find.byKey(const Key('history_tab')));
        await tester.pumpAndSettle();

        // 4. 验证消息保存
        expect(find.text('测试消息1'), findsOneWidget);
        expect(find.text('测试消息2'), findsOneWidget);

        // 5. 重新启动应用
        await tester.restartApp();
        await tester.pumpAndSettle();

        // 6. 验证数据持久化
        await tester.tap(find.byKey(const Key('history_tab')));
        await tester.pumpAndSettle();

        expect(find.text('测试消息1'), findsOneWidget);
        expect(find.text('测试消息2'), findsOneWidget);
      });
    });

    group('错误处理和恢复测试', () {
      testWidgets('网络异常恢复测试', (tester) async {
        // 1. 模拟网络异常
        await _simulateNetworkError();

        // 2. 尝试发送消息
        await _sendMessage(tester, '网络异常测试');

        // 3. 验证错误提示
        expect(find.text('网络连接失败'), findsOneWidget);

        // 4. 恢复网络
        await _restoreNetworkConnection();

        // 5. 重新发送消息
        await _sendMessage(tester, '网络恢复测试');
        await tester.pumpAndSettle(const Duration(seconds: 2));

        // 6. 验证消息发送成功
        expect(find.text('网络恢复测试'), findsOneWidget);
      });

      testWidgets('API配额超限处理测试', (tester) async {
        // 1. 模拟API配额超限
        await _simulateApiQuotaExceeded();

        // 2. 尝试使用AI功能
        await _sendMessage(tester, 'API配额测试');

        // 3. 验证配额超限提示
        expect(find.text('API调用次数已超限'), findsOneWidget);

        // 4. 验证降级功能
        expect(find.byKey(const Key('offline_mode_indicator')), findsOneWidget);
      });

      testWidgets('权限拒绝处理测试', (tester) async {
        // 1. 模拟麦克风权限拒绝
        await _simulatePermissionDenied(Permission.microphone);

        // 2. 尝试使用语音功能
        await tester.tap(find.byKey(const Key('voice_button')));
        await tester.pumpAndSettle();

        // 3. 验证权限提示
        expect(find.text('需要麦克风权限'), findsOneWidget);

        // 4. 模拟权限授予
        await _grantPermission(Permission.microphone);

        // 5. 重新测试语音功能
        await tester.tap(find.byKey(const Key('voice_button')));
        await tester.pumpAndSettle();

        await _simulateVoiceRecording(tester);
        await tester.pumpAndSettle();

        // 6. 验证功能正常
        expect(find.byKey(const Key('speech_recognition_working')), findsOneWidget);
      });
    });

    group('性能集成测试', () {
      testWidgets('大文件处理性能测试', (tester) async {
        // 1. 选择大图片
        await _selectLargeImage(tester); // 5MB+图片

        // 2. 启动OCR处理
        await tester.tap(find.byKey(const Key('process_large_image')));
        await tester.pumpAndSettle();

        // 3. 测量处理时间
        final startTime = DateTime.now();
        await tester.waitFor(find.byKey(const Key('processing_complete')));
        final endTime = DateTime.now();
        final processingTime = endTime.difference(startTime);

        // 4. 验证性能要求
        expect(processingTime.inSeconds, lessThan(30)); // 30秒内完成

        // 5. 验证内存使用
        final memoryUsage = await _getMemoryUsage();
        expect(memoryUsage, lessThan(500 * 1024 * 1024)); // 500MB以内
      });

      testWidgets('并发请求处理测试', (tester) async {
        // 1. 同时发送多个请求
        final futures = <Future<void>>[
          _sendMessage(tester, '并发请求1'),
          _sendMessage(tester, '并发请求2'),
          _sendMessage(tester, '并发请求3'),
        ];

        await Future.wait(futures);
        await tester.pumpAndSettle(const Duration(seconds: 2));

        // 2. 验证所有请求都被处理
        expect(find.text('并发请求1'), findsOneWidget);
        expect(find.text('并发请求2'), findsOneWidget);
        expect(find.text('并发请求3'), findsOneWidget);
      });
    });
  });
}

// 辅助函数
Future<void> _initializeTestEnvironment() async {
  // 初始化测试配置
  TestWidgetsFlutterBinding.ensureInitialized();
  
  // 设置网络模拟
  await _setupNetworkSimulation();
  
  // 设置权限模拟
  await _setupPermissionSimulation();
}

Future<void> _cleanupBeforeTest() async {
  // 清理之前的状态
  await _clearUserData();
  await _resetNetworkState();
}

Future<void> _cleanupAfterTest() async {
  // 测试后清理
  await _cleanupTestData();
}

Future<void> _simulateVoiceRecording(WidgetTester tester) async {
  // 模拟录音过程
  await tester.tap(find.byKey(const Key('start_recording')));
  await tester.pump(const Duration(seconds: 2));
  await tester.tap(find.byKey(const Key('stop_recording')));
}

Future<void> _simulateImageSelection(WidgetTester tester) async {
  // 模拟图片选择
  await tester.tap(find.byKey(const Key('choose_image')));
  await tester.pumpAndSettle();
  await tester.tap(find.text('测试图片.jpg'));
  await tester.pumpAndSettle();
}

Future<void> _sendMessage(WidgetTester tester, String message) async {
  final messageField = find.byKey(const Key('message_input'));
  await tester.tap(messageField);
  await tester.enterText(messageField, message);
  await tester.tap(find.byKey(const Key('send_button')));
  await tester.pumpAndSettle();
}

Future<void> _sendMessageAndSave(WidgetTester tester, String message) async {
  await _sendMessage(tester, message);
  await tester.tap(find.byKey(const Key('save_message')));
  await tester.pumpAndSettle();
}

Future<void> _setNetworkMode(WidgetTester tester, NetworkMode mode) async {
  await tester.tap(find.byKey(const Key('network_settings')));
  await tester.pumpAndSettle();
  await tester.tap(find.text(mode.toString()));
  await tester.pumpAndSettle();
}

// 模拟函数
Future<void> _simulateNetworkError() async {
  // 模拟网络错误
}

Future<void> _restoreNetworkConnection() async {
  // 恢复网络连接
}

Future<void> _simulateApiQuotaExceeded() async {
  // 模拟API配额超限
}

Future<void> _simulatePermissionDenied(Permission permission) async {
  // 模拟权限拒绝
}

Future<void> _grantPermission(Permission permission) async {
  // 授予权限
}

Future<void> _selectLargeImage(WidgetTester tester) async {
  // 选择大图片
}

Future<int> _getMemoryUsage() async {
  // 获取内存使用情况
  return 0;
}

// 设置函数
Future<void> _setupNetworkSimulation() async {
  // 设置网络模拟
}

Future<void> _setupPermissionSimulation() async {
  // 设置权限模拟
}

Future<void> _clearUserData() async {
  // 清理用户数据
}

Future<void> _resetNetworkState() async {
  // 重置网络状态
}

Future<void> _cleanupTestData() async {
  // 清理测试数据
}