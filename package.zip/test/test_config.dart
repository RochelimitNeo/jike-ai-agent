import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'dart:io';
import 'dart:convert';

/// 测试配置文件
/// 包含测试环境配置、API端点、测试数据等
class TestConfig {
  // 测试环境配置
  static const String testEnvironment = 'test';
  static const String baseUrl = 'https://test-api.example.com';
  static const String mockApiUrl = 'http://localhost:8080';
  
  // 测试数据路径
  static const String testDataPath = 'test/test_data/';
  static const String mockResponsesPath = 'test/mock_responses/';
  
  // 测试超时配置
  static const Duration defaultTimeout = Duration(seconds: 30);
  static const Duration longTimeout = Duration(minutes: 2);
  
  // 权限测试配置
  static const List<String> requiredPermissions = [
    'android.permission.RECORD_AUDIO',
    'android.permission.CAMERA',
    'android.permission.WRITE_EXTERNAL_STORAGE',
    'android.permission.READ_EXTERNAL_STORAGE',
  ];
  
  // API测试配置
  static const Map<String, String> testApiEndpoints = {
    'auth': '/api/auth',
    'ocr': '/api/ocr',
    'speech': '/api/speech',
    'ai': '/api/ai',
    'user': '/api/user',
  };
  
  // 性能测试阈值
  static const Map<String, num> performanceThresholds = {
    'apiResponseTime': 2000, // 毫秒
    'ocrProcessingTime': 3000,
    'speechRecognitionTime': 5000,
    'memoryUsage': 100, // MB
    'cpuUsage': 80, // 百分比
  };
  
  // 获取测试数据
  static Future<Map<String, dynamic>> getTestData(String fileName) async {
    try {
      final file = File('${testDataPath}$fileName.json');
      if (await file.exists()) {
        final content = await file.readAsString();
        return json.decode(content);
      }
    } catch (e) {
      print('Error loading test data: $e');
    }
    return {};
  }
  
  // 获取模拟响应
  static Future<String> getMockResponse(String endpoint) async {
    try {
      final file = File('${mockResponsesPath}$endpoint.json');
      if (await file.exists()) {
        return await file.readAsString();
      }
    } catch (e) {
      print('Error loading mock response: $e');
    }
    return '{}';
  }
}

/// 测试工具类
class TestUtils {
  // 等待异步操作
  static Future<void> waitFor(Future<bool> condition(),
      {Duration timeout = const Duration(seconds: 10)}) async {
    final endTime = DateTime.now().add(timeout);
    while (DateTime.now().isBefore(endTime)) {
      if (await condition()) return;
      await Future.delayed(const Duration(milliseconds: 100));
    }
    throw TimeoutException('Condition not met within timeout');
  }
  
  // 生成测试数据
  static Map<String, dynamic> generateTestUserData() => {
        'id': 'test_user_123',
        'name': 'Test User',
        'email': 'test@example.com',
        'preferences': {
          'language': 'zh-CN',
          'theme': 'dark',
          'notifications': true,
        },
      };
  
  // 验证响应格式
  static bool isValidApiResponse(Map<String, dynamic> response) {
    return response.containsKey('status') &&
           response.containsKey('data') &&
           response.containsKey('timestamp');
  }
  
  // 模拟网络延迟
  static Future<void> simulateNetworkDelay(
      {Duration min = const Duration(milliseconds: 100),
      Duration max = const Duration(milliseconds: 500)}) async {
    final delay = Duration(
        milliseconds: min.inMilliseconds +
            (max.inMilliseconds - min.inMilliseconds).abs());
    await Future.delayed(delay);
  }
}

/// 性能测试工具
class PerformanceTestUtils {
  // 测量执行时间
  static Future<Duration> measureExecutionTime(Future<void> Function() action) async {
    final stopwatch = Stopwatch()..start();
    await action();
    stopwatch.stop();
    return stopwatch.elapsed;
  }
  
  // 测量内存使用
  static Future<int> measureMemoryUsage(Future<void> Function() action) async {
    final startMemory = ProcessInfo.currentRss;
    await action();
    final endMemory = ProcessInfo.currentRss;
    return endMemory - startMemory;
  }
  
  // 检查性能阈值
  static bool isWithinThreshold(Duration executionTime, num threshold) {
    return executionTime.inMilliseconds <= threshold;
  }
}

/// 权限测试工具
class PermissionTestUtils {
  // 检查权限状态
  static Future<bool> checkPermission(String permission) async {
    // 模拟权限检查逻辑
    await Future.delayed(const Duration(milliseconds: 100));
    return true; // 实际实现中会调用系统API
  }
  
  // 请求权限
  static Future<bool> requestPermission(String permission) async {
    // 模拟权限请求逻辑
    await Future.delayed(const Duration(milliseconds: 200));
    return true; // 实际实现中会调用系统API
  }
  
  // 验证权限集
  static Future<bool> validateRequiredPermissions() async {
    for (final permission in TestConfig.requiredPermissions) {
      if (!await checkPermission(permission)) {
        return false;
      }
    }
    return true;
  }
}