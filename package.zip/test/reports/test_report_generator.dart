import 'dart:io';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import '../test_config.dart';

/// 测试报告生成器
class TestReportGenerator {
  static const String reportDir = 'test/reports/';
  
  /// 生成综合测试报告
  static Future<TestReport> generateComprehensiveReport() async {
    final report = TestReport(
      timestamp: DateTime.now(),
      testEnvironment: TestConfig.testEnvironment,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      skippedTests: 0,
      duration: Duration.zero,
      moduleReports: {},
    );

    // 收集各模块测试结果
    report.moduleReports['ai_conversation'] = await _collectModuleResults('ai_conversation');
    report.moduleReports['speech_recognition'] = await _collectModuleResults('speech_recognition');
    report.moduleReports['ocr_recognition'] = await _collectModuleResults('ocr_recognition');
    report.moduleReports['integration'] = await _collectModuleResults('integration');
    report.moduleReports['ui_automation'] = await _collectModuleResults('ui_automation');
    report.moduleReports['api_testing'] = await _collectModuleResults('api_testing');
    report.moduleReports['permission_management'] = await _collectModuleResults('permission_management');

    // 计算总体统计
    for (final report in report.moduleReports.values) {
      report.totalTests += report.totalTests;
      report.passedTests += report.passedTests;
      report.failedTests += report.failedTests;
      report.skippedTests += report.skippedTests;
      report.duration += report.duration;
    }

    report.totalTests = report.moduleReports.values
        .fold(0, (sum, r) => sum + r.totalTests);
    report.passedTests = report.moduleReports.values
        .fold(0, (sum, r) => sum + r.passedTests);
    report.failedTests = report.moduleReports.values
        .fold(0, (sum, r) => sum + r.failedTests);
    report.skippedTests = report.moduleReports.values
        .fold(0, (sum, r) => sum + r.skippedTests);

    return report;
  }

  /// 收集模块测试结果
  static Future<ModuleTestReport> _collectModuleResults(String moduleName) async {
    final report = ModuleTestReport(
      moduleName: moduleName,
      totalTests: 0,
      passedTests: 0,
      failedTests: 0,
      skippedTests: 0,
      duration: Duration.zero,
      testGroups: {},
      performanceMetrics: {},
    );

    // 模拟读取测试结果文件
    final resultFile = File('${reportDir}${moduleName}_results.json');
    if (await resultFile.exists()) {
      final content = await resultFile.readAsString();
      final data = json.decode(content);
      
      report.totalTests = data['totalTests'] ?? 0;
      report.passedTests = data['passedTests'] ?? 0;
      report.failedTests = data['failedTests'] ?? 0;
      report.skippedTests = data['skippedTests'] ?? 0;
      
      if (data['duration'] != null) {
        report.duration = Duration(milliseconds: data['duration']);
      }

      // 解析测试组结果
      if (data['testGroups'] != null) {
        for (final entry in data['testGroups'].entries) {
          report.testGroups[entry.key] = TestGroupResult(
            name: entry.key,
            totalTests: entry.value['totalTests'] ?? 0,
            passedTests: entry.value['passedTests'] ?? 0,
            failedTests: entry.value['failedTests'] ?? 0,
            duration: Duration(milliseconds: entry.value['duration'] ?? 0),
            errors: List<String>.from(entry.value['errors'] ?? []),
          );
        }
      }

      // 解析性能指标
      if (data['performanceMetrics'] != null) {
        report.performanceMetrics.addAll(Map<String, num>.from(data['performanceMetrics']));
      }
    }

    return report;
  }

  /// 生成HTML报告
  static Future<String> generateHtmlReport(TestReport report) async {
    final html = StringBuffer();
    
    html.writeln('<!DOCTYPE html>');
    html.writeln('<html lang="zh-CN">');
    html.writeln('<head>');
    html.writeln('    <meta charset="UTF-8">');
    html.writeln('    <meta name="viewport" content="width=device-width, initial-scale=1.0">');
    html.writeln('    <title>AI助手测试报告</title>');
    html.writeln('    <style>');
    html.writeln('        body { font-family: Arial, sans-serif; margin: 20px; }');
    html.writeln('        .header { background: #2196F3; color: white; padding: 20px; border-radius: 5px; }');
    html.writeln('        .summary { display: flex; gap: 20px; margin: 20px 0; }');
    html.writeln('        .metric { background: #f5f5f5; padding: 15px; border-radius: 5px; text-align: center; }');
    html.writeln('        .metric h3 { margin: 0; color: #333; }');
    html.writeln('        .metric .value { font-size: 24px; font-weight: bold; margin: 5px 0; }');
    html.writeln('        .module { border: 1px solid #ddd; margin: 20px 0; border-radius: 5px; }');
    html.writeln('        .module-header { background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ddd; }');
    html.writeln('        .module-content { padding: 15px; }');
    html.writeln('        .success { color: #4CAF50; }');
    html.writeln('        .error { color: #f44336; }');
    html.writeln('        .warning { color: #ff9800; }');
    html.writeln('        table { width: 100%; border-collapse: collapse; margin: 10px 0; }');
    html.writeln('        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }');
    html.writeln('        th { background-color: #f2f2f2; }');
    html.writeln('        .progress-bar { width: 100%; height: 20px; background: #f0f0f0; border-radius: 10px; overflow: hidden; }');
    html.writeln('        .progress-fill { height: 100%; background: #4CAF50; transition: width 0.3s; }');
    html.writeln('    </style>');
    html.writeln('</head>');
    html.writeln('<body>');
    
    // 标题和基本信息
    html.writeln('    <div class="header">');
    html.writeln('        <h1>AI助手功能测试报告</h1>');
    html.writeln('        <p>生成时间: ${report.timestamp.toIso8601String()}</p>');
    html.writeln('        <p>测试环境: ${report.testEnvironment}</p>');
    html.writeln('        <p>总耗时: ${_formatDuration(report.duration)}</p>');
    html.writeln('    </div>');
    
    // 总体统计
    html.writeln('    <div class="summary">');
    html.writeln('        <div class="metric">');
    html.writeln('            <h3>总测试数</h3>');
    html.writeln('            <div class="value">${report.totalTests}</div>');
    html.writeln('        </div>');
    html.writeln('        <div class="metric">');
    html.writeln('            <h3>通过</h3>');
    html.writeln('            <div class="value success">${report.passedTests}</div>');
    html.writeln('        </div>');
    html.writeln('        <div class="metric">');
    html.writeln('            <h3>失败</h3>');
    html.writeln('            <div class="value error">${report.failedTests}</div>');
    html.writeln('        </div>');
    html.writeln('        <div class="metric">');
    html.writeln('            <h3>跳过</h3>');
    html.writeln('            <div class="value warning">${report.skippedTests}</div>');
    html.writeln('        </div>');
    html.writeln('    </div>');
    
    // 通过率
    final passRate = report.totalTests > 0 ? 
        (report.passedTests / report.totalTests * 100).toStringAsFixed(1) : '0.0';
    html.writeln('    <div style="margin: 20px 0;">');
    html.writeln('        <h3>总体通过率</h3>');
    html.writeln('        <div class="progress-bar">');
    html.writeln('            <div class="progress-fill" style="width: $passRate%"></div>');
    html.writeln('        </div>');
    html.writeln('        <p style="text-align: center; margin: 10px 0;">$passRate%</p>');
    html.writeln('    </div>');
    
    // 各模块详细结果
    html.writeln('    <h2>模块测试详情</h2>');
    
    for (final entry in report.moduleReports.entries) {
      final moduleName = entry.key;
      final moduleReport = entry.value;
      final modulePassRate = moduleReport.totalTests > 0 ?
          (moduleReport.passedTests / moduleReport.totalTests * 100).toStringAsFixed(1) : '0.0';
      
      html.writeln('    <div class="module">');
      html.writeln('        <div class="module-header">');
      html.writeln('            <h3>${_getModuleDisplayName(moduleName)}</h3>');
      html.writeln('            <p>测试数: ${moduleReport.totalTests} | 通过: ${moduleReport.passedTests} | 失败: ${moduleReport.failedTests} | 耗时: ${_formatDuration(moduleReport.duration)}</p>');
      html.writeln('            <div class="progress-bar" style="width: 200px;">');
      html.writeln('                <div class="progress-fill" style="width: $modulePassRate%"></div>');
      html.writeln('            </div>');
      html.writeln('        </div>');
      html.writeln('        <div class="module-content">');
      
      // 测试组详情
      if (moduleReport.testGroups.isNotEmpty) {
        html.writeln('            <h4>测试组详情</h4>');
        html.writeln('            <table>');
        html.writeln('                <tr><th>测试组</th><th>总测试</th><th>通过</th><th>失败</th><th>耗时</th></tr>');
        
        for (final group in moduleReport.testGroups.values) {
          html.writeln('                <tr>');
          html.writeln('                    <td>${group.name}</td>');
          html.writeln('                    <td>${group.totalTests}</td>');
          html.writeln('                    <td class="success">${group.passedTests}</td>');
          html.writeln('                    <td class="error">${group.failedTests}</td>');
          html.writeln('                    <td>${_formatDuration(group.duration)}</td>');
          html.writeln('                </tr>');
        }
        
        html.writeln('            </table>');
      }
      
      // 性能指标
      if (moduleReport.performanceMetrics.isNotEmpty) {
        html.writeln('            <h4>性能指标</h4>');
        html.writeln('            <table>');
        html.writeln('                <tr><th>指标</th><th>值</th><th>状态</th></tr>');
        
        for (final entry in moduleReport.performanceMetrics.entries) {
          final status = _evaluatePerformanceMetric(entry.key, entry.value);
          html.writeln('                <tr>');
          html.writeln('                    <td>${entry.key}</td>');
          html.writeln('                    <td>${entry.value}</td>');
          html.writeln('                    <td class="$status">$status</td>');
          html.writeln('                </tr>');
        }
        
        html.writeln('            </table>');
      }
      
      html.writeln('        </div>');
      html.writeln('    </div>');
    }
    
    html.writeln('</body>');
    html.writeln('</html>');
    
    return html.toString();
  }

  /// 生成JSON报告
  static Future<String> generateJsonReport(TestReport report) async {
    final jsonData = {
      'timestamp': report.timestamp.toIso8601String(),
      'testEnvironment': report.testEnvironment,
      'summary': {
        'totalTests': report.totalTests,
        'passedTests': report.passedTests,
        'failedTests': report.failedTests,
        'skippedTests': report.skippedTests,
        'duration': report.duration.inMilliseconds,
        'passRate': report.totalTests > 0 ? 
            (report.passedTests / report.totalTests) : 0.0,
      },
      'modules': report.moduleReports.map((key, value) => MapEntry(key, {
        'moduleName': value.moduleName,
        'totalTests': value.totalTests,
        'passedTests': value.passedTests,
        'failedTests': value.failedTests,
        'skippedTests': value.skippedTests,
        'duration': value.duration.inMilliseconds,
        'testGroups': value.testGroups.map((k, v) => MapEntry(k, {
          'name': v.name,
          'totalTests': v.totalTests,
          'passedTests': v.passedTests,
          'failedTests': v.failedTests,
          'duration': v.duration.inMilliseconds,
          'errors': v.errors,
        })),
        'performanceMetrics': value.performanceMetrics,
      })),
    };
    
    return JsonEncoder.withIndent('  ').convert(jsonData);
  }

  /// 保存报告文件
  static Future<void> saveReport(TestReport report) async {
    final dir = Directory(reportDir);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    
    // 保存HTML报告
    final htmlContent = await generateHtmlReport(report);
    final htmlFile = File('${reportDir}test_report.html');
    await htmlFile.writeAsString(htmlContent);
    
    // 保存JSON报告
    final jsonContent = await generateJsonReport(report);
    final jsonFile = File('${reportDir}test_report.json');
    await jsonFile.writeAsString(jsonContent);
    
    // 生成覆盖率报告
    await _generateCoverageReport(report);
  }

  /// 生成覆盖率报告
  static Future<void> _generateCoverageReport(TestReport report) async {
    final coverage = {
      'ai_conversation': _calculateCoverage(report.moduleReports['ai_conversation']),
      'speech_recognition': _calculateCoverage(report.moduleReports['speech_recognition']),
      'ocr_recognition': _calculateCoverage(report.moduleReports['ocr_recognition']),
      'integration': _calculateCoverage(report.moduleReports['integration']),
      'ui_automation': _calculateCoverage(report.moduleReports['ui_automation']),
      'api_testing': _calculateCoverage(report.moduleReports['api_testing']),
      'permission_management': _calculateCoverage(report.moduleReports['permission_management']),
    };
    
    final coverageHtml = _generateCoverageHtml(coverage);
    final coverageFile = File('${reportDir}coverage_report.html');
    await coverageFile.writeAsString(coverageHtml);
  }

  /// 计算覆盖率
  static double _calculateCoverage(ModuleTestReport? report) {
    if (report == null || report.totalTests == 0) return 0.0;
    
    // 简化的覆盖率计算：基于通过的测试数
    return report.passedTests / report.totalTests;
  }

  /// 生成覆盖率HTML报告
  static String _generateCoverageHtml(Map<String, double> coverage) {
    final html = StringBuffer();
    
    html.writeln('<!DOCTYPE html>');
    html.writeln('<html lang="zh-CN">');
    html.writeln('<head>');
    html.writeln('    <meta charset="UTF-8">');
    html.writeln('    <title>代码覆盖率报告</title>');
    html.writeln('    <style>');
    html.writeln('        body { font-family: Arial, sans-serif; margin: 20px; }');
    html.writeln('        .coverage-item { margin: 10px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }');
    html.writeln('        .coverage-bar { width: 300px; height: 20px; background: #f0f0f0; border-radius: 10px; overflow: hidden; display: inline-block; }');
    html.writeln('        .coverage-fill { height: 100%; transition: width 0.3s; }');
    html.writeln('        .high { background: #4CAF50; }');
    html.writeln('        .medium { background: #ff9800; }');
    html.writeln('        .low { background: #f44336; }');
    html.writeln('    </style>');
    html.writeln('</head>');
    html.writeln('<body>');
    html.writeln('    <h1>代码覆盖率报告</h1>');
    
    for (final entry in coverage.entries) {
      final moduleName = _getModuleDisplayName(entry.key);
      final coveragePercent = (entry.value * 100).toStringAsFixed(1);
      final cssClass = entry.value >= 0.8 ? 'high' : 
                      entry.value >= 0.6 ? 'medium' : 'low';
      
      html.writeln('    <div class="coverage-item">');
      html.writeln('        <h3>$moduleName</h3>');
      html.writeln('        <div class="coverage-bar">');
      html.writeln('            <div class="coverage-fill $cssClass" style="width: $coveragePercent%"></div>');
      html.writeln('        </div>');
      html.writeln('        <span>$coveragePercent%</span>');
      html.writeln('    </div>');
    }
    
    html.writeln('</body>');
    html.writeln('</html>');
    
    return html.toString();
  }

  /// 格式化持续时间
  static String _formatDuration(Duration duration) {
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}m ${duration.inSeconds % 60}s';
    } else if (duration.inMinutes > 0) {
      return '${duration.inMinutes}m ${duration.inSeconds % 60}s';
    } else {
      return '${duration.inSeconds}s';
    }
  }

  /// 获取模块显示名称
  static String _getModuleDisplayName(String moduleName) {
    final displayNames = {
      'ai_conversation': 'AI对话模块',
      'speech_recognition': '语音识别模块',
      'ocr_recognition': 'OCR识别模块',
      'integration': '集成测试',
      'ui_automation': 'UI自动化测试',
      'api_testing': 'API接口测试',
      'permission_management': '权限管理测试',
    };
    
    return displayNames[moduleName] ?? moduleName;
  }

  /// 评估性能指标
  static String _evaluatePerformanceMetric(String metric, num value) {
    switch (metric) {
      case 'apiResponseTime':
        return value <= TestConfig.performanceThresholds['apiResponseTime']! ? '良好' : '需要优化';
      case 'ocrProcessingTime':
        return value <= TestConfig.performanceThresholds['ocrProcessingTime']! ? '良好' : '需要优化';
      case 'speechRecognitionTime':
        return value <= TestConfig.performanceThresholds['speechRecognitionTime']! ? '良好' : '需要优化';
      case 'memoryUsage':
        return value <= TestConfig.performanceThresholds['memoryUsage']! ? '良好' : '需要优化';
      default:
        return '未知';
    }
  }
}

/// 测试报告数据类
class TestReport {
  final DateTime timestamp;
  final String testEnvironment;
  int totalTests;
  int passedTests;
  int failedTests;
  int skippedTests;
  Duration duration;
  final Map<String, ModuleTestReport> moduleReports;

  TestReport({
    required this.timestamp,
    required this.testEnvironment,
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.skippedTests,
    required this.duration,
    required this.moduleReports,
  });
}

/// 模块测试报告
class ModuleTestReport {
  final String moduleName;
  int totalTests;
  int passedTests;
  int failedTests;
  int skippedTests;
  Duration duration;
  final Map<String, TestGroupResult> testGroups;
  final Map<String, num> performanceMetrics;

  ModuleTestReport({
    required this.moduleName,
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.skippedTests,
    required this.duration,
    required this.testGroups,
    required this.performanceMetrics,
  });
}

/// 测试组结果
class TestGroupResult {
  final String name;
  final int totalTests;
  final int passedTests;
  final int failedTests;
  final Duration duration;
  final List<String> errors;

  TestGroupResult({
    required this.name,
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.duration,
    required this.errors,
  });
}