import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import '../../lib/services/ai_conversation/ai_conversation.dart';
import '../../lib/services/ai_conversation/ai_conversation_service.dart';
import '../../lib/services/ai_conversation/models/ai_models.dart';
import '../../lib/services/ai_conversation/providers/base_provider.dart';
import '../test_config.dart';

// 生成模拟类
@GenerateMocks([AiConversationService, BaseAiProvider])
import 'ai_conversation_test.mocks.dart';

void main() {
  group('AI对话模块测试', () {
    late AiConversation aiConversation;
    late MockAiConversationService mockService;
    late MockBaseAiProvider mockProvider;

    setUp(() {
      mockService = MockAiConversationService();
      mockProvider = MockBaseAiProvider();
      aiConversation = AiConversation(service: mockService);
    });

    group('基本对话功能测试', () {
      test('应该成功发送消息并接收响应', () async {
        // 准备测试数据
        final message = Message(
          id: 'msg_001',
          content: '你好，请介绍一下人工智能',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        final expectedResponse = Message(
          id: 'msg_002',
          content: '人工智能（Artificial Intelligence，AI）是计算机科学的一个分支...',
          role: MessageRole.assistant,
          timestamp: DateTime.now(),
        );

        // 设置模拟行为
        when(mockService.sendMessage(any))
            .thenAnswer((_) async => expectedResponse);

        // 执行测试
        final response = await aiConversation.sendMessage(message);

        // 验证结果
        expect(response, isNotNull);
        expect(response!.id, equals('msg_002'));
        expect(response.role, equals(MessageRole.assistant));
        expect(response.content, isNotEmpty);

        // 验证方法调用
        verify(mockService.sendMessage(message)).called(1);
      });

      test('应该正确处理空消息', () async {
        final emptyMessage = Message(
          id: 'empty_001',
          content: '',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        // 设置模拟行为 - 空消息应该抛出异常
        when(mockService.sendMessage(any))
            .thenThrow(Exception('消息内容不能为空'));

        // 执行测试并验证异常
        expect(
          () => aiConversation.sendMessage(emptyMessage),
          throwsA(isA<Exception>()),
        );

        verify(mockService.sendMessage(emptyMessage)).called(1);
      });

      test('应该正确处理长消息', () async {
        final longMessage = Message(
          id: 'long_001',
          content: '这是一个很长的消息' * 1000, // 模拟超长消息
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        final truncatedResponse = Message(
          id: 'resp_001',
          content: '消息已收到，内容较长，正在处理中...',
          role: MessageRole.assistant,
          timestamp: DateTime.now(),
        );

        when(mockService.sendMessage(any))
            .thenAnswer((_) async => truncatedResponse);

        final response = await aiConversation.sendMessage(longMessage);

        expect(response, isNotNull);
        expect(response!.content, isNotEmpty);
        verify(mockService.sendMessage(any)).called(1);
      });
    });

    group('对话历史管理测试', () {
      test('应该正确保存和检索对话历史', () async {
        final messages = [
          Message(
            id: 'msg_001',
            content: '第一个问题',
            role: MessageRole.user,
            timestamp: DateTime.now(),
          ),
          Message(
            id: 'msg_002',
            content: '第一个回答',
            role: MessageRole.assistant,
            timestamp: DateTime.now(),
          ),
        ];

        when(mockService.getConversationHistory())
            .thenAnswer((_) async => messages);

        final history = await aiConversation.getConversationHistory();

        expect(history, isNotEmpty);
        expect(history.length, equals(2));
        expect(history[0].content, equals('第一个问题'));
        expect(history[1].content, equals('第一个回答'));

        verify(mockService.getConversationHistory()).called(1);
      });

      test('应该正确清空对话历史', () async {
        when(mockService.clearConversationHistory())
            .thenAnswer((_) async => true);

        final result = await aiConversation.clearConversationHistory();

        expect(result, isTrue);
        verify(mockService.clearConversationHistory()).called(1);
      });

      test('应该正确限制对话历史长度', () async {
        final oldMessages = List.generate(50, (index) => Message(
          id: 'msg_$index',
          content: '消息 $index',
          role: index % 2 == 0 ? MessageRole.user : MessageRole.assistant,
          timestamp: DateTime.now(),
        ));

        when(mockService.getConversationHistory())
            .thenAnswer((_) async => oldMessages);
        when(mockService.trimConversationHistory(any))
            .thenAnswer((_) async => true);

        await aiConversation.trimConversationHistory(maxLength: 20);

        verify(mockService.trimConversationHistory(20)).called(1);
      });
    });

    group('错误处理测试', () {
      test('应该正确处理网络异常', () async {
        final message = Message(
          id: 'msg_001',
          content: '测试网络异常',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        when(mockService.sendMessage(any))
            .thenThrow(Exception('网络连接失败'));

        expect(
          () => aiConversation.sendMessage(message),
          throwsA(isA<Exception>()),
        );

        verify(mockService.sendMessage(message)).called(1);
      });

      test('应该正确处理API限流', () async {
        final message = Message(
          id: 'msg_001',
          content: '测试API限流',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        when(mockService.sendMessage(any))
            .thenThrow(Exception('API调用频率过高，请稍后重试'));

        expect(
          () => aiConversation.sendMessage(message),
          throwsA(isA<Exception>()),
        );

        verify(mockService.sendMessage(message)).called(1);
      });

      test('应该正确处理认证失败', () async {
        final message = Message(
          id: 'msg_001',
          content: '测试认证失败',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        when(mockService.sendMessage(any))
            .thenThrow(Exception('认证失败，请检查API密钥'));

        expect(
          () => aiConversation.sendMessage(message),
          throwsA(isA<Exception>()),
        );

        verify(mockService.sendMessage(message)).called(1);
      });
    });

    group('性能测试', () {
      test('消息发送响应时间应该在合理范围内', () async {
        final message = Message(
          id: 'perf_001',
          content: '性能测试消息',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        );

        final response = Message(
          id: 'perf_resp_001',
          content: '性能测试响应',
          role: MessageRole.assistant,
          timestamp: DateTime.now(),
        );

        // 模拟网络延迟
        when(mockService.sendMessage(any))
            .thenAnswer((_) async {
          await TestUtils.simulateNetworkDelay();
          return response;
        });

        final executionTime = await PerformanceTestUtils.measureExecutionTime(
          () => aiConversation.sendMessage(message),
        );

        expect(executionTime.inMilliseconds, lessThan(TestConfig.performanceThresholds['apiResponseTime']!));
        verify(mockService.sendMessage(message)).called(1);
      });

      test('对话历史检索性能测试', () async {
        final largeHistory = List.generate(100, (index) => Message(
          id: 'msg_$index',
          content: '消息 $index',
          role: index % 2 == 0 ? MessageRole.user : MessageRole.assistant,
          timestamp: DateTime.now(),
        ));

        when(mockService.getConversationHistory())
            .thenAnswer((_) async => largeHistory);

        final executionTime = await PerformanceTestUtils.measureExecutionTime(
          () => aiConversation.getConversationHistory(),
        );

        expect(executionTime.inMilliseconds, lessThan(1000)); // 1秒内完成
        verify(mockService.getConversationHistory()).called(1);
      });
    });

    group('并发测试', () {
      test('应该正确处理并发消息发送', () async {
        final messages = List.generate(5, (index) => Message(
          id: 'concurrent_$index',
          content: '并发消息 $index',
          role: MessageRole.user,
          timestamp: DateTime.now(),
        ));

        final responses = List.generate(5, (index) => Message(
          id: 'resp_$index',
          content: '并发响应 $index',
          role: MessageRole.assistant,
          timestamp: DateTime.now(),
        ));

        when(mockService.sendMessage(any))
            .thenAnswer((invocation) async {
          final message = invocation.positionalArguments[0] as Message;
          final index = int.parse(message.id.split('_')[1]);
          return responses[index];
        });

        final futures = messages
            .map((message) => aiConversation.sendMessage(message))
            .toList();

        final results = await Future.wait(futures);

        expect(results.length, equals(5));
        for (int i = 0; i < results.length; i++) {
          expect(results[i], isNotNull);
          expect(results[i]!.id, equals('resp_$i'));
        }

        verify(mockService.sendMessage(any)).called(5);
      });
    });
  });
}