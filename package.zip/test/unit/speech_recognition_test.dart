import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import '../../lib/services/speech_recognition/speech_recognition_service.dart';
import '../../lib/services/speech_recognition/models/speech_models.dart';
import '../../lib/services/speech_recognition/providers/speech_provider.dart';
import '../../lib/services/audio_processing/audio_processing_service.dart';
import '../test_config.dart';

// 生成模拟类
@GenerateMocks([SpeechRecognitionService, SpeechProvider, AudioProcessingService])
import 'speech_recognition_test.mocks.dart';

void main() {
  group('语音识别模块测试', () {
    late SpeechRecognitionService speechService;
    late MockSpeechProvider mockProvider;
    late MockAudioProcessingService mockAudioProcessor;

    setUp(() {
      mockProvider = MockSpeechProvider();
      mockAudioProcessor = MockAudioProcessingService();
      speechService = SpeechRecognitionService(
        provider: mockProvider,
        audioProcessor: mockAudioProcessor,
      );
    });

    group('基本语音识别功能测试', () {
      test('应该成功识别语音文本', () async {
        // 准备测试音频数据
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        final expectedText = '你好，这是语音识别测试';
        final expectedResult = SpeechRecognitionResult(
          text: expectedText,
          confidence: 0.95,
          language: 'zh-CN',
          duration: const Duration(seconds: 3),
          timestamp: DateTime.now(),
        );

        // 设置模拟行为
        when(mockAudioProcessor.processAudio(any))
            .thenAnswer((_) async => audioData);
        when(mockProvider.recognizeSpeech(any))
            .thenAnswer((_) async => expectedResult);

        // 执行测试
        final result = await speechService.recognizeSpeech(audioData);

        // 验证结果
        expect(result, isNotNull);
        expect(result!.text, equals(expectedText));
        expect(result.confidence, greaterThan(0.9));
        expect(result.language, equals('zh-CN'));
        expect(result.duration, equals(const Duration(seconds: 3)));

        // 验证方法调用
        verify(mockAudioProcessor.processAudio(any)).called(1);
        verify(mockProvider.recognizeSpeech(any)).called(1);
      });

      test('应该正确处理空音频数据', () async {
        final emptyAudioData = AudioData(
          bytes: [],
          sampleRate: 16000,
          channels: 1,
        );

        when(mockAudioProcessor.processAudio(any))
            .thenThrow(Exception('音频数据为空'));

        // 执行测试并验证异常
        expect(
          () => speechService.recognizeSpeech(emptyAudioData),
          throwsA(isA<Exception>()),
        );

        verify(mockAudioProcessor.processAudio(emptyAudioData)).called(1);
      });

      test('应该正确处理音频质量检测', () async {
        final poorQualityAudio = AudioData(
          bytes: List.generate(16000, (index) => 0.1), // 低音量音频
          sampleRate: 16000,
          channels: 1,
        );

        final qualityResult = AudioQualityResult(
          snr: 5.0, // 低信噪比
          volume: 0.1,
          quality: AudioQuality.poor,
        );

        when(mockAudioProcessor.analyzeAudioQuality(any))
            .thenAnswer((_) async => qualityResult);

        final quality = await speechService.analyzeAudioQuality(poorQualityAudio);

        expect(quality, isNotNull);
        expect(quality.quality, equals(AudioQuality.poor));
        expect(quality.snr, lessThan(10.0));

        verify(mockAudioProcessor.analyzeAudioQuality(poorQualityAudio)).called(1);
      });

      test('应该正确处理多语言识别', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        final multiLanguageResult = SpeechRecognitionResult(
          text: 'Hello, 你好, こんにちは',
          confidence: 0.88,
          language: 'multi',
          detectedLanguages: ['en', 'zh-CN', 'ja'],
          duration: const Duration(seconds: 5),
          timestamp: DateTime.now(),
        );

        when(mockProvider.recognizeMultiLanguage(any))
            .thenAnswer((_) async => multiLanguageResult);

        final result = await speechService.recognizeMultiLanguage(audioData);

        expect(result, isNotNull);
        expect(result!.detectedLanguages, contains('zh-CN'));
        expect(result.detectedLanguages, hasLength(3));

        verify(mockProvider.recognizeMultiLanguage(audioData)).called(1);
      });
    });

    group('实时语音识别测试', () {
      test('应该正确处理实时语音流', () async {
        final audioStream = Stream.fromIterable([
          AudioData(
            bytes: List.generate(4000, (index) => (index % 256).toDouble()),
            sampleRate: 16000,
            channels: 1,
          ),
          AudioData(
            bytes: List.generate(4000, (index) => ((index + 4000) % 256).toDouble()),
            sampleRate: 16000,
            channels: 1,
          ),
        ]);

        final streamResults = [
          SpeechRecognitionResult(
            text: '第一部分语音',
            confidence: 0.92,
            language: 'zh-CN',
            duration: const Duration(seconds: 1),
            timestamp: DateTime.now(),
          ),
          SpeechRecognitionResult(
            text: '第二部分语音',
            confidence: 0.89,
            language: 'zh-CN',
            duration: const Duration(seconds: 1),
            timestamp: DateTime.now(),
          ),
        ];

        when(mockProvider.recognizeStream(any))
            .thenAnswer((_) async* {
          yield streamResults[0];
          yield streamResults[1];
        });

        final results = <SpeechRecognitionResult>[];
        await speechService.recognizeStream(audioStream).forEach(results.add);

        expect(results.length, equals(2));
        expect(results[0].text, equals('第一部分语音'));
        expect(results[1].text, equals('第二部分语音'));

        verify(mockProvider.recognizeStream(any)).called(1);
      });

      test('应该正确处理实时识别的语音活动检测', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        final vadResult = VoiceActivityResult(
          hasSpeech: true,
          speechStart: const Duration(seconds: 0),
          speechEnd: const Duration(seconds: 3),
          confidence: 0.95,
        );

        when(mockAudioProcessor.detectVoiceActivity(any))
            .thenAnswer((_) async => vadResult);

        final result = await speechService.detectVoiceActivity(audioData);

        expect(result, isNotNull);
        expect(result.hasSpeech, isTrue);
        expect(result.speechStart, equals(const Duration(seconds: 0)));
        expect(result.confidence, greaterThan(0.9));

        verify(mockAudioProcessor.detectVoiceActivity(audioData)).called(1);
      });
    });

    group('错误处理测试', () {
      test('应该正确处理麦克风权限拒绝', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        when(mockAudioProcessor.processAudio(any))
            .thenThrow(Exception('麦克风权限被拒绝'));

        expect(
          () => speechService.recognizeSpeech(audioData),
          throwsA(isA<Exception>()),
        );

        verify(mockAudioProcessor.processAudio(audioData)).called(1);
      });

      test('应该正确处理音频格式不支持', () async {
        final unsupportedAudio = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 8000, // 不支持的采样率
          channels: 3, // 不支持的通道数
        );

        when(mockAudioProcessor.processAudio(any))
            .thenThrow(Exception('不支持的音频格式'));

        expect(
          () => speechService.recognizeSpeech(unsupportedAudio),
          throwsA(isA<Exception>()),
        );

        verify(mockAudioProcessor.processAudio(unsupportedAudio)).called(1);
      });

      test('应该正确处理网络异常', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        when(mockProvider.recognizeSpeech(any))
            .thenThrow(Exception('网络连接失败'));

        expect(
          () => speechService.recognizeSpeech(audioData),
          throwsA(isA<Exception>()),
        );

        verify(mockProvider.recognizeSpeech(audioData)).called(1);
      });

      test('应该正确处理API配额超限', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        when(mockProvider.recognizeSpeech(any))
            .thenThrow(Exception('API配额已用完'));

        expect(
          () => speechService.recognizeSpeech(audioData),
          throwsA(isA<Exception>()),
        );

        verify(mockProvider.recognizeSpeech(audioData)).called(1);
      });
    });

    group('性能测试', () {
      test('语音识别响应时间应该在合理范围内', () async {
        final audioData = AudioData(
          bytes: List.generate(16000, (index) => (index % 256).toDouble()),
          sampleRate: 16000,
          channels: 1,
        );

        final expectedResult = SpeechRecognitionResult(
          text: '性能测试文本',
          confidence: 0.95,
          language: 'zh-CN',
          duration: const Duration(seconds: 2),
          timestamp: DateTime.now(),
        );

        when(mockAudioProcessor.processAudio(any))
            .thenAnswer((_) async => audioData);
        when(mockProvider.recognizeSpeech(any))
            .thenAnswer((_) async {
          await TestUtils.simulateNetworkDelay();
          return expectedResult;
        });

        final executionTime = await PerformanceTestUtils.measureExecutionTime(
          () => speechService.recognizeSpeech(audioData),
        );

        expect(executionTime.inMilliseconds, 
               lessThan(TestConfig.performanceThresholds['speechRecognitionTime']!));
        
        verify(mockAudioProcessor.processAudio(audioData)).called(1);
        verify(mockProvider.recognizeSpeech(audioData)).called(1);
      });

      test('音频处理内存使用测试', () async {
        final largeAudioData = AudioData(
          bytes: List.generate(1600000, (index) => (index % 256).toDouble()), // 1MB音频数据
          sampleRate: 16000,
          channels: 1,
        );

        final expectedResult = SpeechRecognitionResult(
          text: '大文件测试',
          confidence: 0.90,
          language: 'zh-CN',
          duration: const Duration(seconds: 100),
          timestamp: DateTime.now(),
        );

        when(mockAudioProcessor.processAudio(any))
            .thenAnswer((_) async => largeAudioData);
        when(mockProvider.recognizeSpeech(any))
            .thenAnswer((_) async => expectedResult);

        final memoryUsage = await PerformanceTestUtils.measureMemoryUsage(
          () => speechService.recognizeSpeech(largeAudioData),
        );

        // 内存使用应该在合理范围内（小于100MB）
        expect(memoryUsage, lessThan(100 * 1024 * 1024));

        verify(mockAudioProcessor.processAudio(largeAudioData)).called(1);
        verify(mockProvider.recognizeSpeech(largeAudioData)).called(1);
      });
    });

    group('配置测试', () {
      test('应该正确应用语音识别配置', () async {
        final config = SpeechRecognitionConfig(
          language: 'en-US',
          sampleRate: 16000,
          maxAlternatives: 3,
          enablePunctuation: true,
          enableWordTimeOffsets: true,
        );

        speechService.updateConfig(config);

        expect(speechService.config.language, equals('en-US'));
        expect(speechService.config.maxAlternatives, equals(3));
        expect(speechService.config.enablePunctuation, isTrue);
      });

      test('应该正确验证配置参数', () async {
        expect(
          () => speechService.updateConfig(SpeechRecognitionConfig(
            language: '', // 无效语言
            sampleRate: 0, // 无效采样率
          )),
          throwsA(isA<Exception>()),
        );
      });
    });
  });
}