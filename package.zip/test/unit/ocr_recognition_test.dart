import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import '../../lib/services/ocr_recognition/ocr_manager.dart';
import '../../lib/services/ocr_recognition/models/ocr_models.dart';
import '../../lib/services/ocr_recognition/providers/ocr_provider.dart';
import '../../lib/services/image_preprocessing/image_preprocessing_service.dart';
import '../test_config.dart';

// 生成模拟类
@GenerateMocks([OcrManager, OcrProvider, ImagePreprocessingService])
import 'ocr_recognition_test.mocks.dart';

void main() {
  group('OCR识别模块测试', () {
    late OcrManager ocrManager;
    late MockOcrProvider mockProvider;
    late MockImagePreprocessingService mockPreprocessor;

    setUp(() {
      mockProvider = MockOcrProvider();
      mockPreprocessor = MockImagePreprocessingService();
      ocrManager = OcrManager(
        provider: mockProvider,
        preprocessor: mockPreprocessor,
      );
    });

    group('基本OCR识别功能测试', () {
      test('应该成功识别图片中的文字', () async {
        // 准备测试图片数据
        final imageData = ImageData(
          bytes: List.generate(10000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        );

        final expectedOcrResult = OcrResult(
          text: 'Hello World 你好世界',
          confidence: 0.95,
          boundingBoxes: [
            BoundingBox(
              x: 100,
              y: 100,
              width: 200,
              height: 50,
              text: 'Hello World',
              confidence: 0.96,
            ),
            BoundingBox(
              x: 100,
              y: 160,
              width: 200,
              height: 50,
              text: '你好世界',
              confidence: 0.94,
            ),
          ],
          language: 'zh-CN',
          processingTime: const Duration(milliseconds: 1500),
          timestamp: DateTime.now(),
        );

        // 设置模拟行为
        when(mockPreprocessor.preprocessImage(any))
            .thenAnswer((_) async => imageData);
        when(mockProvider.recognizeText(any))
            .thenAnswer((_) async => expectedOcrResult);

        // 执行测试
        final result = await ocrManager.recognizeText(imageData);

        // 验证结果
        expect(result, isNotNull);
        expect(result!.text, equals('Hello World 你好世界'));
        expect(result.confidence, greaterThan(0.9));
        expect(result.boundingBoxes, hasLength(2));
        expect(result.language, equals('zh-CN'));
        expect(result.processingTime, lessThan(const Duration(seconds: 3)));

        // 验证方法调用
        verify(mockPreprocessor.preprocessImage(imageData)).called(1);
        verify(mockProvider.recognizeText(imageData)).called(1);
      });

      test('应该正确处理空图片数据', () async {
        final emptyImageData = ImageData(
          bytes: [],
          width: 0,
          height: 0,
          format: 'jpeg',
        );

        when(mockPreprocessor.preprocessImage(any))
            .thenThrow(Exception('图片数据为空'));

        // 执行测试并验证异常
        expect(
          () => ocrManager.recognizeText(emptyImageData),
          throwsA(isA<Exception>()),
        );

        verify(mockPreprocessor.preprocessImage(emptyImageData)).called(1);
      });

      test('应该正确处理图片质量分析', () async {
        final lowQualityImage = ImageData(
          bytes: List.generate(10000, (index) => (index % 256).toDouble()),
          width: 640,
          height: 480,
          format: 'jpeg',
        );

        final qualityResult = ImageQualityResult(
          quality: ImageQuality.poor,
          blur: 0.8,
          brightness: 0.3,
          contrast: 0.4,
          recommendations: ['建议提高图片分辨率', '建议增强对比度'],
        );

        when(mockPreprocessor.analyzeImageQuality(any))
            .thenAnswer((_) async => qualityResult);

        final result = await ocrManager.analyzeImageQuality(lowQualityImage);

        expect(result, isNotNull);
        expect(result.quality, equals(ImageQuality.poor));
        expect(result.blur, greaterThan(0.5));
        expect(result.recommendations, isNotEmpty);

        verify(mockPreprocessor.analyzeImageQuality(lowQualityImage)).called(1);
      });

      test('应该正确处理多语言OCR识别', () async {
        final multilingualImage = ImageData(
          bytes: List.generate(15000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'png',
        );

        final multilingualResult = OcrResult(
          text: 'Hello 你好 こんにちは',
          confidence: 0.88,
          detectedLanguages: ['en', 'zh-CN', 'ja'],
          boundingBoxes: [
            BoundingBox(
              x: 100,
              y: 100,
              width: 150,
              height: 40,
              text: 'Hello',
              confidence: 0.95,
            ),
            BoundingBox(
              x: 260,
              y: 100,
              width: 100,
              height: 40,
              text: '你好',
              confidence: 0.90,
            ),
            BoundingBox(
              x: 370,
              y: 100,
              width: 120,
              height: 40,
              text: 'こんにちは',
              confidence: 0.85,
            ),
          ],
          language: 'multi',
          processingTime: const Duration(seconds: 2),
          timestamp: DateTime.now(),
        );

        when(mockProvider.recognizeMultilingual(any))
            .thenAnswer((_) async => multilingualResult);

        final result = await ocrManager.recognizeMultilingual(multilingualImage);

        expect(result, isNotNull);
        expect(result.detectedLanguages, contains('zh-CN'));
        expect(result.detectedLanguages, hasLength(3));
        expect(result.boundingBoxes, hasLength(3));

        verify(mockProvider.recognizeMultilingual(multilingualImage)).called(1);
      });
    });

    group('批量OCR识别测试', () {
      test('应该正确处理批量图片识别', () async {
        final images = List.generate(5, (index) => ImageData(
          bytes: List.generate(10000, (i) => (i % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        ));

        final batchResults = List.generate(5, (index) => OcrResult(
          text: '批量识别结果 $index',
          confidence: 0.90 + index * 0.01,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: Duration(milliseconds: 1000 + index * 100),
          timestamp: DateTime.now(),
        ));

        when(mockProvider.recognizeBatch(any))
            .thenAnswer((_) async => batchResults);

        final results = await ocrManager.recognizeBatch(images);

        expect(results, hasLength(5));
        for (int i = 0; i < results.length; i++) {
          expect(results[i], isNotNull);
          expect(results[i]!.text, equals('批量识别结果 $i'));
        }

        verify(mockProvider.recognizeBatch(images)).called(1);
      });

      test('应该正确处理批量识别的错误恢复', () async {
        final images = List.generate(3, (index) => ImageData(
          bytes: List.generate(10000, (i) => (i % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        ));

        final partialResults = [
          OcrResult(
            text: '成功识别 1',
            confidence: 0.95,
            boundingBoxes: [],
            language: 'zh-CN',
            processingTime: const Duration(milliseconds: 1000),
            timestamp: DateTime.now(),
          ),
          null, // 第二张图片识别失败
          OcrResult(
            text: '成功识别 3',
            confidence: 0.88,
            boundingBoxes: [],
            language: 'zh-CN',
            processingTime: const Duration(milliseconds: 1200),
            timestamp: DateTime.now(),
          ),
        ];

        when(mockProvider.recognizeBatch(any))
            .thenAnswer((_) async => partialResults);

        final results = await ocrManager.recognizeBatchWithErrorRecovery(images);

        expect(results, hasLength(3));
        expect(results[0], isNotNull);
        expect(results[1], isNull); // 第二张图片失败
        expect(results[2], isNotNull);

        verify(mockProvider.recognizeBatch(images)).called(1);
      });
    });

    group('高级OCR功能测试', () {
      test('应该正确处理表格识别', () async {
        final tableImage = ImageData(
          bytes: List.generate(20000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'png',
        );

        final tableResult = TableOcrResult(
          text: '姓名\\t年龄\\t城市\\n张三\\t25\\t北京\\n李四\\t30\\t上海',
          confidence: 0.92,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: const Duration(seconds: 2),
          timestamp: DateTime.now(),
          tables: [
            TableStructure(
              rows: 3,
              columns: 3,
              cells: [
                TableCell(row: 0, column: 0, text: '姓名', confidence: 0.95),
                TableCell(row: 0, column: 1, text: '年龄', confidence: 0.94),
                TableCell(row: 0, column: 2, text: '城市', confidence: 0.93),
                TableCell(row: 1, column: 0, text: '张三', confidence: 0.92),
                TableCell(row: 1, column: 1, text: '25', confidence: 0.96),
                TableCell(row: 1, column: 2, text: '北京', confidence: 0.91),
              ],
            ),
          ],
        );

        when(mockProvider.recognizeTable(any))
            .thenAnswer((_) async => tableResult);

        final result = await ocrManager.recognizeTable(tableImage);

        expect(result, isNotNull);
        expect(result.tables, hasLength(1));
        expect(result.tables[0].rows, equals(3));
        expect(result.tables[0].columns, equals(3));
        expect(result.text, contains('姓名'));
        expect(result.text, contains('张三'));

        verify(mockProvider.recognizeTable(tableImage)).called(1);
      });

      test('应该正确处理手写文字识别', () async {
        final handwrittenImage = ImageData(
          bytes: List.generate(15000, (index) => (index % 256).toDouble()),
          width: 1024,
          height: 768,
          format: 'png',
        );

        final handwrittenResult = HandwritingOcrResult(
          text: '这是手写文字识别测试',
          confidence: 0.85,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: const Duration(seconds: 3),
          timestamp: DateTime.now(),
          handwritingConfidence: 0.88,
          strokeData: [
            StrokeData(points: [Point(x: 100, y: 100), Point(x: 150, y: 120)]),
          ],
        );

        when(mockProvider.recognizeHandwriting(any))
            .thenAnswer((_) async => handwrittenResult);

        final result = await ocrManager.recognizeHandwriting(handwrittenImage);

        expect(result, isNotNull);
        expect(result.text, equals('这是手写文字识别测试'));
        expect(result.handwritingConfidence, greaterThan(0.8));
        expect(result.strokeData, isNotEmpty);

        verify(mockProvider.recognizeHandwriting(handwrittenImage)).called(1);
      });
    });

    group('错误处理测试', () {
      test('应该正确处理不支持的图片格式', () async {
        final unsupportedImage = ImageData(
          bytes: List.generate(10000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'gif', // 不支持的格式
        );

        when(mockPreprocessor.preprocessImage(any))
            .thenThrow(Exception('不支持的图片格式'));

        expect(
          () => ocrManager.recognizeText(unsupportedImage),
          throwsA(isA<Exception>()),
        );

        verify(mockPreprocessor.preprocessImage(unsupportedImage)).called(1);
      });

      test('应该正确处理图片分辨率过低', () async {
        final lowResImage = ImageData(
          bytes: List.generate(1000, (index) => (index % 256).toDouble()),
          width: 100,
          height: 100,
          format: 'jpeg',
        );

        when(mockPreprocessor.analyzeImageQuality(any))
            .thenAnswer((_) async => ImageQualityResult(
                  quality: ImageQuality.poor,
                  blur: 0.9,
                  brightness: 0.2,
                  contrast: 0.3,
                  recommendations: ['图片分辨率过低'],
                ));

        final quality = await ocrManager.analyzeImageQuality(lowResImage);

        expect(quality.quality, equals(ImageQuality.poor));
        expect(quality.recommendations, contains('图片分辨率过低'));
      });

      test('应该正确处理网络超时', () async {
        final imageData = ImageData(
          bytes: List.generate(10000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        );

        when(mockProvider.recognizeText(any))
            .thenThrow(Exception('网络请求超时'));

        expect(
          () => ocrManager.recognizeText(imageData),
          throwsA(isA<Exception>()),
        );

        verify(mockProvider.recognizeText(imageData)).called(1);
      });

      test('应该正确处理API配额超限', () async {
        final imageData = ImageData(
          bytes: List.generate(10000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        );

        when(mockProvider.recognizeText(any))
            .thenThrow(Exception('API调用次数已超限'));

        expect(
          () => ocrManager.recognizeText(imageData),
          throwsA(isA<Exception>()),
        );

        verify(mockProvider.recognizeText(imageData)).called(1);
      });
    });

    group('性能测试', () {
      test('OCR识别响应时间应该在合理范围内', () async {
        final imageData = ImageData(
          bytes: List.generate(15000, (index) => (index % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        );

        final expectedResult = OcrResult(
          text: '性能测试文本',
          confidence: 0.95,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: const Duration(seconds: 2),
          timestamp: DateTime.now(),
        );

        when(mockPreprocessor.preprocessImage(any))
            .thenAnswer((_) async => imageData);
        when(mockProvider.recognizeText(any))
            .thenAnswer((_) async {
          await TestUtils.simulateNetworkDelay();
          return expectedResult;
        });

        final executionTime = await PerformanceTestUtils.measureExecutionTime(
          () => ocrManager.recognizeText(imageData),
        );

        expect(executionTime.inMilliseconds, 
               lessThan(TestConfig.performanceThresholds['ocrProcessingTime']!));

        verify(mockPreprocessor.preprocessImage(imageData)).called(1);
        verify(mockProvider.recognizeText(imageData)).called(1);
      });

      test('大图片处理内存使用测试', () async {
        final largeImageData = ImageData(
          bytes: List.generate(5000000, (index) => (index % 256).toDouble()), // 5MB图片
          width: 4096,
          height: 3072,
          format: 'jpeg',
        );

        final expectedResult = OcrResult(
          text: '大图片测试',
          confidence: 0.90,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: const Duration(seconds: 5),
          timestamp: DateTime.now(),
        );

        when(mockPreprocessor.preprocessImage(any))
            .thenAnswer((_) async => largeImageData);
        when(mockProvider.recognizeText(any))
            .thenAnswer((_) async => expectedResult);

        final memoryUsage = await PerformanceTestUtils.measureMemoryUsage(
          () => ocrManager.recognizeText(largeImageData),
        );

        // 内存使用应该在合理范围内（小于200MB）
        expect(memoryUsage, lessThan(200 * 1024 * 1024));

        verify(mockPreprocessor.preprocessImage(largeImageData)).called(1);
        verify(mockProvider.recognizeText(largeImageData)).called(1);
      });

      test('批量处理性能测试', () async {
        final images = List.generate(10, (index) => ImageData(
          bytes: List.generate(10000, (i) => (i % 256).toDouble()),
          width: 1920,
          height: 1080,
          format: 'jpeg',
        ));

        final batchResults = List.generate(10, (index) => OcrResult(
          text: '批量测试 $index',
          confidence: 0.90,
          boundingBoxes: [],
          language: 'zh-CN',
          processingTime: Duration(milliseconds: 1000),
          timestamp: DateTime.now(),
        ));

        when(mockProvider.recognizeBatch(any))
            .thenAnswer((_) async => batchResults);

        final executionTime = await PerformanceTestUtils.measureExecutionTime(
          () => ocrManager.recognizeBatch(images),
        );

        // 批量处理应该在合理时间内完成
        expect(executionTime.inMilliseconds, lessThan(15000)); // 15秒内

        verify(mockProvider.recognizeBatch(images)).called(1);
      });
    });

    group('配置测试', () {
      test('应该正确应用OCR配置', () async {
        final config = OcrConfig(
          language: 'en',
          confidenceThreshold: 0.8,
          enableTableDetection: true,
          enableHandwritingRecognition: false,
          maxImageSize: Size(2048, 2048),
        );

        ocrManager.updateConfig(config);

        expect(ocrManager.config.language, equals('en'));
        expect(ocrManager.config.confidenceThreshold, equals(0.8));
        expect(ocrManager.config.enableTableDetection, isTrue);
        expect(ocrManager.config.enableHandwritingRecognition, isFalse);
      });

      test('应该正确验证配置参数', () async {
        expect(
          () => ocrManager.updateConfig(OcrConfig(
            language: '', // 无效语言
            confidenceThreshold: 1.5, // 超出范围
          )),
          throwsA(isA<Exception>()),
        );
      });
    });
  });
}