import 'dart:io';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

/// 测试工具类
class TestHelpers {
  /// 生成随机文本
  static String generateRandomText({int minLength = 10, int maxLength = 100}) {
    final random = Random();
    final length = random.nextInt(maxLength - minLength) + minLength;
    
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return String.fromCharCodes(
      Iterable.generate(length, (_) => chars.codeUnitAt(random.nextInt(chars.length))),
    );
  }

  /// 生成随机数字
  static int generateRandomNumber({int min = 0, int max = 1000}) {
    return Random().nextInt(max - min) + min;
  }

  /// 生成随机布尔值
  static bool generateRandomBool() {
    return Random().nextBool();
  }

  /// 生成测试图片数据
  static List<int> generateTestImageData({int width = 1920, int height = 1080}) {
    final size = width * height * 3; // RGB
    return List.generate(size, (index) => Random().nextInt(256));
  }

  /// 生成测试音频数据
  static List<double> generateTestAudioData({
    int sampleRate = 16000,
    Duration duration = const Duration(seconds: 2),
  }) {
    final sampleCount = (sampleRate * duration.inSeconds).round();
    return List.generate(sampleCount, (index) => 
        sin(2 * pi * 440 * index / sampleRate) * 0.1); // 440Hz正弦波
  }

  /// 创建测试消息
  static Map<String, dynamic> createTestMessage({
    String? id,
    String? content,
    String? role,
    DateTime? timestamp,
  }) {
    return {
      'id': id ?? 'test_msg_${generateRandomNumber()}',
      'content': content ?? generateRandomText(),
      'role': role ?? 'user',
      'timestamp': (timestamp ?? DateTime.now()).toIso8601String(),
    };
  }

  /// 创建测试用户
  static Map<String, dynamic> createTestUser({
    String? id,
    String? name,
    String? email,
    Map<String, dynamic>? preferences,
  }) {
    return {
      'id': id ?? 'test_user_${generateRandomNumber()}',
      'name': name ?? 'Test User',
      'email': email ?? 'test@example.com',
      'preferences': preferences ?? {
        'language': 'zh-CN',
        'theme': 'dark',
        'notifications': true,
      },
    };
  }

  /// 模拟网络延迟
  static Future<void> simulateNetworkDelay({
    Duration min = const Duration(milliseconds: 100),
    Duration max = const Duration(milliseconds: 1000),
  }) async {
    final delay = Duration(
      milliseconds: min.inMilliseconds + 
          Random().nextInt(max.inMilliseconds - min.inMilliseconds),
    );
    await Future.delayed(delay);
  }

  /// 模拟文件上传
  static Future<Map<String, dynamic>> simulateFileUpload({
    String fileType = 'image',
    int fileSize = 1024 * 1024, // 1MB
  }) async {
    await simulateNetworkDelay();
    
    return {
      'success': true,
      'fileId': 'uploaded_file_${generateRandomNumber()}',
      'fileSize': fileSize,
      'fileType': fileType,
      'uploadTime': DateTime.now().toIso8601String(),
    };
  }

  /// 验证Widget存在
  static Finder findWidget(WidgetTester tester, Type widgetType) {
    return find.byType(widgetType);
  }

  /// 验证Widget文本内容
  static Finder findText(WidgetTester tester, String text) {
    return find.text(text);
  }

  /// 验证Widget Key
  static Finder findKey(WidgetTester tester, String keyValue) {
    return find.byKey(Key(keyValue));
  }

  /// 等待Widget出现
  static Future<Finder> waitForWidget(
    WidgetTester tester,
    Finder finder, {
    Duration timeout = const Duration(seconds: 10),
  }) async {
    await tester.waitFor(finder, timeout: timeout);
    return finder;
  }

  /// 等待Widget消失
  static Future<Finder> waitForWidgetToDisappear(
    WidgetTester tester,
    Finder finder, {
    Duration timeout = const Duration(seconds: 10),
  }) async {
    await tester.waitFor(
      () => tester.binding.defaultTestMode ? true : !finder.evaluate().isEmpty,
      timeout: timeout,
    );
    return finder;
  }

  /// 模拟滑动手势
  static Future<void> simulateSwipe(
    WidgetTester tester,
    Finder finder,
    Offset start,
    Offset end, {
    Duration duration = const Duration(milliseconds: 300),
  }) async {
    await tester.fling(finder, end - start, 1000);
    await tester.pumpAndSettle(duration);
  }

  /// 模拟点击操作
  static Future<void> simulateTap(
    WidgetTester tester,
    Finder finder,
  ) async {
    await tester.tap(finder);
    await tester.pumpAndSettle();
  }

  /// 模拟输入操作
  static Future<void> simulateInput(
    WidgetTester tester,
    Finder finder,
    String text,
  ) async {
    await tester.tap(finder);
    await tester.enterText(finder, text);
    await tester.pumpAndSettle();
  }

  /// 模拟滚动操作
  static Future<void> simulateScroll(
    WidgetTester tester,
    Finder finder,
    double delta,
  ) async {
    await tester.scrollUntilVisible(finder, delta);
    await tester.pumpAndSettle();
  }

  /// 验证UI状态
  static void verifyUIState(
    WidgetTester tester,
    String description, {
    required bool condition,
    String? expectedText,
    Type? expectedWidget,
  }) {
    if (condition) {
      expect(true, true); // 状态正确
      debugPrint('✅ $description');
    } else {
      if (expectedText != null) {
        expect(find.text(expectedText), findsOneWidget);
      }
      if (expectedWidget != null) {
        expect(find.byType(expectedWidget), findsOneWidget);
      }
      debugPrint('❌ $description - 状态验证失败');
    }
  }

  /// 验证数据格式
  static bool validateApiResponse(Map<String, dynamic> response) {
    return response.containsKey('status') &&
           response.containsKey('data') &&
           response.containsKey('timestamp');
  }

  /// 验证JSON格式
  static bool validateJsonFormat(String jsonString) {
    try {
      json.decode(jsonString);
      return true;
    } catch (e) {
      return false;
    }
  }

  /// 验证文件格式
  static bool validateFileFormat(String fileName, List<String> allowedFormats) {
    final extension = fileName.split('.').last.toLowerCase();
    return allowedFormats.contains(extension);
  }

  /// 验证图片格式
  static bool isValidImageFormat(String format) {
    const imageFormats = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    return imageFormats.contains(format.toLowerCase());
  }

  /// 验证音频格式
  static bool isValidAudioFormat(String format) {
    const audioFormats = ['mp3', 'wav', 'aac', 'flac', 'ogg', 'm4a'];
    return audioFormats.contains(format.toLowerCase());
  }

  /// 清理测试数据
  static Future<void> cleanupTestData() async {
    // 清理临时文件
    final tempDir = Directory.systemTemp;
    if (await tempDir.exists()) {
      await for (final entity in tempDir.list()) {
        if (entity.path.contains('test_') && 
            DateTime.now().difference(entity.statSync().modified).inHours > 1) {
          try {
            await entity.delete();
          } catch (e) {
            // 忽略删除失败
          }
        }
      }
    }
  }

  /// 记录测试结果
  static void logTestResult(String testName, bool passed, String message) {
    final timestamp = DateTime.now().toIso8601String();
    final status = passed ? 'PASS' : 'FAIL';
    debugPrint('[$timestamp] $testName: $status - $message');
  }

  /// 创建测试报告数据
  static Map<String, dynamic> createTestReportData({
    required String testName,
    required bool passed,
    Duration? duration,
    String? errorMessage,
    Map<String, dynamic>? metadata,
  }) {
    return {
      'testName': testName,
      'passed': passed,
      'timestamp': DateTime.now().toIso8601String(),
      'duration': duration?.inMilliseconds ?? 0,
      'errorMessage': errorMessage,
      'metadata': metadata ?? {},
    };
  }
}

/// 测试数据生成器
class TestDataGenerator {
  static const List<String> sampleTexts = [
    '你好，欢迎使用AI助手！',
    '这是一个测试消息。',
    '请帮我识别这段文字。',
    '语音识别功能测试。',
    'OCR文字识别测试。',
    '网络连接测试。',
    '权限验证测试。',
    '性能测试数据。',
    '压力测试内容。',
    '集成测试场景。',
  ];

  static const List<String> sampleEmails = [
    'test@example.com',
    'user@test.com',
    'demo@domain.com',
    'admin@system.com',
  ];

  static const List<String> sampleNames = [
    '张三',
    '李四',
    '王五',
    '赵六',
    'John Doe',
    'Jane Smith',
    'Test User',
  ];

  /// 生成样本文本
  static String getRandomSampleText() {
    return sampleTexts[Random().nextInt(sampleTexts.length)];
  }

  /// 生成样本邮箱
  static String getRandomSampleEmail() {
    return sampleEmails[Random().nextInt(sampleEmails.length)];
  }

  /// 生成样本姓名
  static String getRandomSampleName() {
    return sampleNames[Random().nextInt(sampleNames.length)];
  }

  /// 生成样本JSON数据
  static Map<String, dynamic> generateSampleJson({
    int depth = 1,
    int maxDepth = 3,
  }) {
    if (depth > maxDepth) {
      return {'value': getRandomSampleText()};
    }

    final data = <String, dynamic>{
      'id': 'item_${generateRandomNumber()}',
      'name': getRandomSampleName(),
      'email': getRandomSampleEmail(),
      'active': generateRandomBool(),
      'score': generateRandomNumber(),
    };

    if (depth < maxDepth) {
      data['nested'] = generateSampleJson(depth: depth + 1, maxDepth: maxDepth);
    }

    return data;
  }

  /// 生成样本配置
  static Map<String, dynamic> generateSampleConfig() {
    return {
      'appName': 'AI助手测试',
      'version': '1.0.0-test',
      'debug': true,
      'apiEndpoint': 'https://api.test.example.com',
      'timeout': 30000,
      'retryCount': 3,
      'features': {
        'aiChat': true,
        'speechRecognition': true,
        'ocrRecognition': true,
        'imageProcessing': false,
      },
      'ui': {
        'theme': 'dark',
        'language': 'zh-CN',
        'animations': true,
      },
    };
  }
}

/// 模拟服务类
class MockServices {
  static const MethodChannel mockChannel = MethodChannel('mock_services');

  static void setupMockChannel() {
    mockChannel.setMockMethodCallHandler((call) async {
      switch (call.method) {
        case 'simulateNetworkRequest':
          final delay = call.arguments['delay'] ?? 1000;
          await Future.delayed(Duration(milliseconds: delay));
          return {
            'success': true,
            'data': {'message': 'Mock response'},
          };
        
        case 'simulateFileUpload':
          final fileName = call.arguments['fileName'] ?? 'test.txt';
          return {
            'success': true,
            'fileId': 'mock_file_${generateRandomNumber()}',
            'fileName': fileName,
          };
        
        case 'simulatePermissionRequest':
          final permission = call.arguments['permission'];
          return {
            'granted': generateRandomBool(),
            'permission': permission,
          };
        
        default:
          return {'success': false, 'error': 'Unknown method'};
      }
    });
  }

  static void clearMockChannel() {
    mockChannel.setMockMethodCallHandler(null);
  }
}

/// 性能测试工具
class PerformanceTestUtils {
  /// 测量函数执行时间
  static Future<Duration> measureExecutionTime(
    Future<void> Function() action,
  ) async {
    final stopwatch = Stopwatch()..start();
    await action();
    stopwatch.stop();
    return stopwatch.elapsed;
  }

  /// 测量内存使用
  static Future<int> measureMemoryUsage(
    Future<void> Function() action,
  ) async {
    // 这里应该使用平台特定的内存监控API
    // 简化实现
    final startMemory = ProcessInfo.currentRss;
    await action();
    final endMemory = ProcessInfo.currentRss;
    return endMemory - startMemory;
  }

  /// 执行压力测试
  static Future<Map<String, dynamic>> performStressTest({
    required Future<void> Function() testAction,
    int iterations = 100,
    Duration delayBetweenRuns = const Duration(milliseconds: 100),
  }) async {
    final results = <String, dynamic>{
      'totalIterations': iterations,
      'successfulRuns': 0,
      'failedRuns': 0,
      'totalTime': Duration.zero,
      'averageTime': Duration.zero,
      'errors': <String>[],
    };

    final stopwatch = Stopwatch()..start();

    for (int i = 0; i < iterations; i++) {
      try {
        final startTime = DateTime.now();
        await testAction();
        final endTime = DateTime.now();
        
        results['successfulRuns']++;
        results['totalTime'] = results['totalTime'] + endTime.difference(startTime);
        
        if (i < iterations - 1) {
          await Future.delayed(delayBetweenRuns);
        }
      } catch (e) {
        results['failedRuns']++;
        results['errors'].add('Iteration $i: $e');
      }
    }

    stopwatch.stop();
    results['averageTime'] = Duration(
      microseconds: results['totalTime'].inMicroseconds ~/ iterations,
    );

    return results;
  }
}

/// 测试环境配置
class TestEnvironmentConfig {
  static bool _initialized = false;

  static Future<void> initialize() async {
    if (_initialized) return;

    try {
      // 设置测试配置
      TestWidgetsFlutterBinding.ensureInitialized();

      // 模拟平台环境
      _setupPlatformEnvironment();

      // 设置测试数据
      _setupTestData();

      // 配置日志级别
      _configureLogging();

      _initialized = true;
      debugPrint('✅ 测试环境配置完成');
    } catch (e) {
      debugPrint('❌ 测试环境配置失败: $e');
      rethrow;
    }
  }

  static void _setupPlatformEnvironment() {
    // 模拟iOS环境
    debugPrint('📱 设置iOS测试环境');
    
    // 模拟Android环境
    debugPrint('🤖 设置Android测试环境');
    
    // 模拟网络环境
    debugPrint('🌐 设置网络测试环境');
  }

  static void _setupTestData() {
    debugPrint('📋 设置测试数据');
    
    // 创建测试目录
    final testDir = Directory('test_data');
    if (!testDir.existsSync()) {
      testDir.createSync();
    }
  }

  static void _configureLogging() {
    debugPrint('📝 配置日志级别');
    
    // 可以在这里配置特定的日志级别
  }

  static void dispose() {
    _initialized = false;
    debugPrint('🧹 清理测试环境');
  }
}