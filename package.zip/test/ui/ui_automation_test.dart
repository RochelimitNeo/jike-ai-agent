import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../lib/main.dart';
import '../../lib/screens/home_screen.dart';
import '../../lib/screens/splash_screen.dart';
import '../../lib/widgets/agent_card.dart';
import '../../lib/widgets/custom_app_bar.dart';
import '../../lib/widgets/loading_indicator.dart';
import '../test_config.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('UI自动化测试', () {
    setUp(() async {
      // 测试前设置
      TestWidgetsFlutterBinding.ensureInitialized();
      await _setupTestEnvironment();
    });

    group('界面渲染测试', () {
      testWidgets('启动页面渲染测试', (tester) async {
        // 启动应用
        await tester.pumpWidget(MyApp());

        // 验证启动页面渲染
        expect(find.byType(SplashScreen), findsOneWidget);
        expect(find.byType(LoadingIndicator), findsOneWidget);
        expect(find.byKey(const Key('app_logo')), findsOneWidget);

        // 验证启动动画
        final logo = tester.widget<AnimatedContainer>(find.byKey(const Key('app_logo')));
        expect(logo.duration, isNotNull);
      });

      testWidgets('主页面布局测试', (tester) async {
        // 模拟启动完成
        await _simulateAppStart(tester);
        await tester.pumpAndSettle();

        // 验证主页面组件
        expect(find.byType(CustomAppBar), findsOneWidget);
        expect(find.byType(AgentCard), findsAtLeastNWidgets(1));
        expect(find.byKey(const Key('quick_actions')), findsOneWidget);
        expect(find.byKey(const Key('bottom_navigation')), findsOneWidget);

        // 验证页面标题
        expect(find.text('AI助手'), findsOneWidget);
      });

      testWidgets('代理卡片显示测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 验证代理卡片数量和内容
        final agentCards = find.byType(AgentCard);
        expect(agentCards, findsAtLeastNWidgets(1));

        // 验证第一个代理卡片的详细信息
        final firstCard = tester.widget<AgentCard>(agentCards.first);
        expect(firstCard.agent, isNotNull);
        expect(firstCard.agent.name, isNotEmpty);

        // 验证卡片交互
        await tester.tap(agentCards.first);
        await tester.pumpAndSettle();

        // 验证卡片选中状态
        expect(find.byKey(const Key('agent_selected')), findsOneWidget);
      });

      testWidgets('快速操作按钮测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 验证快速操作按钮
        final voiceButton = find.byKey(const Key('voice_action'));
        final textButton = find.byKey(const Key('text_action'));
        final imageButton = find.byKey(const Key('image_action'));

        expect(voiceButton, findsOneWidget);
        expect(textButton, findsOneWidget);
        expect(imageButton, findsOneWidget);

        // 验证按钮图标和文字
        expect(find.text('语音输入'), findsOneWidget);
        expect(find.text('文字输入'), findsOneWidget);
        expect(find.text('图片识别'), findsOneWidget);
      });
    });

    group('用户交互测试', () {
      testWidgets('语音输入界面测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 点击语音输入按钮
        await tester.tap(find.byKey(const Key('voice_action')));
        await tester.pumpAndSettle();

        // 验证语音输入界面
        expect(find.byType(VoiceInterface), findsOneWidget);
        expect(find.byKey(const Key('voice_waveform')), findsOneWidget);
        expect(find.byKey(const Key('record_button')), findsOneWidget);
        expect(find.byKey(const Key('stop_button')), findsOneWidget);

        // 测试录音按钮
        await tester.tap(find.byKey(const Key('record_button')));
        await tester.pump();

        // 验证录音状态
        expect(find.byKey(const Key('recording_indicator')), findsOneWidget);
        expect(find.byKey(const Key('recording_time')), findsOneWidget);

        // 测试停止录音
        await tester.tap(find.byKey(const Key('stop_button')));
        await tester.pumpAndSettle();

        // 验证录音完成状态
        expect(find.byKey(const Key('recording_complete')), findsOneWidget);
      });

      testWidgets('文字输入界面测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 点击文字输入按钮
        await tester.tap(find.byKey(const Key('text_action')));
        await tester.pumpAndSettle();

        // 验证文字输入界面
        expect(find.byType(TextField), findsAtLeastNWidgets(1));
        expect(find.byKey(const Key('send_button')), findsOneWidget);
        expect(find.byKey(const Key('clear_button')), findsOneWidget);

        // 测试输入文字
        final textField = find.byKey(const Key('message_input'));
        await tester.tap(textField);
        await tester.enterText(textField, '测试消息');
        await tester.pump();

        // 验证输入内容
        expect(find.text('测试消息'), findsOneWidget);

        // 测试发送按钮
        await tester.tap(find.byKey(const Key('send_button')));
        await tester.pumpAndSettle();

        // 验证消息发送
        expect(find.byKey(const Key('message_sent')), findsOneWidget);
      });

      testWidgets('图片识别界面测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 点击图片识别按钮
        await tester.tap(find.byKey(const Key('image_action')));
        await tester.pumpAndSettle();

        // 验证图片选择界面
        expect(find.byKey(const Key('image_picker')), findsOneWidget);
        expect(find.byKey(const Key('camera_button')), findsOneWidget);
        expect(find.byKey(const Key('gallery_button')), findsOneWidget);

        // 模拟选择图片
        await tester.tap(find.byKey(const Key('gallery_button')));
        await tester.pumpAndSettle();

        // 验证图片预览
        expect(find.byKey(const Key('image_preview')), findsOneWidget);
        expect(find.byKey(const Key('ocr_processing')), findsOneWidget);

        // 等待OCR处理完成
        await tester.pumpAndSettle(const Duration(seconds: 3));

        // 验证OCR结果
        expect(find.byKey(const Key('ocr_result')), findsOneWidget);
        expect(find.byKey(const Key('recognized_text')), findsOneWidget);
      });
    });

    group('响应式布局测试', () {
      testWidgets('手机竖屏布局测试', (tester) async {
        // 设置手机屏幕尺寸
        await tester.binding.setSurfaceSize(const Size(375, 667));
        await tester.pumpWidget(MyApp());
        await _simulateAppStart(tester);
        await tester.pumpAndSettle();

        // 验证竖屏布局
        expect(find.byKey(const Key('mobile_layout')), findsOneWidget);
        expect(find.byType(Column), findsAtLeastNWidgets(1));
        expect(find.byType(Row), findsAtLeastNWidgets(1));

        // 验证导航栏
        final bottomNav = find.byKey(const Key('bottom_navigation'));
        expect(bottomNav, findsOneWidget);
      });

      testWidgets('平板横屏布局测试', (tester) async {
        // 设置平板屏幕尺寸
        await tester.binding.setSurfaceSize(const Size(1024, 768));
        await tester.pumpWidget(MyApp());
        await _simulateAppStart(tester);
        await tester.pumpAndSettle();

        // 验证横屏布局
        expect(find.byKey(const Key('tablet_layout')), findsOneWidget);
        expect(find.byType(Row), findsAtLeastNWidgets(1));

        // 验证侧边栏
        expect(find.byKey(const Key('side_navigation')), findsOneWidget);
      });

      testWidgets('屏幕旋转测试', (tester) async {
        // 初始竖屏
        await tester.binding.setSurfaceSize(const Size(375, 667));
        await tester.pumpWidget(MyApp());
        await _simulateAppStart(tester);
        await tester.pumpAndSettle();

        // 切换到横屏
        await tester.binding.setSurfaceSize(const Size(667, 375));
        await tester.pumpAndSettle();

        // 验证布局适应性
        expect(find.byKey(const Key('responsive_layout')), findsOneWidget);
      });
    });

    group('主题和样式测试', () {
      testWidgets('主题切换测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 打开设置
        await tester.tap(find.byKey(const Key('settings_button')));
        await tester.pumpAndSettle();

        // 切换到暗色主题
        await tester.tap(find.byKey(const Key('dark_theme_switch')));
        await tester.pumpAndSettle();

        // 验证主题变更
        expect(find.byKey(const Key('dark_theme_active')), findsOneWidget);

        // 验证颜色变更
        final backgroundColor = tester.widget<Container>(find.byKey(const Key('main_background'))).color;
        expect(backgroundColor, equals(Colors.grey[900]));
      });

      testWidgets('字体大小调整测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 打开设置
        await tester.tap(find.byKey(const Key('settings_button')));
        await tester.pumpAndSettle();

        // 调整字体大小
        await tester.tap(find.byKey(const Key('increase_font_size')));
        await tester.pumpAndSettle();

        // 验证字体大小变更
        final titleText = tester.widget<Text>(find.text('AI助手'));
        expect(titleText.style?.fontSize, greaterThan(20.0));
      });
    });

    group('无障碍功能测试', () {
      testWidgets('屏幕阅读器支持测试', (tester) async {
        // 启用屏幕阅读器模式
        await _enableScreenReader(tester);

        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 验证可访问性标签
        expect(find.byKey(const Key('home_title')), findsOneWidget);
        final titleWidget = tester.widget(find.byKey(const Key('home_title')));
        expect(titleWidget.semanticsLabel, isNotEmpty);

        // 验证按钮描述
        final voiceButton = tester.widget(find.byKey(const Key('voice_action')));
        expect(voiceButton.semanticsLabel, equals('语音输入按钮'));
      });

      testWidgets('手势操作测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 测试滑动手势
        await tester.fling(
          find.byKey(const Key('main_content')),
          const Offset(-100, 0),
          1000,
        );
        await tester.pumpAndSettle();

        // 验证滑动效果
        expect(find.byKey(const Key('swipe_navigation')), findsOneWidget);

        // 测试双击手势
        await tester.tap(find.byType(AgentCard), times: 2);
        await tester.pumpAndSettle();

        // 验证双击效果
        expect(find.byKey(const Key('double_tap_action')), findsOneWidget);
      });
    });

    group('性能和用户体验测试', () {
      testWidgets('页面切换性能测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        final startTime = DateTime.now();

        // 执行页面切换
        await tester.tap(find.byKey(const Key('history_tab')));
        await tester.pumpAndSettle();

        final endTime = DateTime.now();
        final switchTime = endTime.difference(startTime);

        // 验证切换性能
        expect(switchTime.inMilliseconds, lessThan(300)); // 300ms内完成

        // 验证页面内容
        expect(find.byKey(const Key('history_page')), findsOneWidget);
      });

      testWidgets('列表滚动性能测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 滚动到列表底部
        await tester.fling(
          find.byKey(const Key('agent_list')),
          const Offset(0, -500),
          1000,
        );
        await tester.pumpAndSettle();

        // 验证滚动性能（无卡顿）
        expect(find.byKey(const Key('smooth_scroll')), findsOneWidget);
      });

      testWidgets('动画性能测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 触发动画
        await tester.tap(find.byKey(const Key('animate_button')));
        await tester.pumpAndSettle();

        // 验证动画流畅度
        expect(find.byKey(const Key('animation_running')), findsOneWidget);

        // 等待动画完成
        await tester.pumpAndSettle(const Duration(seconds: 1));

        expect(find.byKey(const Key('animation_complete')), findsOneWidget);
      });
    });

    group('错误状态UI测试', () {
      testWidgets('网络错误显示测试', (tester) async {
        await _simulateNetworkError();

        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 尝试发送消息
        await tester.tap(find.byKey(const Key('text_action')));
        await tester.pumpAndSettle();

        await tester.enterText(find.byKey(const Key('message_input')), '测试消息');
        await tester.tap(find.byKey(const Key('send_button')));
        await tester.pumpAndSettle();

        // 验证错误提示
        expect(find.byKey(const Key('network_error_dialog')), findsOneWidget);
        expect(find.text('网络连接失败'), findsOneWidget);
      });

      testWidgets('加载状态显示测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 触发长时间操作
        await tester.tap(find.byKey(const Key('process_large_image')));
        await tester.pumpAndSettle();

        // 验证加载状态
        expect(find.byType(CircularProgressIndicator), findsOneWidget);
        expect(find.text('正在处理...'), findsOneWidget);
        expect(find.byKey(const Key('loading_overlay')), findsOneWidget);
      });

      testWidgets('空状态显示测试', (tester) async {
        await _navigateToHome(tester);
        await tester.pumpAndSettle();

        // 清空数据
        await _clearAllData();

        // 切换到历史页面
        await tester.tap(find.byKey(const Key('history_tab')));
        await tester.pumpAndSettle();

        // 验证空状态
        expect(find.byKey(const Key('empty_state')), findsOneWidget);
        expect(find.text('暂无数据'), findsOneWidget);
        expect(find.byKey(const Key('retry_button')), findsOneWidget);
      });
    });
  });
}

// 辅助函数
Future<void> _setupTestEnvironment() async {
  // 设置测试环境
}

Future<void> _simulateAppStart(WidgetTester tester) async {
  // 模拟应用启动
  await tester.pumpWidget(MyApp());
  await tester.pumpAndSettle(const Duration(seconds: 2));
}

Future<void> _navigateToHome(WidgetTester tester) async {
  // 导航到主页
  await _simulateAppStart(tester);
  await tester.tap(find.byKey(const Key('skip_splash')));
  await tester.pumpAndSettle();
}

Future<void> _enableScreenReader(WidgetTester tester) async {
  // 启用屏幕阅读器
}

Future<void> _simulateNetworkError() async {
  // 模拟网络错误
}

Future<void> _clearAllData() async {
  // 清空所有数据
}