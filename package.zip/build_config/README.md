---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022045f35118087b44c3585b66ac70db6fec5f9f7b6092cf012475ffd345822935d3022100e21ccef3f20d0fc91623173d4c2668e54666ea78f3596d49c06fb5a4292c34d0
    ReservedCode2: 3045022036929fd9ea94e0e55e7aff105c1d2d926cd86a73818cd920677e56e499c17a92022100d9094b64051a548fc05acffed0a6a72a1630a797b3ebaec9c5c3b1fa04f9c084
---

# APK构建和打包系统

一个完整的Flutter/Android APK构建、分割、优化和部署系统。

## 🚀 特性

- **Flutter构建**: 完整的Flutter APK构建配置
- **Gradle优化**: 高性能Gradle构建配置
- **资源优化**: 图片、字体、音频资源自动优化
- **代码混淆**: ProGuard/R8代码保护和混淆
- **多APK支持**: 按架构、密度、版本分割APK
- **CI/CD集成**: GitHub Actions、Jenkins、Docker支持
- **APK优化**: 大小、性能、安装速度优化
- **自动化**: 一键构建、测试、部署

## 📁 目录结构

```
build_config/
├── build.sh                 # 主构建脚本
├── README.md               # 本文档
├── flutter/                # Flutter构建配置
│   ├── build_config.yaml   # Flutter构建配置
│   ├── pubspec.yaml       # 优化的依赖配置
│   └── build_apk.sh       # Flutter构建脚本
├── gradle/                 # Gradle构建配置
│   ├── build.gradle       # 根级构建配置
│   ├── app_build.gradle   # 应用级构建配置
│   └── gradle.properties   # Gradle属性配置
├── resources/              # 资源优化配置
│   ├── resource_optimization.yaml  # 资源优化配置
│   └── optimize_resources.sh        # 资源优化脚本
├── proguard/               # 代码混淆配置
│   ├── proguard-rules.pro # ProGuard规则
│   └── proguard_optimizer.sh       # ProGuard优化脚本
├── multi_apk/              # 多APK分割配置
│   ├── split_config.yaml   # 分割配置
│   └── build_multi_apk.sh  # 多APK构建脚本
├── ci_cd/                  # CI/CD配置
│   ├── github_actions.yml # GitHub Actions配置
│   ├── jenkinsfile        # Jenkins Pipeline配置
│   ├── Dockerfile          # Docker构建环境
│   └── docker-compose.yml  # Docker Compose配置
└── optimization/           # APK优化配置
    ├── apk_optimization_config.yaml # APK优化配置
    └── apk_optimizer.sh           # APK优化脚本
```

## 🛠 安装依赖

### 基础依赖

```bash
# 安装Flutter
curl -s https://flutter.dev/docs | grep -o 'https://storage.googleapis.com/[^\"]*linux.tar.xz' | head -1 | xargs wget -O flutter.tar.xz
tar xf flutter.tar.xz
export PATH="$PATH:`pwd`/flutter/bin"

# 安装Android SDK
# 下载Android Command Line Tools
wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
unzip commandlinetools-linux-9477386_latest.zip
mkdir -p ~/android-sdk/cmdline-tools
mv cmdline-tools latest
mv latest ~/android-sdk/cmdline-tools/

# 设置环境变量
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin

# 安装Android SDK组件
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

### 优化工具

```bash
# macOS
brew install pngquant jpegoptim webp imagemagick

# Ubuntu/Debian
sudo apt-get install pngquant jpegoptim webp-tools imagemagick

# Node.js (用于SVG优化)
npm install -g svgo
```

## 🚀 快速开始

### 1. 初始化环境

```bash
# 克隆项目
git clone <your-repo>
cd <your-project>

# 初始化构建环境
bash build_config/build.sh setup
```

### 2. 构建APK

```bash
# 构建Release APK
bash build_config/build.sh build --type=release

# 构建分割APK
bash build_config/build.sh build --type=release --split=true

# 构建特定架构APK
bash build_config/build.sh build --type=release --arch=arm64-v8a
```

### 3. 优化APK

```bash
# 优化所有APK
bash build_config/build.sh optimize --all

# 优化单个APK
bash build_config/build.sh optimize --apk=build/outputs/apk/app-release.apk
```

### 4. 构建多APK

```bash
# 构建架构分割APK
bash build_config/build.sh multi --abi

# 构建密度分割APK
bash build_config/build.sh multi --density

# 构建版本变体APK
bash build_config/build.sh multi --variant
```

## 📋 详细用法

### 主构建脚本

```bash
# 显示帮助
bash build_config/build.sh help

# 初始化环境
bash build_config/build.sh setup

# 构建APK
bash build_config/build.sh build --type=release --split=true --arch=universal

# 优化APK
bash build_config/build.sh optimize --all

# 资源优化
bash build_config/build.sh resources --all
bash build_config/build.sh resources --png
bash build_config/build.sh resources --jpeg
bash build_config/build.sh resources --fonts

# 多APK构建
bash build_config/build.sh multi --abi
bash build_config/build.sh multi --density
bash build_config/build.sh multi --variant

# CI/CD配置
bash build_config/build.sh ci --github
bash build_config/build.sh ci --jenkins
bash build_config/build.sh ci --docker

# 运行测试
bash build_config/build.sh test --unit
bash build_config/build.sh test --integration

# 部署
bash build_config/build.sh deploy --firebase
bash build_config/build.sh deploy --google-play

# 清理
bash build_config/build.sh clean

# 生成报告
bash build_config/build.sh report
```

### Flutter构建脚本

```bash
# 清理构建
bash build_config/flutter/build_apk.sh clean

# 构建Debug APK
bash build_config/flutter/build_apk.sh debug

# 构建Profile APK
bash build_config/flutter/build_apk.sh profile

# 构建分割APK
bash build_config/flutter/build_apk.sh split

# 构建统一APK
bash build_config/flutter/build_apk.sh unified

# 构建所有类型
bash build_config/flutter/build_apk.sh full
```

### 资源优化脚本

```bash
# 优化所有资源
bash build_config/resources/optimize_resources.sh all

# 优化PNG图片
bash build_config/resources/optimize_resources.sh png

# 优化JPEG图片
bash build_config/resources/optimize_resources.sh jpeg

# 转换为WebP
bash build_config/resources/optimize_resources.sh webp

# 优化字体
bash build_config/resources/optimize_resources.sh fonts

# 优化音频
bash build_config/resources/optimize_resources.sh audio
```

### ProGuard优化脚本

```bash
# 生成ProGuard配置
bash build_config/proguard/proguard_optimizer.sh config

# 执行代码混淆
bash build_config/proguard/proguard_optimizer.sh optimize

# 分析优化结果
bash build_config/proguard/proguard_optimizer.sh analyze
```

### 多APK构建脚本

```bash
# 构建所有分割类型
bash build_config/multi_apk/build_multi_apk.sh all

# 构建架构分割APK
bash build_config/multi_apk/build_multi_apk.sh abi

# 构建密度分割APK
bash build_config/multi_apk/build_multi_apk.sh density

# 构建版本变体APK
bash build_config/multi_apk/build_multi_apk.sh variant

# 构建统一APK
bash build_config/multi_apk/build_multi_apk.sh universal
```

### APK优化脚本

```bash
# 优化所有APK
bash build_config/optimization/apk_optimizer.sh all

# 优化单个APK
bash build_config/optimization/apk_optimizer.sh single build/outputs/apk/app-release.apk

# 仅优化资源
bash build_config/optimization/apk_optimizer.sh resources

# 生成优化报告
bash build_config/optimization/apk_optimizer.sh report
```

## 🔧 配置说明

### Flutter配置 (`flutter/build_config.yaml`)

```yaml
build:
  app_name: "your_app_name"
  package_name: "com.yourcompany.yourapp"
  version_code: 1
  version_name: "1.0.0"

platforms:
  android:
    min_sdk: 21
    target_sdk: 34
    compile_sdk: 34
    ndk_version: "21.1.6352462"

build_options:
  split_per_abi: true
  shrink_resources: true
  obfuscate: true
  tree_shake_icons: true
  enable_r8: true

architectures:
  - arm64-v8a
  - armeabi-v7a
  - x86_64
```

### ProGuard配置 (`proguard/proguard-rules.pro`)

- 代码混淆规则
- 保留第三方库
- 移除调试信息
- 优化配置

### 资源优化配置 (`resources/resource_optimization.yaml`)

```yaml
image_optimization:
  png:
    enabled: true
    compression_level: 6
    quality_range: [65, 85]
  
  webp:
    enabled: true
    quality: 85

font_optimization:
  subset_fonts: true
  languages: ["zh-CN", "en-US"]
```

### 多APK配置 (`multi_apk/split_config.yaml`)

```yaml
abi_splits:
  enable: true
  include:
    - "arm64-v8a"
    - "armeabi-v7a"
    - "x86_64"

density_splits:
  enable: true
  include:
    - "xhdpi"
    - "xxhdpi"
    - "xxxhdpi"
```

## 🐳 Docker使用

### 构建Docker镜像

```bash
# 构建Flutter构建环境镜像
docker build -f build_config/ci_cd/Dockerfile -t flutter-builder .

# 使用Docker Compose
docker-compose -f build_config/ci_cd/docker-compose.yml up flutter-builder
```

### Docker Compose服务

```yaml
# 在Docker中构建Release APK
docker-compose -f build_config/ci_cd/docker-compose.yml run --rm flutter-builder

# 在Docker中优化APK
docker-compose -f build_config/ci_cd/docker-compose.yml run --rm apk-optimizer

# 运行CI构建
docker-compose -f build_config/ci_cd/docker-compose.yml run --rm flutter-ci
```

## 🚀 CI/CD集成

### GitHub Actions

1. 将配置文件复制到项目根目录：

```bash
bash build_config/build.sh ci --github
```

2. 设置GitHub Secrets：
   - `SIGNING_KEY`: Base64编码的签名密钥
   - `STORE_PASSWORD`: 签名密钥密码
   - `KEY_ALIAS`: 密钥别名
   - `KEY_PASSWORD`: 密钥密码

### Jenkins

1. 将Jenkinsfile复制到项目根目录：

```bash
bash build_config/build.sh ci --jenkins
```

2. 在Jenkins中配置Pipeline项目

### Docker CI

1. 构建Docker镜像：

```bash
bash build_config/build.sh ci --docker
```

2. 在CI环境中使用Docker镜像

## 📊 优化效果

### 大小优化

- **图片压缩**: PNG/JPEG压缩可减少30-50%大小
- **WebP转换**: 可进一步减少20-40%大小
- **字体子集化**: 字体文件可减少60-80%大小
- **代码混淆**: R8/ProGuard可减少15-25%大小

### 性能优化

- **分割APK**: 减少下载和安装时间
- **资源优化**: 加快应用启动速度
- **代码优化**: 提升运行时性能

## 📋 最佳实践

### 1. 项目结构

```
your_project/
├── android/                 # Android原生代码
├── lib/                     # Flutter Dart代码
├── assets/                  # 应用资源
├── build_config/           # 构建配置
├── pubspec.yaml            # Flutter依赖
├── android/app/build.gradle # Android构建脚本
└── README.md              # 项目文档
```

### 2. 版本管理

```yaml
# 版本命名规范
version_code: 1            # 递增的整数
version_name: "1.0.0"      # 主版本.次版本.修订版本

# 发布分支策略
main      # 生产版本
develop   # 开发版本
feature/* # 功能分支
hotfix/*  # 热修复分支
```

### 3. 签名配置

```properties
# android/gradle.properties
MYAPP_UPLOAD_STORE_FILE=upload-keystore.jks
MYAPP_UPLOAD_STORE_PASSWORD=your_store_password
MYAPP_UPLOAD_KEY_ALIAS=your_key_alias
MYAPP_UPLOAD_KEY_PASSWORD=your_key_password
```

### 4. 依赖管理

```yaml
# pubspec.yaml优化
dependencies:
  # 使用 конкрет版本而非范围版本
  flutter: "3.16.0"
  provider: "6.0.5"

dev_dependencies:
  # 开发依赖分离
  build_runner: "2.3.3"
  json_serializable: "6.6.2"
```

## 🐛 故障排除

### 常见问题

1. **Flutter doctor报错**
   ```bash
   flutter doctor --android-licenses
   ```

2. **签名错误**
   ```bash
   # 检查签名文件
   keytool -list -keystore android/app/upload-keystore.jks
   ```

3. **构建失败**
   ```bash
   # 清理构建缓存
   flutter clean
   ./gradlew clean
   ```

4. **依赖冲突**
   ```bash
   # 更新依赖
   flutter pub upgrade
   ```

### 日志调试

```bash
# 启用详细日志
flutter build apk --verbose

# Gradle调试
./gradlew --stacktrace --info assembleRelease
```

## 📈 性能监控

### APK大小监控

```bash
# 生成大小报告
bash build_config/build.sh report

# 监控APK大小变化
find build/ -name "*.apk" -exec ls -lh {} \;
```

### 构建时间监控

```bash
# 使用time命令监控构建时间
time flutter build apk --release
```

## 🔒 安全配置

### 代码保护

1. **启用混淆**: 在release构建中启用R8
2. **移除调试信息**: 配置ProGuard移除调试符号
3. **签名验证**: 使用强密码保护签名密钥

### 权限最小化

```xml
<!-- 仅请求必要权限 -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## 📚 扩展功能

### 自定义构建步骤

在`build.sh`中添加自定义脚本：

```bash
# 自定义构建步骤
custom_build_step() {
    log_step "执行自定义构建步骤..."
    # 添加你的构建逻辑
}
```

### 插件集成

支持与第三方工具集成：

- Firebase App Distribution
- Google Play Console
- App Center
- CodeMagic

## 🤝 贡献

欢迎提交Issue和Pull Request！

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 推送到分支
5. 创建Pull Request

## 📄 许可证

本项目采用MIT许可证。详见LICENSE文件。

## 📞 支持

如有问题，请：

1. 查看本文档的故障排除部分
2. 搜索GitHub Issues
3. 创建新的Issue描述问题

---

**APK构建系统** - 让Flutter应用构建更简单、更高效！🚀