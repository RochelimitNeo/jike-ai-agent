#!/bin/bash
# APK构建主脚本
# 整合所有构建步骤的一站式解决方案

set -e

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_CONFIG_DIR="$SCRIPT_DIR"
VERSION="1.0.0"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_header() {
    echo -e "${PURPLE}[HEADER]${NC} $1"
}

log_step() {
    echo -e "${CYAN}[STEP]${NC} $1"
}

# 显示帮助信息
show_help() {
    cat << EOF
APK构建主脚本 v$VERSION

用法: $0 [命令] [选项]

命令:
  setup          - 初始化构建环境
  build          - 构建APK
    --type       - 构建类型 (debug|profile|release)
    --split      - 是否分割APK (true|false)
    --arch       - 目标架构 (arm64-v8a|armeabi-v7a|x86_64)
  
  optimize       - 优化APK
    --apk        - APK文件路径
    --all        - 优化所有APK
  
  resources      - 优化资源
    --all        - 优化所有资源
    --png        - 优化PNG图片
    --jpeg       - 优化JPEG图片
    --fonts      - 优化字体
  
  multi          - 构建多APK
    --abi        - 构建架构分割APK
    --density    - 构建密度分割APK
    --variant    - 构建版本变体
  
  ci             - CI/CD构建
    --github     - 生成GitHub Actions配置
    --jenkins    - 生成Jenkins配置
    --docker     - 构建Docker镜像
  
  clean          - 清理构建文件
  
  report         - 生成构建报告
  
  test           - 运行测试
    --unit       - 单元测试
    --integration- 集成测试
  
  deploy         - 部署
    --firebase   - 部署到Firebase
    --google-play- 部署到Google Play
  
  help           - 显示此帮助信息

示例:
  $0 setup
  $0 build --type=release --split=true
  $0 optimize --all
  $0 multi --abi
  $0 ci --github
  $0 test --unit

配置文件位置:
  $SCRIPT_DIR/
  ├── flutter/          # Flutter构建配置
  ├── gradle/           # Gradle构建配置
  ├── resources/        # 资源优化配置
  ├── proguard/        # 代码混淆配置
  ├── multi_apk/        # 多APK分割配置
  ├── ci_cd/           # CI/CD配置
  └── optimization/    # APK优化配置

更多信息请访问: https://github.com/your-repo/apk-build-system
EOF
}

# 检查系统依赖
check_dependencies() {
    log_step "检查系统依赖..."
    
    local missing_deps=()
    
    # 检查Flutter
    if ! command -v flutter &> /dev/null; then
        missing_deps+=("flutter")
    fi
    
    # 检查Java
    if ! command -v java &> /dev/null; then
        missing_deps+=("java")
    fi
    
    # 检查Android SDK
    if [ -z "$ANDROID_HOME" ]; then
        missing_deps+=("android-sdk")
    fi
    
    # 检查Git
    if ! command -v git &> /dev/null; then
        missing_deps+=("git")
    fi
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        log_error "缺少以下依赖: ${missing_deps[*]}"
        log_info "请安装缺失的依赖后重试"
        return 1
    fi
    
    # 显示版本信息
    log_success "Flutter: $(flutter --version | head -n1)"
    log_success "Java: $(java -version 2>&1 | head -n1)"
    log_success "Android SDK: ${ANDROID_HOME:-未设置}"
    log_success "Git: $(git --version)"
    
    return 0
}

# 初始化构建环境
setup_environment() {
    log_header "初始化构建环境"
    
    check_dependencies || return 1
    
    log_step "创建构建目录..."
    mkdir -p "$PROJECT_ROOT/build"
    mkdir -p "$PROJECT_ROOT/build/outputs/apk"
    mkdir -p "$PROJECT_ROOT/build/tmp"
    mkdir -p "$PROJECT_ROOT/reports"
    mkdir -p "$PROJECT_ROOT/gradle-cache"
    
    log_step "配置Flutter..."
    flutter config --no-analytics
    flutter config --disable-telemetry
    
    log_step "检查Flutter依赖..."
    if [ -f "$PROJECT_ROOT/pubspec.yaml" ]; then
        cd "$PROJECT_ROOT"
        flutter pub get
        cd - > /dev/null
    fi
    
    log_step "配置Android签名..."
    if [ ! -f "$PROJECT_ROOT/android/app/upload-keystore.jks" ]; then
        log_warning "未找到签名文件，创建调试签名..."
        keytool -genkey -v -keystore "$PROJECT_ROOT/android/app/debug.keystore" \
            -storepass android -alias androiddebugkey \
            -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
            -dname "CN=Android Debug,O=Android,C=US"
    fi
    
    log_step "检查构建工具..."
    flutter doctor
    
    log_success "构建环境初始化完成"
}

# 构建APK
build_apk() {
    local build_type=${1:-"release"}
    local split_abi=${2:-"true"}
    local architecture=${3:-"universal"}
    
    log_header "构建APK"
    log_info "构建类型: $build_type"
    log_info "分割架构: $split_abi"
    log_info "目标架构: $architecture"
    
    check_dependencies || return 1
    
    cd "$PROJECT_ROOT"
    
    log_step "清理构建目录..."
    flutter clean
    flutter pub get
    
    log_step "开始构建..."
    
    case $architecture in
        "universal")
            log_info "构建统一APK..."
            flutter build apk --$build_type
            ;;
        "arm64-v8a"|"armeabi-v7a"|"x86_64")
            log_info "构建特定架构APK: $architecture"
            flutter build apk --$build_type --target-platform android-$architecture
            ;;
        "split")
            log_info "构建分割APK..."
            flutter build apk --$build_type --split-per-abi
            ;;
        *)
            log_error "未知架构: $architecture"
            return 1
            ;;
    esac
    
    # 移动构建产物
    local apk_source="build/app/outputs/flutter-apk/app-$build_type.apk"
    local apk_dest="build/outputs/apk/${PROJECT_NAME:-app}-$build_type.apk"
    
    if [ -f "$apk_source" ]; then
        mv "$apk_source" "$apk_dest"
        log_success "APK构建完成: $apk_dest"
        
        # 显示APK信息
        local size=$(du -h "$apk_dest" | cut -f1)
        log_info "APK大小: $size"
    else
        log_error "APK构建失败: $apk_source 不存在"
        return 1
    fi
    
    cd - > /dev/null
    log_success "APK构建任务完成"
}

# 优化APK
optimize_apk() {
    local apk_file=${1:-""}
    local optimize_all=${2:-"false"}
    
    log_header "APK优化"
    
    if [ "$optimize_all" = "true" ]; then
        log_step "优化所有APK文件..."
        bash "$BUILD_CONFIG_DIR/optimization/apk_optimizer.sh" all
    elif [ -n "$apk_file" ]; then
        log_step "优化APK: $apk_file"
        bash "$BUILD_CONFIG_DIR/optimization/apk_optimizer.sh" single "$apk_file"
    else
        log_error "请指定APK文件或使用 --all 参数"
        return 1
    fi
    
    log_success "APK优化完成"
}

# 优化资源
optimize_resources() {
    local resource_type=${1:-"all"}
    
    log_header "资源优化"
    log_info "优化类型: $resource_type"
    
    case $resource_type in
        "all")
            log_step "优化所有资源..."
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" all
            ;;
        "png")
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" png
            ;;
        "jpeg")
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" jpeg
            ;;
        "webp")
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" webp
            ;;
        "fonts")
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" fonts
            ;;
        "audio")
            bash "$BUILD_CONFIG_DIR/resources/optimize_resources.sh" audio
            ;;
        *)
            log_error "未知的资源类型: $resource_type"
            return 1
            ;;
    esac
    
    log_success "资源优化完成"
}

# 构建多APK
build_multi_apk() {
    local split_type=${1:-"abi"}
    
    log_header "多APK构建"
    log_info "分割类型: $split_type"
    
    case $split_type in
        "abi")
            bash "$BUILD_CONFIG_DIR/multi_apk/build_multi_apk.sh" abi
            ;;
        "density")
            bash "$BUILD_CONFIG_DIR/multi_apk/build_multi_apk.sh" density
            ;;
        "variant")
            bash "$BUILD_CONFIG_DIR/multi_apk/build_multi_apk.sh" variant
            ;;
        "all")
            bash "$BUILD_CONFIG_DIR/multi_apk/build_multi_apk.sh" all
            ;;
        *)
            log_error "未知的分割类型: $split_type"
            return 1
            ;;
    esac
    
    log_success "多APK构建完成"
}

# CI/CD配置
setup_ci() {
    local ci_type=${1:-"github"}
    
    log_header "CI/CD配置"
    log_info "CI类型: $ci_type"
    
    case $ci_type in
        "github")
            log_step "配置GitHub Actions..."
            cp "$BUILD_CONFIG_DIR/ci_cd/github_actions.yml" "$PROJECT_ROOT/.github/workflows/build.yml"
            log_success "GitHub Actions配置完成"
            ;;
        "jenkins")
            log_step "配置Jenkins..."
            cp "$BUILD_CONFIG_DIR/ci_cd/jenkinsfile" "$PROJECT_ROOT/Jenkinsfile"
            log_success "Jenkins配置完成"
            ;;
        "docker")
            log_step "构建Docker镜像..."
            docker-compose -f "$BUILD_CONFIG_DIR/ci_cd/docker-compose.yml" build
            log_success "Docker镜像构建完成"
            ;;
        *)
            log_error "未知的CI类型: $ci_type"
            return 1
            ;;
    esac
    
    log_success "CI/CD配置完成"
}

# 清理构建文件
clean_build() {
    log_header "清理构建文件"
    
    log_step "清理Flutter构建目录..."
    if [ -f "$PROJECT_ROOT/pubspec.yaml" ]; then
        cd "$PROJECT_ROOT"
        flutter clean
        cd - > /dev/null
    fi
    
    log_step "清理构建目录..."
    rm -rf "$PROJECT_ROOT/build"
    rm -rf "$PROJECT_ROOT/reports"
    rm -rf "$PROJECT_ROOT/.dart_tool"
    rm -rf "$PROJECT_ROOT/.flutter-plugins"
    rm -rf "$PROJECT_ROOT/.flutter-plugins-dependencies"
    
    log_step "清理Gradle缓存..."
    rm -rf "$PROJECT_ROOT/gradle-cache"
    rm -rf "$PROJECT_ROOT/android/.gradle"
    
    log_success "清理完成"
}

# 生成构建报告
generate_report() {
    log_header "生成构建报告"
    
    local report_file="$PROJECT_ROOT/reports/build_report_$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "========================================="
        echo "APK构建报告"
        echo "========================================="
        echo "生成时间: $(date)"
        echo "项目路径: $PROJECT_ROOT"
        echo "脚本版本: $VERSION"
        echo ""
        
        echo "系统信息:"
        echo "----------------------------------------"
        echo "Flutter版本: $(flutter --version | head -n1)"
        echo "Dart版本: $(dart --version)"
        echo "Java版本: $(java -version 2>&1 | head -n1)"
        echo "Android SDK: ${ANDROID_HOME:-未设置}"
        echo ""
        
        echo "构建文件:"
        echo "----------------------------------------"
        if [ -d "$PROJECT_ROOT/build" ]; then
            find "$PROJECT_ROOT/build" -name "*.apk" -exec ls -lh {} \; | awk '{print $9 ": " $5}'
        else
            echo "未找到构建文件"
        fi
        
        echo ""
        echo "环境检查:"
        echo "----------------------------------------"
        echo "Flutter安装: $(command -v flutter >/dev/null 2>&1 && echo '✓' || echo '✗')"
        echo "Java安装: $(command -v java >/dev/null 2>&1 && echo '✓' || echo '✗')"
        echo "Android SDK: $([ -n "$ANDROID_HOME" ] && echo '✓' || echo '✗')"
        echo "Git安装: $(command -v git >/dev/null 2>&1 && echo '✓' || echo '✗')"
        
    } > "$report_file"
    
    log_success "构建报告已生成: $report_file"
    
    # 显示报告内容
    cat "$report_file"
}

# 运行测试
run_tests() {
    local test_type=${1:-"unit"}
    
    log_header "运行测试"
    log_info "测试类型: $test_type"
    
    cd "$PROJECT_ROOT"
    
    case $test_type in
        "unit")
            log_step "运行单元测试..."
            flutter test --no-pub
            ;;
        "integration")
            log_step "运行集成测试..."
            flutter test integration_test/ --no-pub
            ;;
        "all")
            log_step "运行所有测试..."
            flutter test --no-pub
            flutter test integration_test/ --no-pub
            ;;
        *)
            log_error "未知的测试类型: $test_type"
            return 1
            ;;
    esac
    
    cd - > /dev/null
    log_success "测试完成"
}

# 部署应用
deploy_app() {
    local deploy_type=${1:-"firebase"}
    
    log_header "部署应用"
    log_info "部署类型: $deploy_type"
    
    case $deploy_type in
        "firebase")
            log_step "部署到Firebase App Distribution..."
            if [ -f "$PROJECT_ROOT/build/outputs/apk/app-release.apk" ]; then
                firebase appdistribution:distribute "$PROJECT_ROOT/build/outputs/apk/app-release.apk" \
                    --app "$FIREBASE_APP_ID" \
                    --groups "testers" \
                    --release-notes "Build $(date)"
                log_success "Firebase部署完成"
            else
                log_error "未找到Release APK文件"
                return 1
            fi
            ;;
        "google-play")
            log_step "部署到Google Play..."
            if [ -f "$PROJECT_ROOT/build/app/outputs/bundle/release/app-release.aab" ]; then
                # 这里需要配置Google Play API
                log_warning "Google Play部署功能需要额外配置"
            else
                log_error "未找到App Bundle文件"
                return 1
            fi
            ;;
        *)
            log_error "未知的部署类型: $deploy_type"
            return 1
            ;;
    esac
}

# 主函数
main() {
    local command=$1
    shift || true
    
    # 解析参数
    local args=("$@")
    local params=""
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --type)
                params="$params --type $2"
                shift 2
                ;;
            --split)
                params="$params --split $2"
                shift 2
                ;;
            --arch)
                params="$params --arch $2"
                shift 2
                ;;
            --apk)
                params="$params --apk $2"
                shift 2
                ;;
            --all)
                params="$params --all"
                shift
                ;;
            --png)
                params="$params png"
                shift
                ;;
            --jpeg)
                params="$params jpeg"
                shift
                ;;
            --fonts)
                params="$params fonts"
                shift
                ;;
            --abi)
                params="$params abi"
                shift
                ;;
            --density)
                params="$params density"
                shift
                ;;
            --variant)
                params="$params variant"
                shift
                ;;
            --github)
                params="$params github"
                shift
                ;;
            --jenkins)
                params="$params jenkins"
                shift
                ;;
            --docker)
                params="$params docker"
                shift
                ;;
            --unit)
                params="$params unit"
                shift
                ;;
            --integration)
                params="$params integration"
                shift
                ;;
            --firebase)
                params="$params firebase"
                shift
                ;;
            --google-play)
                params="$params google-play"
                shift
                ;;
            *)
                params="$params $1"
                shift
                ;;
        esac
    done
    
    # 执行命令
    case $command in
        "setup")
            setup_environment
            ;;
        "build")
            local build_type="release"
            local split_abi="true"
            local architecture="universal"
            
            # 解析构建参数
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "--type") build_type=$2; shift 2 ;;
                    "--split") split_abi=$2; shift 2 ;;
                    "--arch") architecture=$2; shift 2 ;;
                    *) shift ;;
                esac
            done
            
            build_apk "$build_type" "$split_abi" "$architecture"
            ;;
        "optimize")
            local apk_file=""
            local optimize_all="false"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "--apk") apk_file=$2; shift 2 ;;
                    "--all") optimize_all="true"; shift ;;
                    *) shift ;;
                esac
            done
            
            optimize_apk "$apk_file" "$optimize_all"
            ;;
        "resources")
            local resource_type="all"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "png"|"jpeg"|"webp"|"fonts"|"audio"|"all")
                        resource_type=$1
                        shift
                        ;;
                    *) shift ;;
                esac
            done
            
            optimize_resources "$resource_type"
            ;;
        "multi")
            local split_type="abi"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "abi"|"density"|"variant"|"all")
                        split_type=$1
                        shift
                        ;;
                    *) shift ;;
                esac
            done
            
            build_multi_apk "$split_type"
            ;;
        "ci")
            local ci_type="github"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "github"|"jenkins"|"docker")
                        ci_type=$1
                        shift
                        ;;
                    *) shift ;;
                esac
            done
            
            setup_ci "$ci_type"
            ;;
        "clean")
            clean_build
            ;;
        "report")
            generate_report
            ;;
        "test")
            local test_type="unit"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "unit"|"integration"|"all")
                        test_type=$1
                        shift
                        ;;
                    *) shift ;;
                esac
            done
            
            run_tests "$test_type"
            ;;
        "deploy")
            local deploy_type="firebase"
            
            while [[ $# -gt 0 ]]; do
                case $1 in
                    "firebase"|"google-play")
                        deploy_type=$1
                        shift
                        ;;
                    *) shift ;;
                esac
            done
            
            deploy_app "$deploy_type"
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        "")
            log_error "请指定命令"
            show_help
            exit 1
            ;;
        *)
            log_error "未知命令: $command"
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"