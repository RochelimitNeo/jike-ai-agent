#!/bin/bash
# 多APK分割构建脚本

set -e

# 配置变量
PROJECT_NAME="jike_ai_agent"
BUILD_DIR="$PROJECT_DIR/build"
OUTPUT_DIR="$BUILD_DIR/outputs/apk/split"
CONFIG_FILE="$PROJECT_DIR/build_config/multi_apk/split_config.yaml"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 解析YAML配置（简化版）
parse_yaml() {
    local yaml_file=$1
    local prefix=$2
    
    while IFS=':' read -r key value; do
        # 跳过注释和空行
        [[ "$key" =~ ^[[:space:]]*# ]] && continue
        [[ -z "${key// }" ]] && continue
        
        # 清理值
        key=$(echo "$key" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        value=$(echo "$value" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        
        # 处理数组
        if [[ "$value" =~ ^\[.*\]$ ]]; then
            # 提取数组元素
            value=$(echo "$value" | sed 's/^\[//;s/\]$//;s/, / /g')
            echo "${prefix}${key}=\"${value}\""
        else
            echo "${prefix}${key}=\"${value}\""
        fi
    done < "$yaml_file"
}

# 加载配置
load_config() {
    log_info "加载多APK分割配置..."
    
    if [ ! -f "$CONFIG_FILE" ]; then
        log_error "配置文件不存在: $CONFIG_FILE"
        exit 1
    fi
    
    # 解析配置
    eval $(parse_yaml "$CONFIG_FILE" "CONFIG_")
    
    log_success "配置加载完成"
}

# 创建构建目录
setup_directories() {
    log_info "创建多APK构建目录..."
    
    mkdir -p "$OUTPUT_DIR"
    mkdir -p "$OUTPUT_DIR/abi"
    mkdir -p "$OUTPUT_DIR/density"
    mkdir -p "$OUTPUT_DIR/variant"
    mkdir -p "$OUTPUT_DIR/locale"
    
    log_success "目录创建完成"
}

# 检查Flutter环境
check_flutter() {
    log_info "检查Flutter环境..."
    
    if ! command -v flutter &> /dev/null; then
        log_error "Flutter未安装或未配置到PATH"
        exit 1
    fi
    
    local flutter_version=$(flutter --version | head -n1)
    log_success "Flutter版本: $flutter_version"
}

# 架构分割构建
build_abi_split() {
    log_info "开始架构分割构建..."
    
    # 默认架构
    local abis=("arm64-v8a" "armeabi-v7a" "x86_64")
    
    # 如果配置中有定义，使用配置中的架构
    if [ ! -z "$CONFIG_abi_include" ]; then
        IFS=' ' read -ra abis <<< "$CONFIG_abi_include"
    fi
    
    for abi in "${abis[@]}"; do
        log_info "构建架构: $abi"
        
        # 构建命令
        local output_file="$OUTPUT_DIR/abi/${PROJECT_NAME}-${abi}.apk"
        flutter build apk --release --target-platform android-$abi --split-per-abi
        
        # 移动文件
        local built_file="build/app/outputs/flutter-apk/app-release.apk"
        if [ -f "$built_file" ]; then
            mv "$built_file" "$output_file"
            log_success "架构APK构建完成: $output_file"
            
            # 显示文件大小
            local size=$(du -h "$output_file" | cut -f1)
            log_info "APK大小: $size"
        else
            log_error "构建失败: $built_file 不存在"
        fi
    done
}

# 屏幕密度分割构建
build_density_split() {
    log_info "开始屏幕密度分割构建..."
    
    # 默认密度
    local densities=("hdpi" "xhdpi" "xxhdpi" "xxxhdpi")
    
    # 如果配置中有定义，使用配置中的密度
    if [ ! -z "$CONFIG_density_include" ]; then
        IFS=' ' read -ra densities <<< "$CONFIG_density_include"
    fi
    
    for density in "${densities[@]}"; do
        log_info "构建密度: $density"
        
        # 临时修改资源
        local temp_res_dir="$BUILD_DIR/temp_res_$density"
        mkdir -p "$temp_res_dir"
        
        # 构建命令（这里需要根据实际Flutter版本调整）
        local output_file="$OUTPUT_DIR/density/${PROJECT_NAME}-${density}.apk"
        
        # 由于Flutter当前不直接支持密度分割，我们构建通用APK
        flutter build apk --release
        local built_file="build/app/outputs/flutter-apk/app-release.apk"
        
        if [ -f "$built_file" ]; then
            # 重命名为密度特定名称
            cp "$built_file" "$output_file"
            log_success "密度APK构建完成: $output_file"
            
            # 显示文件大小
            local size=$(du -h "$output_file" | cut -f1)
            log_info "APK大小: $size"
        else
            log_error "构建失败: $built_file 不存在"
        fi
        
        # 清理临时目录
        rm -rf "$temp_res_dir"
    done
}

# 版本变体构建
build_variants() {
    log_info "开始版本变体构建..."
    
    # 获取配置中的变体
    local variants=("debug" "release")
    
    # 如果配置中有定义，使用配置中的变体
    if [ ! -z "$CONFIG_version_name" ]; then
        IFS=' ' read -ra variants <<< "$CONFIG_version_name"
    fi
    
    for variant in "${variants[@]}"; do
        log_info "构建变体: $variant"
        
        local output_file="$OUTPUT_DIR/variant/${PROJECT_NAME}-${variant}.apk"
        
        case $variant in
            "debug")
                flutter build apk --debug
                ;;
            "profile")
                flutter build apk --profile
                ;;
            "release"|*)
                flutter build apk --release
                ;;
        esac
        
        # 移动文件
        local built_file="build/app/outputs/flutter-apk/app-${variant}.apk"
        if [ -f "$built_file" ]; then
            mv "$built_file" "$output_file"
            log_success "变体APK构建完成: $output_file"
            
            # 显示文件大小
            local size=$(du -h "$output_file" | cut -f1)
            log_info "APK大小: $size"
        else
            log_error "构建失败: $built_file 不存在"
        fi
    done
}

# 统一APK构建
build_universal() {
    log_info "构建统一APK..."
    
    flutter build apk --release
    local built_file="build/app/outputs/flutter-apk/app-release.apk"
    local output_file="$OUTPUT_DIR/${PROJECT_NAME}-universal.apk"
    
    if [ -f "$built_file" ]; then
        mv "$built_file" "$output_file"
        log_success "统一APK构建完成: $output_file"
        
        # 显示文件大小
        local size=$(du -h "$output_file" | cut -f1)
        log_info "APK大小: $size"
    else
        log_error "统一APK构建失败"
        return 1
    fi
}

# APK优化
optimize_apk() {
    local apk_file=$1
    
    if [ ! -f "$apk_file" ]; then
        log_error "APK文件不存在: $apk_file"
        return 1
    fi
    
    log_info "优化APK: $apk_file"
    
    # 获取优化前大小
    local original_size=$(stat -f%z "$apk_file" 2>/dev/null || stat -c%s "$apk_file" 2>/dev/null)
    
    # zipalign优化
    if command -v zipalign &> /dev/null; then
        zipalign -v 4 "$apk_file" "${apk_file%.apk}-aligned.apk"
        mv "${apk_file%.apk}-aligned.apk" "$apk_file"
        log_info "zipalign优化完成"
    fi
    
    # 重新签名（如果需要）
    if [ -f "$HOME/.android/debug.keystore" ] && command -v apksigner &> /dev/null; then
        apksigner sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "${apk_file%.apk}-signed.apk" "$apk_file"
        mv "${apk_file%.apk}-signed.apk" "$apk_file"
        log_info "APK重新签名完成"
    fi
    
    # 获取优化后大小
    local optimized_size=$(stat -f%z "$apk_file" 2>/dev/null || stat -c%s "$apk_file" 2>/dev/null)
    
    if [ $optimized_size -lt $original_size ]; then
        local savings=$((original_size - optimized_size))
        local percentage=$((savings * 100 / original_size))
        log_success "APK优化完成: 节省 $savings bytes ($percentage%)"
    fi
}

# 生成APK清单
generate_apk_list() {
    local list_file="$OUTPUT_DIR/apk_manifest.json"
    
    log_info "生成APK清单..."
    
    cat > "$list_file" << EOF
{
  "project_name": "$PROJECT_NAME",
  "build_time": "$(date -Iseconds)",
  "flutter_version": "$(flutter --version | head -n1)",
  "apks": [
EOF
    
    local first=true
    
    # 遍历所有APK文件
    find "$OUTPUT_DIR" -name "*.apk" -type f | while read -r apk; do
        local relative_path=$(realpath --relative-to="$OUTPUT_DIR" "$apk")
        local filename=$(basename "$apk")
        local size=$(stat -f%z "$apk" 2>/dev/null || stat -c%s "$apk" 2>/dev/null)
        local md5=$(md5sum "$apk" 2>/dev/null | cut -d' ' -f1)
        
        # 添加逗号（除了第一个）
        if [ "$first" = true ]; then
            first=false
        else
            echo "," >> "$list_file"
        fi
        
        cat >> "$list_file" << EOF
    {
      "name": "$filename",
      "path": "$relative_path",
      "size": $size,
      "size_human": "$(du -h "$apk" | cut -f1)",
      "md5": "$md5",
      "type": "$(dirname "$relative_path" | sed 's|/.*||')"
    }
EOF
    done
    
    echo "" >> "$list_file"
    cat >> "$list_file" << EOF
  ]
}
EOF
    
    log_success "APK清单已生成: $list_file"
}

# 生成构建报告
generate_report() {
    local report_file="$OUTPUT_DIR/build_report.txt"
    
    log_info "生成构建报告..."
    
    {
        echo "=================================================="
        echo "多APK分割构建报告"
        echo "=================================================="
        echo "项目名称: $PROJECT_NAME"
        echo "构建时间: $(date)"
        echo "Flutter版本: $(flutter --version | head -n1)"
        echo "Dart版本: $(dart --version)"
        echo ""
        
        echo "构建文件统计:"
        echo "----------------------------------------"
        local total_files=$(find "$OUTPUT_DIR" -name "*.apk" | wc -l)
        local total_size=$(find "$OUTPUT_DIR" -name "*.apk" -exec stat -f%z {} + 2>/dev/null | awk '{sum += $1} END {print sum}')
        local total_size_human=$(du -sh "$OUTPUT_DIR" 2>/dev/null | cut -f1)
        
        echo "APK文件总数: $total_files"
        echo "总大小: $total_size bytes ($total_size_human)"
        echo ""
        
        echo "文件详情:"
        echo "----------------------------------------"
        find "$OUTPUT_DIR" -name "*.apk" -type f | while read -r apk; do
            local filename=$(basename "$apk")
            local size=$(stat -f%z "$apk" 2>/dev/null || stat -c%s "$apk" 2>/dev/null)
            local size_human=$(du -h "$apk" | cut -f1)
            local relative_path=$(realpath --relative-to="$OUTPUT_DIR" "$apk")
            echo "$relative_path: $size bytes ($size_human)"
        done
        
        echo ""
        echo "推荐下载策略:"
        echo "----------------------------------------"
        echo "• arm64-v8a: 现代Android设备（推荐）"
        echo "• armeabi-v7a: 较老Android设备"
        echo "• universal: 所有设备（文件较大）"
        
    } > "$report_file"
    
    log_success "构建报告已生成: $report_file"
}

# 主函数
main() {
    local action=$1
    
    case $action in
        "all")
            check_flutter
            load_config
            setup_directories
            
            # 构建所有类型
            build_abi_split
            build_density_split
            build_variants
            build_universal
            
            # 优化所有APK
            log_info "优化所有APK文件..."
            find "$OUTPUT_DIR" -name "*.apk" -type f | while read -r apk; do
                optimize_apk "$apk"
            done
            
            generate_apk_list
            generate_report
            
            log_success "多APK分割构建完成"
            ;;
        "abi")
            check_flutter
            load_config
            setup_directories
            build_abi_split
            
            # 优化架构APK
            find "$OUTPUT_DIR/abi" -name "*.apk" -type f | while read -r apk; do
                optimize_apk "$apk"
            done
            
            generate_report
            ;;
        "density")
            check_flutter
            load_config
            setup_directories
            build_density_split
            
            # 优化密度APK
            find "$OUTPUT_DIR/density" -name "*.apk" -type f | while read -r apk; do
                optimize_apk "$apk"
            done
            
            generate_report
            ;;
        "variant")
            check_flutter
            load_config
            setup_directories
            build_variants
            
            # 优化变体APK
            find "$OUTPUT_DIR/variant" -name "*.apk" -type f | while read -r apk; do
                optimize_apk "$apk"
            done
            
            generate_report
            ;;
        "universal")
            check_flutter
            load_config
            setup_directories
            build_universal
            optimize_apk "$OUTPUT_DIR/${PROJECT_NAME}-universal.apk"
            generate_report
            ;;
        *)
            echo "用法: $0 {all|abi|density|variant|universal}"
            echo ""
            echo "命令说明:"
            echo "  all      - 构建所有类型的分割APK"
            echo "  abi      - 构建架构分割APK"
            echo "  density  - 构建密度分割APK"
            echo "  variant  - 构建版本变体APK"
            echo "  universal- 构建统一APK"
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"