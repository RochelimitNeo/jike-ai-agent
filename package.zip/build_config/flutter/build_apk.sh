#!/bin/bash
# Flutter APK构建脚本

set -e

# 配置变量
PROJECT_NAME="jike_ai_agent"
BUILD_DIR="build"
OUTPUT_DIR="build/outputs/apk"
RELEASE_DIR="release"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 清理函数
clean_build() {
    log_info "清理构建目录..."
    flutter clean
    flutter pub get
    rm -rf $BUILD_DIR
    rm -rf $OUTPUT_DIR
    mkdir -p $OUTPUT_DIR
}

# 依赖检查
check_dependencies() {
    log_info "检查构建依赖..."
    
    if ! command -v flutter &> /dev/null; then
        log_error "Flutter未安装或未配置到PATH"
        exit 1
    fi
    
    if ! command -v java &> /dev/null; then
        log_error "Java未安装"
        exit 1
    fi
    
    log_success "依赖检查通过"
}

# 资源优化
optimize_resources() {
    log_info "优化应用资源..."
    
    # 压缩图片资源
    find assets/ -type f \( -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" \) -exec pngquant --force --output {} {} \;
    
    # 转换WebP格式（如果支持）
    for img in assets/images/*.png; do
        if [[ -f "$img" ]]; then
            cwebp -q 85 "$img" -o "${img%.png}.webp" 2>/dev/null || true
        fi
    done
    
    log_success "资源优化完成"
}

# 构建APK
build_apk() {
    local BUILD_TYPE=$1
    local ARCH=$2
    local OUTPUT_FILE=""
    
    case $BUILD_TYPE in
        "debug")
            log_info "构建Debug APK..."
            OUTPUT_FILE="$OUTPUT_DIR/${PROJECT_NAME}-debug-$ARCH.apk"
            flutter build apk --debug --target-platform android-$ARCH
            ;;
        "profile")
            log_info "构建Profile APK..."
            OUTPUT_FILE="$OUTPUT_DIR/${PROJECT_NAME}-profile-$ARCH.apk"
            flutter build apk --profile --target-platform android-$ARCH
            ;;
        "release")
            log_info "构建Release APK..."
            OUTPUT_FILE="$OUTPUT_DIR/${PROJECT_NAME}-release-$ARCH.apk"
            flutter build apk --release --target-platform android-$ARCH --obfuscate --split-debug-info=build/debug-info/
            ;;
        *)
            log_error "未知的构建类型: $BUILD_TYPE"
            exit 1
            ;;
    esac
    
    # 移动文件到输出目录
    mv build/app/outputs/flutter-apk/app-$BUILD_TYPE.apk "$OUTPUT_FILE"
    log_success "APK构建完成: $OUTPUT_FILE"
}

# 分割APK构建
build_split_apk() {
    log_info "开始构建分割APK..."
    
    for arch in arm64-v8a armeabi-v7a x86_64; do
        log_info "构建架构: $arch"
        build_apk "release" "$arch"
    done
}

# 统一APK构建
build_unified_apk() {
    log_info "开始构建统一APK..."
    flutter build apk --release --split-per-abi
    mv build/app/outputs/flutter-apk/app-release.apk "$OUTPUT_DIR/${PROJECT_NAME}-universal-release.apk"
    log_success "统一APK构建完成"
}

# APK优化
optimize_apk() {
    local apk_file=$1
    
    if [[ ! -f "$apk_file" ]]; then
        log_error "APK文件不存在: $apk_file"
        return 1
    fi
    
    log_info "优化APK: $apk_file"
    
    # 获取APK信息
    local size_before=$(du -h "$apk_file" | cut -f1)
    log_info "优化前大小: $size_before"
    
    # 使用zipalign优化
    zipalign -v 4 "$apk_file" "${apk_file%.apk}-aligned.apk"
    mv "${apk_file%.apk}-aligned.apk" "$apk_file"
    
    # 使用apksigner签名
    if command -v apksigner &> /dev/null; then
        log_info "重新签名APK..."
        apksigner sign --ks ~/.android/debug.keystore --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "${apk_file%.apk}-signed.apk" "$apk_file"
        mv "${apk_file%.apk}-signed.apk" "$apk_file"
    fi
    
    local size_after=$(du -h "$apk_file" | cut -f1)
    log_info "优化后大小: $size_after"
    log_success "APK优化完成"
}

# 生成构建报告
generate_report() {
    log_info "生成构建报告..."
    
    local report_file="$OUTPUT_DIR/build-report-$(date +%Y%m%d-%H%M%S).txt"
    
    {
        echo "==================================="
        echo "Flutter APK构建报告"
        echo "==================================="
        echo "构建时间: $(date)"
        echo "Flutter版本: $(flutter --version | head -n 1)"
        echo "Dart版本: $(dart --version)"
        echo ""
        echo "构建文件:"
        ls -la "$OUTPUT_DIR"
        echo ""
        echo "APK详情:"
        for apk in "$OUTPUT_DIR"/*.apk; do
            if [[ -f "$apk" ]]; then
                echo "文件: $(basename "$apk")"
                echo "大小: $(du -h "$apk" | cut -f1)"
                echo "MD5: $(md5sum "$apk" | cut -d' ' -f1)"
                echo "---"
            fi
        done
    } > "$report_file"
    
    log_success "构建报告已生成: $report_file"
}

# 主函数
main() {
    local action=$1
    
    case $action in
        "clean")
            clean_build
            ;;
        "debug")
            check_dependencies
            clean_build
            optimize_resources
            build_apk "debug" "arm64-v8a"
            generate_report
            ;;
        "profile")
            check_dependencies
            clean_build
            optimize_resources
            build_apk "profile" "arm64-v8a"
            generate_report
            ;;
        "split")
            check_dependencies
            clean_build
            optimize_resources
            build_split_apk
            # 优化每个APK
            for apk in "$OUTPUT_DIR"/*release*.apk; do
                if [[ -f "$apk" ]]; then
                    optimize_apk "$apk"
                fi
            done
            generate_report
            ;;
        "unified")
            check_dependencies
            clean_build
            optimize_resources
            build_unified_apk
            optimize_apk "$OUTPUT_DIR/${PROJECT_NAME}-universal-release.apk"
            generate_report
            ;;
        "full")
            check_dependencies
            clean_build
            optimize_resources
            build_unified_apk
            build_split_apk
            # 优化所有APK
            for apk in "$OUTPUT_DIR"/*.apk; do
                if [[ -f "$apk" ]]; then
                    optimize_apk "$apk"
                fi
            done
            generate_report
            ;;
        *)
            echo "用法: $0 {clean|debug|profile|split|unified|full}"
            echo ""
            echo "命令说明:"
            echo "  clean   - 清理构建目录"
            echo "  debug   - 构建Debug APK"
            echo "  profile - 构建Profile APK"
            echo "  split   - 构建分割APK（按架构）"
            echo "  unified - 构建统一APK"
            echo "  full    - 构建所有类型APK"
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"