#!/bin/bash
# 资源优化脚本
# 用于优化APK中的各种资源

set -e

# 配置变量
PROJECT_DIR="$(pwd)"
ASSETS_DIR="$PROJECT_DIR/assets"
BUILD_DIR="$PROJECT_DIR/build"
RESOURCES_DIR="$PROJECT_DIR/android/app/src/main/res"
OUTPUT_DIR="$BUILD_DIR/optimized_resources"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查工具依赖
check_dependencies() {
    log_info "检查资源优化工具..."
    
    local missing_tools=()
    
    # 检查PNG工具
    if ! command -v pngquant &> /dev/null; then
        missing_tools+=("pngquant")
    fi
    
    # 检查JPEG工具
    if ! command -v jpegoptim &> /dev/null; then
        missing_tools+=("jpegoptim")
    fi
    
    # 检查WebP工具
    if ! command -v cwebp &> /dev/null; then
        missing_tools+=("webp")
    fi
    
    # 检查SVG工具
    if ! command -v svgo &> /dev/null; then
        missing_tools+=("svgo")
    fi
    
    # 检查字体工具
    if ! command -v fonttools &> /dev/null; then
        missing_tools+=("fonttools")
    fi
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        log_warning "缺少以下工具: ${missing_tools[*]}"
        log_info "安装命令: brew install ${missing_tools[*]}"
    else
        log_success "所有工具检查通过"
    fi
}

# 创建输出目录
setup_directories() {
    log_info "创建优化目录..."
    
    mkdir -p "$OUTPUT_DIR"
    mkdir -p "$OUTPUT_DIR/images"
    mkdir -p "$OUTPUT_DIR/fonts"
    mkdir -p "$OUTPUT_DIR/audio"
    mkdir -p "$OUTPUT_DIR/video"
    mkdir -p "$OUTPUT_DIR/other"
    
    log_success "目录创建完成"
}

# PNG优化
optimize_png() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "优化PNG图片..."
    
    find "$source_dir" -name "*.png" -type f | while read -r file; do
        local filename=$(basename "$file")
        local output_file="$output_dir/$filename"
        
        # PNG量化压缩
        if pngquant --force --ext .png -- "$file" 2>/dev/null; then
            log_info "压缩PNG: $filename"
        fi
        
        # 复制到输出目录
        cp "$file" "$output_file"
        
        # 显示文件大小变化
        local original_size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
        local optimized_size=$(stat -f%z "$output_file" 2>/dev/null || stat -c%s "$output_file" 2>/dev/null)
        local savings=$((original_size - optimized_size))
        
        if [ $savings -gt 0 ]; then
            local percentage=$((savings * 100 / original_size))
            log_info "  $filename: ${original_size} bytes -> ${optimized_size} bytes (${percentage}% 节省)"
        fi
    done
}

# JPEG优化
optimize_jpeg() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "优化JPEG图片..."
    
    find "$source_dir" -name "*.jpg" -o -name "*.jpeg" | while read -r file; do
        local filename=$(basename "$file")
        local output_file="$output_dir/${filename%.*}.jpg"
        
        # JPEG优化
        if jpegoptim --max=85 --strip-all --all-progressive --dest="$output_dir" "$file" 2>/dev/null; then
            log_info "优化JPEG: $filename"
        fi
    done
}

# WebP转换
convert_to_webp() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "转换为WebP格式..."
    
    find "$source_dir" -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" | while read -r file; do
        local filename=$(basename "$file")
        local name_without_ext="${filename%.*}"
        local webp_file="$output_dir/${name_without_ext}.webp"
        
        # 转换为WebP
        if cwebp -q 85 "$file" -o "$webp_file" 2>/dev/null; then
            local original_size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
            local webp_size=$(stat -f%z "$webp_file" 2>/dev/null || stat -c%s "$webp_file" 2>/dev/null)
            local savings=$((original_size - webp_size))
            
            if [ $savings -gt 0 ]; then
                local percentage=$((savings * 100 / original_size))
                log_info "  WebP转换: $filename -> ${name_without_ext}.webp (${percentage}% 节省)"
            fi
        fi
    done
}

# SVG优化
optimize_svg() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "优化SVG文件..."
    
    find "$source_dir" -name "*.svg" | while read -r file; do
        local filename=$(basename "$file")
        local output_file="$output_dir/$filename"
        
        # 使用svgo优化SVG
        if command -v svgo &> /dev/null; then
            svgo --config='{"plugins": [{"name": "preset-default"}, {"name": "removeDimensions"}]}' -i "$file" -o "$output_file" 2>/dev/null
            log_info "优化SVG: $filename"
        else
            # 如果没有svgo，直接复制
            cp "$file" "$output_file"
        fi
    done
}

# 字体优化
optimize_fonts() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "优化字体文件..."
    
    find "$source_dir" -name "*.ttf" -o -name "*.otf" | while read -r file; do
        local filename=$(basename "$file")
        local output_file="$output_dir/$filename"
        
        # 使用pyftsubset进行字体子集化（如果字体工具可用）
        if command -v pyftsubset &> /dev/null; then
            # 提取常用字符
            pyftsubset "$file" \
                --text="一二三四五六七八九十百千万亿零一二三四五六七八九十百千万亿零ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789" \
                --output-file="$output_file"
            log_info "字体子集化: $filename"
        else
            # 如果没有字体工具，直接复制
            cp "$file" "$output_file"
            log_info "复制字体: $filename"
        fi
    done
}

# 音频优化
optimize_audio() {
    local source_dir=$1
    local output_dir=$2
    
    log_info "优化音频文件..."
    
    find "$source_dir" -name "*.mp3" -o -name "*.wav" -o -name "*.m4a" | while read -r file; do
        local filename=$(basename "$file")
        local output_file="$output_dir/${filename%.*}.opus"
        
        # 使用ffmpeg转换为Opus格式（如果可用）
        if command -v ffmpeg &> /dev/null; then
            ffmpeg -i "$file" -c:a libopus -b:a 64k -ar 22050 "$output_file" -y 2>/dev/null
            log_info "音频转换: $filename -> ${filename%.*}.opus"
        else
            # 如果没有ffmpeg，复制原始文件
            cp "$file" "$output_dir/$filename"
        fi
    done
}

# 移除未使用资源
remove_unused_resources() {
    log_info "检测未使用的资源..."
    
    # 这里可以实现资源使用分析逻辑
    # 例如，分析代码中对资源的引用，删除未使用的资源文件
    
    log_success "资源使用分析完成"
}

# 生成资源报告
generate_report() {
    local report_file="$OUTPUT_DIR/resource_optimization_report.txt"
    
    log_info "生成优化报告..."
    
    {
        echo "========================================="
        echo "资源优化报告"
        echo "========================================="
        echo "优化时间: $(date)"
        echo ""
        echo "优化前后对比:"
        echo ""
        
        # 图片统计
        local original_images=$(find "$ASSETS_DIR" -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" | wc -l)
        local optimized_images=$(find "$OUTPUT_DIR/images" -name "*.png" -o -name "*.jpg" -o -name "*.webp" | wc -l)
        echo "图片文件: $original_images -> $optimized_images"
        
        # 文件大小统计
        local original_size=$(du -sh "$ASSETS_DIR" 2>/dev/null | cut -f1)
        local optimized_size=$(du -sh "$OUTPUT_DIR" 2>/dev/null | cut -f1)
        echo "总大小: $original_size -> $optimized_size"
        
        echo ""
        echo "详细文件列表:"
        echo "-----------------------------------------"
        find "$OUTPUT_DIR" -type f -exec ls -lh {} \; | awk '{print $9 ": " $5}'
        
    } > "$report_file"
    
    log_success "优化报告已生成: $report_file"
}

# 主函数
main() {
    local action=$1
    
    case $action in
        "all")
            check_dependencies
            setup_directories
            
            # 优化各类资源
            optimize_png "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            optimize_jpeg "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            convert_to_webp "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            optimize_svg "$ASSETS_DIR/icons" "$OUTPUT_DIR/images"
            optimize_fonts "$ASSETS_DIR/fonts" "$OUTPUT_DIR/fonts"
            optimize_audio "$ASSETS_DIR/audio" "$OUTPUT_DIR/audio"
            
            remove_unused_resources
            generate_report
            
            log_success "所有资源优化完成"
            ;;
        "png")
            check_dependencies
            setup_directories
            optimize_png "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            ;;
        "jpeg")
            check_dependencies
            setup_directories
            optimize_jpeg "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            ;;
        "webp")
            check_dependencies
            setup_directories
            convert_to_webp "$ASSETS_DIR/images" "$OUTPUT_DIR/images"
            ;;
        "fonts")
            check_dependencies
            setup_directories
            optimize_fonts "$ASSETS_DIR/fonts" "$OUTPUT_DIR/fonts"
            ;;
        "audio")
            check_dependencies
            setup_directories
            optimize_audio "$ASSETS_DIR/audio" "$OUTPUT_DIR/audio"
            ;;
        *)
            echo "用法: $0 {all|png|jpeg|webp|fonts|audio}"
            echo ""
            echo "命令说明:"
            echo "  all   - 优化所有资源"
            echo "  png   - 优化PNG图片"
            echo "  jpeg  - 优化JPEG图片"
            echo "  webp  - 转换为WebP格式"
            echo "  fonts - 优化字体文件"
            echo "  audio - 优化音频文件"
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"