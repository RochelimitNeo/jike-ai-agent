#!/bin/bash
# APK构建系统快速安装脚本

set -e

# 配置变量
INSTALL_DIR="$(pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SYSTEM_TYPE=$(uname -s)

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_header() {
    echo -e "${PURPLE}[SETUP]${NC} $1"
}

# 显示欢迎信息
show_welcome() {
    cat << 'EOF'
╔══════════════════════════════════════╗
║        APK构建系统安装向导            ║
║    Flutter/Android APK Build System  ║
║                                      ║
║  自动化构建 | 优化 | 分割 | 部署     ║
╚══════════════════════════════════════╝

欢迎使用APK构建系统！

此安装程序将帮助您：
✓ 配置Flutter开发环境
✓ 安装Android SDK工具
✓ 设置构建优化工具
✓ 配置APK分割和优化
✓ 设置CI/CD集成

开始安装...
EOF
}

# 检查操作系统
check_os() {
    log_header "检查操作系统"
    
    case "$SYSTEM_TYPE" in
        "Darwin")
            log_success "检测到macOS系统"
            OS_TYPE="macos"
            PACKAGE_MANAGER="brew"
            ;;
        "Linux")
            log_success "检测到Linux系统"
            OS_TYPE="linux"
            if command -v apt-get &> /dev/null; then
                PACKAGE_MANAGER="apt"
            elif command -v yum &> /dev/null; then
                PACKAGE_MANAGER="yum"
            elif command -v dnf &> /dev/null; then
                PACKAGE_MANAGER="dnf"
            else
                log_error "不支持的Linux发行版"
                exit 1
            fi
            ;;
        *)
            log_error "不支持的操作系统: $SYSTEM_TYPE"
            log_info "请在macOS或Linux系统上运行此脚本"
            exit 1
            ;;
    esac
}

# 检查依赖
check_dependencies() {
    log_header "检查基础依赖"
    
    local missing_deps=()
    
    # 检查curl
    if ! command -v curl &> /dev/null; then
        missing_deps+=("curl")
    fi
    
    # 检查git
    if ! command -v git &> /dev/null; then
        missing_deps+=("git")
    fi
    
    # 检查unzip
    if ! command -v unzip &> /dev/null; then
        missing_deps+=("unzip")
    fi
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        log_warning "缺少基础依赖: ${missing_deps[*]}"
        log_info "正在自动安装..."
        install_basic_dependencies
    else
        log_success "基础依赖检查通过"
    fi
}

# 安装基础依赖
install_basic_dependencies() {
    case $PACKAGE_MANAGER in
        "brew")
            if ! command -v brew &> /dev/null; then
                log_info "安装Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            
            for dep in "${missing_deps[@]}"; do
                case $dep in
                    "curl"|"git"|"unzip")
                        brew install "$dep"
                        ;;
                esac
            done
            ;;
        "apt")
            sudo apt-get update
            sudo apt-get install -y "${missing_deps[@]}"
            ;;
        "yum")
            sudo yum install -y "${missing_deps[@]}"
            ;;
        "dnf")
            sudo dnf install -y "${missing_deps[@]}"
            ;;
    esac
    
    log_success "基础依赖安装完成"
}

# 安装Flutter
install_flutter() {
    log_header "安装Flutter"
    
    if command -v flutter &> /dev/null; then
        local flutter_version=$(flutter --version | head -n1)
        log_info "Flutter已安装: $flutter_version"
        return 0
    fi
    
    local flutter_version="3.16.0"
    local flutter_dir="$HOME/flutter"
    
    log_info "下载Flutter $flutter_version..."
    
    if [[ "$SYSTEM_TYPE" == "Darwin" ]]; then
        local flutter_url="https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_${flutter_version}-stable.zip"
    else
        local flutter_url="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${flutter_version}-stable.tar.xz"
    fi
    
    cd "$HOME"
    wget -q "$flutter_url" -O flutter.zip
    
    if [[ "$flutter_url" == *.zip ]]; then
        unzip -q flutter.zip
    else
        tar xf flutter.zip
    fi
    
    rm flutter.zip
    
    # 配置Flutter
    export PATH="$PATH:$flutter_dir/bin"
    echo "export PATH=\"\$PATH:$flutter_dir/bin\"" >> ~/.bashrc
    
    # 接受Android许可证
    flutter doctor --android-licenses || true
    
    log_success "Flutter安装完成"
    
    # 显示安装信息
    log_info "Flutter已添加到PATH，重新打开终端或运行:"
    log_info "  source ~/.bashrc"
}

# 安装Android SDK
install_android_sdk() {
    log_header "安装Android SDK"
    
    if [ -n "$ANDROID_HOME" ] && [ -d "$ANDROID_HOME" ]; then
        log_info "Android SDK已安装: $ANDROID_HOME"
        return 0
    fi
    
    local android_dir="$HOME/android-sdk"
    mkdir -p "$android_dir"
    
    log_info "下载Android Command Line Tools..."
    
    cd "$android_dir"
    
    # 下载最新的Command Line Tools
    if [[ "$SYSTEM_TYPE" == "Darwin" ]]; then
        local cmdtools_url="https://dl.google.com/android/repository/commandlinetools-mac-9477386_latest.zip"
    else
        local cmdtools_url="https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip"
    fi
    
    wget -q "$cmdtools_url" -O cmdtools.zip
    unzip -q cmdtools.zip
    rm cmdtools.zip
    
    # 配置Command Line Tools路径
    mkdir -p cmdline-tools/latest
    mv cmdline-tools/* cmdline-tools/latest/ 2>/dev/null || true
    
    # 设置环境变量
    export ANDROID_HOME="$android_dir"
    export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"
    
    echo "export ANDROID_HOME=\"$android_dir\"" >> ~/.bashrc
    echo "export PATH=\"\$PATH:\$ANDROID_HOME/platform-tools:\$ANDROID_HOME/cmdline-tools/latest/bin\"" >> ~/.bashrc
    
    # 安装必需的SDK组件
    log_info "安装Android SDK组件..."
    yes | sdkmanager --licenses || true
    sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" "ndk;21.1.6352462"
    
    log_success "Android SDK安装完成"
    log_info "Android SDK路径: $android_dir"
}

# 安装Java
install_java() {
    log_header "检查Java环境"
    
    if command -v java &> /dev/null; then
        local java_version=$(java -version 2>&1 | head -n1)
        log_info "Java已安装: $java_version"
        return 0
    fi
    
    case $PACKAGE_MANAGER in
        "brew")
            brew install openjdk@17
            echo 'export PATH="/opt/homebrew/opt/openjdk@17/bin:$PATH"' >> ~/.bashrc
            ;;
        "apt")
            sudo apt-get install -y openjdk-17-jdk
            ;;
        "yum")
            sudo yum install -y java-17-openjdk-devel
            ;;
        "dnf")
            sudo dnf install -y java-17-openjdk-devel
            ;;
    esac
    
    log_success "Java安装完成"
}

# 安装优化工具
install_optimization_tools() {
    log_header "安装APK优化工具"
    
    case $PACKAGE_MANAGER in
        "brew")
            # macOS
            brew install pngquant jpegoptim webp imagemagick
            
            # 安装Node.js和SVG优化工具
            if ! command -v node &> /dev/null; then
                brew install node
            fi
            npm install -g svgo
            ;;
        "apt")
            # Ubuntu/Debian
            sudo apt-get update
            sudo apt-get install -y pngquant jpegoptim webp-tools imagemagick nodejs npm
            
            # 安装SVG优化工具
            npm install -g svgo
            ;;
        "yum")
            # CentOS/RHEL (需要EPEL)
            sudo yum install -y epel-release
            sudo yum install -y pngquant jpegoptim webp-tools ImageMagick nodejs npm
            npm install -g svgo
            ;;
        "dnf")
            # Fedora
            sudo dnf install -y pngquant jpegoptim webp-tools ImageMagick nodejs npm
            npm install -g svgo
            ;;
    esac
    
    log_success "优化工具安装完成"
    
    # 验证工具安装
    local tools=("pngquant" "jpegoptim" "cwebp" "svgo")
    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            log_success "$tool 已安装"
        else
            log_warning "$tool 安装可能失败"
        fi
    done
}

# 安装Docker (可选)
install_docker() {
    log_header "安装Docker (可选)"
    
    read -p "是否安装Docker? (y/n): " install_docker
    
    if [[ $install_docker =~ ^[Yy]$ ]]; then
        case $PACKAGE_MANAGER in
            "brew")
                brew install --cask docker
                ;;
            "apt")
                curl -fsSL https://get.docker.com -o get-docker.sh
                sudo sh get-docker.sh
                rm get-docker.sh
                sudo usermod -aG docker "$USER"
                ;;
            *)
                log_info "请手动安装Docker: https://docs.docker.com/get-docker/"
                ;;
        esac
        
        log_success "Docker安装完成"
        log_info "可能需要重新登录或重启以生效"
    else
        log_info "跳过Docker安装"
    fi
}

# 配置环境变量
configure_environment() {
    log_header "配置环境变量"
    
    local shell_config=""
    
    # 检测shell配置文件
    if [ -n "$BASH_VERSION" ]; then
        if [ -f "$HOME/.bashrc" ]; then
            shell_config="$HOME/.bashrc"
        elif [ -f "$HOME/.bash_profile" ]; then
            shell_config="$HOME/.bash_profile"
        else
            shell_config="$HOME/.bashrc"
        fi
    elif [ -n "$ZSH_VERSION" ]; then
        shell_config="$HOME/.zshrc"
    fi
    
    log_info "更新配置文件: $shell_config"
    
    # 添加Flutter和Android SDK到PATH (如果尚未添加)
    if ! grep -q "flutter/bin" "$shell_config"; then
        echo "" >> "$shell_config"
        echo "# Flutter SDK" >> "$shell_config"
        echo 'export PATH="$PATH:$HOME/flutter/bin"' >> "$shell_config"
    fi
    
    if ! grep -q "android-sdk" "$shell_config"; then
        echo "" >> "$shell_config"
        echo "# Android SDK" >> "$shell_config"
        echo 'export ANDROID_HOME="$HOME/android-sdk"' >> "$shell_config"
        echo 'export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"' >> "$shell_config"
    fi
    
    log_success "环境变量配置完成"
    log_info "请重新打开终端或运行: source $shell_config"
}

# 创建项目结构
setup_project_structure() {
    log_header "设置项目结构"
    
    mkdir -p "$INSTALL_DIR"/{build,reports,gradle-cache,assets}
    mkdir -p "$INSTALL_DIR"/{build/outputs/apk,build/tmp}
    
    # 复制构建配置文件
    cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/build_config/" 2>/dev/null || true
    
    # 设置权限
    chmod +x "$INSTALL_DIR/build_config"/*.sh
    
    log_success "项目结构创建完成"
}

# 验证安装
verify_installation() {
    log_header "验证安装"
    
    local errors=0
    
    # 检查Flutter
    if command -v flutter &> /dev/null; then
        log_success "✓ Flutter: $(flutter --version | head -n1)"
    else
        log_error "✗ Flutter未找到"
        ((errors++))
    fi
    
    # 检查Android SDK
    if [ -n "$ANDROID_HOME" ] && [ -d "$ANDROID_HOME" ]; then
        log_success "✓ Android SDK: $ANDROID_HOME"
    else
        log_error "✗ Android SDK未配置"
        ((errors++))
    fi
    
    # 检查Java
    if command -v java &> /dev/null; then
        log_success "✓ Java: $(java -version 2>&1 | head -n1)"
    else
        log_error "✗ Java未找到"
        ((errors++))
    fi
    
    # 检查优化工具
    local tools=("pngquant" "jpegoptim" "cwebp")
    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            log_success "✓ $tool"
        else
            log_warning "✗ $tool (可选)"
        fi
    done
    
    # 测试Flutter doctor
    log_info "运行Flutter Doctor检查..."
    flutter doctor --android-licenses 2>&1 | grep -E "(✓|✗|X)" | while read -r line; do
        log_info "  $line"
    done
    
    if [ $errors -eq 0 ]; then
        log_success "安装验证通过！"
    else
        log_warning "安装验证发现 $errors 个错误，请检查上述信息"
    fi
}

# 显示完成信息
show_completion() {
    cat << 'EOF'

╔══════════════════════════════════════╗
║           安装完成！ 🎉             ║
╚══════════════════════════════════════╝

APK构建系统已成功安装！

下一步操作：
1. 重新打开终端或运行：
   source ~/.bashrc

2. 进入您的Flutter项目目录：
   cd /path/to/your/flutter/project

3. 初始化构建环境：
   bash build_config/build.sh setup

4. 构建您的第一个APK：
   bash build_config/build.sh build --type=release

可用命令：
• bash build_config/build.sh help        - 显示帮助
• bash build_config/build.sh setup       - 初始化环境
• bash build_config/build.sh build       - 构建APK
• bash build_config/build.sh optimize    - 优化APK
• bash build_config/build.sh multi        - 构建多APK
• bash build_config/build.sh ci          - 配置CI/CD

配置文件位置：
• build_config/                        - 构建配置目录
• build_config/README.md               - 详细文档

技术栈支持：
✓ Flutter 3.16+
✓ Android SDK 34
✓ Java 17
✓ R8/ProGuard混淆
✓ 多架构APK分割
✓ 资源优化
✓ CI/CD集成

享受APK构建的自动化之旅！

EOF
}

# 主安装流程
main() {
    show_welcome
    
    # 检查是否以root用户运行
    if [ "$EUID" -eq 0 ]; then
        log_error "请不要以root用户运行此脚本"
        exit 1
    fi
    
    check_os
    check_dependencies
    install_java
    install_flutter
    install_android_sdk
    install_optimization_tools
    install_docker
    configure_environment
    setup_project_structure
    verify_installation
    show_completion
    
    log_success "APK构建系统安装完成！"
}

# 显示帮助
show_help() {
    cat << EOF
APK构建系统安装脚本

用法: $0 [选项]

选项:
  --help, -h     显示此帮助信息
  --skip-docker  跳过Docker安装
  --verify-only  仅验证当前安装

示例:
  $0              # 完整安装
  $0 --skip-docker # 跳过Docker安装
  $0 --verify-only # 仅验证安装

支持的操作系统:
  • macOS
  • Linux (Ubuntu/Debian/CentOS/Fedora)

EOF
}

# 解析命令行参数
SKIP_DOCKER=false
VERIFY_ONLY=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --help|-h)
            show_help
            exit 0
            ;;
        --skip-docker)
            SKIP_DOCKER=true
            shift
            ;;
        --verify-only)
            VERIFY_ONLY=true
            shift
            ;;
        *)
            log_error "未知参数: $1"
            show_help
            exit 1
            ;;
    esac
done

# 执行主安装流程
if [ "$VERIFY_ONLY" = true ]; then
    verify_installation
else
    main
fi