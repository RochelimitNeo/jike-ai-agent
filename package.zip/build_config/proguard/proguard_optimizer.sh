#!/bin/bash
# ProGuard代码混淆和优化脚本

set -e

# 配置变量
PROJECT_DIR="$(pwd)"
BUILD_DIR="$PROJECT_DIR/build"
OUTPUT_DIR="$BUILD_DIR/proguard"
MAPPING_DIR="$OUTPUT_DIR/mapping"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查ProGuard工具
check_proguard() {
    log_info "检查ProGuard工具..."
    
    # 检查Android SDK中的ProGuard
    if [ -z "$ANDROID_HOME" ]; then
        log_warning "ANDROID_HOME未设置，尝试查找系统中的ProGuard"
    fi
    
    # 查找proguard.jar
    local proguard_jar=""
    
    if [ ! -z "$ANDROID_HOME" ]; then
        proguard_jar=$(find "$ANDROID_HOME" -name "proguard*.jar" 2>/dev/null | head -n 1)
    fi
    
    if [ -z "$proguard_jar" ] && command -v proguard &> /dev/null; then
        proguard_jar=$(which proguard)
    fi
    
    if [ -z "$proguard_jar" ]; then
        log_error "未找到ProGuard工具"
        log_info "请安装Android SDK Tools或设置ANDROID_HOME环境变量"
        return 1
    fi
    
    echo "PROGUARD_JAR=$proguard_jar" > "$OUTPUT_DIR/proguard_config.env"
    log_success "ProGuard工具找到: $proguard_jar"
    return 0
}

# 创建输出目录
setup_directories() {
    log_info "创建ProGuard输出目录..."
    
    mkdir -p "$OUTPUT_DIR"
    mkdir -p "$MAPPING_DIR"
    mkdir -p "$OUTPUT_DIR/reports"
    
    log_success "目录创建完成"
}

# 生成ProGuard配置
generate_config() {
    local config_file="$OUTPUT_DIR/generated_proguard.txt"
    
    log_info "生成ProGuard配置..."
    
    cat > "$config_file" << 'EOF'
# Generated ProGuard Configuration
# 自动生成于 $(date)

# 基本优化设置
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
-optimizations !code/simplification/arithmetic,!field/*,!class/merging/*

# 保留关键类
-keep public class * extends android.app.Application
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Fragment
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# 保留Parcelable
-keepclassmembers class * implements android.os.Parcelable {
  public static final android.os.Parcelable$Creator CREATOR;
}

# 保留枚举
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# 保留native方法
-keepclasseswithmembernames class * {
    native <methods>;
}

# Flutter应用特定保留
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }
-keep class com.example.jike_ai_agent.** { *; }

# 保留反射和注解
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes SourceFile,LineNumberTable

# 第三方库保留
-keep class com.google.gson.** { *; }
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }
-keep class okio.** { *; }
-keep class android.security.keystore.** { *; }
-keep class androidx.multidex.** { *; }

# 移除调试信息
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
}

# 高级优化
-allowaccessmodification
-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*
-dontpreverify

# 输出配置
-printmapping mapping.txt
-printseeds seeds.txt
-printusage usage.txt
EOF
    
    log_success "ProGuard配置已生成: $config_file"
}

# 执行ProGuard优化
run_proguard() {
    local input_jar=$1
    local output_jar=$2
    local config_file=$3
    
    if [ ! -f "$input_jar" ]; then
        log_error "输入JAR文件不存在: $input_jar"
        return 1
    fi
    
    log_info "执行ProGuard优化..."
    
    # 加载ProGuard配置
    source "$OUTPUT_DIR/proguard_config.env"
    
    # 执行ProGuard
    java -jar "$PROGUARD_JAR" \
        -injars "$input_jar" \
        -outjars "$output_jar" \
        "@$config_file" \
        "@$PROJECT_DIR/build_config/proguard/proguard-rules.pro" \
        -libraryjars "$ANDROID_HOME/platforms/android-*/android.jar"
    
    if [ $? -eq 0 ]; then
        log_success "ProGuard优化完成"
        
        # 显示优化统计
        local original_size=$(stat -f%z "$input_jar" 2>/dev/null || stat -c%s "$input_jar" 2>/dev/null)
        local optimized_size=$(stat -f%z "$output_jar" 2>/dev/null || stat -c%s "$output_jar" 2>/dev/null)
        local savings=$((original_size - optimized_size))
        
        if [ $savings -gt 0 ]; then
            local percentage=$((savings * 100 / original_size))
            log_info "优化结果: ${original_size} bytes -> ${optimized_size} bytes (${percentage}% 节省)"
        fi
        
        return 0
    else
        log_error "ProGuard优化失败"
        return 1
    fi
}

# 分析优化结果
analyze_results() {
    local mapping_dir=$1
    
    log_info "分析优化结果..."
    
    # 检查映射文件
    if [ -f "$mapping_dir/mapping.txt" ]; then
        log_success "映射文件已生成: $mapping_dir/mapping.txt"
        
        # 统计混淆的类数量
        local obfuscated_classes=$(grep -c "^[a-z]" "$mapping_dir/mapping.txt" 2>/dev/null || echo "0")
        log_info "混淆的类数量: $obfuscated_classes"
    fi
    
    # 检查种子文件
    if [ -f "$mapping_dir/seeds.txt" ]; then
        log_success "种子文件已生成: $mapping_dir/seeds.txt"
        
        # 统计保留的类数量
        local kept_classes=$(grep -c "^[a-zA-Z]" "$mapping_dir/seeds.txt" 2>/dev/null || echo "0")
        log_info "保留的类数量: $kept_classes"
    fi
    
    # 检查使用文件
    if [ -f "$mapping_dir/usage.txt" ]; then
        log_success "使用文件已生成: $mapping_dir/usage.txt"
        
        # 检查是否有未使用的代码被移除
        local removed_code=$(grep -c "was removed" "$mapping_dir/usage.txt" 2>/dev/null || echo "0")
        log_info "移除的代码条目: $removed_code"
    fi
}

# 生成优化报告
generate_report() {
    local report_file="$OUTPUT_DIR/proguard_optimization_report.txt"
    
    log_info "生成优化报告..."
    
    {
        echo "============================================"
        echo "ProGuard代码混淆和优化报告"
        echo "============================================"
        echo "优化时间: $(date)"
        echo "ProGuard版本: $(java -jar $(find $ANDROID_HOME -name 'proguard*.jar' | head -n1) 2>/dev/null | grep -o 'ProGuard version [0-9.]*' || echo 'Unknown')"
        echo ""
        
        echo "输入文件:"
        ls -la "$BUILD_DIR"/*.apk 2>/dev/null || echo "未找到APK文件"
        echo ""
        
        echo "输出文件:"
        ls -la "$OUTPUT_DIR"/*.jar 2>/dev/null || echo "未找到优化后的JAR文件"
        echo ""
        
        echo "映射文件:"
        ls -la "$MAPPING_DIR"/*.txt 2>/dev/null || echo "未找到映射文件"
        echo ""
        
        echo "文件大小对比:"
        if [ -f "$BUILD_DIR/classes.jar" ] && [ -f "$OUTPUT_DIR/classes-optimized.jar" ]; then
            local original=$(stat -f%z "$BUILD_DIR/classes.jar" 2>/dev/null || stat -c%s "$BUILD_DIR/classes.jar" 2>/dev/null)
            local optimized=$(stat -f%z "$OUTPUT_DIR/classes-optimized.jar" 2>/dev/null || stat -c%s "$OUTPUT_DIR/classes-optimized.jar" 2>/dev/null)
            echo "  原始JAR: $original bytes"
            echo "  优化JAR: $optimized bytes"
            
            if [ $optimized -gt 0 ]; then
                local savings=$((original - optimized))
                local percentage=$((savings * 100 / original))
                echo "  节省: $savings bytes ($percentage%)"
            fi
        fi
        
        echo ""
        echo "优化详情:"
        echo "-----------------------------------------"
        
        # 统计映射信息
        if [ -f "$MAPPING_DIR/mapping.txt" ]; then
            local obfuscated=$(grep -c "^[a-z]" "$MAPPING_DIR/mapping.txt" 2>/dev/null || echo "0")
            echo "混淆的类: $obfuscated"
        fi
        
        if [ -f "$MAPPING_DIR/seeds.txt" ]; then
            local kept=$(grep -c "^[a-zA-Z]" "$MAPPING_DIR/seeds.txt" 2>/dev/null || echo "0")
            echo "保留的类: $kept"
        fi
        
        if [ -f "$MAPPING_DIR/usage.txt" ]; then
            local removed=$(grep -c "was removed" "$MAPPING_DIR/usage.txt" 2>/dev/null || echo "0")
            echo "移除的代码条目: $removed"
        fi
        
    } > "$report_file"
    
    log_success "优化报告已生成: $report_file"
}

# 主函数
main() {
    local action=$1
    
    case $action in
        "config")
            setup_directories
            if check_proguard; then
                generate_config
                log_success "ProGuard配置完成"
            else
                log_error "ProGuard工具检查失败"
                exit 1
            fi
            ;;
        "optimize")
            local input_jar=${2:-$BUILD_DIR/classes.jar}
            local output_jar=$OUTPUT_DIR/classes-optimized.jar
            local config_file=$OUTPUT_DIR/generated_proguard.txt
            
            setup_directories
            
            if ! check_proguard; then
                exit 1
            fi
            
            if ! generate_config; then
                exit 1
            fi
            
            if run_proguard "$input_jar" "$output_jar" "$config_file"; then
                analyze_results "$MAPPING_DIR"
                generate_report
                log_success "ProGuard优化完成"
            else
                log_error "ProGuard优化失败"
                exit 1
            fi
            ;;
        "analyze")
            if [ -d "$MAPPING_DIR" ]; then
                analyze_results "$MAPPING_DIR"
            else
                log_error "未找到映射目录，请先运行优化"
                exit 1
            fi
            ;;
        *)
            echo "用法: $0 {config|optimize [input_jar]|analyze}"
            echo ""
            echo "命令说明:"
            echo "  config    - 生成ProGuard配置"
            echo "  optimize  - 执行代码混淆优化"
            echo "  analyze   - 分析优化结果"
            echo ""
            echo "示例:"
            echo "  $0 config"
            echo "  $0 optimize build/classes.jar"
            echo "  $0 analyze"
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"