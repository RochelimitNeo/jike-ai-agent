import 'package:flutter/material.dart';

class QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Color? iconColor;
  final Color? textColor;
  final double? size;
  final double? iconSize;
  final double? fontSize;
  final bool isLoading;
  final bool isEnabled;
  final EdgeInsetsGeometry? padding;
  final BorderRadius? borderRadius;

  const QuickActionButton({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
    this.backgroundColor,
    this.iconColor,
    this.textColor,
    this.size,
    this.iconSize,
    this.fontSize,
    this.isLoading = false,
    this.isEnabled = true,
    this.padding,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = backgroundColor ?? theme.colorScheme.surface;
    final iconCol = iconColor ?? theme.colorScheme.onSurface;
    final textCol = textColor ?? theme.colorScheme.onSurface;
    
    final buttonSize = size ?? 80.0;
    final buttonIconSize = iconSize ?? 24.0;
    final buttonFontSize = fontSize ?? 12.0;
    
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isEnabled && !isLoading ? onTap : null,
        borderRadius: borderRadius ?? BorderRadius.circular(12),
        child: Container(
          width: buttonSize,
          height: buttonSize,
          padding: padding ?? const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isEnabled ? bgColor : bgColor.withOpacity(0.5),
            borderRadius: borderRadius ?? BorderRadius.circular(12),
            border: Border.all(
              color: theme.colorScheme.outline.withOpacity(0.2),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              isLoading
                ? SizedBox(
                    width: buttonIconSize,
                    height: buttonIconSize,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(iconCol),
                    ),
                  )
                : Icon(
                    icon,
                    color: iconCol,
                    size: buttonIconSize,
                  ),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: textCol,
                  fontSize: buttonFontSize,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 圆形快速操作按钮
class CircularQuickActionButton extends StatelessWidget {
  final IconData icon;
  final String? label;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Color? iconColor;
  final double size;
  final double? iconSize;
  final bool isLoading;
  final bool isEnabled;
  final EdgeInsetsGeometry? padding;
  final String? tooltip;

  const CircularQuickActionButton({
    super.key,
    required this.icon,
    this.label,
    this.onTap,
    this.backgroundColor,
    this.iconColor,
    this.size = 56,
    this.iconSize,
    this.isLoading = false,
    this.isEnabled = true,
    this.padding,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = backgroundColor ?? theme.colorScheme.primary;
    final iconCol = iconColor ?? theme.colorScheme.onPrimary;
    
    final buttonIconSize = iconSize ?? size * 0.4;

    Widget button = Container(
      width: size,
      height: size,
      padding: padding ?? const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isEnabled ? bgColor : bgColor.withOpacity(0.5),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: bgColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: isLoading
        ? SizedBox(
            width: buttonIconSize,
            height: buttonIconSize,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(iconCol),
            ),
          )
        : Icon(
            icon,
            color: iconCol,
            size: buttonIconSize,
          ),
    );

    if (tooltip != null) {
      button = Tooltip(
        message: tooltip!,
        child: button,
      );
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isEnabled && !isLoading ? onTap : null,
        borderRadius: BorderRadius.circular(size / 2),
        child: button,
      ),
    );
  }
}

// 渐变快速操作按钮
class GradientQuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final List<Color>? gradientColors;
  final Color? iconColor;
  final Color? textColor;
  final double? size;
  final double? iconSize;
  final double? fontSize;
  final bool isLoading;
  final bool isEnabled;
  final EdgeInsetsGeometry? padding;
  final BorderRadius? borderRadius;

  const GradientQuickActionButton({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
    this.gradientColors,
    this.iconColor,
    this.textColor,
    this.size,
    this.iconSize,
    this.fontSize,
    this.isLoading = false,
    this.isEnabled = true,
    this.padding,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final colors = gradientColors ?? [
      Theme.of(context).colorScheme.primary,
      Theme.of(context).colorScheme.primary.withOpacity(0.8),
    ];
    
    final buttonSize = size ?? 80.0;
    final buttonIconSize = iconSize ?? 24.0;
    final buttonFontSize = fontSize ?? 12.0;
    final iconCol = iconColor ?? Colors.white;
    final textCol = textColor ?? Colors.white;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isEnabled && !isLoading ? onTap : null,
        borderRadius: borderRadius ?? BorderRadius.circular(12),
        child: Container(
          width: buttonSize,
          height: buttonSize,
          padding: padding ?? const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: colors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: borderRadius ?? BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: colors[0].withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              isLoading
                ? SizedBox(
                    width: buttonIconSize,
                    height: buttonIconSize,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(iconCol),
                    ),
                  )
                : Icon(
                    icon,
                    color: iconCol,
                    size: buttonIconSize,
                  ),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: textCol,
                  fontSize: buttonFontSize,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 浮动快速操作按钮
class FloatingQuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Color? iconColor;
  final Color? textColor;
  final double? size;
  final double? iconSize;
  final double? fontSize;
  final bool isLoading;
  final bool isEnabled;
  final EdgeInsetsGeometry? padding;
  final String? tooltip;

  const FloatingQuickActionButton({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
    this.backgroundColor,
    this.iconColor,
    this.textColor,
    this.size,
    this.iconSize,
    this.fontSize,
    this.isLoading = false,
    this.isEnabled = true,
    this.padding,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = backgroundColor ?? theme.colorScheme.surface;
    final iconCol = iconColor ?? theme.colorScheme.onSurface;
    final textCol = textColor ?? theme.colorScheme.onSurface;
    
    final buttonSize = size ?? 60.0;
    final buttonIconSize = iconSize ?? 20.0;
    final buttonFontSize = fontSize ?? 10.0;

    Widget button = Container(
      width: buttonSize,
      height: buttonSize,
      padding: padding ?? const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: isEnabled ? bgColor : bgColor.withOpacity(0.5),
        shape: BoxShape.circle,
        border: Border.all(
          color: theme.colorScheme.outline.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          isLoading
            ? SizedBox(
                width: buttonIconSize,
                height: buttonIconSize,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(iconCol),
                ),
              )
            : Icon(
                icon,
                color: iconCol,
                size: buttonIconSize,
              ),
          if (label.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: textCol,
                fontSize: buttonFontSize,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );

    if (tooltip != null) {
      button = Tooltip(
        message: tooltip!,
        child: button,
      );
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isEnabled && !isLoading ? onTap : null,
        borderRadius: BorderRadius.circular(buttonSize / 2),
        child: button,
      ),
    );
  }
}

// 快速操作按钮组
class QuickActionButtonGroup extends StatelessWidget {
  final List<QuickActionButtonItem> buttons;
  final double spacing;
  final double runSpacing;
  final int crossAxisCount;
  final double childAspectRatio;
  final Alignment alignment;

  const QuickActionButtonGroup({
    super.key,
    required this.buttons,
    this.spacing = 16,
    this.runSpacing = 16,
    this.crossAxisCount = 4,
    this.childAspectRatio = 1.0,
    this.alignment = Alignment.center,
  });

  @override
  Widget build(BuildContext context) {
    if (crossAxisCount == 1) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: buttons.map((button) {
          return Padding(
            padding: EdgeInsets.only(bottom: spacing),
            child: QuickActionButton(
              icon: button.icon,
              label: button.label,
              onTap: button.onTap,
              backgroundColor: button.backgroundColor,
              iconColor: button.iconColor,
              textColor: button.textColor,
              size: button.size,
              iconSize: button.iconSize,
              fontSize: button.fontSize,
              isLoading: button.isLoading,
              isEnabled: button.isEnabled,
            ),
          );
        }).toList(),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: spacing,
        mainAxisSpacing: runSpacing,
        childAspectRatio: childAspectRatio,
      ),
      itemCount: buttons.length,
      itemBuilder: (context, index) {
        final button = buttons[index];
        return QuickActionButton(
          icon: button.icon,
          label: button.label,
          onTap: button.onTap,
          backgroundColor: button.backgroundColor,
          iconColor: button.iconColor,
          textColor: button.textColor,
          size: button.size,
          iconSize: button.iconSize,
          fontSize: button.fontSize,
          isLoading: button.isLoading,
          isEnabled: button.isEnabled,
        );
      },
    );
  }
}

class QuickActionButtonItem {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Color? iconColor;
  final Color? textColor;
  final double? size;
  final double? iconSize;
  final double? fontSize;
  final bool isLoading;
  final bool isEnabled;

  const QuickActionButtonItem({
    required this.icon,
    required this.label,
    this.onTap,
    this.backgroundColor,
    this.iconColor,
    this.textColor,
    this.size,
    this.iconSize,
    this.fontSize,
    this.isLoading = false,
    this.isEnabled = true,
  });
}