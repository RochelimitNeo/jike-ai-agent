import 'package:flutter/material.dart';

class LoadingIndicator extends StatefulWidget {
  final double size;
  final Color? color;
  final double strokeWidth;
  final String? text;
  final bool showText;
  final LoadingType type;

  const LoadingIndicator({
    super.key,
    this.size = 40,
    this.color,
    this.strokeWidth = 4,
    this.text,
    this.showText = true,
    this.type = LoadingType.circular,
  });

  @override
  State<LoadingIndicator> createState() => _LoadingIndicatorState();
}

class _LoadingIndicatorState extends State<LoadingIndicator>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.color ?? Theme.of(context).primaryColor;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildLoadingWidget(color),
        if (widget.showText && widget.text != null) ...[
          const SizedBox(height: 8),
          Text(
            widget.text!,
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildLoadingWidget(Color color) {
    switch (widget.type) {
      case LoadingType.circular:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(color),
            strokeWidth: widget.strokeWidth,
          ),
        );
      
      case LoadingType.linear:
        return SizedBox(
          width: widget.size * 2,
          height: widget.size / 3,
          child: LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(color),
            backgroundColor: color.withOpacity(0.3),
          ),
        );
      
      case LoadingType.dots:
        return _DotsAnimation(
          size: widget.size,
          color: color,
          controller: _controller,
        );
      
      case LoadingType.pulse:
        return _PulseAnimation(
          size: widget.size,
          color: color,
          controller: _controller,
        );
      
      case LoadingType.wave:
        return _WaveAnimation(
          size: widget.size,
          color: color,
          controller: _controller,
        );
      
      case LoadingType.spinner:
        return _SpinnerAnimation(
          size: widget.size,
          color: color,
          controller: _controller,
        );
    }
  }
}

enum LoadingType {
  circular,
  linear,
  dots,
  pulse,
  wave,
  spinner,
}

// 点状动画
class _DotsAnimation extends StatelessWidget {
  final double size;
  final Color color;
  final AnimationController controller;

  const _DotsAnimation({
    required this.size,
    required this.color,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (index) {
            final delay = index * 0.2;
            final animation = Tween<double>(
              begin: 0.0,
              end: 1.0,
            ).animate(
              CurvedAnimation(
                parent: controller,
                curve: Interval(
                  delay,
                  1.0,
                  curve: Curves.easeInOut,
                ),
              ),
            );

            return AnimatedBuilder(
              animation: animation,
              builder: (context, child) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: size * 0.05),
                  width: size * 0.15,
                  height: size * 0.15,
                  decoration: BoxDecoration(
                    color: color.withOpacity(animation.value),
                    shape: BoxShape.circle,
                  ),
                );
              },
            );
          }),
        );
      },
    );
  }
}

// 脉冲动画
class _PulseAnimation extends StatelessWidget {
  final double size;
  final Color color;
  final AnimationController controller;

  const _PulseAnimation({
    required this.size,
    required this.color,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return Transform.scale(
          scale: 1 + (controller.value * 0.3),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.5),
                  blurRadius: size * 0.3,
                  spreadRadius: size * 0.1,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// 波浪动画
class _WaveAnimation extends StatelessWidget {
  final double size;
  final Color color;
  final AnimationController controller;

  const _WaveAnimation({
    required this.size,
    required this.color,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(5, (index) {
            final height = size * 0.5;
            final barHeight = height * (0.5 + 0.5 * controller.value);
            
            return Container(
              width: size * 0.1,
              height: barHeight,
              margin: EdgeInsets.symmetric(horizontal: size * 0.02),
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(size * 0.05),
              ),
            );
          }),
        );
      },
    );
  }
}

// 旋转动画
class _SpinnerAnimation extends StatelessWidget {
  final double size;
  final Color color;
  final AnimationController controller;

  const _SpinnerAnimation({
    required this.size,
    required this.color,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        return Transform.rotate(
          angle: controller.value * 2 * 3.14159,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              border: '${size * 0.15} solid transparent',
              borderTop: '${size * 0.15} solid $color',
              borderRadius: BorderRadius.circular(size / 2),
            ),
          ),
        );
      },
    );
  }
}

// 简洁的加载指示器
class SimpleLoadingIndicator extends StatelessWidget {
  final double size;
  final Color? color;

  const SimpleLoadingIndicator({
    super.key,
    this.size = 24,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final indicatorColor = color ?? Theme.of(context).primaryColor;
    
    return SizedBox(
      width: size,
      height: size,
      child: CircularProgressIndicator(
        strokeWidth: size * 0.1,
        valueColor: AlwaysStoppedAnimation<Color>(indicatorColor),
      ),
    );
  }
}

// 全屏加载对话框
class FullScreenLoading extends StatelessWidget {
  final String? message;
  final Color? backgroundColor;

  const FullScreenLoading({
    super.key,
    this.message,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: backgroundColor ?? Colors.black54,
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const LoadingIndicator(
                size: 40,
                type: LoadingType.spinner,
              ),
              if (message != null) ...[
                const SizedBox(height: 16),
                Text(
                  message!,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// 按钮加载状态
class ButtonLoading extends StatelessWidget {
  final bool isLoading;
  final Widget child;
  final double size;
  final Color? color;

  const ButtonLoading({
    super.key,
    required this.isLoading,
    required this.child,
    this.size = 16,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SimpleLoadingIndicator(
            size: size,
            color: color,
          ),
          const SizedBox(width: 8),
          child,
        ],
      );
    }
    return child;
  }
}