import 'package:flutter/material.dart';

class LogoWidget extends StatelessWidget {
  final double size;
  final Color? color;
  final bool showText;
  final String? title;
  final double? titleSize;

  const LogoWidget({
    super.key,
    this.size = 80,
    this.color,
    this.showText = true,
    this.title,
    this.titleSize,
  });

  @override
  Widget build(BuildContext context) {
    final logoColor = color ?? const Color(0xFF2196F3);
    
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: logoColor,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: logoColor.withOpacity(0.3),
                blurRadius: size * 0.1,
                offset: Offset(0, size * 0.05),
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // AI符号背景
              Positioned(
                top: size * 0.15,
                left: size * 0.15,
                right: size * 0.15,
                child: Container(
                  height: size * 0.2,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(size * 0.1),
                  ),
                ),
              ),
              // 主AI符号
              Positioned(
                top: size * 0.25,
                left: size * 0.2,
                right: size * 0.2,
                child: Container(
                  height: size * 0.3,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(size * 0.15),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.psychology,
                      color: logoColor,
                      size: size * 0.18,
                    ),
                  ),
                ),
              ),
              // 数据点
              Positioned(
                top: size * 0.05,
                right: size * 0.15,
                child: Container(
                  width: size * 0.08,
                  height: size * 0.08,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.5),
                        blurRadius: size * 0.02,
                        offset: Offset(0, size * 0.02),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: size * 0.25,
                left: size * 0.1,
                child: Container(
                  width: size * 0.06,
                  height: size * 0.06,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.7),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Positioned(
                bottom: size * 0.15,
                right: size * 0.1,
                child: Container(
                  width: size * 0.06,
                  height: size * 0.06,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.7),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              // 边框装饰
              Positioned(
                top: size * 0.05,
                left: size * 0.05,
                right: size * 0.05,
                bottom: size * 0.05,
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white.withOpacity(0.3),
                      width: size * 0.02,
                    ),
                    borderRadius: BorderRadius.circular(size / 2),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (showText) ...[
          const SizedBox(height: 12),
          Text(
            title ?? 'AI',
            style: TextStyle(
              color: logoColor,
              fontSize: titleSize ?? size * 0.2,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ],
    );
  }
}

// 带动画的Logo组件
class AnimatedLogoWidget extends StatefulWidget {
  final double size;
  final Color? color;
  final bool showText;
  final String? title;
  final double? titleSize;
  final Duration duration;

  const AnimatedLogoWidget({
    super.key,
    this.size = 80,
    this.color,
    this.showText = true,
    this.title,
    this.titleSize,
    this.duration = const Duration(milliseconds: 1500),
  });

  @override
  State<AnimatedLogoWidget> createState() => _AnimatedLogoWidgetState();
}

class _AnimatedLogoWidgetState extends State<AnimatedLogoWidget>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.elasticOut,
    ));

    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 0.1,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    ));

    _colorAnimation = ColorTween(
      begin: const Color(0xFF1976D2),
      end: widget.color ?? const Color(0xFF2196F3),
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Transform.rotate(
            angle: _rotationAnimation.value,
            child: Opacity(
              opacity: _fadeAnimation.value,
              child: LogoWidget(
                size: widget.size,
                color: _colorAnimation.value,
                showText: widget.showText,
                title: widget.title,
                titleSize: widget.titleSize,
              ),
            ),
          ),
        );
      },
    );
  }
}

// 圆形Logo组件
class CircleLogoWidget extends StatelessWidget {
  final double size;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final String? title;
  final IconData? icon;
  final double? titleSize;

  const CircleLogoWidget({
    super.key,
    this.size = 80,
    this.backgroundColor,
    this.foregroundColor,
    this.title,
    this.icon,
    this.titleSize,
  });

  @override
  Widget build(BuildContext context) {
    final bgColor = backgroundColor ?? const Color(0xFF2196F3);
    final fgColor = foregroundColor ?? Colors.white;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: bgColor,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: bgColor.withOpacity(0.3),
            blurRadius: size * 0.1,
            offset: Offset(0, size * 0.05),
          ),
        ],
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                color: fgColor,
                size: size * 0.4,
              ),
              const SizedBox(height: 4),
            ],
            if (title != null)
              Text(
                title!,
                style: TextStyle(
                  color: fgColor,
                  fontSize: titleSize ?? size * 0.3,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
      ),
    );
  }
}