import 'package:flutter/material.dart';

class AgentCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final bool isActive;
  final int? notificationCount;
  final Widget? customWidget;
  final double width;
  final double height;

  const AgentCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    this.onTap,
    this.isActive = false,
    this.notificationCount,
    this.customWidget,
    this.width = 160,
    this.height = 120,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: isActive 
          ? Border.all(color: color, width: 2)
          : Border.all(color: theme.colorScheme.outline.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildIconSection(context),
                const SizedBox(height: 12),
                _buildTitleSection(context),
                const SizedBox(height: 4),
                _buildSubtitleSection(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIconSection(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color,
            size: 20,
          ),
        ),
        const Spacer(),
        if (isActive)
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
        if (notificationCount != null && notificationCount! > 0)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: theme.of(context).colorScheme.error,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              notificationCount! > 99 ? '99+' : notificationCount.toString(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTitleSection(BuildContext context) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
        color: Theme.of(context).colorScheme.onSurface,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildSubtitleSection(BuildContext context) {
    return Text(
      subtitle,
      style: Theme.of(context).textTheme.bodySmall?.copyWith(
        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }
}

// 可展开的Agent卡片
class ExpandableAgentCard extends StatefulWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final bool isActive;
  final Widget? expandedContent;
  final bool isExpanded;
  final double width;
  final double height;

  const ExpandableAgentCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    this.onTap,
    this.isActive = false,
    this.expandedContent,
    this.isExpanded = false,
    this.width = 160,
    this.height = 120,
  });

  @override
  State<ExpandableAgentCard> createState() => _ExpandableAgentCardState();
}

class _ExpandableAgentCardState extends State<ExpandableAgentCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;
  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _isExpanded = widget.isExpanded;
    if (_isExpanded) {
      _animationController.value = 1.0;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleExpanded() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AgentCard(
            title: widget.title,
            subtitle: widget.subtitle,
            icon: widget.icon,
            color: widget.color,
            onTap: widget.expandedContent != null ? _toggleExpanded : widget.onTap,
            isActive: widget.isActive,
            width: widget.width,
            height: widget.height,
          ),
          SizeTransition(
            sizeFactor: _expandAnimation,
            child: widget.expandedContent != null
              ? Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: widget.expandedContent,
                )
              : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

// 圆形Agent卡片
class CircleAgentCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final double size;
  final String? badgeText;
  final bool hasBadge;

  const CircleAgentCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.onTap,
    this.size = 80,
    this.badgeText,
    this.hasBadge = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(
                color: color.withOpacity(0.3),
                width: 2,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(
                  icon,
                  color: color,
                  size: size * 0.4,
                ),
                if (hasBadge && badgeText != null)
                  Positioned(
                    top: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        badgeText!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

// Agent卡片列表
class AgentCardList extends StatelessWidget {
  final List<AgentCardItem> items;
  final int crossAxisCount;
  final double childAspectRatio;
  final double horizontalPadding;
  final double verticalPadding;

  const AgentCardList({
    super.key,
    required this.items,
    this.crossAxisCount = 2,
    this.childAspectRatio = 1.2,
    this.horizontalPadding = 16,
    this.verticalPadding = 8,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: childAspectRatio,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return AgentCard(
            title: item.title,
            subtitle: item.subtitle,
            icon: item.icon,
            color: item.color,
            onTap: item.onTap,
            isActive: item.isActive,
            notificationCount: item.notificationCount,
          );
        },
      ),
    );
  }
}

class AgentCardItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final bool isActive;
  final int? notificationCount;

  const AgentCardItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    this.onTap,
    this.isActive = false,
    this.notificationCount,
  });
}