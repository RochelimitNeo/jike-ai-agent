import 'package:flutter/material.dart';

enum ActivityType {
  conversation,
  imageRecognition,
  voiceAssistant,
  documentAssistant,
  general,
  error,
  success,
  info
}

enum ActivityStatus {
  pending,
  inProgress,
  completed,
  failed,
  cancelled
}

class ActivityModel {
  final String id;
  final String title;
  final String? description;
  final ActivityType type;
  final ActivityStatus status;
  final DateTime timestamp;
  final Duration? duration;
  final Map<String, dynamic>? metadata;
  final IconData? icon;
  final Color? color;
  final bool isNew;
  final String? errorMessage;

  const ActivityModel({
    required this.id,
    required this.title,
    this.description,
    required this.type,
    required this.status,
    required this.timestamp,
    this.duration,
    this.metadata,
    this.icon,
    this.color,
    this.isNew = false,
    this.errorMessage,
  });

  // 复制并修改活动对象
  ActivityModel copyWith({
    String? id,
    String? title,
    String? description,
    ActivityType? type,
    ActivityStatus? status,
    DateTime? timestamp,
    Duration? duration,
    Map<String, dynamic>? metadata,
    IconData? icon,
    Color? color,
    bool? isNew,
    String? errorMessage,
  }) {
    return ActivityModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      type: type ?? this.type,
      status: status ?? this.status,
      timestamp: timestamp ?? this.timestamp,
      duration: duration ?? this.duration,
      metadata: metadata ?? this.metadata,
      icon: icon ?? this.icon,
      color: color ?? this.color,
      isNew: isNew ?? this.isNew,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  // 从JSON创建活动对象
  factory ActivityModel.fromJson(Map<String, dynamic> json) {
    return ActivityModel(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      type: ActivityType.values.firstWhere(
        (type) => type.toString().split('.').last == json['type'],
        orElse: () => ActivityType.general,
      ),
      status: ActivityStatus.values.firstWhere(
        (status) => status.toString().split('.').last == json['status'],
        orElse: () => ActivityStatus.pending,
      ),
      timestamp: DateTime.parse(json['timestamp'] as String),
      duration: json['duration'] != null
          ? Duration(milliseconds: json['duration'] as int)
          : null,
      metadata: json['metadata'] as Map<String, dynamic>?,
      icon: json['icon'] != null ? IconData(json['icon'] as int) : null,
      color: json['color'] != null ? Color(json['color'] as int) : null,
      isNew: json['isNew'] as bool? ?? false,
      errorMessage: json['errorMessage'] as String?,
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type.toString().split('.').last,
      'status': status.toString().split('.').last,
      'timestamp': timestamp.toIso8601String(),
      'duration': duration?.inMilliseconds,
      'metadata': metadata,
      'icon': icon?.codePoint,
      'color': color?.value,
      'isNew': isNew,
      'errorMessage': errorMessage,
    };
  }

  // 获取活动的显示时间
  String get displayTime {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inSeconds < 60) {
      return '刚刚';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}分钟前';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}小时前';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}天前';
    } else {
      return '${timestamp.year}-${timestamp.month.toString().padLeft(2, '0')}-${timestamp.day.toString().padLeft(2, '0')}';
    }
  }

  // 获取状态颜色
  Color get statusColor {
    switch (status) {
      case ActivityStatus.pending:
        return Colors.grey;
      case ActivityStatus.inProgress:
        return Colors.blue;
      case ActivityStatus.completed:
        return Colors.green;
      case ActivityStatus.failed:
        return Colors.red;
      case ActivityStatus.cancelled:
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  // 获取状态图标
  IconData get statusIcon {
    switch (status) {
      case ActivityStatus.pending:
        return Icons.schedule;
      case ActivityStatus.inProgress:
        return Icons.hourglass_empty;
      case ActivityStatus.completed:
        return Icons.check_circle;
      case ActivityStatus.failed:
        return Icons.error;
      case ActivityStatus.cancelled:
        return Icons.cancel;
      default:
        return Icons.info;
    }
  }

  // 获取类型默认颜色
  Color get defaultColor {
    switch (type) {
      case ActivityType.conversation:
        return const Color(0xFF4CAF50);
      case ActivityType.imageRecognition:
        return const Color(0xFFFF9800);
      case ActivityType.voiceAssistant:
        return const Color(0xFF2196F3);
      case ActivityType.documentAssistant:
        return const Color(0xFF9C27B0);
      case ActivityType.general:
        return const Color(0xFF607D8B);
      case ActivityType.error:
        return const Color(0xFFF44336);
      case ActivityType.success:
        return const Color(0xFF4CAF50);
      case ActivityType.info:
        return const Color(0xFF2196F3);
      default:
        return const Color(0xFF607D8B);
    }
  }

  // 获取类型默认图标
  IconData get defaultIcon {
    switch (type) {
      case ActivityType.conversation:
        return Icons.chat;
      case ActivityType.imageRecognition:
        return Icons.image_search;
      case ActivityType.voiceAssistant:
        return Icons.mic;
      case ActivityType.documentAssistant:
        return Icons.description;
      case ActivityType.general:
        return Icons.activity;
      case ActivityType.error:
        return Icons.error_outline;
      case ActivityType.success:
        return Icons.check_circle_outline;
      case ActivityType.info:
        return Icons.info_outline;
      default:
        return Icons.activity;
    }
  }

  // 获取持续时间显示
  String get durationDisplay {
    if (duration == null) return '';
    
    final minutes = duration!.inMinutes;
    final seconds = duration!.inSeconds % 60;
    
    if (minutes > 0) {
      return '${minutes}分${seconds}秒';
    } else {
      return '${seconds}秒';
    }
  }

  // 检查是否为今天的活动
  bool get isToday {
    final now = DateTime.now();
    return timestamp.year == now.year &&
        timestamp.month == now.month &&
        timestamp.day == now.day;
  }

  // 检查是否为本周的活动
  bool get isThisWeek {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final endOfWeek = startOfWeek.add(const Duration(days: 6));
    
    return timestamp.isAfter(startOfWeek) && timestamp.isBefore(endOfWeek);
  }

  @override
  String toString() {
    return 'ActivityModel(id: $id, title: $title, type: $type, status: $status)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ActivityModel &&
        other.id == id &&
        other.title == title &&
        other.type == type &&
        other.status == status &&
        other.timestamp == timestamp;
  }

  @override
  int get hashCode {
    return id.hashCode ^ title.hashCode ^ type.hashCode ^ status.hashCode ^ timestamp.hashCode;
  }
}

// 活动工厂类
class ActivityFactory {
  // 创建对话活动
  static ActivityModel createConversation({
    required String title,
    String? description,
    ActivityStatus status = ActivityStatus.completed,
    Duration? duration,
    Map<String, dynamic>? metadata,
  }) {
    return ActivityModel(
      id: 'conversation_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      description: description,
      type: ActivityType.conversation,
      status: status,
      timestamp: DateTime.now(),
      duration: duration,
      metadata: metadata,
    );
  }

  // 创建图像识别活动
  static ActivityModel createImageRecognition({
    required String title,
    String? description,
    ActivityStatus status = ActivityStatus.completed,
    Duration? duration,
    Map<String, dynamic>? metadata,
  }) {
    return ActivityModel(
      id: 'image_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      description: description,
      type: ActivityType.imageRecognition,
      status: status,
      timestamp: DateTime.now(),
      duration: duration,
      metadata: metadata,
    );
  }

  // 创建语音助手活动
  static ActivityModel createVoiceAssistant({
    required String title,
    String? description,
    ActivityStatus status = ActivityStatus.completed,
    Duration? duration,
    Map<String, dynamic>? metadata,
  }) {
    return ActivityModel(
      id: 'voice_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      description: description,
      type: ActivityType.voiceAssistant,
      status: status,
      timestamp: DateTime.now(),
      duration: duration,
      metadata: metadata,
    );
  }

  // 创建错误活动
  static ActivityModel createError({
    required String title,
    String? errorMessage,
    Map<String, dynamic>? metadata,
  }) {
    return ActivityModel(
      id: 'error_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      description: errorMessage,
      type: ActivityType.error,
      status: ActivityStatus.failed,
      timestamp: DateTime.now(),
      errorMessage: errorMessage,
      metadata: metadata,
    );
  }
}