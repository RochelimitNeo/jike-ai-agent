import 'package:flutter/material.dart';

class UserModel {
  final String id;
  final String name;
  final String email;
  final String? avatar;
  final DateTime createdAt;
  final UserPreferences preferences;
  final Map<String, dynamic>? metadata;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.avatar,
    required this.createdAt,
    required this.preferences,
    this.metadata,
  });

  // 复制并修改用户对象
  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? avatar,
    DateTime? createdAt,
    UserPreferences? preferences,
    Map<String, dynamic>? metadata,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      avatar: avatar ?? this.avatar,
      createdAt: createdAt ?? this.createdAt,
      preferences: preferences ?? this.preferences,
      metadata: metadata ?? this.metadata,
    );
  }

  // 从JSON创建用户对象
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      name: json['name'] as String,
      email: json['email'] as String,
      avatar: json['avatar'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
      preferences: UserPreferences.fromJson(json['preferences'] as Map<String, dynamic>),
      metadata: json['metadata'] as Map<String, dynamic>?,
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'avatar': avatar,
      'createdAt': createdAt.toIso8601String(),
      'preferences': preferences.toJson(),
      'metadata': metadata,
    };
  }

  // 获取用户显示名称
  String get displayName => name.isNotEmpty ? name : email.split('@').first;

  // 获取头像URL或默认头像
  String get avatarUrl => avatar ?? 'https://via.placeholder.com/150x150?text=Avatar';

  // 检查是否为新用户（注册时间少于7天）
  bool get isNewUser {
    final daysSinceCreation = DateTime.now().difference(createdAt).inDays;
    return daysSinceCreation <= 7;
  }

  // 获取用户年龄（注册至今的天数）
  int get accountAgeInDays {
    return DateTime.now().difference(createdAt).inDays;
  }

  @override
  String toString() {
    return 'UserModel(id: $id, name: $name, email: $email)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserModel &&
        other.id == id &&
        other.name == name &&
        other.email == email;
  }

  @override
  int get hashCode {
    return id.hashCode ^ name.hashCode ^ email.hashCode;
  }
}

class UserPreferences {
  final ThemeMode theme;
  final String language;
  final bool notificationsEnabled;
  final bool analyticsEnabled;
  final String? voiceAssistantLanguage;
  final Map<String, dynamic>? customSettings;

  const UserPreferences({
    required this.theme,
    required this.language,
    required this.notificationsEnabled,
    this.analyticsEnabled = true,
    this.voiceAssistantLanguage,
    this.customSettings,
  });

  // 复制并修改偏好设置
  UserPreferences copyWith({
    ThemeMode? theme,
    String? language,
    bool? notificationsEnabled,
    bool? analyticsEnabled,
    String? voiceAssistantLanguage,
    Map<String, dynamic>? customSettings,
  }) {
    return UserPreferences(
      theme: theme ?? this.theme,
      language: language ?? this.language,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      analyticsEnabled: analyticsEnabled ?? this.analyticsEnabled,
      voiceAssistantLanguage: voiceAssistantLanguage ?? this.voiceAssistantLanguage,
      customSettings: customSettings ?? this.customSettings,
    );
  }

  // 从JSON创建偏好设置
  factory UserPreferences.fromJson(Map<String, dynamic> json) {
    return UserPreferences(
      theme: ThemeMode.values.firstWhere(
        (mode) => mode.toString().split('.').last == json['theme'],
        orElse: () => ThemeMode.system,
      ),
      language: json['language'] as String,
      notificationsEnabled: json['notificationsEnabled'] as bool,
      analyticsEnabled: json['analyticsEnabled'] as bool? ?? true,
      voiceAssistantLanguage: json['voiceAssistantLanguage'] as String?,
      customSettings: json['customSettings'] as Map<String, dynamic>?,
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'theme': theme.toString().split('.').last,
      'language': language,
      'notificationsEnabled': notificationsEnabled,
      'analyticsEnabled': analyticsEnabled,
      'voiceAssistantLanguage': voiceAssistantLanguage,
      'customSettings': customSettings,
    };
  }

  @override
  String toString() {
    return 'UserPreferences(theme: $theme, language: $language, notifications: $notificationsEnabled)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserPreferences &&
        other.theme == theme &&
        other.language == language &&
        other.notificationsEnabled == notificationsEnabled &&
        other.analyticsEnabled == analyticsEnabled &&
        other.voiceAssistantLanguage == voiceAssistantLanguage;
  }

  @override
  int get hashCode {
    return theme.hashCode ^
        language.hashCode ^
        notificationsEnabled.hashCode ^
        analyticsEnabled.hashCode ^
        (voiceAssistantLanguage?.hashCode ?? 0);
  }
}