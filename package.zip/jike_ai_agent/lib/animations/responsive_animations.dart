import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'animation_config.dart';
import 'animation_mixins.dart';

/// 响应式动画系统
/// 根据用户操作和设备特性动态调整动画效果

/// 设备性能检测器
class DevicePerformanceDetector {
  static bool _isLowEndDevice = false;
  static bool _isHighEndDevice = false;

  /// 检测设备性能
  static void detectDevicePerformance() {
    // 这里可以通过实际检测来判断设备性能
    // 暂时使用简单的判断逻辑
    final devicePixelRatio = WidgetsBinding.instance.window.devicePixelRatio;
    final screenSize = WidgetsBinding.instance.window.physicalSize;
    
    // 基于屏幕分辨率判断设备性能
    final totalPixels = screenSize.width * screenSize.height;
    
    if (totalPixels < 1000000) { // 小于100万像素
      _isLowEndDevice = true;
      _isHighEndDevice = false;
    } else if (totalPixels > 4000000) { // 大于400万像素
      _isLowEndDevice = false;
      _isHighEndDevice = true;
    } else {
      _isLowEndDevice = false;
      _isHighEndDevice = false;
    }
  }

  /// 是否为低端设备
  static bool get isLowEndDevice => _isLowEndDevice;
  
  /// 是否为高端设备
  static bool get isHighEndDevice => _isHighEndDevice;
  
  /// 获取性能级别
  static PerformanceLevel get performanceLevel {
    if (_isLowEndDevice) return PerformanceLevel.low;
    if (_isHighEndDevice) return PerformanceLevel.high;
    return PerformanceLevel.medium;
  }

  /// 根据设备性能获取动画持续时间
  static Duration getAnimationDuration(Duration baseDuration) {
    switch (performanceLevel) {
      case PerformanceLevel.low:
        return Duration(
          milliseconds: (baseDuration.inMilliseconds * 0.7).round(),
        );
      case PerformanceLevel.medium:
        return baseDuration;
      case PerformanceLevel.high:
        return Duration(
          milliseconds: (baseDuration.inMilliseconds * 1.3).round(),
        );
    }
  }

  /// 根据设备性能获取缓动曲线
  static Curve getAnimationCurve(Curve baseCurve) {
    switch (performanceLevel) {
      case PerformanceLevel.low:
        return Curves.easeOut; // 更简单的缓动
      case PerformanceLevel.medium:
        return baseCurve;
      case PerformanceLevel.high:
        return baseCurve;
    }
  }

  /// 是否启用复杂动画
  static bool enableComplexAnimations() {
    return !_isLowEndDevice;
  }

  /// 是否启用粒子效果
  static bool enableParticleEffects() {
    return _isHighEndDevice;
  }
}

/// 性能级别枚举
enum PerformanceLevel {
  low,
  medium,
  high,
}

/// 自适应动画组件
class AdaptiveAnimationWidget extends StatefulWidget {
  final Widget child;
  final Widget Function(BuildContext context, double progress)? builder;
  final Duration duration;
  final Curve curve;
  final bool enableAdvanced;
  final bool respectUserPreferences;

  const AdaptiveAnimationWidget({
    super.key,
    required this.child,
    this.builder,
    this.duration = const Duration(milliseconds: 300),
    this.curve = Curves.easeInOut,
    this.enableAdvanced = true,
    this.respectUserPreferences = true,
  });

  @override
  State<AdaptiveAnimationWidget> createState() => _AdaptiveAnimationWidgetState();
}

class _AdaptiveAnimationWidgetState extends State<AdaptiveAnimationWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isAnimating = false;

  @override
  void initState() {
    super.initState();
    
    final baseDuration = widget.duration;
    final adaptiveDuration = DevicePerformanceDetector.getAnimationDuration(baseDuration);
    
    _controller = AnimationController(
      duration: adaptiveDuration,
      vsync: this,
    );

    final baseCurve = widget.curve;
    final adaptiveCurve = DevicePerformanceDetector.getAnimationCurve(baseCurve);
    
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: adaptiveCurve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// 播放动画
  Future<void> playAnimation() async {
    if (_isAnimating) return;
    
    setState(() {
      _isAnimating = true;
    });
    
    await _controller.forward();
    
    setState(() {
      _isAnimating = false;
    });
  }

  /// 重置动画
  void resetAnimation() {
    _controller.reset();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        if (widget.builder != null) {
          return widget.builder!(context, _animation.value);
        }
        
        return widget.child;
      },
    );
  }
}

/// 智能滚动动画
class SmartScrollAnimation extends StatefulWidget {
  final Widget child;
  final ScrollController? controller;
  final Duration duration;
  final Curve curve;
  final bool enableElastic;

  const SmartScrollAnimation({
    super.key,
    required this.child,
    this.controller,
    this.duration = const Duration(milliseconds: 500),
    this.curve = Curves.easeOut,
    this.enableElastic = true,
  });

  @override
  State<SmartScrollAnimation> createState() => _SmartScrollAnimationState();
}

class _SmartScrollAnimationState extends State<SmartScrollAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = widget.controller ?? ScrollController();
    
    final adaptiveDuration = DevicePerformanceDetector.getAnimationDuration(widget.duration);
    
    _controller = AnimationController(
      duration: adaptiveDuration,
      vsync: this,
    );

    final adaptiveCurve = DevicePerformanceDetector.getAnimationCurve(widget.curve);
    
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: adaptiveCurve));

    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _controller.dispose();
    if (widget.controller == null) {
      _scrollController.dispose();
    }
    super.dispose();
  }

  void _onScroll() {
    // 滚动时的响应式动画逻辑
    final offset = _scrollController.offset;
    final maxOffset = _scrollController.position.maxScrollExtent;
    
    if (maxOffset > 0) {
      final progress = (offset / maxOffset).clamp(0.0, 1.0);
      
      // 根据滚动进度调整子组件的显示
      setState(() {
        // 可以在这里根据滚动进度更新子组件
      });
    }
  }

  /// 滚动到顶部
  Future<void> scrollToTop({bool smooth = true}) async {
    if (!smooth) {
      _scrollController.jumpTo(0);
      return;
    }

    final startOffset = _scrollController.offset;
    final startTime = DateTime.now();
    const endOffset = 0.0;
    const totalDuration = 500; // 毫秒

    Timer.periodic(const Duration(milliseconds: 16), (timer) {
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final progress = (elapsed / totalDuration).clamp(0.0, 1.0);
      
      final currentOffset = startOffset + (endOffset - startOffset) * progress;
      _scrollController.jumpTo(currentOffset);
      
      if (progress >= 1.0) {
        timer.cancel();
      }
    });
  }

  /// 滚动到底部
  Future<void> scrollToBottom({bool smooth = true}) async {
    if (!_scrollController.hasClients) return;

    final targetOffset = _scrollController.position.maxScrollExtent;
    
    if (!smooth) {
      _scrollController.jumpTo(targetOffset);
      return;
    }

    final startOffset = _scrollController.offset;
    final startTime = DateTime.now();
    const totalDuration = 500;

    Timer.periodic(const Duration(milliseconds: 16), (timer) {
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final progress = (elapsed / totalDuration).clamp(0.0, 1.0);
      
      final currentOffset = startOffset + (targetOffset - startOffset) * progress;
      _scrollController.jumpTo(currentOffset);
      
      if (progress >= 1.0) {
        timer.cancel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: _scrollController,
      children: [
        widget.child,
      ],
    );
  }
}

/// 自适应布局动画
class AdaptiveLayoutAnimation extends StatefulWidget {
  final Widget child;
  final Duration duration;
  final Curve curve;
  final bool enableReorder;

  const AdaptiveLayoutAnimation({
    super.key,
    required this.child,
    this.duration = const Duration(milliseconds: 300),
    this.curve = Curves.easeInOut,
    this.enableReorder = true,
  });

  @override
  State<AdaptiveLayoutAnimation> createState() => _AdaptiveLayoutAnimationState();
}

class _AdaptiveLayoutAnimationState extends State<AdaptiveLayoutAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    
    final adaptiveDuration = DevicePerformanceDetector.getAnimationDuration(widget.duration);
    
    _controller = AnimationController(
      duration: adaptiveDuration,
      vsync: this,
    );

    final adaptiveCurve = DevicePerformanceDetector.getAnimationCurve(widget.curve);
    
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: adaptiveCurve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// 重新布局动画
  Future<void> relayout() async {
    await _controller.forward();
    await _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Transform.scale(
          scale: _animation.value,
          child: widget.child,
        );
      },
    );
  }
}

/// 智能加载动画
class SmartLoadingAnimation extends StatefulWidget {
  final Widget? child;
  final String? message;
  final LoadingType type;
  final Duration duration;
  final bool adaptive;

  const SmartLoadingAnimation({
    super.key,
    this.child,
    this.message,
    this.type = LoadingType.circular,
    this.duration = const Duration(milliseconds: 1000),
    this.adaptive = true,
  });

  @override
  State<SmartLoadingAnimation> createState() => _SmartLoadingAnimationState();
}

class _SmartLoadingAnimationState extends State<SmartLoadingAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    
    Duration adaptiveDuration = widget.duration;
    if (widget.adaptive) {
      adaptiveDuration = DevicePerformanceDetector.getAnimationDuration(widget.duration);
    }
    
    _controller = AnimationController(
      duration: adaptiveDuration,
      vsync: this,
    );

    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.linear));

    _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.child != null) {
      return widget.child!;
    }

    final adaptiveSize = widget.adaptive 
        ? (DevicePerformanceDetector.isLowEndDevice ? 32.0 : 40.0)
        : 40.0;

    return LoadingStateWidget(
      type: widget.type,
      message: widget.message,
      size: adaptiveSize,
    );
  }
}

/// 手势响应式动画
class GestureResponsiveAnimation extends StatefulWidget {
  final Widget child;
  final Function(double progress)? onProgress;
  final Function(TapDownDetails)? onTapDown;
  final Function(TapUpDetails)? onTapUp;
  final Function(DragUpdateDetails)? onDragUpdate;
  final double intensity;

  const GestureResponsiveAnimation({
    super.key,
    required this.child,
    this.onProgress,
    this.onTapDown,
    this.onTapUp,
    this.onDragUpdate,
    this.intensity = 1.0,
  });

  @override
  State<GestureResponsiveAnimation> createState() => _GestureResponsiveAnimationState();
}

class _GestureResponsiveAnimationState extends State<GestureResponsiveAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _positionAnimation;
  double _currentScale = 1.0;
  Offset _currentPosition = Offset.zero;
  Offset? _startPosition;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _positionAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    widget.onTapDown?.call(details);
    
    // 计算点击强度
    final intensity = _calculateIntensity(details.localPosition);
    _animateTo(intensity);
  }

  void _handleTapUp(TapUpDetails details) {
    widget.onTapUp?.call(details);
    _animateTo(0.0);
  }

  void _handleDragUpdate(DragUpdateDetails details) {
    widget.onDragUpdate?.call(details);
    
    // 计算拖拽距离
    if (_startPosition == null) {
      _startPosition = details.localPosition;
    }
    
    final delta = details.localPosition - _startPosition!;
    final distance = delta.distance;
    final maxDistance = 100.0;
    final intensity = (distance / maxDistance).clamp(0.0, 1.0);
    
    _animateTo(intensity);
  }

  double _calculateIntensity(Offset position) {
    // 基于点击位置计算动画强度
    // 中心点击强度最高，边缘强度较低
    final center = Offset(
      MediaQuery.of(context).size.width / 2,
      MediaQuery.of(context).size.height / 2,
    );
    final distance = (position - center).distance;
    final maxDistance = math.min(
      MediaQuery.of(context).size.width,
      MediaQuery.of(context).size.height,
    ) / 2;
    
    return (1.0 - (distance / maxDistance)).clamp(0.0, 1.0);
  }

  void _animateTo(double targetIntensity) {
    final adaptiveIntensity = targetIntensity * widget.intensity;
    
    _scaleAnimation = Tween<double>(
      begin: _currentScale,
      end: 1.0 + (adaptiveIntensity * 0.1),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    
    _currentScale = 1.0 + (adaptiveIntensity * 0.1);
    widget.onProgress?.call(adaptiveIntensity);
    
    _controller.forward().then((_) {
      _controller.reverse();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onPanUpdate: _handleDragUpdate,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Transform.translate(
              offset: _positionAnimation.value,
              child: widget.child,
            ),
          );
        },
      ),
    );
  }
}

/// 自适应颜色动画
class AdaptiveColorAnimation extends StatefulWidget {
  final Widget child;
  final Color startColor;
  final Color endColor;
  final Duration duration;
  final Curve curve;

  const AdaptiveColorAnimation({
    super.key,
    required this.child,
    required this.startColor,
    required this.endColor,
    this.duration = const Duration(milliseconds: 300),
    this.curve = Curves.easeInOut,
  });

  @override
  State<AdaptiveColorAnimation> createState() => _AdaptiveColorAnimationState();
}

class _AdaptiveColorAnimationState extends State<AdaptiveColorAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();
    
    final adaptiveDuration = DevicePerformanceDetector.getAnimationDuration(widget.duration);
    
    _controller = AnimationController(
      duration: adaptiveDuration,
      vsync: this,
    );

    final adaptiveCurve = DevicePerformanceDetector.getAnimationCurve(widget.curve);
    
    _colorAnimation = ColorTween(
      begin: widget.startColor,
      end: widget.endColor,
    ).animate(CurvedAnimation(parent: _controller, curve: adaptiveCurve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// 播放颜色动画
  Future<void> animateToEnd() async {
    await _controller.forward();
  }

  /// 播放颜色动画回退
  Future<void> animateToStart() async {
    await _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _colorAnimation,
      builder: (context, child) {
        return ColorFiltered(
          colorFilter: ColorFilter.mode(
            _colorAnimation.value ?? widget.startColor,
            BlendMode.srcIn,
          ),
          child: widget.child,
        );
      },
    );
  }
}

/// 智能性能优化器
class SmartPerformanceOptimizer {
  static Timer? _optimizationTimer;
  static bool _isLowPerformance = false;

  /// 启动性能监控
  static void startMonitoring() {
    _optimizationTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _checkPerformance();
    });
  }

  /// 停止性能监控
  static void stopMonitoring() {
    _optimizationTimer?.cancel();
    _optimizationTimer = null;
  }

  /// 检查性能并调整动画
  static void _checkPerformance() {
    // 这里可以添加实际性能检测逻辑
    // 例如：检查CPU使用率、内存使用情况、帧率等
    
    final random = math.Random();
    final shouldOptimize = random.nextBool();
    
    if (shouldOptimize && !_isLowPerformance) {
      _isLowPerformance = true;
      _applyPerformanceOptimizations();
    } else if (!shouldOptimize && _isLowPerformance) {
      _isLowPerformance = false;
      _removePerformanceOptimizations();
    }
  }

  /// 应用性能优化
  static void _applyPerformanceOptimizations() {
    // 减少动画帧率
    // 简化动画效果
    // 禁用复杂动画
  }

  /// 移除性能优化
  static void _removePerformanceOptimizations() {
    // 恢复正常动画效果
  }

  /// 获取当前性能状态
  static bool get isLowPerformance => _isLowPerformance;
}

/// 环境感知动画
class EnvironmentAwareAnimation extends StatefulWidget {
  final Widget child;
  final Widget Function(BuildContext context, EnvironmentInfo info)? builder;
  final Duration updateDuration;

  const EnvironmentAwareAnimation({
    super.key,
    required this.child,
    this.builder,
    this.updateDuration = const Duration(milliseconds: 1000),
  });

  @override
  State<EnvironmentAwareAnimation> createState() => _EnvironmentAwareAnimationState();
}

class _EnvironmentAwareAnimationState extends State<EnvironmentAwareAnimation> {
  EnvironmentInfo? _environmentInfo;
  Timer? _updateTimer;

  @override
  void initState() {
    super.initState();
    _updateEnvironmentInfo();
    _startPeriodicUpdate();
  }

  @override
  void dispose() {
    _updateTimer?.cancel();
    super.dispose();
  }

  void _updateEnvironmentInfo() {
    final mediaQuery = MediaQuery.of(context);
    final devicePixelRatio = mediaQuery.devicePixelRatio;
    final screenSize = mediaQuery.size;
    final brightness = mediaQuery.platformBrightness;
    
    setState(() {
      _environmentInfo = EnvironmentInfo(
        screenSize: screenSize,
        devicePixelRatio: devicePixelRatio,
        isDarkMode: brightness == Brightness.dark,
        performanceLevel: DevicePerformanceDetector.performanceLevel,
        isLandscape: screenSize.width > screenSize.height,
        isTablet: screenSize.shortestSide > 600,
        isLowEndDevice: DevicePerformanceDetector.isLowEndDevice,
      );
    });
  }

  void _startPeriodicUpdate() {
    _updateTimer = Timer.periodic(widget.updateDuration, (_) {
      _updateEnvironmentInfo();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.builder != null && _environmentInfo != null) {
      return widget.builder!(context, _environmentInfo!);
    }
    
    return widget.child;
  }
}

/// 环境信息类
class EnvironmentInfo {
  final Size screenSize;
  final double devicePixelRatio;
  final bool isDarkMode;
  final PerformanceLevel performanceLevel;
  final bool isLandscape;
  final bool isTablet;
  final bool isLowEndDevice;

  const EnvironmentInfo({
    required this.screenSize,
    required this.devicePixelRatio,
    required this.isDarkMode,
    required this.performanceLevel,
    required this.isLandscape,
    required this.isTablet,
    required this.isLowEndDevice,
  });
}