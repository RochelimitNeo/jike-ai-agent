import 'package:flutter/material.dart';
import 'animation_config.dart';
import 'animation_mixins.dart';

/// 元素动画系统
/// 提供按钮、列表、消息等元素的动画效果

/// 按钮动画组件
class AnimatedButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? splashColor;
  final Duration animationDuration;
  final Curve curve;
  final double scaleFactor;
  final bool enableScale;
  final bool enableRipple;
  final BorderRadius? borderRadius;

  const AnimatedButton({
    super.key,
    required this.child,
    this.onPressed,
    this.backgroundColor,
    this.splashColor,
    this.animationDuration = const Duration(milliseconds: 150),
    this.curve = Curves.easeOut,
    this.scaleFactor = 0.95,
    this.enableScale = true,
    this.enableRipple = true,
    this.borderRadius,
  });

  @override
  State<AnimatedButton> createState() => _AnimatedButtonState();
}

class _AnimatedButtonState extends State<AnimatedButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: widget.scaleFactor,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    _colorAnimation = ColorTween(
      begin: widget.backgroundColor,
      end: widget.backgroundColor?.withOpacity(0.8),
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: widget.onPressed,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              decoration: BoxDecoration(
                color: _colorAnimation.value,
                borderRadius: widget.borderRadius ?? BorderRadius.circular(8),
              ),
              child: widget.enableRipple
                  ? Material(
                      color: Colors.transparent,
                      child: InkWell(
                        splashColor: widget.splashColor,
                        borderRadius: widget.borderRadius ?? BorderRadius.circular(8),
                        onTap: widget.onPressed,
                        child: widget.child,
                      ),
                    )
                  : widget.child,
            ),
          );
        },
      ),
    );
  }
}

/// 浮动动作按钮动画
class AnimatedFloatingActionButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Duration animationDuration;
  final double rotationAngle;

  const AnimatedFloatingActionButton({
    super.key,
    required this.child,
    this.onPressed,
    this.backgroundColor,
    this.animationDuration = const Duration(milliseconds: 200),
    this.rotationAngle = 0.0,
  });

  @override
  State<AnimatedFloatingActionButton> createState() => _AnimatedFloatingActionButtonState();
}

class _AnimatedFloatingActionButtonState extends State<AnimatedFloatingActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));

    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: widget.rotationAngle,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _controller.forward().then((_) => _controller.reverse());
        widget.onPressed?.call();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Transform.rotate(
              angle: _rotationAnimation.value,
              child: FloatingActionButton(
                backgroundColor: widget.backgroundColor,
                onPressed: widget.onPressed,
                child: widget.child,
              ),
            ),
          );
        },
      ),
    );
  }
}

/// 列表项动画
class AnimatedListItem extends StatefulWidget {
  final Widget child;
  final int index;
  final Duration delay;
  final Duration duration;
  final Curve curve;
  final SlideDirection slideDirection;

  const AnimatedListItem({
    super.key,
    required this.child,
    required this.index,
    this.delay = const Duration(milliseconds: 100),
    this.duration = const Duration(milliseconds: 400),
    this.curve = Curves.easeOut,
    this.slideDirection = SlideDirection.up,
  });

  @override
  State<AnimatedListItem> createState() => _AnimatedListItemState();
}

class _AnimatedListItemState extends State<AnimatedListItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);

    // 设置初始位置
    Offset beginOffset;
    switch (widget.slideDirection) {
      case SlideDirection.left:
        beginOffset = const Offset(-1.0, 0.0);
        break;
      case SlideDirection.right:
        beginOffset = const Offset(1.0, 0.0);
        break;
      case SlideDirection.up:
        beginOffset = const Offset(0.0, 1.0);
        break;
      case SlideDirection.down:
        beginOffset = const Offset(0.0, -1.0);
        break;
    }

    _slideAnimation = Tween<Offset>(
      begin: beginOffset,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    // 延迟启动动画
    Future.delayed(widget.delay * widget.index, () {
      if (mounted) {
        _controller.forward();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return SlideTransition(
          position: _slideAnimation,
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: widget.child,
          ),
        );
      },
    );
  }
}

/// 列表容器动画
class AnimatedListView extends StatefulWidget {
  final List<Widget> children;
  final Duration itemDelay;
  final Duration itemDuration;
  final SlideDirection slideDirection;
  final Curve curve;
  final ScrollPhysics? physics;
  final EdgeInsetsGeometry? padding;

  const AnimatedListView({
    super.key,
    required this.children,
    this.itemDelay = const Duration(milliseconds: 100),
    this.itemDuration = const Duration(milliseconds: 400),
    this.slideDirection = SlideDirection.up,
    this.curve = Curves.easeOut,
    this.physics,
    this.padding,
  });

  @override
  State<AnimatedListView> createState() => _AnimatedListViewState();
}

class _AnimatedListViewState extends State<AnimatedListView> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: widget.physics,
      padding: widget.padding,
      itemCount: widget.children.length,
      itemBuilder: (context, index) {
        return AnimatedListItem(
          child: widget.children[index],
          index: index,
          delay: widget.itemDelay,
          duration: widget.itemDuration,
          curve: widget.curve,
          slideDirection: widget.slideDirection,
        );
      },
    );
  }
}

/// 网格容器动画
class AnimatedGridView extends StatefulWidget {
  final List<Widget> children;
  final int crossAxisCount;
  final double childAspectRatio;
  final Duration itemDelay;
  final Duration itemDuration;
  final SlideDirection slideDirection;
  final Curve curve;
  final double crossAxisSpacing;
  final double mainAxisSpacing;
  final EdgeInsetsGeometry? padding;

  const AnimatedGridView({
    super.key,
    required this.children,
    required this.crossAxisCount,
    this.childAspectRatio = 1.0,
    this.itemDelay = const Duration(milliseconds: 100),
    this.itemDuration = const Duration(milliseconds: 400),
    this.slideDirection = SlideDirection.up,
    this.curve = Curves.easeOut,
    this.crossAxisSpacing = 8.0,
    this.mainAxisSpacing = 8.0,
    this.padding,
  });

  @override
  State<AnimatedGridView> createState() => _AnimatedGridViewState();
}

class _AnimatedGridViewState extends State<AnimatedGridView> {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: widget.padding,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: widget.crossAxisCount,
        childAspectRatio: widget.childAspectRatio,
        crossAxisSpacing: widget.crossAxisSpacing,
        mainAxisSpacing: widget.mainAxisSpacing,
      ),
      itemCount: widget.children.length,
      itemBuilder: (context, index) {
        return AnimatedListItem(
          child: widget.children[index],
          index: index,
          delay: widget.itemDelay,
          duration: widget.itemDuration,
          curve: widget.curve,
          slideDirection: widget.slideDirection,
        );
      },
    );
  }
}

/// 消息出现动画
class AnimatedMessage extends StatefulWidget {
  final Widget child;
  final MessageType messageType;
  final Duration duration;
  final VoidCallback? onDismiss;
  final bool autoDismiss;

  const AnimatedMessage({
    super.key,
    required this.child,
    this.messageType = MessageType.info,
    this.duration = const Duration(milliseconds: 300),
    this.onDismiss,
    this.autoDismiss = false,
  });

  @override
  State<AnimatedMessage> createState() => _AnimatedMessageState();
}

class _AnimatedMessageState extends State<AnimatedMessage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, -1.0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.bounceOut));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));

    _controller.forward();

    if (widget.autoDismiss) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) {
          _dismiss();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _dismiss() {
    _controller.reverse().then((_) {
      widget.onDismiss?.call();
    });
  }

  Color _getMessageColor() {
    switch (widget.messageType) {
      case MessageType.success:
        return Colors.green;
      case MessageType.error:
        return Colors.red;
      case MessageType.warning:
        return Colors.orange;
      case MessageType.info:
        return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _slideAnimation,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          decoration: BoxDecoration(
            color: _getMessageColor().withOpacity(0.1),
            border: Border.all(color: _getMessageColor(), width: 1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              Expanded(child: widget.child),
              if (widget.onDismiss != null)
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: _dismiss,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 加载动画组件
class AnimatedLoadingIndicator extends StatefulWidget {
  final double size;
  final Color? color;
  final LoadingType type;
  final Duration duration;

  const AnimatedLoadingIndicator({
    super.key,
    this.size = 40.0,
    this.color,
    this.type = LoadingType.circular,
    this.duration = const Duration(milliseconds: 1200),
  });

  @override
  State<AnimatedLoadingIndicator> createState() => _AnimatedLoadingIndicatorState();
}

class _AnimatedLoadingIndicatorState extends State<AnimatedLoadingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotationAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);

    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.linear));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _pulseAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.type) {
      case LoadingType.circular:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              widget.color ?? Theme.of(context).primaryColor,
            ),
          ),
        );
      case LoadingType.spinner:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return Transform.rotate(
                angle: _rotationAnimation.value * 2 * 3.14159,
                child: CustomPaint(
                  painter: SpinnerPainter(
                    color: widget.color ?? Theme.of(context).primaryColor,
                    animation: _rotationAnimation,
                  ),
                ),
              );
            },
          ),
        );
      case LoadingType.pulse:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (widget.color ?? Theme.of(context).primaryColor).withOpacity(_pulseAnimation.value),
                  ),
                ),
              );
            },
          ),
        );
      case LoadingType.dots:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (index) {
            return AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final delay = index * 0.2;
                final time = (_controller.value + delay) % 1.0;
                final scale = time < 0.5 ? time * 2 : (1 - time) * 2;
                
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  width: widget.size / 4,
                  height: widget.size / 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.color ?? Theme.of(context).primaryColor,
                  ),
                  child: Transform.scale(
                    scale: scale,
                  ),
                );
              },
            );
          }),
        );
    }
  }
}

/// 加载类型枚举
enum LoadingType {
  circular,
  spinner,
  pulse,
  dots,
}

/// 消息类型枚举
enum MessageType {
  success,
  error,
  warning,
  info,
}

/// 自定义旋转器绘制器
class SpinnerPainter extends CustomPainter {
  final Color color;
  final Animation<double> animation;

  SpinnerPainter({
    required this.color,
    required this.animation,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final double radius = size.width / 2;
    final Offset center = Offset(size.width / 2, size.height / 2);

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      animation.value * 2 * 3.14159,
      3.14159 / 2,
      false,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant SpinnerPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.animation.value != animation.value;
  }
}

/// 刷新指示器动画
class AnimatedRefreshIndicator extends StatefulWidget {
  final Widget child;
  final RefreshIndicatorTriggerMode triggerMode;
  final RefreshIndicator refreshTriggerPullOffset;
  final Widget? childRefresh;

  const AnimatedRefreshIndicator({
    super.key,
    required this.child,
    this.triggerMode = RefreshIndicatorTriggerMode.anywhere,
    this.refreshTriggerPullOffset = RefreshIndicatorTriggerMode.anywhere == RefreshIndicatorTriggerMode.anywhere 
        ? 80.0 : 40.0,
    this.childRefresh,
  });

  @override
  State<AnimatedRefreshIndicator> createState() => _AnimatedRefreshIndicatorState();
}

class _AnimatedRefreshIndicatorState extends State<AnimatedRefreshIndicator> {
  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      triggerMode: widget.triggerMode,
      edgeOffset: widget.refreshTriggerPullOffset,
      color: Theme.of(context).primaryColor,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      strokeWidth: 3.0,
      onRefresh: () async {
        // 模拟刷新
        await Future.delayed(const Duration(seconds: 2));
      },
      child: widget.child,
    );
  }
}