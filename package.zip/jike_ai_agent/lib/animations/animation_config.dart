import 'package:flutter/material.dart';

/// 动画配置常量 - 保持豆包+Claude设计一致性
class AnimationConfig {
  // 主题颜色 - 与app主题保持一致
  static const Color primaryColor = Color(0xFF2196F3);
  static const Color secondaryColor = Color(0xFF03DAC6);
  static const Color accentColor = Color(0xFF6200EE);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color surfaceColor = Color(0xFFFFFFFF);
  static const Color errorColor = Color(0xFFB00020);

  // 动画持续时间
  static const Duration fastDuration = Duration(milliseconds: 150);
  static const Duration normalDuration = Duration(milliseconds: 300);
  static const Duration slowDuration = Duration(milliseconds: 500);
  static const Duration verySlowDuration = Duration(milliseconds: 800);

  // 缓动曲线
  static const Curve easeOut = Curves.easeOut;
  static const Curve easeIn = Curves.easeIn;
  static const Curve easeInOut = Curves.easeInOut;
  static const Curve bounceOut = Curves.bounceOut;
  static const Curve elasticOut = Curves.elasticOut;
  static const Curve backOut = Curves.backOut;
  static const Curve fastOutSlowIn = Curves.fastOutSlowIn;

  // 间距和尺寸
  static const double minTouchTarget = 48.0;
  static const double cardRadius = 16.0;
  static const double buttonRadius = 8.0;
  static const double smallRadius = 4.0;

  // 阴影配置
  static const double lightShadowBlur = 10.0;
  static const double mediumShadowBlur = 20.0;
  static const double heavyShadowBlur = 30.0;
  static const double shadowOpacity = 0.1;

  // Z轴层级
  static const double elevationLow = 2.0;
  static const double elevationMedium = 4.0;
  static const double elevationHigh = 8.0;

  // 手势阈值
  static const double swipeThreshold = 50.0;
  static const double longPressThreshold = 500.0;
  static const double doubleTapThreshold = 200.0;
  static const double pinchThreshold = 0.1;

  /// 获取主题动画配置
  static ThemeData getThemeAnimationConfig() {
    return ThemeData(
      // 页面转场动画
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
        },
      ),

      // 动画持续时间
      timeDilation: 1.0, // 全局动画速度

      // Material组件动画配置
      materialTapTargetSize: MaterialTapTargetSize.padded,
    );
  }

  /// 获取自定义缓动曲线
  static List<Curve> getCustomCurves() {
    return [
      Curves.easeInOutCubic,  // 平滑过渡
      Curves.elasticInOut,    // 弹性效果
      Curves.bounceInOut,     // 弹跳效果
      Curves.smooth,         // 平滑曲线
      Curves.decelerate,     // 减速
      Curves.accelerate,     // 加速
    ];
  }

  /// 获取预设的动画组合
  static List<AnimationPreset> getPresets() {
    return [
      AnimationPreset(
        name: 'snappy',
        duration: fastDuration,
        curve: easeOut,
        scale: 0.95,
      ),
      AnimationPreset(
        name: 'smooth',
        duration: normalDuration,
        curve: easeInOut,
        scale: 1.0,
      ),
      AnimationPreset(
        name: 'bouncy',
        duration: slowDuration,
        curve: bounceOut,
        scale: 1.05,
      ),
      AnimationPreset(
        name: 'elastic',
        duration: verySlowDuration,
        curve: elasticOut,
        scale: 1.1,
      ),
    ];
  }
}

/// 动画预设配置
class AnimationPreset {
  final String name;
  final Duration duration;
  final Curve curve;
  final double scale;
  final double? opacityStart;
  final double? opacityEnd;

  const AnimationPreset({
    required this.name,
    required this.duration,
    required this.curve,
    required this.scale,
    this.opacityStart,
    this.opacityEnd,
  });

  /// 创建淡入动画
  factory AnimationPreset.fadeIn() {
    return const AnimationPreset(
      name: 'fadeIn',
      duration: Duration(milliseconds: 300),
      curve: Curves.easeIn,
      scale: 1.0,
      opacityStart: 0.0,
      opacityEnd: 1.0,
    );
  }

  /// 创建淡出动画
  factory AnimationPreset.fadeOut() {
    return const AnimationPreset(
      name: 'fadeOut',
      duration: Duration(milliseconds: 300),
      curve: Curves.easeOut,
      scale: 1.0,
      opacityStart: 1.0,
      opacityEnd: 0.0,
    );
  }

  /// 创建滑入动画
  factory AnimationPreset.slideIn({required SlideDirection direction}) {
    return AnimationPreset(
      name: 'slideIn_${direction.name}',
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
      scale: 1.0,
    );
  }

  /// 创建弹跳动画
  factory AnimationPreset.bounce() {
    return const AnimationPreset(
      name: 'bounce',
      duration: Duration(milliseconds: 600),
      curve: Curves.bounceOut,
      scale: 1.1,
    );
  }

  /// 创建缩放动画
  factory AnimationPreset.scale({double targetScale = 1.05}) {
    return AnimationPreset(
      name: 'scale_$targetScale',
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOut,
      scale: targetScale,
    );
  }
}

/// 滑动方向
enum SlideDirection {
  left,
  right,
  up,
  down,
}

/// 动画状态
enum AnimationState {
  idle,
  playing,
  completed,
  error,
}

/// 动画类型
enum AnimationType {
  fade,
  slide,
  scale,
  rotate,
  bounce,
  elastic,
  custom,
}

/// 手势类型
enum GestureType {
  tap,
  doubleTap,
  longPress,
  swipe,
  pinch,
  drag,
  rotation,
}