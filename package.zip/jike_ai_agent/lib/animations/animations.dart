/// 动画和交互效果系统
/// 提供完整的Flutter动画解决方案
/// 
/// 包含以下模块：
/// - 页面转场动画
/// - 元素动画
/// - 手势交互
/// - 视觉反馈
/// - 响应式动画
/// - 动画配置
/// - 动画混入

// 配置和常量
export 'animation_config.dart';

// 动画混入
export 'animation_mixins.dart';

// 页面转场动画
export 'page_transitions.dart';

// 元素动画
export 'element_animations.dart';

// 手势交互
export 'gesture_animations.dart';

// 视觉反馈
export 'visual_feedback.dart';

// 响应式动画
export 'responsive_animations.dart';

/// 快速使用示例：
/// 
/// 1. 按钮动画：
/// ```dart
/// AnimatedButton(
///   child: Text('点击我'),
///   onPressed: () {},
/// )
/// ```
/// 
/// 2. 页面转场：
/// ```dart
/// Navigator.push(
///   context,
///   AdvancedPageTransition(
///     page: NewPage(),
///     transitionType: TransitionType.slideLeft,
///   ),
/// );
/// ```
/// 
/// 3. 手势交互：
/// ```dart
/// GestureDetectorEx(
///   child: Container(),
///   type: GestureType.longPress,
///   onLongPress: () {},
/// )
/// ```
/// 
/// 4. 加载状态：
/// ```dart
/// LoadingStateWidget(
///   type: LoadingType.spinner,
///   message: '加载中...',
/// )
/// ```
/// 
/// 5. 响应式动画：
/// ```dart
/// AdaptiveAnimationWidget(
///   child: MyWidget(),
///   builder: (context, progress) {
///     return Transform.scale(
///       scale: progress,
///       child: MyWidget(),
///     );
///   },
/// )
/// ```
/// 
/// 使用建议：
/// 1. 根据设备性能调整动画复杂度
/// 2. 使用混入手减少重复代码
/// 3. 保持动画与主题的一致性
/// 4. 注意动画性能，避免过于复杂的动画
/// 5. 提供适当的用户反馈