import 'package:flutter/material.dart';
import 'animation_config.dart';

/// 页面转场动画系统
/// 提供多种流畅的页面切换效果

/// 自定义页面转场构建器
class CustomPageTransitions {
  /// 淡入转场
  static Widget fadeTransitions(BuildContext context, Animation<double> animation, 
      Animation<double> secondaryAnimation, Widget child) {
    return FadeTransition(opacity: animation, child: child);
  }

  /// 滑入转场 - 从右到左
  static Widget slideRightToLeft(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    const Offset begin = Offset(1.0, 0.0);
    const Offset end = Offset.zero;
    const Curve curve = Curves.easeInOut;

    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  /// 滑入转场 - 从下到上
  static Widget slideBottomToTop(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    const Offset begin = Offset(0.0, 1.0);
    const Offset end = Offset.zero;
    const Curve curve = Curves.easeOut;

    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  /// 缩放转场
  static Widget scaleTransition(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    const double begin = 0.8;
    const double end = 1.0;

    final scaleAnimation = Tween<double>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: Curves.easeInOut),
    );

    return ScaleTransition(scale: scaleAnimation, child: child);
  }

  /// 旋转缩放转场
  static Widget rotateScaleTransition(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    const double scaleBegin = 0.8;
    const double rotationBegin = -0.1;

    final scaleAnimation = Tween<double>(begin: scaleBegin, end: 1.0).animate(
      CurvedAnimation(parent: animation, curve: Curves.elasticOut),
    );

    final rotationAnimation = Tween<double>(begin: rotationBegin, end: 0.0).animate(
      CurvedAnimation(parent: animation, curve: Curves.elasticOut),
    );

    return AnimatedBuilder(
      animation: Listenable.merge([scaleAnimation, rotationAnimation]),
      builder: (context, child) {
        return Transform.scale(
          scale: scaleAnimation.value,
          child: Transform.rotate(
            angle: rotationAnimation.value,
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  /// 弹性转场
  static Widget elasticTransition(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.scale(
          scale: animation.value,
          child: Transform.rotate(
            angle: (animation.value - 1) * 0.1,
            child: Opacity(
              opacity: animation.value,
              child: child,
            ),
          ),
        );
      },
      child: child,
    );
  }

  /// 3D翻转转场
  static Widget flipTransition(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform(
          transform: Matrix4.rotationY(animation.value * 3.14159),
          alignment: Alignment.center,
          child: child,
        );
      },
      child: child,
    );
  }

  /// 波浪转场
  static Widget waveTransition(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - animation.value) * 50 * animation.value),
          child: Opacity(
            opacity: animation.value,
            child: child,
          ),
        );
      },
      child: child,
    );
  }
}

/// 高级页面转场组件
class AdvancedPageTransition extends PageRouteBuilder {
  final Widget page;
  final Duration duration;
  final Curve curve;
  final TransitionType transitionType;
  final Offset? customOffset;
  final Alignment? customAlignment;

  AdvancedPageTransition({
    required this.page,
    this.duration = const Duration(milliseconds: 300),
    this.curve = Curves.easeInOut,
    this.transitionType = TransitionType.fade,
    this.customOffset,
    this.customAlignment,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => page,
          transitionDuration: duration,
          reverseTransitionDuration: duration,
          barrierColor: Colors.black.withOpacity(0.1),
          barrierDismissible: false,
        );

  @override
  Widget buildTransitions(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    switch (transitionType) {
      case TransitionType.fade:
        return _buildFadeTransition(animation, child);
      case TransitionType.slideLeft:
        return _buildSlideLeftTransition(animation, child);
      case TransitionType.slideRight:
        return _buildSlideRightTransition(animation, child);
      case TransitionType.slideUp:
        return _buildSlideUpTransition(animation, child);
      case TransitionType.slideDown:
        return _buildSlideDownTransition(animation, child);
      case TransitionType.scale:
        return _buildScaleTransition(animation, child);
      case TransitionType.rotate:
        return _buildRotateTransition(animation, child);
      case TransitionType.elastic:
        return _buildElasticTransition(animation, child);
      case TransitionType.flip:
        return _buildFlipTransition(animation, child);
      case TransitionType.custom:
        return _buildCustomTransition(animation, child);
    }
  }

  Widget _buildFadeTransition(Animation<double> animation, Widget child) {
    return FadeTransition(opacity: animation, child: child);
  }

  Widget _buildSlideLeftTransition(Animation<double> animation, Widget child) {
    const Offset begin = Offset(1.0, 0.0);
    final Offset end = customOffset ?? Offset.zero;
    
    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  Widget _buildSlideRightTransition(Animation<double> animation, Widget child) {
    const Offset begin = Offset(-1.0, 0.0);
    final Offset end = customOffset ?? Offset.zero;
    
    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  Widget _buildSlideUpTransition(Animation<double> animation, Widget child) {
    const Offset begin = Offset(0.0, 1.0);
    final Offset end = customOffset ?? Offset.zero;
    
    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  Widget _buildSlideDownTransition(Animation<double> animation, Widget child) {
    const Offset begin = Offset(0.0, -1.0);
    final Offset end = customOffset ?? Offset.zero;
    
    final animationOffset = Tween<Offset>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return SlideTransition(position: animationOffset, child: child);
  }

  Widget _buildScaleTransition(Animation<double> animation, Widget child) {
    const double begin = 0.8;
    const double end = 1.0;

    final scaleAnimation = Tween<double>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return ScaleTransition(scale: scaleAnimation, child: child);
  }

  Widget _buildRotateTransition(Animation<double> animation, Widget child) {
    const double begin = -0.1;
    const double end = 0.0;

    final rotationAnimation = Tween<double>(begin: begin, end: end).animate(
      CurvedAnimation(parent: animation, curve: curve),
    );

    return RotationTransition(turns: rotationAnimation, child: child);
  }

  Widget _buildElasticTransition(Animation<double> animation, Widget child) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.scale(
          scale: animation.value,
          child: Transform.rotate(
            angle: (animation.value - 1) * 0.05,
            child: Opacity(
              opacity: animation.value,
              child: child,
            ),
          ),
        );
      },
      child: child,
    );
  }

  Widget _buildFlipTransition(Animation<double> animation, Widget child) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform(
          transform: Matrix4.rotationY(animation.value * 3.14159),
          alignment: customAlignment ?? Alignment.center,
          child: child,
        );
      },
      child: child,
    );
  }

  Widget _buildCustomTransition(Animation<double> animation, Widget child) {
    // 自定义过渡逻辑
    final scaleAnimation = Tween<double>(begin: 0.9, end: 1.0).animate(
      CurvedAnimation(parent: animation, curve: Curves.elasticOut),
    );

    return ScaleTransition(scale: scaleAnimation, child: child);
  }
}

/// 转场类型枚举
enum TransitionType {
  fade,
  slideLeft,
  slideRight,
  slideUp,
  slideDown,
  scale,
  rotate,
  elastic,
  flip,
  custom,
}

/// 快速转场扩展
extension QuickPageTransitions on Widget {
  /// 淡入转场
  Widget withFadeTransition(BuildContext context, {Duration? duration}) {
    return AnimatedBuilder(
      animation: ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0),
      builder: (context, child) {
        final animation = ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0);
        return FadeTransition(opacity: animation, child: child);
      },
      child: this,
    );
  }

  /// 滑入转场
  Widget withSlideTransition(BuildContext context, {
    Duration? duration,
    SlideDirection direction = SlideDirection.right,
    Curve curve = Curves.easeOut,
  }) {
    return AnimatedBuilder(
      animation: ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0),
      builder: (context, child) {
        final animation = ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0);
        
        Offset beginOffset;
        switch (direction) {
          case SlideDirection.left:
            beginOffset = const Offset(-1.0, 0.0);
            break;
          case SlideDirection.right:
            beginOffset = const Offset(1.0, 0.0);
            break;
          case SlideDirection.up:
            beginOffset = const Offset(0.0, -1.0);
            break;
          case SlideDirection.down:
            beginOffset = const Offset(0.0, 1.0);
            break;
        }

        final animationOffset = Tween<Offset>(begin: beginOffset, end: Offset.zero).animate(
          CurvedAnimation(parent: animation, curve: curve),
        );

        return SlideTransition(position: animationOffset, child: child);
      },
      child: this,
    );
  }

  /// 缩放转场
  Widget withScaleTransition(BuildContext context, {
    Duration? duration,
    Curve curve = Curves.easeInOut,
    double begin = 0.8,
  }) {
    return AnimatedBuilder(
      animation: ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0),
      builder: (context, child) {
        final animation = ModalRoute.of(context)?.animation ?? const AlwaysStoppedAnimation(0.0);
        
        final scaleAnimation = Tween<double>(begin: begin, end: 1.0).animate(
          CurvedAnimation(parent: animation, curve: curve),
        );

        return ScaleTransition(scale: scaleAnimation, child: child);
      },
      child: this,
    );
  }
}

/// 转场动画预设
class PageTransitionPreset {
  final TransitionType type;
  final Duration duration;
  final Curve curve;
  final String name;

  const PageTransitionPreset({
    required this.type,
    required this.duration,
    required this.curve,
    required this.name,
  });

  /// 快速转场
  static const PageTransitionPreset fast = PageTransitionPreset(
    type: TransitionType.scale,
    duration: Duration(milliseconds: 200),
    curve: Curves.easeOut,
    name: 'fast',
  );

  /// 标准转场
  static const PageTransitionPreset standard = PageTransitionPreset(
    type: TransitionType.slideRight,
    duration: Duration(milliseconds: 300),
    curve: Curves.easeInOut,
    name: 'standard',
  );

  /// 流畅转场
  static const PageTransitionPreset smooth = PageTransitionPreset(
    type: TransitionType.fade,
    duration: Duration(milliseconds: 400),
    curve: Curves.easeInOut,
    name: 'smooth',
  );

  /// 弹性转场
  static const PageTransitionPreset elastic = PageTransitionPreset(
    type: TransitionType.elastic,
    duration: Duration(milliseconds: 600),
    curve: Curves.elasticOut,
    name: 'elastic',
  );

  /// 3D转场
  static const PageTransitionPreset flip = PageTransitionPreset(
    type: TransitionType.flip,
    duration: Duration(milliseconds: 500),
    curve: Curves.easeInOut,
    name: 'flip',
  );

  /// 获取预设列表
  static List<PageTransitionPreset> getPresets() {
    return [fast, standard, smooth, elastic, flip];
  }

  /// 根据名称获取预设
  static PageTransitionPreset? getPresetByName(String name) {
    return getPresets().firstWhere(
      (preset) => preset.name == name,
      orElse: () => standard,
    );
  }
}

/// 智能转场选择器
class SmartPageTransitionSelector {
  /// 根据页面类型自动选择合适的转场动画
  static TransitionType selectTransition({
    required String fromPage,
    required String toPage,
    TransitionType? customTransition,
  }) {
    if (customTransition != null) {
      return customTransition;
    }

    // 登录页 -> 主页：使用fade
    if ((fromPage.contains('login') || fromPage.contains('splash')) && 
        toPage.contains('home')) {
      return TransitionType.fade;
    }

    // 主页 -> 详情页：使用slide
    if (fromPage.contains('home') && toPage.contains('detail')) {
      return TransitionType.slideRight;
    }

    // 列表 -> 详情：使用scale
    if (fromPage.contains('list') && toPage.contains('detail')) {
      return TransitionType.scale;
    }

    // 设置页面：使用slide
    if (toPage.contains('setting') || toPage.contains('config')) {
      return TransitionType.slideLeft;
    }

    // 默认使用标准转场
    return TransitionType.standard;
  }

  /// 根据设备性能选择动画
  static Duration selectDuration({
    required bool isLowEndDevice,
    Duration? customDuration,
  }) {
    if (customDuration != null) {
      return customDuration;
    }

    if (isLowEndDevice) {
      return const Duration(milliseconds: 200);
    }

    return const Duration(milliseconds: 300);
  }
}