---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022100a695950c72c0c7adf7b88363e749177ac22a751aac2abc68188ad0af0ba2d7c202203440146a122007f805ad23bc15206d98fa8190ea00a931b99ed2639859afbe91
    ReservedCode2: 3046022100ed714164a7bfd86001e2e6c4546bdb9b4e8b5f2319bd85bcfcfc218f80ff28950221008f0a6796435612b30ff7ead1c81891d60bf48f0331eccf20cd4db5211c288363
---

# Flutter 动画和交互效果系统

一个完整的Flutter动画和交互效果解决方案，提供流畅的动画体验和丰富的交互功能。

## 🌟 特性

- **页面转场动画** - 多种流畅的页面切换效果
- **元素动画** - 按钮、列表、加载等元素动画
- **手势交互** - 支持滑动、长按、双击、双指缩放等
- **视觉反馈** - 点击反馈、状态提示、加载动画等
- **响应式动画** - 根据设备和用户操作动态调整
- **性能优化** - 自适应设备性能，确保流畅体验
- **设计一致性** - 保持豆包+Claude的设计风格

## 📁 目录结构

```
lib/animations/
├── animations.dart              # 主入口文件
├── animation_config.dart        # 动画配置常量
├── animation_mixins.dart        # 动画混入类
├── page_transitions.dart       # 页面转场动画
├── element_animations.dart     # 元素动画
├── gesture_animations.dart      # 手势交互
├── visual_feedback.dart        # 视觉反馈
├── responsive_animations.dart  # 响应式动画
├── example.dart                # 使用示例
└── README.md                   # 说明文档
```

## 🚀 快速开始

### 1. 导入动画系统

```dart
import 'package:your_app/animations/animations.dart';
```

### 2. 基础使用

#### 按钮动画
```dart
AnimatedButton(
  child: Text('点击我'),
  onPressed: () {
    print('按钮被点击');
  },
)
```

#### 页面转场
```dart
Navigator.push(
  context,
  AdvancedPageTransition(
    page: NewPage(),
    transitionType: TransitionType.slideLeft,
  ),
);
```

#### 手势交互
```dart
GestureDetectorEx(
  type: GestureType.longPress,
  onLongPress: () {
    print('检测到长按');
  },
  child: Container(),
)
```

## 🎨 动画组件详细说明

### 1. 页面转场动画

#### 基础转场
- `TransitionType.fade` - 淡入淡出
- `TransitionType.slideLeft/Right/Up/Down` - 滑动转场
- `TransitionType.scale` - 缩放转场
- `TransitionType.rotate` - 旋转转场

#### 高级转场
- `TransitionType.elastic` - 弹性转场
- `TransitionType.flip` - 3D翻转转场
- `TransitionType.custom` - 自定义转场

```dart
// 快速转场
AdvancedPageTransition(
  page: DetailPage(),
  transitionType: TransitionType.slideRight,
  duration: Duration(milliseconds: 300),
  curve: Curves.easeInOut,
);

// 预设转场
AdvancedPageTransition(
  page: DetailPage(),
  // 使用预设配置
  // PageTransitionPreset.elastic
  // PageTransitionPreset.flip
  // PageTransitionPreset.smooth
);
```

### 2. 元素动画

#### 按钮动画
```dart
// 标准按钮
AnimatedButton(
  child: Text('按钮'),
  onPressed: () {},
  backgroundColor: Colors.blue,
  enableScale: true,
  enableRipple: true,
)

// 浮动按钮
AnimatedFloatingActionButton(
  child: Icon(Icons.add),
  onPressed: () {},
  rotationAngle: 45.0,
)
```

#### 列表动画
```dart
// 动画列表
AnimatedListView(
  children: [
    ListTile(title: Text('项目 1')),
    ListTile(title: Text('项目 2')),
    ListTile(title: Text('项目 3')),
  ],
  slideDirection: SlideDirection.up,
  itemDelay: Duration(milliseconds: 100),
)

// 单个列表项
AnimatedListItem(
  child: ListTile(title: Text('项目')),
  index: 0,
  slideDirection: SlideDirection.left,
)
```

#### 加载动画
```dart
LoadingStateWidget(
  type: LoadingType.circular, // circular, spinner, pulse, dots
  message: '加载中...',
  size: 40.0,
)
```

### 3. 手势交互

#### 基础手势
```dart
GestureDetectorEx(
  type: GestureType.tap,        // 轻触
  onTap: () => print('轻触'),
  
  type: GestureType.doubleTap,   // 双击
  onDoubleTap: () => print('双击'),
  
  type: GestureType.longPress,   // 长按
  onLongPress: () => print('长按'),
)
```

#### 滑动手势
```dart
SwipeableWidget(
  direction: SwipeDirection.left,
  threshold: 100.0,
  onSwipe: (direction, velocity) {
    print('滑动方向: $direction');
  },
  child: Container(),
)
```

#### 捏合缩放
```dart
PinchableWidget(
  minScale: 0.5,
  maxScale: 3.0,
  onScaleChanged: (scale) {
    print('缩放比例: $scale');
  },
  child: Image.network('url'),
)
```

#### 长按反馈
```dart
LongPressableWidget(
  duration: Duration(milliseconds: 500),
  onLongPress: () {
    print('长按操作');
  },
  feedbackWidget: Icon(Icons.feedback),
  child: Container(),
)
```

### 4. 视觉反馈

#### 点击反馈
```dart
TapFeedbackWidget(
  onTap: () => print('点击'),
  splashColor: Colors.grey,
  highlightColor: Colors.lightBlue,
  borderRadius: 8.0,
  child: Container(),
)
```

#### 涟漪反馈
```dart
RippleFeedbackWidget(
  onTap: () => print('涟漪'),
  rippleColor: Colors.blue,
  duration: Duration(milliseconds: 400),
  child: Container(),
)
```

#### 状态反馈
```dart
// 加载状态
StateManager.getStateWidget(
  state: StateManager.loadingState,
  message: '正在加载...',
)

// 成功状态
StateManager.getStateWidget(
  state: StateManager.successState,
  message: '操作成功',
)

// 错误状态
StateManager.getStateWidget(
  state: StateManager.errorState,
  message: '操作失败',
  onRetry: () => retry(),
)

// 空状态
StateManager.getStateWidget(
  state: StateManager.emptyState,
  message: '暂无数据',
  onAction: () => addData(),
  actionText: '添加数据',
)
```

### 5. 响应式动画

#### 自适应动画
```dart
AdaptiveAnimationWidget(
  duration: Duration(milliseconds: 300),
  builder: (context, progress) {
    return Transform.scale(
      scale: progress,
      child: Container(),
    );
  },
)
```

#### 智能滚动
```dart
SmartScrollAnimation(
  controller: scrollController,
  child: ListView.builder(...),
  enableElastic: true,
)

// 滚动方法
scrollController.scrollToTop();
scrollController.scrollToBottom();
```

#### 手势响应式
```dart
GestureResponsiveAnimation(
  child: Container(),
  onProgress: (progress) {
    print('响应强度: $progress');
  },
  intensity: 1.0,
)
```

## 🎯 高级功能

### 1. 动画混入类

使用混入类减少重复代码：

```dart
class MyWidget extends StatefulWidget 
    with ScaleAnimationMixin, FadeAnimationMixin {
  
  @override
  void initState() {
    super.initState();
    initScaleAnimation();
    initFadeAnimation();
  }
  
  @override
  Widget build(BuildContext context) {
    return buildScaleAnimation(
      child: buildFadeAnimation(
        child: Container(),
      ),
    );
  }
}
```

### 2. 性能优化

系统自动检测设备性能并优化：

```dart
// 获取设备性能
bool isLowEnd = DevicePerformanceDetector.isLowEndDevice;
PerformanceLevel level = DevicePerformanceDetector.performanceLevel;

// 自适应动画持续时间
Duration duration = DevicePerformanceDetector.getAnimationDuration(
  Duration(milliseconds: 300),
);

// 根据性能启用/禁用复杂动画
bool enableComplex = DevicePerformanceDetector.enableComplexAnimations();
```

### 3. 环境感知

根据运行环境调整动画：

```dart
EnvironmentAwareAnimation(
  builder: (context, info) {
    return Container(
      child: info.isDarkMode ? DarkTheme() : LightTheme(),
    );
  },
)
```

### 4. 自定义动画配置

```dart
class CustomAnimationPreset extends AnimationPreset {
  const CustomAnimationPreset()
    : super(
        name: 'custom',
        duration: Duration(milliseconds: 400),
        curve: Curves.elasticOut,
        scale: 1.1,
      );
}
```

## 📱 设备适配

### 低端设备
- 减少动画复杂度
- 缩短动画持续时间
- 使用简单的缓动曲线
- 禁用粒子效果

### 高端设备
- 启用复杂动画
- 增加动画持续时间
- 使用弹性动画
- 启用粒子效果

### 平板设备
- 调整触摸目标大小
- 优化布局动画
- 适配横屏模式

## 🔧 配置选项

### 主题配置
```dart
MaterialApp(
  theme: ThemeData(
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
      },
    ),
    timeDilation: 1.0, // 全局动画速度
  ),
)
```

### 动画预设
```dart
// 快速动画
AnimationPreset.fast

// 标准动画
AnimationPreset.standard

// 弹性动画
AnimationPreset.elastic

// 自定义动画
AnimationPreset(
  name: 'myPreset',
  duration: Duration(milliseconds: 300),
  curve: Curves.bounceOut,
  scale: 1.05,
)
```

## 🐛 常见问题

### Q: 动画性能不好怎么办？
A: 
1. 检查设备性能级别
2. 减少同时播放的动画数量
3. 使用简单的缓动曲线
4. 启用性能模式

### Q: 如何自定义动画持续时间？
A:
```dart
AnimatedButton(
  animationDuration: Duration(milliseconds: 200),
  child: Text('按钮'),
  onPressed: () {},
)
```

### Q: 如何禁用动画？
A:
```dart
// 全局禁用
MaterialApp(
  theme: ThemeData(timeDilation: 0.0),
)

// 组件级禁用
AnimatedButton(
  // 将duration设为0
  animationDuration: Duration.zero,
)
```

## 📝 使用建议

1. **保持一致性**: 使用统一的动画预设和配置
2. **性能优先**: 根据设备性能调整动画复杂度
3. **用户反馈**: 为重要操作提供视觉反馈
4. **可访问性**: 考虑减少动画选项
5. **测试**: 在不同设备和网络环境下测试动画效果

## 📄 许可证

本项目采用 MIT 许可证。详情请参阅 LICENSE 文件。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📞 支持

如有问题，请创建 Issue 或联系维护者。