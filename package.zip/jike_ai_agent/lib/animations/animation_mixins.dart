import 'package:flutter/material.dart';
import 'animation_config.dart';

/// 基础动画混入 - 提供常用的动画控制功能
mixin BaseAnimationMixin on State<StatefulWidget> {
  // 动画控制器映射
  final Map<String, AnimationController> _animationControllers = {};
  final Map<String, Animation> _animations = {};

  /// 创建动画控制器
  AnimationController createAnimationController({
    required String name,
    required Duration duration,
    TickerProvider? vsync,
  }) {
    if (_animationControllers.containsKey(name)) {
      _animationControllers[name]?.dispose();
    }
    
    final controller = AnimationController(
      duration: duration,
      vsync: vsync ?? this,
    );
    
    _animationControllers[name] = controller;
    return controller;
  }

  /// 创建动画
  Animation<T> createAnimation<T>({
    required String name,
    required AnimationController controller,
    required Curve curve,
    T? begin,
    T? end,
  }) {
    final animation = CurvedAnimation(
      parent: controller,
      curve: curve,
    );
    
    _animations[name] = animation;
    return animation;
  }

  /// 播放动画
  void playAnimation(String name) {
    final controller = _animationControllers[name];
    controller?.forward();
  }

  /// 反向播放动画
  void reverseAnimation(String name) {
    final controller = _animationControllers[name];
    controller?.reverse();
  }

  /// 重置动画
  void resetAnimation(String name) {
    final controller = _animationControllers[name];
    controller?.reset();
  }

  /// 循环播放动画
  void loopAnimation(String name) {
    final controller = _animationControllers[name];
    controller?.repeat();
  }

  /// 停止动画
  void stopAnimation(String name) {
    final controller = _animationControllers[name];
    controller?.stop();
  }

  /// 获取动画值
  T? getAnimationValue<T>(String name) {
    final animation = _animations[name] as Animation<T>?;
    return animation?.value;
  }

  /// 批量创建动画
  void createBatchAnimations(List<BatchAnimationConfig> configs) {
    for (final config in configs) {
      createAnimationController(
        name: config.name,
        duration: config.duration,
        vsync: this,
      );
    }
  }

  /// 清理所有动画
  @override
  void dispose() {
    for (final controller in _animationControllers.values) {
      controller.dispose();
    }
    _animationControllers.clear();
    _animations.clear();
    super.dispose();
  }
}

/// 批量动画配置
class BatchAnimationConfig {
  final String name;
  final Duration duration;
  final Curve curve;
  final double? begin;
  final double? end;

  const BatchAnimationConfig({
    required this.name,
    required this.duration,
    required this.curve,
    this.begin,
    this.end,
  });
}

/// 缩放动画混入
mixin ScaleAnimationMixin on State<StatefulWidget> {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;

  /// 初始化缩放动画
  void initScaleAnimation({
    Duration duration = const Duration(milliseconds: 200),
    Curve curve = Curves.easeOut,
    double minScale = 0.95,
    double maxScale = 1.05,
  }) {
    _scaleController = AnimationController(
      duration: duration,
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: minScale,
      end: maxScale,
    ).animate(CurvedAnimation(
      parent: _scaleController,
      curve: curve,
    ));
  }

  /// 播放缩放动画
  Future<void> playScaleAnimation({
    bool forward = true,
    VoidCallback? onComplete,
  }) async {
    if (forward) {
      await _scaleController.forward();
    } else {
      await _scaleController.reverse();
    }
    onComplete?.call();
  }

  /// 缩放动画Widget
  Widget buildScaleAnimation({
    required Widget child,
    double? scaleOverride,
  }) {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        final scale = scaleOverride ?? _scaleAnimation.value;
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: child,
    );
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }
}

/// 淡入淡出动画混入
mixin FadeAnimationMixin on State<StatefulWidget> {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  /// 初始化淡入淡出动画
  void initFadeAnimation({
    Duration duration = const Duration(milliseconds: 300),
    Curve curve = Curves.easeInOut,
    double beginOpacity = 0.0,
    double endOpacity = 1.0,
  }) {
    _fadeController = AnimationController(
      duration: duration,
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: beginOpacity,
      end: endOpacity,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: curve,
    ));
  }

  /// 播放淡入动画
  Future<void> playFadeIn() async {
    await _fadeController.forward();
  }

  /// 播放淡出动画
  Future<void> playFadeOut() async {
    await _fadeController.reverse();
  }

  /// 淡入淡出动画Widget
  Widget buildFadeAnimation({
    required Widget child,
    double? opacityOverride,
  }) {
    return AnimatedBuilder(
      animation: _fadeAnimation,
      builder: (context, child) {
        final opacity = opacityOverride ?? _fadeAnimation.value;
        return Opacity(
          opacity: opacity,
          child: child,
        );
      },
      child: child,
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }
}

/// 滑入滑出动画混入
mixin SlideAnimationMixin on State<StatefulWidget> {
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  /// 初始化滑入动画
  void initSlideAnimation({
    Duration duration = const Duration(milliseconds: 400),
    Curve curve = Curves.easeOut,
    Offset beginOffset = const Offset(0, 1),
    Offset endOffset = Offset.zero,
    SlideDirection? direction,
  }) {
    _slideController = AnimationController(
      duration: duration,
      vsync: this,
    );

    Offset beginOffset = beginOffset;
    if (direction != null) {
      switch (direction) {
        case SlideDirection.left:
          beginOffset = const Offset(-1, 0);
          break;
        case SlideDirection.right:
          beginOffset = const Offset(1, 0);
          break;
        case SlideDirection.up:
          beginOffset = const Offset(0, -1);
          break;
        case SlideDirection.down:
          beginOffset = const Offset(0, 1);
          break;
      }
    }

    _slideAnimation = Tween<Offset>(
      begin: beginOffset,
      end: endOffset,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: curve,
    ));
  }

  /// 播放滑入动画
  Future<void> playSlideIn() async {
    await _slideController.forward();
  }

  /// 播放滑出动画
  Future<void> playSlideOut() async {
    await _slideController.reverse();
  }

  /// 滑入滑出动画Widget
  Widget buildSlideAnimation({
    required Widget child,
    Offset? offsetOverride,
  }) {
    return AnimatedBuilder(
      animation: _slideAnimation,
      builder: (context, child) {
        final offset = offsetOverride ?? _slideAnimation.value;
        return Transform.translate(
          offset: offset,
          child: child,
        );
      },
      child: child,
    );
  }

  @override
  void dispose() {
    _slideController.dispose();
    super.dispose();
  }
}

/// 组合动画混入
mixin CompositeAnimationMixin on State<StatefulWidget> {
  late AnimationController _compositeController;
  late List<Animation> _compositeAnimations;

  /// 初始化组合动画
  void initCompositeAnimation({
    required Duration duration,
    List<AnimationConfigItem>? animations,
  }) {
    _compositeController = AnimationController(
      duration: duration,
      vsync: this,
    );

    _compositeAnimations = animations?.map((config) {
      return CurvedAnimation(
        parent: _compositeController,
        curve: config.curve,
      );
    }).toList() ?? [];
  }

  /// 播放组合动画
  Future<void> playCompositeAnimation() async {
    await _compositeController.forward();
  }

  /// 获取组合动画的子动画
  Animation<T>? getCompositeAnimation<T>(int index) {
    if (index < _compositeAnimations.length) {
      return _compositeAnimations[index] as Animation<T>?;
    }
    return null;
  }

  @override
  void dispose() {
    _compositeController.dispose();
    super.dispose();
  }
}

/// 组合动画配置项
class AnimationConfigItem {
  final Curve curve;
  final Duration? customDuration;

  const AnimationConfigItem({
    required this.curve,
    this.customDuration,
  });
}