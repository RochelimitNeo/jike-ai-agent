/// 动画系统集成指南
/// 
/// 本文件展示如何将动画系统集成到现有Flutter项目中

import 'package:flutter/material.dart';
import 'animations.dart';

/// 主应用集成示例
class IntegratedApp extends StatelessWidget {
  const IntegratedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '集成动画系统的应用',
      debugShowCheckedModeBanner: false,
      
      // 使用动画配置
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: const Color(0xFF2196F3),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2196F3),
          brightness: Brightness.light,
        ),
        
        // 应用动画配置
        useMaterial3: true,
        
        // 配置页面转场
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
            TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
          },
        ),
        
        // 全局动画速度
        timeDilation: 1.0,
      ),
      
      home: const IntegratedHomePage(),
      
      // 使用自定义路由（可选）
      onGenerateRoute: _generateRoute,
    );
  }

  Route<dynamic> _generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/home':
        return AdvancedPageTransition(
          page: const IntegratedHomePage(),
          transitionType: TransitionType.fade,
        );
      case '/detail':
        final args = settings.arguments as String?;
        return AdvancedPageTransition(
          page: DetailPage(title: args ?? '详情'),
          transitionType: TransitionType.slideRight,
        );
      default:
        return MaterialPageRoute(
          builder: (context) => const Scaffold(
            body: Center(child: Text('页面未找到')),
          ),
        );
    }
  }
}

/// 集成动画的首页
class IntegratedHomePage extends StatelessWidget {
  const IntegratedHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('动画系统集成示例'),
        backgroundColor: const Color(0xFF2196F3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: const IntegratedHomeContent(),
    );
  }
}

/// 集成动画的内容区域
class IntegratedHomeContent extends StatefulWidget {
  const IntegratedHomeContent({super.key});

  @override
  State<IntegratedHomeContent> createState() => _IntegratedHomeContentState();
}

class _IntegratedHomeContentState extends State<IntegratedHomeContent> {
  int _selectedIndex = 0;
  bool _isLoading = false;
  String _statusMessage = '';

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // 动画按钮示例
        _buildSection(
          '动画按钮',
          Row(
            children: [
              Expanded(
                child: AnimatedButton(
                  onPressed: () => _navigateToDetail(context, '标准按钮'),
                  backgroundColor: Theme.of(context).primaryColor,
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    child: const Text(
                      '标准按钮',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              AnimatedFloatingActionButton(
                onPressed: () => _navigateToDetail(context, '浮动按钮'),
                child: const Icon(Icons.add),
              ),
            ],
          ),
        ),

        // 动画列表示例
        _buildSection(
          '动画列表',
          AnimatedListView(
            slideDirection: SlideDirection.up,
            children: [
              _buildListTile('智能助手', 'AI驱动的智能助手', Icons.smart_toy),
              _buildListTile('语音识别', '语音转文字功能', Icons.mic),
              _buildListTile('图像识别', '图片内容识别', Icons.image),
              _buildListTile('自然语言', '自然语言处理', Icons.chat),
            ],
          ),
        ),

        // 手势交互示例
        _buildSection(
          '手势交互',
          SwipeableWidget(
            direction: SwipeDirection.left,
            onSwipe: (direction, velocity) {
              _showMessage('滑动方向: $direction');
            },
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue, Colors.purple],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text(
                '左右滑动试试',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ),

        // 加载状态示例
        _buildSection(
          '加载状态',
          AnimatedButton(
            onPressed: _simulateLoading,
            child: Container(
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isLoading)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                  if (_isLoading) const SizedBox(width: 8),
                  Text(
                    _isLoading ? '加载中...' : '开始加载',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // 视觉反馈示例
        _buildSection(
          '视觉反馈',
          Row(
            children: [
              Expanded(
                child: TapFeedbackWidget(
                  onTap: () => _showMessage('涟漪反馈'),
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.purple,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      '涟漪反馈',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: RippleFeedbackWidget(
                  onTap: () => _showMessage('波纹反馈'),
                  child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.indigo,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      '波纹反馈',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // 状态管理示例
        _buildSection(
          '状态管理',
          StateManager.getStateWidget(
            state: _getStateFromMessage(_statusMessage),
            message: _statusMessage.isEmpty ? '点击下方按钮测试状态' : _statusMessage,
            onRetry: () => setState(() => _statusMessage = ''),
            actionText: '测试状态',
            onAction: () => _showMessage('执行了自定义操作'),
          ),
        ),
      ],
    );
  }

  Widget _buildSection(String title, Widget child) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        child,
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildListTile(String title, String subtitle, IconData icon) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: Theme.of(context).primaryColor),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _navigateToDetail(context, title),
      ),
    );
  }

  void _navigateToDetail(BuildContext context, String title) {
    Navigator.pushNamed(context, '/detail', arguments: title);
  }

  void _simulateLoading() async {
    setState(() => _isLoading = true);
    
    // 模拟异步操作
    await Future.delayed(const Duration(seconds: 2));
    
    if (mounted) {
      setState(() {
        _isLoading = false;
        _statusMessage = '操作完成！';
      });
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  int _getStateFromMessage(String message) {
    if (message.contains('加载')) return StateManager.loadingState;
    if (message.contains('完成') || message.contains('成功')) return StateManager.successState;
    if (message.contains('失败') || message.contains('错误')) return StateManager.errorState;
    if (message.isEmpty) return StateManager.normalState;
    return StateManager.normalState;
  }
}

/// 详情页面示例
class DetailPage extends StatelessWidget {
  final String title;

  const DetailPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: const Color(0xFF2196F3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.animation,
              size: 80,
              color: Theme.of(context).primaryColor,
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '这是详情页面',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            AnimatedButton(
              onPressed: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '返回',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 集成到现有Widget的示例
class ExistingWidgetWithAnimation extends StatelessWidget {
  const ExistingWidgetWithAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // 使用动画标题
            Text(
              '带有动画的卡片',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            
            // 使用动画按钮
            AnimatedButton(
              onPressed: () => _showActionDialog(context),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                alignment: Alignment.center,
                child: const Text(
                  '执行操作',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showActionDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('操作确认'),
        content: const Text('您确定要执行此操作吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          AnimatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('操作已执行')),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                '确认',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 集成建议
/// 
/// 1. 在main.dart中应用主题配置
/// 2. 使用AnimatedButton替换所有按钮
/// 3. 使用AnimatedListView替换静态列表
/// 4. 添加手势交互到关键功能
/// 5. 使用StateManager管理加载状态
/// 6. 定期检查设备性能并优化动画
/// 7. 保持动画风格的一致性