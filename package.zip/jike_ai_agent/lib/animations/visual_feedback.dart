import 'package:flutter/material.dart';
import 'animation_config.dart';
import 'animation_mixins.dart';

/// 视觉反馈系统
/// 提供点击反馈、加载状态、错误提示等视觉反馈效果

/// 点击反馈效果
class TapFeedbackWidget extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color? splashColor;
  final Color? highlightColor;
  final double borderRadius;
  final Duration duration;
  final Curve curve;
  final double scaleFactor;

  const TapFeedbackWidget({
    super.key,
    required this.child,
    this.onTap,
    this.splashColor,
    this.highlightColor,
    this.borderRadius = 8.0,
    this.duration = const Duration(milliseconds: 150),
    this.curve = Curves.easeOut,
    this.scaleFactor = 0.95,
  });

  @override
  State<TapFeedbackWidget> createState() => _TapFeedbackWidgetState();
}

class _TapFeedbackWidgetState extends State<TapFeedbackWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: widget.scaleFactor,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) => _controller.reverse(),
      onTapCancel: () => _controller.reverse(),
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(widget.borderRadius),
              child: InkWell(
                splashColor: widget.splashColor,
                highlightColor: widget.highlightColor,
                borderRadius: BorderRadius.circular(widget.borderRadius),
                onTap: widget.onTap,
                child: widget.child,
              ),
            ),
          );
        },
      ),
    );
  }
}

/// 涟漪反馈效果
class RippleFeedbackWidget extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color rippleColor;
  final Color? overlayColor;
  final Duration duration;
  final double borderRadius;

  const RippleFeedbackWidget({
    super.key,
    required this.child,
    this.onTap,
    this.rippleColor = Colors.grey,
    this.overlayColor,
    this.duration = const Duration(milliseconds: 400),
    this.borderRadius = 8.0,
  });

  @override
  State<RippleFeedbackWidget> createState() => _RippleFeedbackWidgetState();
}

class _RippleFeedbackWidgetState extends State<RippleFeedbackWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _opacityAnimation = Tween<double>(
      begin: 0.5,
      end: 0.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _playRipple() {
    _controller.forward().then((_) {
      _controller.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _playRipple();
        widget.onTap?.call();
      },
      child: Stack(
        children: [
          widget.child,
          AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              if (_controller.isAnimating) {
                return Positioned.fill(
                  child: CustomPaint(
                    painter: RipplePainter(
                      animation: _scaleAnimation,
                      color: widget.rippleColor.withOpacity(_opacityAnimation.value),
                      borderRadius: widget.borderRadius,
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
    );
  }
}

/// 涟漪绘制器
class RipplePainter extends CustomPainter {
  final Animation<double> animation;
  final Color color;
  final double borderRadius;

  RipplePainter({
    required this.animation,
    required this.color,
    required this.borderRadius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width + size.height) / 4 * animation.value;
    
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant RipplePainter oldDelegate) {
    return oldDelegate.animation.value != animation.value ||
           oldDelegate.color != color;
  }
}

/// 加载状态指示器
class LoadingStateWidget extends StatefulWidget {
  final LoadingType type;
  final String? message;
  final double size;
  final Color? color;
  final Widget? customWidget;
  final Duration duration;
  final bool showMessage;

  const LoadingStateWidget({
    super.key,
    this.type = LoadingType.circular,
    this.message,
    this.size = 40.0,
    this.color,
    this.customWidget,
    this.duration = const Duration(milliseconds: 1200),
    this.showMessage = true,
  });

  @override
  State<LoadingStateWidget> createState() => _LoadingStateWidgetState();
}

class _LoadingStateWidgetState extends State<LoadingStateWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotationAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );

    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.linear));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _pulseAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildLoadingWidget() {
    switch (widget.type) {
      case LoadingType.circular:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              widget.color ?? Theme.of(context).primaryColor,
            ),
            strokeWidth: 3,
          ),
        );
      
      case LoadingType.spinner:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return Transform.rotate(
                angle: _rotationAnimation.value * 2 * 3.14159,
                child: CustomPaint(
                  painter: SpinnerPainter(
                    color: widget.color ?? Theme.of(context).primaryColor,
                    animation: _rotationAnimation,
                  ),
                ),
              );
            },
          ),
        );
      
      case LoadingType.pulse:
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (widget.color ?? Theme.of(context).primaryColor)
                        .withOpacity(_pulseAnimation.value * 0.3),
                    border: Border.all(
                      color: widget.color ?? Theme.of(context).primaryColor,
                      width: 2,
                    ),
                  ),
                ),
              );
            },
          ),
        );
      
      case LoadingType.dots:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (index) {
            return AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final delay = index * 0.2;
                final time = (_controller.value + delay) % 1.0;
                final scale = time < 0.5 ? time * 2 : (1 - time) * 2;
                
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: widget.size / 20),
                  width: widget.size / 4,
                  height: widget.size / 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.color ?? Theme.of(context).primaryColor,
                  ),
                  child: Transform.scale(
                    scale: scale,
                  ),
                );
              },
            );
          }),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        widget.customWidget ?? _buildLoadingWidget(),
        if (widget.showMessage && widget.message != null) ...[
          SizedBox(height: widget.size / 4),
          Text(
            widget.message!,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ],
    );
  }
}

/// 错误提示组件
class ErrorStateWidget extends StatefulWidget {
  final String message;
  final String? details;
  final VoidCallback? onRetry;
  final String? retryText;
  final Widget? icon;
  final Color? backgroundColor;
  final Color? textColor;
  final Duration animationDuration;

  const ErrorStateWidget({
    super.key,
    required this.message,
    this.details,
    this.onRetry,
    this.retryText,
    this.icon,
    this.backgroundColor,
    this.textColor,
    this.animationDuration = const Duration(milliseconds: 500),
  });

  @override
  State<ErrorStateWidget> createState() => _ErrorStateWidgetState();
}

class _ErrorStateWidgetState extends State<ErrorStateWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeIn));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = widget.backgroundColor ?? theme.colorScheme.errorContainer;
    final txtColor = widget.textColor ?? theme.colorScheme.onErrorContainer;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Opacity(
            opacity: _fadeAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.error.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    widget.icon ?? Icons.error_outline,
                    size: 48,
                    color: theme.colorScheme.error,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.message,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: txtColor,
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  if (widget.details != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      widget.details!,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: txtColor.withOpacity(0.7),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                  if (widget.onRetry != null) ...[
                    const SizedBox(height: 16),
                    TapFeedbackWidget(
                      onTap: widget.onRetry,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primary,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          widget.retryText ?? '重试',
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: theme.colorScheme.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// 空状态组件
class EmptyStateWidget extends StatefulWidget {
  final String message;
  final String? subtitle;
  final Widget? icon;
  final VoidCallback? onAction;
  final String? actionText;
  final Color? backgroundColor;
  final Duration animationDuration;

  const EmptyStateWidget({
    super.key,
    required this.message,
    this.subtitle,
    this.icon,
    this.onAction,
    this.actionText,
    this.backgroundColor,
    this.animationDuration = const Duration(milliseconds: 600),
  });

  @override
  State<EmptyStateWidget> createState() => _EmptyStateWidgetState();
}

class _EmptyStateWidgetState extends State<EmptyStateWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return SlideTransition(
          position: _slideAnimation,
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Container(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  widget.icon ?? Icon(
                    Icons.inbox_outlined,
                    size: 64,
                    color: theme.colorScheme.onSurface.withOpacity(0.3),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    widget.message,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withOpacity(0.8),
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  if (widget.subtitle != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      widget.subtitle!,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                  if (widget.onAction != null && widget.actionText != null) ...[
                    const SizedBox(height: 24),
                    TapFeedbackWidget(
                      onTap: widget.onAction,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primary,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          widget.actionText!,
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: theme.colorScheme.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// 成功状态组件
class SuccessStateWidget extends StatefulWidget {
  final String message;
  final VoidCallback? onDismiss;
  final Duration duration;
  final bool autoDismiss;
  final Widget? icon;
  final Color? backgroundColor;

  const SuccessStateWidget({
    super.key,
    required this.message,
    this.onDismiss,
    this.duration = const Duration(milliseconds: 300),
    this.autoDismiss = false,
    this.icon,
    this.backgroundColor,
  });

  @override
  State<SuccessStateWidget> createState() => _SuccessStateWidgetState();
}

class _SuccessStateWidgetState extends State<SuccessStateWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeIn));

    _controller.forward();

    if (widget.autoDismiss) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) {
          _dismiss();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _dismiss() {
    _controller.reverse().then((_) {
      widget.onDismiss?.call();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = widget.backgroundColor ?? theme.colorScheme.primaryContainer;

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Opacity(
            opacity: _fadeAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.primary,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  widget.icon ?? Icon(
                    Icons.check_circle_outline,
                    color: theme.colorScheme.primary,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.message,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  if (widget.onDismiss != null)
                    IconButton(
                      icon: Icon(
                        Icons.close,
                        color: theme.colorScheme.onPrimaryContainer,
                        size: 20,
                      ),
                      onPressed: _dismiss,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(
                        minWidth: 32,
                        minHeight: 32,
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// 状态管理器
class StateManager {
  static const int loadingState = 0;
  static const int successState = 1;
  static const int errorState = 2;
  static const int emptyState = 3;
  static const int normalState = 4;

  static Widget getStateWidget({
    required int state,
    String? message,
    String? details,
    VoidCallback? onRetry,
    VoidCallback? onAction,
    String? actionText,
    Widget? icon,
    Color? backgroundColor,
  }) {
    switch (state) {
      case loadingState:
        return LoadingStateWidget(
          message: message ?? '加载中...',
          type: LoadingType.circular,
        );
      case successState:
        return SuccessStateWidget(
          message: message ?? '操作成功',
          autoDismiss: true,
        );
      case errorState:
        return ErrorStateWidget(
          message: message ?? '发生错误',
          details: details,
          onRetry: onRetry,
          retryText: actionText ?? '重试',
        );
      case emptyState:
        return EmptyStateWidget(
          message: message ?? '暂无数据',
          icon: icon,
          onAction: onAction,
          actionText: actionText,
        );
      default:
        return const SizedBox.shrink();
    }
  }
}