import 'package:flutter/material.dart';
import 'animations.dart';

/// 动画系统使用示例
/// 展示如何在实际应用中使用各种动画组件

void main() {
  runApp(const AnimationExampleApp());
}

class AnimationExampleApp extends StatelessWidget {
  const AnimationExampleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '动画系统示例',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: const Color(0xFF2196F3),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2196F3),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const AnimationExampleHome(),
    );
  }
}

class AnimationExampleHome extends StatefulWidget {
  const AnimationExampleHome({super.key});

  @override
  State<AnimationExampleHome> createState() => _AnimationExampleHomeState();
}

class _AnimationExampleHomeState extends State<AnimationExampleHome> {
  int _currentIndex = 0;
  bool _isLoading = false;
  bool _showSuccess = false;
  bool _showError = false;
  String _message = '';

  final List<Widget> _pages = [
    const PageTransitionsDemo(),
    const ElementAnimationsDemo(),
    const GestureAnimationsDemo(),
    const VisualFeedbackDemo(),
    const ResponsiveAnimationsDemo(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('动画系统示例'),
        backgroundColor: const Color(0xFF2196F3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.navigation),
            label: '页面转场',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.touch_app),
            label: '元素动画',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.swipe),
            label: '手势交互',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.visibility),
            label: '视觉反馈',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.device_hub),
            label: '响应式动画',
          ),
        ],
      ),
    );
  }
}

/// 页面转场动画演示
class PageTransitionsDemo extends StatelessWidget {
  const PageTransitionsDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '页面转场动画',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        
        _buildTransitionButton(
          context,
          '淡入转场',
          TransitionType.fade,
          Icons.fade,
        ),
        _buildTransitionButton(
          context,
          '滑动转场',
          TransitionType.slideRight,
          Icons.arrow_forward,
        ),
        _buildTransitionButton(
          context,
          '缩放转场',
          TransitionType.scale,
          Icons.zoom_out_map,
        ),
        _buildTransitionButton(
          context,
          '弹性转场',
          TransitionType.elastic,
          Icons.flash_on,
        ),
        _buildTransitionButton(
          context,
          '3D翻转',
          TransitionType.flip,
          Icons.rotate_90_degrees_ccw,
        ),
      ],
    );
  }

  Widget _buildTransitionButton(
    BuildContext context,
    String title,
    TransitionType type,
    IconData icon,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: AnimatedButton(
        child: ListTile(
          leading: Icon(icon),
          title: Text(title),
          trailing: const Icon(Icons.arrow_forward_ios),
        ),
        onPressed: () {
          Navigator.push(
            context,
            AdvancedPageTransition(
              page: DetailPage(title: title),
              transitionType: type,
            ),
          );
        },
      ),
    );
  }
}

/// 元素动画演示
class ElementAnimationsDemo extends StatefulWidget {
  const ElementAnimationsDemo({super.key});

  @override
  State<ElementAnimationsDemo> createState() => _ElementAnimationsDemoState();
}

class _ElementAnimationsDemoState extends State<ElementAnimationsDemo> {
  final List<String> _items = ['项目 1', '项目 2', '项目 3', '项目 4', '项目 5'];
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '元素动画',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),

        // 动画按钮示例
        const Text('动画按钮', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Row(
          children: [
            AnimatedButton(
              onPressed: () => _showMessage('标准按钮被点击'),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '标准按钮',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            const SizedBox(width: 16),
            AnimatedFloatingActionButton(
              onPressed: () => _showMessage('浮动按钮被点击'),
              child: const Icon(Icons.add),
            ),
          ],
        ),
        const SizedBox(height: 24),

        // 动画列表示例
        const Text('动画列表', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        AnimatedListView(
          children: _items.map((item) => _buildListItem(item)).toList(),
        ),
        const SizedBox(height: 16),

        // 加载动画示例
        const Text('加载动画', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        if (_isLoading)
          const Center(child: CircularProgressIndicator())
        else
          AnimatedButton(
            onPressed: () {
              setState(() => _isLoading = true);
              Future.delayed(const Duration(seconds: 2), () {
                if (mounted) {
                  setState(() => _isLoading = false);
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                '开始加载',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildListItem(String item) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: const Icon(Icons.list),
        title: Text(item),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showMessage('$item 被点击'),
      ),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 1),
      ),
    );
  }
}

/// 手势交互演示
class GestureAnimationsDemo extends StatelessWidget {
  const GestureAnimationsDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '手势交互',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),

        // 滑动手势
        const Text('滑动手势', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        SizedBox(
          height: 100,
          child: SwipeableWidget(
            direction: SwipeDirection.left,
            threshold: 100,
            onSwipe: (direction, velocity) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('滑动 $direction')),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue, Colors.purple],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text(
                '左右滑动试试',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // 长按手势
        const Text('长按手势', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        LongPressableWidget(
          onLongPress: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('检测到长按')),
            );
          },
          child: Container(
            height: 60,
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.center,
            child: const Text(
              '长按我',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // 多手势组合
        const Text('多手势组合', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        GestureDetectorEx(
          type: GestureType.tap,
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('轻触')),
            );
          },
          onDoubleTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('双击')),
            );
          },
          onLongPress: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('长按')),
            );
          },
          child: Container(
            height: 80,
            decoration: BoxDecoration(
              color: Colors.teal,
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.center,
            child: const Text(
              '轻触/双击/长按我',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ],
    );
  }
}

/// 视觉反馈演示
class VisualFeedbackDemo extends StatefulWidget {
  const VisualFeedbackDemo({super.key});

  @override
  State<VisualFeedbackDemo> createState() => _VisualFeedbackDemoState();
}

class _VisualFeedbackDemoState extends State<VisualFeedbackDemo> {
  int _currentState = StateManager.normalState;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '视觉反馈',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),

        // 状态切换
        const Text('状态反馈', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Column(
          children: [
            Row(
              children: [
                AnimatedButton(
                  onPressed: () => setState(() => _currentState = StateManager.loadingState),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('加载状态', style: TextStyle(color: Colors.white)),
                  ),
                ),
                const SizedBox(width: 8),
                AnimatedButton(
                  onPressed: () => setState(() => _currentState = StateManager.successState),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('成功状态', style: TextStyle(color: Colors.white)),
                  ),
                ),
                const SizedBox(width: 8),
                AnimatedButton(
                  onPressed: () => setState(() => _currentState = StateManager.errorState),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('错误状态', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            StateManager.getStateWidget(
              state: _currentState,
              message: _getStateMessage(),
              onRetry: () => setState(() => _currentState = StateManager.normalState),
            ),
          ],
        ),
        const SizedBox(height: 24),

        // 点击反馈
        const Text('点击反馈', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Row(
          children: [
            TapFeedbackWidget(
              onTap: () => _showMessage('涟漪反馈'),
              child: Container(
                height: 50,
                width: 100,
                decoration: BoxDecoration(
                  color: Colors.purple,
                  borderRadius: BorderRadius.circular(8),
                ),
                alignment: Alignment.center,
                child: const Text('涟漪', style: TextStyle(color: Colors.white)),
              ),
            ),
            const SizedBox(width: 16),
            RippleFeedbackWidget(
              onTap: () => _showMessage('波纹反馈'),
              child: Container(
                height: 50,
                width: 100,
                decoration: BoxDecoration(
                  color: Colors.indigo,
                  borderRadius: BorderRadius.circular(8),
                ),
                alignment: Alignment.center,
                child: const Text('波纹', style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ],
    );
  }

  String _getStateMessage() {
    switch (_currentState) {
      case StateManager.loadingState:
        return '正在加载数据...';
      case StateManager.successState:
        return '操作成功完成！';
      case StateManager.errorState:
        return '操作失败，请重试';
      default:
        return '';
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }
}

/// 响应式动画演示
class ResponsiveAnimationsDemo extends StatefulWidget {
  const ResponsiveAnimationsDemo({super.key});

  @override
  State<ResponsiveAnimationsDemo> createState() => _ResponsiveAnimationsDemoState();
}

class _ResponsiveAnimationsDemoState extends State<ResponsiveAnimationsDemo> {
  double _progress = 0.0;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '响应式动画',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),

        // 自适应动画
        const Text('自适应动画', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        AdaptiveAnimationWidget(
          builder: (context, progress) {
            return Transform.rotate(
              angle: progress * 2 * 3.14159,
              child: Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  color: Colors.cyan,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.refresh, color: Colors.white, size: 40),
              ),
            );
          },
        ),
        const SizedBox(height: 16),

        // 手势响应式动画
        const Text('手势响应式动画', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        GestureResponsiveAnimation(
          child: Container(
            height: 100,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.pink, Colors.orange],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                '进度: ${(_progress * 100).toInt()}%',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
          ),
          onProgress: (progress) {
            setState(() {
              _progress = progress;
            });
          },
        ),
        const SizedBox(height: 16),

        // 智能加载动画
        const Text('智能加载动画', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        const SmartLoadingAnimation(
          type: LoadingType.spinner,
          message: '根据设备性能调整的动画',
        ),
        const SizedBox(height: 16),

        // 环境感知动画
        const Text('环境感知动画', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        EnvironmentAwareAnimation(
          builder: (context, info) {
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: info.isDarkMode ? Colors.grey[800] : Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('屏幕尺寸: ${info.screenSize.width.toInt()} x ${info.screenSize.height.toInt()}'),
                  Text('设备像素比: ${info.devicePixelRatio.toStringAsFixed(2)}'),
                  Text('暗色模式: ${info.isDarkMode ? '是' : '否'}'),
                  Text('性能级别: ${info.performanceLevel.name}'),
                  Text('是否为平板: ${info.isTablet ? '是' : '否'}'),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}

/// 详情页面示例
class DetailPage extends StatelessWidget {
  final String title;

  const DetailPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: const Color(0xFF2196F3),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.animation,
              size: 80,
              color: Color(0xFF2196F3),
            ),
            SizedBox(height: 24),
            Text(
              '动画演示页面',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2196F3),
              ),
            ),
            SizedBox(height: 16),
            Text(
              '这里展示了各种页面转场动画效果',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}