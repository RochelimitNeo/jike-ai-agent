import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'animation_config.dart';
import 'animation_mixins.dart';

/// 手势交互系统
/// 处理滑动、长按、双击、双指缩放等手势操作

/// 手势检测器组件
class GestureDetectorEx extends StatefulWidget {
  final Widget child;
  final GestureType type;
  final VoidCallback? onTap;
  final VoidCallback? onDoubleTap;
  final VoidCallback? onLongPress;
  final Function(DragStartDetails)? onPanStart;
  final Function(DragUpdateDetails)? onPanUpdate;
  final Function(DragEndDetails)? onPanEnd;
  final Function(DoubleTapDetails)? onDoubleTapDown;
  final Function(TapDownDetails)? onTapDown;
  final Function(TapUpDetails)? onTapUp;
  final Function(TapCancelDetails)? onTapCancel;
  final Function(ScaleStartDetails)? onScaleStart;
  final Function(ScaleUpdateDetails)? onScaleUpdate;
  final Function(ScaleEndDetails)? onScaleEnd;
  final Function(SwipeDirection)? onSwipe;
  final VoidCallback? onLongPressStart;
  final VoidCallback? onLongPressEnd;
  final VoidCallback? onLongPressMoveUpdate;
  final VoidCallback? onLongPressUp;
  final Duration longPressDuration;
  final double swipeThreshold;
  final bool enableLongPress;
  final bool enableDoubleTap;
  final bool enableSwipe;
  final bool enablePinch;
  final bool enableRotation;

  const GestureDetectorEx({
    super.key,
    required this.child,
    required this.type,
    this.onTap,
    this.onDoubleTap,
    this.onLongPress,
    this.onPanStart,
    this.onPanUpdate,
    this.onPanEnd,
    this.onDoubleTapDown,
    this.onTapDown,
    this.onTapUp,
    this.onTapCancel,
    this.onScaleStart,
    this.onScaleUpdate,
    this.onScaleEnd,
    this.onSwipe,
    this.onLongPressStart,
    this.onLongPressEnd,
    this.onLongPressMoveUpdate,
    this.onLongPressUp,
    this.longPressDuration = const Duration(milliseconds: 500),
    this.swipeThreshold = 50.0,
    this.enableLongPress = true,
    this.enableDoubleTap = true,
    this.enableSwipe = true,
    this.enablePinch = true,
    this.enableRotation = true,
  });

  @override
  State<GestureDetectorEx> createState() => _GestureDetectorExState();
}

class _GestureDetectorExState extends State<GestureDetectorEx>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isLongPressing = false;
  Timer? _longPressTimer;
  Offset? _longPressOffset;
  Offset? _lastTapOffset;
  DateTime? _lastTapTime;
  Offset? _panStartPosition;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    _longPressTimer?.cancel();
    super.dispose();
  }

  void _startLongPress(Offset position) {
    _longPressTimer = Timer(widget.longPressDuration, () {
      setState(() {
        _isLongPressing = true;
        _longPressOffset = position;
      });
      widget.onLongPress?.call();
      widget.onLongPressStart?.call();
      _controller.forward();
    });
  }

  void _cancelLongPress() {
    _longPressTimer?.cancel();
    if (_isLongPressing) {
      widget.onLongPressEnd?.call();
    }
    setState(() {
      _isLongPressing = false;
      _longPressOffset = null;
    });
    _controller.reverse();
  }

  void _handleTapDown(TapDownDetails details) {
    widget.onTapDown?.call(details);
  }

  void _handleTapUp(TapUpDetails details) {
    widget.onTapUp?.call(details);
    
    final currentTime = DateTime.now();
    final currentOffset = details.globalPosition;
    
    // 双击检测
    if (widget.enableDoubleTap && 
        _lastTapTime != null && 
        _lastTapOffset != null &&
        currentTime.difference(_lastTapTime!).inMilliseconds < 300 &&
        (currentOffset - _lastTapOffset!).distance < 50) {
      widget.onDoubleTap?.call();
      widget.onDoubleTapDown?.call(DoubleTapDetails(globalPosition: currentOffset));
      _lastTapTime = null;
      _lastTapOffset = null;
    } else {
      widget.onTap?.call();
      _lastTapTime = currentTime;
      _lastTapOffset = currentOffset;
    }
  }

  void _handleTapCancel() {
    widget.onTapCancel?.call();
    _cancelLongPress();
  }

  void _handlePanStart(DragStartDetails details) {
    _panStartPosition = details.globalPosition;
    widget.onPanStart?.call(details);
  }

  void _handlePanUpdate(DragUpdateDetails details) {
    widget.onPanUpdate?.call(details);
    
    if (_panStartPosition != null) {
      final delta = details.globalPosition - _panStartPosition!;
      
      // 滑动检测
      if (widget.enableSwipe && delta.distance > widget.swipeThreshold) {
        SwipeDirection direction;
        if (delta.dx.abs() > delta.dy.abs()) {
          direction = delta.dx > 0 ? SwipeDirection.right : SwipeDirection.left;
        } else {
          direction = delta.dy > 0 ? SwipeDirection.down : SwipeDirection.up;
        }
        widget.onSwipe?.call(direction);
      }
    }
  }

  void _handlePanEnd(DragEndDetails details) {
    widget.onPanEnd?.call(details);
    _panStartPosition = null;
  }

  void _handleScaleStart(ScaleStartDetails details) {
    widget.onScaleStart?.call(details);
  }

  void _handleScaleUpdate(ScaleUpdateDetails details) {
    widget.onScaleUpdate?.call(details);
  }

  void _handleScaleEnd(ScaleEndDetails details) {
    widget.onScaleEnd?.call(details);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      onPanStart: _handlePanStart,
      onPanUpdate: _handlePanUpdate,
      onPanEnd: _handlePanEnd,
      onScaleStart: _handleScaleStart,
      onScaleUpdate: _handleScaleUpdate,
      onScaleEnd: _handleScaleEnd,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: widget.child,
          );
        },
      ),
    );
  }
}

/// 滑动手势处理组件
class SwipeableWidget extends StatefulWidget {
  final Widget child;
  final SwipeDirection direction;
  final double threshold;
  final Function(SwipeDirection direction, double velocity)? onSwipe;
  final Duration animationDuration;
  final Curve curve;

  const SwipeableWidget({
    super.key,
    required this.child,
    this.direction = SwipeDirection.left,
    this.threshold = 100.0,
    this.onSwipe,
    this.animationDuration = const Duration(milliseconds: 300),
    this.curve = Curves.easeInOut,
  });

  @override
  State<SwipeableWidget> createState() => _SwipeableWidgetState();
}

class _SwipeableWidgetState extends State<SwipeableWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  bool _isAnimating = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleDragUpdate(DragUpdateDetails details) {
    if (_isAnimating) return;

    Offset begin = Offset.zero;
    switch (widget.direction) {
      case SwipeDirection.left:
        begin = Offset(-details.primaryDelta ?? 0, 0);
        break;
      case SwipeDirection.right:
        begin = Offset(details.primaryDelta ?? 0, 0);
        break;
      case SwipeDirection.up:
        begin = Offset(0, -details.primaryDelta ?? 0);
        break;
      case SwipeDirection.down:
        begin = Offset(0, details.primaryDelta ?? 0);
        break;
    }

    _slideAnimation = Tween<Offset>(
      begin: begin,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    setState(() {});
  }

  void _handleDragEnd(DragEndDetails details) {
    if (_isAnimating) return;

    final velocity = details.primaryVelocity ?? 0;
    final shouldTrigger = velocity.abs() > widget.threshold;

    if (shouldTrigger) {
      _isAnimating = true;
      _controller.forward().then((_) {
        widget.onSwipe?.call(widget.direction, velocity);
        _controller.reverse().then((_) {
          setState(() {
            _isAnimating = false;
          });
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragUpdate: widget.direction == SwipeDirection.left || 
                              widget.direction == SwipeDirection.right
          ? _handleDragUpdate
          : null,
      onVerticalDragUpdate: widget.direction == SwipeDirection.up || 
                            widget.direction == SwipeDirection.down
          ? _handleDragUpdate
          : null,
      onHorizontalDragEnd: widget.direction == SwipeDirection.left || 
                           widget.direction == SwipeDirection.right
          ? _handleDragEnd
          : null,
      onVerticalDragEnd: widget.direction == SwipeDirection.up || 
                        widget.direction == SwipeDirection.down
          ? _handleDragEnd
          : null,
      child: AnimatedBuilder(
        animation: _slideAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: _slideAnimation.value,
            child: widget.child,
          );
        },
      ),
    );
  }
}

/// 捏合缩放手势组件
class PinchableWidget extends StatefulWidget {
  final Widget child;
  final Function(double scale)? onScaleChanged;
  final Function(Offset position)? onScalePositionChanged;
  final double minScale;
  final double maxScale;
  final Duration animationDuration;
  final Curve curve;

  const PinchableWidget({
    super.key,
    required this.child,
    this.onScaleChanged,
    this.onScalePositionChanged,
    this.minScale = 0.5,
    this.maxScale = 3.0,
    this.animationDuration = const Duration(milliseconds: 200),
    this.curve = Curves.easeInOut,
  });

  @override
  State<PinchableWidget> createState() => _PinchableWidgetState();
}

class _PinchableWidgetState extends State<PinchableWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _positionAnimation;
  double _currentScale = 1.0;
  Offset _currentPosition = Offset.zero;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
    _positionAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleScaleStart(ScaleStartDetails details) {
    _controller.stop();
  }

  void _handleScaleUpdate(ScaleUpdateDetails details) {
    setState(() {
      _currentScale = details.scale.clamp(widget.minScale, widget.maxScale);
      _currentPosition = details.localFocalPoint;
      
      widget.onScaleChanged?.call(_currentScale);
      widget.onScalePositionChanged?.call(_currentPosition);
    });
  }

  void _handleScaleEnd(ScaleEndDetails details) {
    _scaleAnimation = Tween<double>(
      begin: _currentScale,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
    
    _positionAnimation = Tween<Offset>(
      begin: _currentPosition,
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    _controller.forward().then(() {
      setState(() {
        _currentScale = 1.0;
        _currentPosition = Offset.zero;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onScaleStart: _handleScaleStart,
      onScaleUpdate: _handleScaleUpdate,
      onScaleEnd: _handleScaleEnd,
      child: Transform.scale(
        scale: _currentScale,
        child: Transform.translate(
          offset: _currentPosition,
          child: widget.child,
        ),
      ),
    );
  }
}

/// 长按手势组件
class LongPressableWidget extends StatefulWidget {
  final Widget child;
  final VoidCallback? onLongPress;
  final VoidCallback? onLongPressStart;
  final VoidCallback? onLongPressEnd;
  final VoidCallback? onLongPressMoveUpdate;
  final VoidCallback? onLongPressUp;
  final Duration duration;
  final Widget? feedbackWidget;
  final Color? feedbackColor;

  const LongPressableWidget({
    super.key,
    required this.child,
    this.onLongPress,
    this.onLongPressStart,
    this.onLongPressEnd,
    this.onLongPressMoveUpdate,
    this.onLongPressUp,
    this.duration = const Duration(milliseconds: 500),
    this.feedbackWidget,
    this.feedbackColor,
  });

  @override
  State<LongPressableWidget> createState() => _LongPressableWidgetState();
}

class _LongPressableWidgetState extends State<LongPressableWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _positionAnimation;
  bool _isPressed = false;
  Offset? _pressPosition;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.duration,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.9,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _positionAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(0, 2),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleLongPressStart() {
    setState(() {
      _isPressed = true;
    });
    widget.onLongPressStart?.call();
    _controller.forward();
  }

  void _handleLongPressEnd() {
    setState(() {
      _isPressed = false;
    });
    widget.onLongPressEnd?.call();
    widget.onLongPress?.call();
    _controller.reverse();
  }

  void _handleLongPressMoveUpdate() {
    widget.onLongPressMoveUpdate?.call();
  }

  void _handleLongPressUp() {
    widget.onLongPressUp?.call();
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: _handleLongPressStart,
      onLongPressEnd: (_) => _handleLongPressEnd(),
      onLongPressMoveUpdate: (_) => _handleLongPressMoveUpdate(),
      onLongPressUp: _handleLongPressUp,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Transform.translate(
              offset: _positionAnimation.value,
              child: widget.child,
            ),
          );
        },
      ),
    );
  }
}

/// 旋转手势组件
class RotatableWidget extends StatefulWidget {
  final Widget child;
  final Function(double angle)? onRotationChanged;
  final double minAngle;
  final double maxAngle;
  final Duration animationDuration;
  final Curve curve;

  const RotatableWidget({
    super.key,
    required this.child,
    this.onRotationChanged,
    this.minAngle = -45.0,
    this.maxAngle = 45.0,
    this.animationDuration = const Duration(milliseconds: 200),
    this.curve = Curves.easeInOut,
  });

  @override
  State<RotatableWidget> createState() => _RotatableWidgetState();
}

class _RotatableWidgetState extends State<RotatableWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _rotationAnimation;
  double _currentAngle = 0.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 0.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleScaleStart(ScaleStartDetails details) {
    _controller.stop();
  }

  void _handleScaleUpdate(ScaleUpdateDetails details) {
    setState(() {
      _currentAngle = (details.rotation * 180 / 3.14159).clamp(widget.minAngle, widget.maxAngle);
      widget.onRotationChanged?.call(_currentAngle);
    });
  }

  void _handleScaleEnd(ScaleEndDetails details) {
    _rotationAnimation = Tween<double>(
      begin: _currentAngle,
      end: 0.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));

    _controller.forward().then(() {
      setState(() {
        _currentAngle = 0.0;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onScaleStart: _handleScaleStart,
      onScaleUpdate: _handleScaleUpdate,
      onScaleEnd: _handleScaleEnd,
      child: Transform.rotate(
        angle: _currentAngle * 3.14159 / 180,
        child: widget.child,
      ),
    );
  }
}

/// 手势组合组件
class MultiGestureWidget extends StatefulWidget {
  final Widget child;
  final Map<GestureType, Function?> handlers;
  final bool enableAllGestures;

  const MultiGestureWidget({
    super.key,
    required this.child,
    required this.handlers,
    this.enableAllGestures = false,
  });

  @override
  State<MultiGestureWidget> createState() => _MultiGestureWidgetState();
}

class _MultiGestureWidgetState extends State<MultiGestureWidget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.handlers[GestureType.tap],
      onDoubleTap: widget.handlers[GestureType.doubleTap],
      onLongPress: widget.handlers[GestureType.longPress],
      onPanStart: widget.handlers[GestureType.drag],
      onPanUpdate: widget.handlers[GestureType.drag],
      onPanEnd: widget.handlers[GestureType.drag],
      onScaleStart: widget.handlers[GestureType.pinch],
      onScaleUpdate: widget.handlers[GestureType.pinch],
      onScaleEnd: widget.handlers[GestureType.pinch],
      child: widget.child,
    );
  }
}

/// 手势反馈组件
class GestureFeedback extends StatelessWidget {
  final Widget child;
  final bool enableHaptic;
  final bool enableAudio;
  final VoidCallback? hapticCallback;
  final VoidCallback? audioCallback;

  const GestureFeedback({
    super.key,
    required this.child,
    this.enableHaptic = true,
    this.enableAudio = false,
    this.hapticCallback,
    this.audioCallback,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (enableHaptic) {
          HapticFeedback.lightImpact();
          hapticCallback?.call();
        }
        if (enableAudio) {
          audioCallback?.call();
        }
      },
      onDoubleTap: () {
        if (enableHaptic) {
          HapticFeedback.mediumImpact();
        }
      },
      onLongPress: () {
        if (enableHaptic) {
          HapticFeedback.heavyImpact();
        }
      },
      child: widget.child,
    );
  }
}