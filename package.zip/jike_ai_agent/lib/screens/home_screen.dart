import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:screen_capture_notifier/screen_capture_notifier.dart';

import '../providers/app_provider.dart';
import '../widgets/custom_app_bar.dart';
import '../widgets/agent_card.dart';
import '../widgets/quick_action_button.dart';
import '../utils/app_constants.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  late AnimationController _fabAnimationController;
  late Animation<double> _fabAnimation;
  final ScreenCaptureNotifier _screenCaptureNotifier = ScreenCaptureNotifier();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeScreenCaptureDetection();
  }

  void _initializeAnimations() {
    _fabAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _fabAnimation = CurvedAnimation(
      parent: _fabAnimationController,
      curve: Curves.easeInOut,
    );

    _fabAnimationController.forward();
  }

  void _initializeScreenCaptureDetection() {
    _screenCaptureNotifier.initialize(
      onCaptureDetected: () {
        // 屏幕截图检测回调
        _onScreenCaptureDetected();
      },
    );
  }

  void _onScreenCaptureDetected() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('屏幕截图检测到，请注意隐私保护'),
        backgroundColor: Colors.orange,
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _fabAnimationController.dispose();
    _screenCaptureNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: const CustomAppBar(
        title: '极客AI助手',
        showBackButton: false,
      ),
      body: Consumer<AppProvider>(
        builder: (context, appProvider, child) {
          return RefreshIndicator(
            onRefresh: () async {
              await appProvider.refreshData();
            },
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 欢迎信息
                  _buildWelcomeSection(appProvider),
                  const SizedBox(height: 24),
                  
                  // 快速操作
                  _buildQuickActionsSection(),
                  const SizedBox(height: 24),
                  
                  // AI助手卡片
                  _buildAgentCardsSection(),
                  const SizedBox(height: 24),
                  
                  // 最近活动
                  _buildRecentActivitySection(appProvider),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: ScaleTransition(
        scale: _fabAnimation,
        child: FloatingActionButton(
          onPressed: () => _showQuickActions(context),
          backgroundColor: const Color(0xFF2196F3),
          child: const Icon(
            Icons.add,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeSection(AppProvider appProvider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2196F3), Color(0xFF1976D2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF2196F3).withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.waving_hand,
                color: Colors.white,
                size: 28,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '欢迎回来，${appProvider.userName ?? "用户"}!',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            '今天让我们一起创造更多可能',
            style: TextStyle(
              fontSize: 16,
              color: Colors.white70,
              fontWeight: FontWeight.w300,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '快速操作',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: QuickActionButton(
                icon: Icons.chat,
                label: '对话',
                onTap: () => _startConversation(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: QuickActionButton(
                icon: Icons.image,
                label: '图像识别',
                onTap: () => _startImageRecognition(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: QuickActionButton(
                icon: Icons.mic,
                label: '语音助手',
                onTap: () => _startVoiceAssistant(),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: QuickActionButton(
                icon: Icons.settings,
                label: '设置',
                onTap: () => _openSettings(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAgentCardsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'AI助手',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.2,
          children: [
            AgentCard(
              title: '智能对话',
              subtitle: '24/7在线对话',
              icon: Icons.chat_bubble,
              color: const Color(0xFF4CAF50),
              onTap: () => _startConversation(),
            ),
            AgentCard(
              title: '图像分析',
              subtitle: '智能图像识别',
              icon: Icons.image_search,
              color: const Color(0xFFFF9800),
              onTap: () => _startImageRecognition(),
            ),
            AgentCard(
              title: '语音助手',
              subtitle: '语音交互体验',
              icon: Icons.mic,
              color: const Color(0xFF2196F3),
              onTap: () => _startVoiceAssistant(),
            ),
            AgentCard(
              title: '文档助手',
              subtitle: '文档处理专家',
              icon: Icons.description,
              color: const Color(0xFF9C27B0),
              onTap: () => _startDocumentAssistant(),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRecentActivitySection(AppProvider appProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '最近活动',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF333333),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: appProvider.recentActivities.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(32),
                  child: Column(
                    children: [
                      Icon(
                        Icons.history,
                        size: 48,
                        color: Colors.grey,
                      ),
                      SizedBox(height: 16),
                      Text(
                        '暂无活动记录',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: appProvider.recentActivities.length,
                  separatorBuilder: (context, index) => const Divider(
                    height: 1,
                    indent: 16,
                    endIndent: 16,
                  ),
                  itemBuilder: (context, index) {
                    final activity = appProvider.recentActivities[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: activity['color'],
                        child: Icon(
                          activity['icon'],
                          color: Colors.white,
                        ),
                      ),
                      title: Text(
                        activity['title'],
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        activity['time'],
                        style: const TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                      onTap: () => _handleActivityTap(activity),
                    );
                  },
                ),
        ),
      ],
    );
  }

  void _showQuickActions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '快速操作',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: _buildQuickActionTile(
                    icon: Icons.chat,
                    label: '开始对话',
                    onTap: () {
                      Navigator.pop(context);
                      _startConversation();
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildQuickActionTile(
                    icon: Icons.camera,
                    label: '拍照识别',
                    onTap: () {
                      Navigator.pop(context);
                      _startImageRecognition();
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionTile({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFFF5F5F5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 32,
              color: const Color(0xFF2196F3),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 事件处理方法
  void _startConversation() {
    // TODO: 实现对话功能
  }

  void _startImageRecognition() {
    // TODO: 实现图像识别功能
  }

  void _startVoiceAssistant() {
    // TODO: 实现语音助手功能
  }

  void _startDocumentAssistant() {
    // TODO: 实现文档助手功能
  }

  void _openSettings() {
    // TODO: 打开设置页面
  }

  void _handleActivityTap(Map<String, dynamic> activity) {
    // TODO: 处理活动点击
  }
}