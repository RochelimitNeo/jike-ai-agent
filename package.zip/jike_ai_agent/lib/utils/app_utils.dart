import 'dart:io';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';

class TextUtils {
  // 检查字符串是否为空或null
  static bool isEmpty(String? text) {
    return text == null || text.trim().isEmpty;
  }

  // 检查字符串是否不为空
  static bool isNotEmpty(String? text) {
    return !isEmpty(text);
  }

  // 字符串截断
  static String truncate(String text, int maxLength, {String suffix = '...'}) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength - suffix.length) + suffix;
  }

  // 首字母大写
  static String capitalize(String text) {
    if (isEmpty(text)) return text;
    return text[0].toUpperCase() + text.substring(1);
  }

  // 驼峰命名转下划线命名
  static String camelCaseToSnakeCase(String text) {
    return text.replaceAllMapped(
      RegExp(r'[A-Z]'),
      (match) => '_${match.group(0)!.toLowerCase()}',
    );
  }

  // 下划线命名转驼峰命名
  static String snakeCaseToCamelCase(String text) {
    return text.replaceAllMapped(
      RegExp(r'_([a-z])'),
      (match) => match.group(1)!.toUpperCase(),
    );
  }

  // 生成随机字符串
  static String generateRandomString(int length, {String charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'}) {
    final random = Random();
    return String.fromCharCodes(
      Iterable.generate(length, (_) => charset.codeUnitAt(random.nextInt(charset.length))),
    );
  }

  // 字符串加密（MD5）
  static String md5(String text) {
    return md5.convert(utf8.encode(text)).toString();
  }

  // 字符串加密（SHA256）
  static String sha256(String text) {
    return sha256.convert(utf8.encode(text)).toString();
  }

  // Base64编码
  static String base64Encode(String text) {
    return base64Encode(utf8.encode(text));
  }

  // Base64解码
  static String base64Decode(String encodedText) {
    return utf8.decode(base64Decode(encodedText));
  }

  // URL编码
  static String urlEncode(String text) {
    return Uri.encodeComponent(text);
  }

  // URL解码
  static String urlDecode(String encodedText) {
    return Uri.decodeComponent(encodedText);
  }

  // 检查邮箱格式
  static bool isValidEmail(String email) {
    if (isEmpty(email)) return false;
    return RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(email);
  }

  // 检查手机号格式（中国大陆）
  static bool isValidPhoneNumber(String phone) {
    if (isEmpty(phone)) return false;
    return RegExp(r'^1[3-9]\d{9}$').hasMatch(phone);
  }

  // 移除HTML标签
  static String removeHtmlTags(String html) {
    return html.replaceAll(RegExp(r'<[^>]*>'), '');
  }

  // 高亮文本关键词
  static List<TextSpan> highlightText(String text, String keyword, {Color? color}) {
    final List<TextSpan> spans = [];
    final List<String> parts = text.split(keyword);
    
    for (int i = 0; i < parts.length; i++) {
      if (i > 0) {
        spans.add(
          TextSpan(
            text: keyword,
            style: TextStyle(
              backgroundColor: color ?? Colors.yellow,
              fontWeight: FontWeight.bold,
            ),
          ),
        );
      }
      spans.add(TextSpan(text: parts[i]));
    }
    
    return spans;
  }
}

class DateTimeUtils {
  // 格式化日期
  static String formatDate(DateTime date, {String pattern = 'yyyy-MM-dd'}) {
    switch (pattern) {
      case 'yyyy-MM-dd':
        return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
      case 'yyyy/MM/dd':
        return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
      case 'MM/dd':
        return '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
      case 'dd/MM/yyyy':
        return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
      default:
        return date.toIso8601String();
    }
  }

  // 格式化时间
  static String formatTime(DateTime date, {String pattern = 'HH:mm'}) {
    switch (pattern) {
      case 'HH:mm':
        return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
      case 'hh:mm a':
        final hour = date.hour > 12 ? date.hour - 12 : (date.hour == 0 ? 12 : date.hour);
        final period = date.hour >= 12 ? 'PM' : 'AM';
        return '${hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')} $period';
      case 'HH:mm:ss':
        return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}:${date.second.toString().padLeft(2, '0')}';
      default:
        return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    }
  }

  // 格式化日期时间
  static String formatDateTime(DateTime date, {String pattern = 'yyyy-MM-dd HH:mm'}) {
    final dateStr = formatDate(date, pattern: pattern.split(' ')[0]);
    final timeStr = formatTime(date, pattern: pattern.split(' ')[1]);
    return '$dateStr $timeStr';
  }

  // 获取相对时间
  static String getRelativeTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inSeconds < 60) {
      return '刚刚';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}分钟前';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}小时前';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}天前';
    } else if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return '${weeks}周前';
    } else if (difference.inDays < 365) {
      final months = (difference.inDays / 30).floor();
      return '${months}个月前';
    } else {
      final years = (difference.inDays / 365).floor();
      return '${years}年前';
    }
  }

  // 检查是否为今天
  static bool isToday(DateTime dateTime) {
    final now = DateTime.now();
    return dateTime.year == now.year &&
        dateTime.month == now.month &&
        dateTime.day == now.day;
  }

  // 检查是否为昨天
  static bool isYesterday(DateTime dateTime) {
    final now = DateTime.now();
    final yesterday = now.subtract(const Duration(days: 1));
    return dateTime.year == yesterday.year &&
        dateTime.month == yesterday.month &&
        dateTime.day == yesterday.day;
  }

  // 检查是否为明天
  static bool isTomorrow(DateTime dateTime) {
    final now = DateTime.now();
    final tomorrow = now.add(const Duration(days: 1));
    return dateTime.year == tomorrow.year &&
        dateTime.month == tomorrow.month &&
        dateTime.day == tomorrow.day;
  }

  // 获取本周开始日期（周一）
  static DateTime getStartOfWeek(DateTime dateTime) {
    final weekday = dateTime.weekday;
    return dateTime.subtract(Duration(days: weekday - 1));
  }

  // 获取本周结束日期（周日）
  static DateTime getEndOfWeek(DateTime dateTime) {
    final startOfWeek = getStartOfWeek(dateTime);
    return startOfWeek.add(const Duration(days: 6));
  }

  // 获取月份第一天
  static DateTime getFirstDayOfMonth(DateTime dateTime) {
    return DateTime(dateTime.year, dateTime.month, 1);
  }

  // 获取月份最后一天
  static DateTime getLastDayOfMonth(DateTime dateTime) {
    return DateTime(dateTime.year, dateTime.month + 1, 0);
  }

  // 计算年龄
  static int calculateAge(DateTime birthDate) {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    
    if (now.month < birthDate.month || 
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    
    return age;
  }

  // 获取中文星期
  static String getChineseWeekday(DateTime dateTime) {
    const weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    return weekdays[dateTime.weekday - 1];
  }

  // 获取中文月份
  static String getChineseMonth(DateTime dateTime) {
    const months = [
      '一月', '二月', '三月', '四月', '五月', '六月',
      '七月', '八月', '九月', '十月', '十一月', '十二月'
    ];
    return months[dateTime.month - 1];
  }
}

class NumberUtils {
  // 格式化数字
  static String formatNumber(int number) {
    if (number < 1000) return number.toString();
    if (number < 1000000) return '${(number / 1000).toStringAsFixed(1)}K';
    if (number < 1000000000) return '${(number / 1000000).toStringAsFixed(1)}M';
    return '${(number / 1000000000).toStringAsFixed(1)}B';
  }

  // 格式化文件大小
  static String formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  // 生成随机数字
  static int randomInt(int min, int max) {
    return min + Random().nextInt(max - min + 1);
  }

  // 检查是否为偶数
  static bool isEven(int number) {
    return number % 2 == 0;
  }

  // 检查是否为奇数
  static bool isOdd(int number) {
    return number % 2 != 0;
  }

  // 获取百分比
  static String getPercentage(int value, int total) {
    if (total == 0) return '0%';
    final percentage = (value / total * 100).round();
    return '$percentage%';
  }

  // 数值范围限制
  static int clamp(int value, int min, int max) {
    return value.clamp(min, max);
  }

  // 浮点数范围限制
  static double clampDouble(double value, double min, double max) {
    return value.clamp(min, max);
  }

  // 四舍五入
  static double roundTo(double value, int decimals) {
    final factor = pow(10, decimals);
    return (value * factor).round() / factor;
  }
}

class ColorUtils {
  // 十六进制颜色转Color
  static Color hexToColor(String hex) {
    final hexCode = hex.replaceAll('#', '');
    return Color(int.parse('FF$hexCode', radix: 16));
  }

  // Color转十六进制
  static String colorToHex(Color color) {
    return '#${color.value.toRadixString(16).substring(2)}';
  }

  // 生成随机颜色
  static Color randomColor() {
    return Color.fromRGBO(
      Random().nextInt(256),
      Random().nextInt(256),
      Random().nextInt(256),
      1.0,
    );
  }

  // 颜色亮度调整
  static Color adjustBrightness(Color color, double factor) {
    final hsl = HSLColor.fromColor(color);
    final lightness = (hsl.lightness * factor).clamp(0.0, 1.0);
    return hsl.withLightness(lightness).toColor();
  }

  // 获取对比色
  static Color getContrastColor(Color background) {
    final luminance = background.computeLuminance();
    return luminance > 0.5 ? Colors.black : Colors.white;
  }

  // 颜色混合
  static Color blend(Color color1, Color color2, double ratio) {
    final r1 = color1.red;
    final g1 = color1.green;
    final b1 = color1.blue;
    final r2 = color2.red;
    final g2 = color2.green;
    final b2 = color2.blue;

    return Color.fromRGBO(
      (r1 * (1 - ratio) + r2 * ratio).round(),
      (g1 * (1 - ratio) + g2 * ratio).round(),
      (b1 * (1 - ratio) + b2 * ratio).round(),
      1.0,
    );
  }
}