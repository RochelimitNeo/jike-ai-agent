// 应用常量配置
class AppConstants {
  // 应用信息
  static const String appName = '极客AI助手';
  static const String appDescription = '您的智能AI助手，提供全方位的智能服务';
  static const String appVersion = '1.0.0';
  static const String appBuildNumber = '1';
  static const String appPackageName = 'com.jikeai.jike_ai_agent';

  // API配置
  static const String baseApiUrl = 'https://api.jikeai.com';
  static const String apiKey = 'your-api-key-here';
  static const Duration apiTimeout = Duration(seconds: 30);

  // 数据库配置
  static const String databaseName = 'jike_ai_agent.db';
  static const int databaseVersion = 1;

  // 存储配置
  static const String sharedPreferencesName = 'jike_ai_agent_prefs';
  static const String cacheDirectoryName = 'cache';
  static const String logDirectoryName = 'logs';

  // 网络配置
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);
  static const Duration connectionTimeout = Duration(seconds: 10);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // 缓存配置
  static const Duration cacheExpirationTime = Duration(hours: 1);
  static const int maxCacheSize = 100 * 1024 * 1024; // 100MB

  // 界面配置
  static const double defaultPadding = 16.0;
  static const double cardElevation = 4.0;
  static const double borderRadius = 12.0;
  static const Duration animationDuration = Duration(milliseconds: 300);

  // 权限配置
  static const List<String> requiredPermissions = [
    'android.permission.CAMERA',
    'android.permission.RECORD_AUDIO',
    'android.permission.READ_EXTERNAL_STORAGE',
    'android.permission.WRITE_EXTERNAL_STORAGE',
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.WAKE_LOCK',
    'android.permission.SYSTEM_ALERT_WINDOW',
  ];

  // 文件类型
  static const List<String> supportedImageTypes = [
    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'
  ];
  static const List<String> supportedAudioTypes = [
    'mp3', 'wav', 'aac', 'ogg', 'm4a'
  ];
  static const List<String> supportedVideoTypes = [
    'mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv'
  ];
  static const List<String> supportedDocumentTypes = [
    'pdf', 'doc', 'docx', 'txt', 'rtf'
  ];

  // 错误消息
  static const String networkError = '网络连接失败，请检查网络设置';
  static const String permissionDenied = '权限被拒绝，请在设置中开启相关权限';
  static const String unknownError = '发生未知错误，请稍后重试';
  static const String serverError = '服务器错误，请稍后重试';
  static const String fileNotFound = '文件不存在或已被删除';
  static const String invalidFormat = '文件格式不支持';
  static const String fileTooLarge = '文件大小超过限制';
  static const String storageSpaceLow = '存储空间不足';

  // 成功消息
  static const String loginSuccess = '登录成功';
  static const String logoutSuccess = '已安全退出';
  static const String dataSaved = '数据保存成功';
  static const String operationSuccess = '操作完成';
  static const String fileUploaded = '文件上传成功';

  // 默认头像
  static const String defaultAvatar = 'https://via.placeholder.com/150x150?text=Avatar';

  // 默认头像颜色
  static const List<Color> defaultAvatarColors = [
    Color(0xFF2196F3), // 蓝色
    Color(0xFF4CAF50), // 绿色
    Color(0xFFFF9800), // 橙色
    Color(0xFF9C27B0), // 紫色
    Color(0xFFF44336), // 红色
    Color(0xFF607D8B), // 灰蓝色
  ];

  // 应用主题色彩
  static const Color primaryColor = Color(0xFF2196F3);
  static const Color primaryDarkColor = Color(0xFF1976D2);
  static const Color accentColor = Color(0xFF03DAC6);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color surfaceColor = Color(0xFFFFFFFF);
  static const Color errorColor = Color(0xFFF44336);

  // 文本颜色
  static const Color textPrimaryColor = Color(0xFF212121);
  static const Color textSecondaryColor = Color(0xFF757575);
  static const Color textHintColor = Color(0xFFBDBDBD);

  // 边框颜色
  static const Color dividerColor = Color(0xFFE0E0E0);
  static const Color borderColor = Color(0xFFE0E0E0);

  // 阴影颜色
  static const Color shadowColor = Color(0x1A000000);

  // 动画配置
  static const Duration shortAnimationDuration = Duration(milliseconds: 200);
  static const Duration mediumAnimationDuration = Duration(milliseconds: 300);
  static const Duration longAnimationDuration = Duration(milliseconds: 500);

  // 分页配置
  static const int defaultPageSize = 20;
  static const int maxPageSize = 100;

  // 设备配置
  static const double minTouchTargetSize = 48.0;
  static const double maxImageSize = 1920.0; // px
  static const double maxVideoSize = 1080.0; // px
  static const int maxFileSize = 50 * 1024 * 1024; // 50MB

  // 安全配置
  static const Duration sessionTimeout = Duration(hours: 24);
  static const Duration autoLogoutDelay = Duration(minutes: 30);
  static const bool enableBiometricAuth = true;
  static const bool enableEncryption = true;

  // 调试配置
  static const bool enableDebugMode = true;
  static const bool enableLogging = true;
  static const bool enableAnalytics = true;
  static const bool enableCrashReporting = true;

  // 功能开关
  static const bool enableVoiceAssistant = true;
  static const bool enableImageRecognition = true;
  static const bool enableDocumentProcessing = true;
  static const bool enableRealTimeChat = true;
  static const bool enableCloudSync = true;

  // 第三方服务配置
  static const Map<String, String> thirdPartyServices = {
    'firebase': 'https://firebase.google.com',
    'google': 'https://developers.google.com',
    'openai': 'https://openai.com',
    'baidu': 'https://ai.baidu.com',
  };

  // 支持的语言
  static const List<String> supportedLanguages = [
    'zh-CN', // 简体中文
    'zh-TW', // 繁体中文
    'en-US', // 英语（美国）
    'ja-JP', // 日语
    'ko-KR', // 韩语
  ];

  // 默认语言
  static const String defaultLanguage = 'zh-CN';

  // 路由配置
  static const Map<String, String> routeNames = {
    'home': '/home',
    'settings': '/settings',
    'profile': '/profile',
    'chat': '/chat',
    'imageRecognition': '/image-recognition',
    'voiceAssistant': '/voice-assistant',
    'documentAssistant': '/document-assistant',
    'login': '/login',
    'splash': '/splash',
  };

  // 正则表达式
  static const RegExp emailRegExp = RegExp(
    r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
  );
  static const RegExp phoneRegExp = RegExp(
    r'^1[3-9]\d{9}$',
  );
  static const RegExp passwordRegExp = RegExp(
    r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$',
  );
}