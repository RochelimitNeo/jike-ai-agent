import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math';
import '../models/user_model.dart';
import '../models/activity_model.dart';

class AppProvider extends ChangeNotifier {
  // 用户信息
  UserModel? _user;
  String? _userName;

  // 最近活动列表
  final List<Map<String, dynamic>> _recentActivities = [];

  // 加载状态
  bool _isLoading = false;

  // 当前页面
  int _currentIndex = 0;

  // Getter
  UserModel? get user => _user;
  String? get userName => _userName;
  List<Map<String, dynamic>> get recentActivities => _recentActivities;
  bool get isLoading => _isLoading;
  int get currentIndex => _currentIndex;

  // 初始化应用数据
  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    try {
      await _loadUserData();
      await _loadRecentActivities();
    } catch (e) {
      debugPrint('初始化数据失败: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // 加载用户数据
  Future<void> _loadUserData() async {
    // 模拟加载用户数据
    await Future.delayed(const Duration(milliseconds: 500));
    
    _user = UserModel(
      id: 'user_${Random().nextInt(1000)}',
      name: 'AI用户',
      email: 'user@example.com',
      avatar: 'https://via.placeholder.com/150',
      createdAt: DateTime.now(),
      preferences: UserPreferences(
        theme: ThemeMode.system,
        language: 'zh-CN',
        notificationsEnabled: true,
      ),
    );
    
    _userName = _user?.name;
  }

  // 加载最近活动
  Future<void> _loadRecentActivities() async {
    // 模拟加载活动数据
    await Future.delayed(const Duration(milliseconds: 300));
    
    _recentActivities.clear();
    
    // 添加一些示例活动
    _recentActivities.addAll([
      {
        'id': 'activity_1',
        'title': '与AI助手完成对话',
        'icon': Icons.chat,
        'color': const Color(0xFF4CAF50),
        'time': '2小时前',
        'type': 'conversation',
      },
      {
        'id': 'activity_2',
        'title': '识别图像：天空照片',
        'icon': Icons.image,
        'color': const Color(0xFFFF9800),
        'time': '1天前',
        'type': 'image_recognition',
      },
      {
        'id': 'activity_3',
        'title': '语音助手对话',
        'icon': Icons.mic,
        'color': const Color(0xFF2196F3),
        'time': '2天前',
        'type': 'voice_assistant',
      },
    ]);
  }

  // 刷新数据
  Future<void> refreshData() async {
    await _loadRecentActivities();
    notifyListeners();
  }

  // 更新用户名
  void updateUserName(String newName) {
    _userName = newName;
    if (_user != null) {
      _user = _user!.copyWith(name: newName);
    }
    notifyListeners();
  }

  // 更新用户偏好设置
  void updateUserPreferences(UserPreferences preferences) {
    if (_user != null) {
      _user = _user!.copyWith(preferences: preferences);
    }
    notifyListeners();
  }

  // 添加新活动
  void addActivity(String title, IconData icon, Color color) {
    final newActivity = {
      'id': 'activity_${DateTime.now().millisecondsSinceEpoch}',
      'title': title,
      'icon': icon,
      'color': color,
      'time': '刚刚',
      'type': 'general',
    };
    
    _recentActivities.insert(0, newActivity);
    
    // 保持最多20条活动记录
    if (_recentActivities.length > 20) {
      _recentActivities.removeLast();
    }
    
    notifyListeners();
  }

  // 清空活动记录
  void clearActivities() {
    _recentActivities.clear();
    notifyListeners();
  }

  // 设置当前页面索引
  void setCurrentIndex(int index) {
    _currentIndex = index;
    notifyListeners();
  }

  // 开始加载
  void startLoading() {
    _isLoading = true;
    notifyListeners();
  }

  // 结束加载
  void stopLoading() {
    _isLoading = false;
    notifyListeners();
  }

  // 模拟登录
  Future<bool> login(String email, String password) async {
    startLoading();
    
    try {
      // 模拟API调用
      await Future.delayed(const Duration(seconds: 1));
      
      // 验证用户凭据（这里只是模拟）
      if (email.isNotEmpty && password.isNotEmpty) {
        _user = UserModel(
          id: 'user_${Random().nextInt(1000)}',
          name: 'AI用户',
          email: email,
          avatar: 'https://via.placeholder.com/150',
          createdAt: DateTime.now(),
          preferences: UserPreferences(
            theme: ThemeMode.system,
            language: 'zh-CN',
            notificationsEnabled: true,
          ),
        );
        
        _userName = _user?.name;
        notifyListeners();
        return true;
      }
      
      return false;
    } finally {
      stopLoading();
    }
  }

  // 模拟登出
  void logout() {
    _user = null;
    _userName = null;
    _recentActivities.clear();
    _currentIndex = 0;
    notifyListeners();
  }

  // 获取用户统计信息
  Map<String, int> getUserStats() {
    return {
      'totalConversations': _recentActivities
          .where((activity) => activity['type'] == 'conversation')
          .length,
      'imagesProcessed': _recentActivities
          .where((activity) => activity['type'] == 'image_recognition')
          .length,
      'voiceInteractions': _recentActivities
          .where((activity) => activity['type'] == 'voice_assistant')
          .length,
      'totalActivities': _recentActivities.length,
    };
  }

  // 检查是否有新的活动
  bool hasNewActivities() {
    return _recentActivities.isNotEmpty;
  }

  // 获取活动数量
  int getActivityCount() {
    return _recentActivities.length;
  }
}