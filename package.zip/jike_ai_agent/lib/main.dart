import 'package:flutter/material.dart';
import 'package:flutter_window_manager/flutter_window_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:provider/provider.dart';

// Import screens
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';

// Import providers
import 'providers/app_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 初始化窗口管理
  await _initializeWindowManager();
  
  // 检查权限
  await _checkPermissions();
  
  runApp(const JikeAiAgentApp());
}

Future<void> _initializeWindowManager() async {
  // 配置窗口管理器
  await FlutterWindowManager.setContentSecure(true);
  await FlutterWindowManager.setSecureFlag(true);
  await FlutterWindowManager.setTitleBarHidden(true);
}

Future<void> _checkPermissions() async {
  // 请求必要权限
  await [
    Permission.camera,
    Permission.microphone,
    Permission.storage,
    Permission.notification,
  ].request();
}

class JikeAiAgentApp extends StatelessWidget {
  const JikeAiAgentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: OverlaySupport(
        child: MaterialApp(
          title: '极客AI助手',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primarySwatch: Colors.blue,
            primaryColor: const Color(0xFF2196F3),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF2196F3),
              brightness: Brightness.light,
            ),
            useMaterial3: true,
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xFF2196F3),
              foregroundColor: Colors.white,
              elevation: 0,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          home: const SplashScreen(),
          routes: {
            '/home': (context) => const HomeScreen(),
          },
        ),
      ),
    );
  }
}