package com.jikeai.jike_ai_agent;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

/**
 * 极客AI助手主Activity
 * 负责处理Android原生功能集成、权限管理、设备管理等
 */
public class MainActivity extends FlutterActivity {
    private static final String TAG = "MainActivity";
    private static final String CHANNEL = "com.jikeai.jike_ai_agent/android";
    
    // 权限请求码
    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 1001;
    private static final int REQUEST_CODE_MEDIA_PROJECTION = 1002;
    private static final int REQUEST_CODE_DEVICE_ADMIN = 1003;
    private static final int REQUEST_CODE_SCREEN_CAPTURE = 1004;
    
    // 系统服务
    private MediaProjectionManager mediaProjectionManager;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName deviceAdminReceiver;
    
    // 权限列表
    private static final String[] REQUIRED_PERMISSIONS = {
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.POST_NOTIFICATIONS,
        Manifest.permission.SYSTEM_ALERT_WINDOW,
        Manifest.permission.WAKE_LOCK,
        Manifest.permission.FOREGROUND_SERVICE,
        Manifest.permission.DISMISS_KEYGUARD,
        Manifest.permission.TURN_SCREEN_ON,
        Manifest.permission.MEDIA_PROJECTION,
        Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 初始化系统服务
        mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        deviceAdminReceiver = new ComponentName(this, DeviceAdminReceiver.class);
        
        // 配置窗口属性
        configureWindow();
        
        // 启动前台服务
        startForegroundService();
        
        Log.d(TAG, "MainActivity created");
    }
    
    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        
        // 注册方法通道
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler(
                (call, result) -> {
                    switch (call.method) {
                        case "checkPermissions":
                            checkPermissions(result);
                            break;
                        case "requestPermissions":
                            requestPermissions(call.<String>argument("permissions"), result);
                            break;
                        case "openAppSettings":
                            openAppSettings(result);
                            break;
                        case "requestOverlayPermission":
                            requestOverlayPermission(result);
                            break;
                        case "isOverlayPermissionGranted":
                            result.success(isOverlayPermissionGranted());
                            break;
                        case "startScreenCapture":
                            startScreenCapture(result);
                            break;
                        case "stopScreenCapture":
                            stopScreenCapture(result);
                            break;
                        case "enableDeviceAdmin":
                            enableDeviceAdmin(result);
                            break;
                        case "disableDeviceAdmin":
                            disableDeviceAdmin(result);
                            break;
                        case "isDeviceAdminEnabled":
                            result.success(isDeviceAdminEnabled());
                            break;
                        case "setScreenOrientation":
                            setScreenOrientation(call.<String>argument("orientation"), result);
                            break;
                        case "keepScreenOn":
                            keepScreenOn(call.<Boolean>argument("keepOn"), result);
                            break;
                        case "hideStatusBar":
                            hideStatusBar(result);
                            break;
                        case "showStatusBar":
                            showStatusBar(result);
                            break;
                        case "preventAppFromClosing":
                            preventAppFromClosing(call.<Boolean>argument("prevent"), result);
                            break;
                        case "getDeviceInfo":
                            getDeviceInfo(result);
                            break;
                        default:
                            result.notImplemented();
                    }
                }
            );
    }
    
    /**
     * 配置窗口属性
     */
    private void configureWindow() {
        // 隐藏状态栏和导航栏
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        
        // 保持屏幕常亮
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        
        // 防止应用在锁屏时关闭
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        
        // 防止截图
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }
    
    /**
     * 启动前台服务
     */
    private void startForegroundService() {
        Intent serviceIntent = new Intent(this, BackgroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }
    
    /**
     * 检查权限
     */
    private void checkPermissions(MethodChannel.Result result) {
        List<String> deniedPermissions = new ArrayList<>();
        List<String> grantedPermissions = new ArrayList<>();
        
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                grantedPermissions.add(permission);
            } else {
                deniedPermissions.add(permission);
            }
        }
        
        Map<String, Object> permissionMap = new HashMap<>();
        permissionMap.put("granted", grantedPermissions);
        permissionMap.put("denied", deniedPermissions);
        permissionMap.put("total", REQUIRED_PERMISSIONS.length);
        permissionMap.put("grantedCount", grantedPermissions.size());
        permissionMap.put("deniedCount", deniedPermissions.size());
        
        result.success(permissionMap);
    }
    
    /**
     * 请求权限
     */
    private void requestPermissions(List<String> permissions, MethodChannel.Result result) {
        if (permissions == null || permissions.isEmpty()) {
            result.error("INVALID_ARGUMENTS", "Permissions list cannot be null or empty", null);
            return;
        }
        
        String[] permissionArray = permissions.toArray(new String[0]);
        ActivityCompat.requestPermissions(this, permissionArray, REQUEST_CODE_DEVICE_ADMIN);
        
        result.success(true);
    }
    
    /**
     * 打开应用设置
     */
    private void openAppSettings(MethodChannel.Result result) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error opening app settings", e);
            result.error("SETTINGS_ERROR", "Failed to open app settings", e.getMessage());
        }
    }
    
    /**
     * 请求悬浮窗权限
     */
    private void requestOverlayPermission(MethodChannel.Result result) {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
        result.success(true);
    }
    
    /**
     * 检查悬浮窗权限
     */
    private boolean isOverlayPermissionGranted() {
        return Settings.canDrawOverlays(this);
    }
    
    /**
     * 开始屏幕捕获
     */
    private void startScreenCapture(MethodChannel.Result result) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Intent captureIntent = mediaProjectionManager.createScreenCaptureIntent();
                startActivityForResult(captureIntent, REQUEST_CODE_SCREEN_CAPTURE);
                result.success(true);
            } else {
                result.error("UNSUPPORTED", "Screen capture not supported on this device", null);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting screen capture", e);
            result.error("CAPTURE_ERROR", "Failed to start screen capture", e.getMessage());
        }
    }
    
    /**
     * 停止屏幕捕获
     */
    private void stopScreenCapture(MethodChannel.Result result) {
        // 停止屏幕捕获的逻辑
        result.success(true);
    }
    
    /**
     * 启用设备管理员
     */
    private void enableDeviceAdmin(MethodChannel.Result result) {
        try {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminReceiver);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "设备管理员权限用于保护应用不被意外关闭");
            startActivity(intent);
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error enabling device admin", e);
            result.error("DEVICE_ADMIN_ERROR", "Failed to enable device admin", e.getMessage());
        }
    }
    
    /**
     * 禁用设备管理员
     */
    private void disableDeviceAdmin(MethodChannel.Result result) {
        try {
            devicePolicyManager.removeActiveAdmin(deviceAdminReceiver);
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error disabling device admin", e);
            result.error("DEVICE_ADMIN_ERROR", "Failed to disable device admin", e.getMessage());
        }
    }
    
    /**
     * 检查设备管理员是否启用
     */
    private boolean isDeviceAdminEnabled() {
        return devicePolicyManager.isAdminActive(deviceAdminReceiver);
    }
    
    /**
     * 设置屏幕方向
     */
    private void setScreenOrientation(String orientation, MethodChannel.Result result) {
        try {
            if (orientation.equals("portrait")) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else if (orientation.equals("landscape")) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            } else if (orientation.equals("auto")) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
            }
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error setting screen orientation", e);
            result.error("ORIENTATION_ERROR", "Failed to set screen orientation", e.getMessage());
        }
    }
    
    /**
     * 保持屏幕常亮
     */
    private void keepScreenOn(boolean keepOn, MethodChannel.Result result) {
        try {
            if (keepOn) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error keeping screen on", e);
            result.error("SCREEN_ERROR", "Failed to keep screen on", e.getMessage());
        }
    }
    
    /**
     * 隐藏状态栏
     */
    private void hideStatusBar(MethodChannel.Result result) {
        try {
            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            controller.hide(WindowInsetsCompat.Type.statusBars());
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error hiding status bar", e);
            result.error("STATUS_BAR_ERROR", "Failed to hide status bar", e.getMessage());
        }
    }
    
    /**
     * 显示状态栏
     */
    private void showStatusBar(MethodChannel.Result result) {
        try {
            WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            controller.show(WindowInsetsCompat.Type.statusBars());
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error showing status bar", e);
            result.error("STATUS_BAR_ERROR", "Failed to show status bar", e.getMessage());
        }
    }
    
    /**
     * 防止应用被关闭
     */
    private void preventAppFromClosing(boolean prevent, MethodChannel.Result result) {
        try {
            if (prevent) {
                // 启用设备管理员
                if (!isDeviceAdminEnabled()) {
                    enableDeviceAdmin(null);
                }
                
                // 设置为前台应用
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
                
                // 防止应用被杀死
                startForegroundService();
            }
            result.success(true);
        } catch (Exception e) {
            Log.e(TAG, "Error preventing app from closing", e);
            result.error("PREVENT_CLOSE_ERROR", "Failed to prevent app from closing", e.getMessage());
        }
    }
    
    /**
     * 获取设备信息
     */
    private void getDeviceInfo(MethodChannel.Result result) {
        try {
            Map<String, Object> deviceInfo = new HashMap<>();
            deviceInfo.put("deviceId", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
            deviceInfo.put("deviceName", Build.MODEL);
            deviceInfo.put("deviceManufacturer", Build.MANUFACTURER);
            deviceInfo.put("deviceBrand", Build.BRAND);
            deviceInfo.put("deviceProduct", Build.PRODUCT);
            deviceInfo.put("deviceBoard", Build.BOARD);
            deviceInfo.put("deviceHardware", Build.HARDWARE);
            deviceInfo.put("deviceSerial", Build.SERIAL);
            deviceInfo.put("osVersion", Build.VERSION.RELEASE);
            deviceInfo.put("osSdkInt", Build.VERSION.SDK_INT);
            deviceInfo.put("osIncremental", Build.VERSION.INCREMENTAL);
            deviceInfo.put("abi", Build.SUPPORTED_ABIS[0]);
            deviceInfo.put("isEmulator", isEmulator());
            deviceInfo.put("isRooted", isRooted());
            
            result.success(deviceInfo);
        } catch (Exception e) {
            Log.e(TAG, "Error getting device info", e);
            result.error("DEVICE_INFO_ERROR", "Failed to get device info", e.getMessage());
        }
    }
    
    /**
     * 检查是否为模拟器
     */
    private boolean isEmulator() {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")
                || "google_sdk".equals(Build.PRODUCT));
    }
    
    /**
     * 检查是否已root
     */
    private boolean isRooted() {
        // 检查root管理应用
        String[] rootApps = {
            "com.noshufou.android.su",
            "com.noshufou.android.su.elite",
            "eu.chainfire.supersu",
            "com.koushikdutta.superuser",
            "com.thirdparty.superuser",
            "com.yellowes.su",
            "com.topjohnwu.magisk",
            "com.kingroot.kinguser",
            "com.kingo.root",
            "com.smedialink.oneclickroot",
            "com.zhiqupk.root.global",
            "com.alephzain.framaroot"
        };
        
        for (String app : rootApps) {
            if (getPackageManager().getLaunchIntentForPackage(app) != null) {
                return true;
            }
        }
        
        // 检查系统文件
        String[] rootFiles = {
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        };
        
        for (String file : rootFiles) {
            if (new java.io.File(file).exists()) {
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("requestCode", requestCode);
        resultMap.put("permissions", permissions);
        resultMap.put("grantResults", grantResults);
        resultMap.put("granted", grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
        
        Log.d(TAG, "Permission result: " + resultMap.toString());
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        Log.d(TAG, "Activity result: requestCode=" + requestCode + ", resultCode=" + resultCode);
        
        if (requestCode == REQUEST_CODE_SCREEN_CAPTURE && resultCode == RESULT_OK) {
            // 屏幕捕获权限已获取
            MediaProjection mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
            if (mediaProjection != null) {
                Log.d(TAG, "Screen capture permission granted");
                // 处理屏幕捕获逻辑
            }
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity resumed");
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity paused");
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity destroyed");
    }
}