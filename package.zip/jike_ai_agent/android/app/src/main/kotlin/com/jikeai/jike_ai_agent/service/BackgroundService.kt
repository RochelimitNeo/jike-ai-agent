package com.jikeai.jike_ai_agent.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jikeai.jike_ai_agent.R
import com.jikeai.jike_ai_agent.MainActivity

/**
 * 后台服务
 * 负责维持应用在后台运行，处理各种后台任务
 */
class BackgroundService : Service() {
    
    companion object {
        private const val TAG = "BackgroundService"
        private const val CHANNEL_ID = "background_service_channel"
        private const val NOTIFICATION_ID = 1001
        
        // 启动服务
        fun startService(context: Context) {
            val startIntent = Intent(context, BackgroundService::class.java)
            context.startForegroundService(startIntent)
        }
        
        // 停止服务
        fun stopService(context: Context) {
            val stopIntent = Intent(context, BackgroundService::class.java)
            context.stopService(stopIntent)
        }
    }
    
    private lateinit var notificationManager: NotificationManager
    private lateinit var notificationChannel: NotificationChannel
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "BackgroundService created")
        
        // 初始化通知管理器
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // 创建通知渠道
        createNotificationChannel()
        
        // 启动前台服务
        startForeground(NOTIFICATION_ID, createNotification())
        
        // 初始化后台任务
        initializeBackgroundTasks()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "BackgroundService started with intent: ${intent?.action}")
        
        // 处理不同的启动命令
        when (intent?.action) {
            "KEEP_ALIVE" -> {
                keepAlive()
            }
            "START_MONITORING" -> {
                startMonitoring()
            }
            "STOP_MONITORING" -> {
                stopMonitoring()
            }
            else -> {
                // 默认启动逻辑
                handleDefaultStart()
            }
        }
        
        // START_STICKY 表示服务被杀死后会自动重启
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        // 这是一个前台服务，不需要绑定
        return null
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "BackgroundService destroyed")
        
        // 清理资源
        cleanupResources()
    }
    
    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "极客AI助手后台服务"
            val descriptionText = "维持应用后台运行，处理AI任务"
            val importance = NotificationManager.IMPORTANCE_LOW
            notificationChannel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(notificationChannel)
        }
    }
    
    /**
     * 创建通知
     */
    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("极客AI助手")
            .setContentText("正在后台运行...")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
    
    /**
     * 更新通知
     */
    private fun updateNotification(title: String, content: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
        
        notificationManager.notify(NOTIFICATION_ID, notification)
    }
    
    /**
     * 初始化后台任务
     */
    private fun initializeBackgroundTasks() {
        // 启动心跳监控
        startHeartbeat()
        
        // 启动内存监控
        startMemoryMonitor()
        
        // 启动电池优化监控
        startBatteryOptimizationMonitor()
    }
    
    /**
     * 保持服务活跃
     */
    private fun keepAlive() {
        Log.d(TAG, "Keeping service alive")
        updateNotification("极客AI助手", "保持后台运行中...")
        
        // 定期更新通知
        Thread {
            while (true) {
                try {
                    Thread.sleep(30000) // 30秒更新一次
                    updateNotification("极客AI助手", "保持后台运行中...")
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }
    
    /**
     * 启动监控
     */
    private fun startMonitoring() {
        Log.d(TAG, "Starting monitoring")
        updateNotification("极客AI助手", "开始监控...")
        
        // 启动各种监控任务
        startProcessMonitor()
        startServiceMonitor()
        startPermissionMonitor()
    }
    
    /**
     * 停止监控
     */
    private fun stopMonitoring() {
        Log.d(TAG, "Stopping monitoring")
        updateNotification("极客AI助手", "监控已停止")
    }
    
    /**
     * 处理默认启动
     */
    private fun handleDefaultStart() {
        Log.d(TAG, "Handling default start")
        updateNotification("极客AI助手", "后台服务已启动")
        
        // 启动定时任务
        startPeriodicTasks()
    }
    
    /**
     * 启动心跳监控
     */
    private fun startHeartbeat() {
        Thread {
            var heartbeatCount = 0
            while (true) {
                try {
                    Thread.sleep(60000) // 1分钟心跳一次
                    heartbeatCount++
                    
                    Log.d(TAG, "Heartbeat $heartbeatCount")
                    
                    // 定期更新通知
                    runOnUiThread {
                        updateNotification("极客AI助手", "运行时间: ${heartbeatCount}分钟")
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Heartbeat error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动内存监控
     */
    private fun startMemoryMonitor() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(300000) // 5分钟检查一次内存
                    
                    val runtime = Runtime.getRuntime()
                    val usedMemory = runtime.totalMemory() - runtime.freeMemory()
                    val maxMemory = runtime.maxMemory()
                    val memoryUsagePercent = (usedMemory * 100 / maxMemory).toInt()
                    
                    Log.d(TAG, "Memory usage: ${memoryUsagePercent}%")
                    
                    // 如果内存使用率超过80%，尝试清理
                    if (memoryUsagePercent > 80) {
                        System.gc() // 建议垃圾回收
                        Log.w(TAG, "High memory usage, triggered GC")
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Memory monitor error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动电池优化监控
     */
    private fun startBatteryOptimizationMonitor() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(600000) // 10分钟检查一次电池优化
                    
                    // 检查应用是否在电池优化白名单中
                    val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                    val isIgnoringBatteryOptimizations = powerManager.isIgnoringBatteryOptimizations(packageName)
                    
                    if (!isIgnoringBatteryOptimizations) {
                        Log.w(TAG, "App is not in battery optimization whitelist")
                        // 可以在这里通知用户将应用添加到白名单
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Battery optimization monitor error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动进程监控
     */
    private fun startProcessMonitor() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(120000) // 2分钟检查一次进程状态
                    
                    val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    val appProcesses = activityManager.runningAppProcesses ?: return@Thread
                    
                    var isAppRunning = false
                    for (appProcess in appProcesses) {
                        if (appProcess.processName == packageName) {
                            isAppRunning = true
                            break
                        }
                    }
                    
                    if (!isAppRunning) {
                        Log.w(TAG, "App process not running, restarting...")
                        restartApp()
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Process monitor error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动服务监控
     */
    private fun startServiceMonitor() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(180000) // 3分钟检查一次服务状态
                    
                    // 检查服务是否还在运行
                    val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    val runningServices = activityManager.getRunningServices(Int.MAX_VALUE)
                    
                    var isServiceRunning = false
                    for (serviceInfo in runningServices) {
                        if (serviceInfo.service.className == this.javaClass.name) {
                            isServiceRunning = true
                            break
                        }
                    }
                    
                    if (!isServiceRunning) {
                        Log.w(TAG, "Service not running, restarting...")
                        restartService()
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Service monitor error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动权限监控
     */
    private fun startPermissionMonitor() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(300000) // 5分钟检查一次权限
                    
                    // 检查关键权限是否被撤销
                    val criticalPermissions = arrayOf(
                        "android.permission.SYSTEM_ALERT_WINDOW",
                        "android.permission.DEVICE_ADMIN"
                    )
                    
                    for (permission in criticalPermissions) {
                        val permissionGranted = checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (!permissionGranted) {
                            Log.w(TAG, "Critical permission revoked: $permission")
                            // 可以在这里通知用户重新授权
                        }
                    }
                    
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Permission monitor error", e)
                }
            }
        }.start()
    }
    
    /**
     * 启动定时任务
     */
    private fun startPeriodicTasks() {
        // 这里可以添加各种定时任务
        Log.d(TAG, "Periodic tasks started")
    }
    
    /**
     * 重启应用
     */
    private fun restartApp() {
        try {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
            
            // 结束当前进程
            android.os.Process.killProcess(android.os.Process.myPid())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restart app", e)
        }
    }
    
    /**
     * 重启服务
     */
    private fun restartService() {
        try {
            val restartIntent = Intent(this, this.javaClass)
            restartIntent.putExtra("restart", true)
            startService(restartIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restart service", e)
        }
    }
    
    /**
     * 清理资源
     */
    private fun cleanupResources() {
        Log.d(TAG, "Cleaning up resources")
        // 清理定时任务、线程等资源
    }
    
    /**
     * 在UI线程执行代码
     */
    private fun runOnUiThread(action: () -> Unit) {
        val mainHandler = android.os.Handler(mainLooper)
        mainHandler.post(action)
    }
}