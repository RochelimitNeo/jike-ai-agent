---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022034bd40ccbcfb84e4d356f092c55fb7b336d90f26057c00c4e3a5ebcbe112b3e7022100ca428290bf397110fbc5d5c8911c3622ddeade277ee21cb06094d726de298371
    ReservedCode2: 3045022100bde8ba22507e36b4192b1ff9cafa69a77a1920fa72f635ca2c42c495c9adfbc6022070d2d1fbd66fbd2a0c8296a7b6350af4c796e05c75bf3584865503ce6b794320
---

# 极客AI助手 (Jike AI Agent)

一个基于Flutter的智能AI助手应用，集成了多种AI功能和Android原生服务，提供全方位的智能服务体验。

## 项目特性

### 🤖 AI功能
- **智能对话**: 24/7在线AI对话助手
- **图像识别**: 智能图像分析和识别
- **语音助手**: 语音交互和语音识别
- **文档处理**: 智能文档分析和处理

### 🛡️ 安全特性
- **屏幕截图检测**: 实时检测屏幕截图行为
- **权限管理**: 完善的Android权限系统
- **设备保护**: 设备管理员权限保护
- **数据加密**: 敏感数据加密存储

### 📱 Android原生集成
- **悬浮窗服务**: 后台悬浮窗支持
- **前台服务**: 确保应用持续运行
- **窗口管理**: 窗口安全和管理功能
- **系统集成**: 深度系统功能集成

## 项目结构

```
jike_ai_agent/
├── lib/                          # Flutter应用代码
│   ├── main.dart                 # 应用入口文件
│   ├── screens/                  # 界面页面
│   │   ├── splash_screen.dart    # 启动页面
│   │   └── home_screen.dart      # 主页面
│   ├── services/                # 服务层（预留）
│   ├── models/                   # 数据模型
│   │   ├── user_model.dart       # 用户模型
│   │   └── activity_model.dart   # 活动模型
│   ├── widgets/                  # 自定义组件
│   │   ├── logo_widget.dart      # Logo组件
│   │   ├── loading_indicator.dart # 加载指示器
│   │   ├── custom_app_bar.dart   # 自定义AppBar
│   │   ├── agent_card.dart       # AI助手卡片
│   │   └── quick_action_button.dart # 快速操作按钮
│   ├── utils/                    # 工具类
│   │   ├── app_constants.dart    # 应用常量
│   │   └── app_utils.dart        # 工具方法
│   └── providers/                # 状态管理
│       └── app_provider.dart     # 应用状态管理
├── android/                      # Android原生代码
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml # Android清单文件
│   │   │   ├── kotlin/com/jikeai/jike_ai_agent/
│   │   │   │   ├── MainActivity.kt  # 主Activity
│   │   │   │   └── service/
│   │   │   │       └── BackgroundService.kt # 后台服务
│   │   │   └── res/              # Android资源文件
│   │   └── build.gradle          # Android构建配置
│   └── build.gradle              # 项目级构建配置
├── pubspec.yaml                  # Flutter依赖配置
└── README.md                     # 项目说明文档
```

## 依赖库

### Flutter依赖
- `flutter_window_manager`: 窗口管理
- `permission_handler`: 权限处理
- `overlay_support`: 悬浮窗支持
- `flutter_native_view`: 原生视图集成
- `screen_capture_notifier`: 屏幕截图检测

### UI和工具
- `provider`: 状态管理
- `http` / `dio`: 网络请求
- `shared_preferences`: 本地存储
- `device_info_plus`: 设备信息

### Android原生依赖
- AndroidX库
- 媒体投影API
- 设备管理员API
- 权限管理库

## 核心功能

### 1. 应用启动流程
1. **启动页面**: 展示Logo和应用信息
2. **权限检查**: 检查并请求必要权限
3. **服务启动**: 启动后台服务和窗口管理
4. **主页加载**: 加载用户数据和功能模块

### 2. Android原生集成
- **MainActivity**: 负责原生功能调用和权限管理
- **BackgroundService**: 后台服务维持应用运行
- **方法通道**: Flutter与Android原生代码通信

### 3. 安全保护机制
- **屏幕截图检测**: 使用MediaProjection API检测截图
- **权限保护**: 多层次权限检查和保护
- **设备管理**: 启用设备管理员权限
- **窗口安全**: 设置窗口安全标志

### 4. 状态管理
- **AppProvider**: 全局应用状态管理
- **用户状态**: 用户登录状态和偏好设置
- **活动记录**: 用户操作和活动历史

## 权限配置

### 必需权限
```xml
<!-- 网络权限 -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<!-- 存储权限 -->
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

<!-- 相机和音频权限 -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />

<!-- 系统权限 -->
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.DEVICE_ADMIN" />
```

### 特殊权限
```xml
<!-- 悬浮窗权限 -->
<uses-permission android:name="android.permission.SYSTEM_OVERLAY_WINDOW" />

<!-- 屏幕捕获检测权限 -->
<uses-permission android:name="android.permission.MEDIA_PROJECTION" />

<!-- 电池优化忽略权限 -->
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
```

## 快速开始

### 环境要求
- Flutter SDK 3.10.0+
- Dart SDK 3.0.0+
- Android Studio / VS Code
- Android SDK 21+ (Android 5.0+)
- Kotlin支持

### 安装步骤

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd jike_ai_agent
   ```

2. **安装依赖**
   ```bash
   flutter pub get
   ```

3. **配置Android环境**
   - 确保Android SDK已安装
   - 配置环境变量
   - 同步Gradle依赖

4. **运行应用**
   ```bash
   flutter run
   ```

### 调试构建
```bash
# Debug版本
flutter run --debug

# Release版本
flutter run --release

# 分析构建
flutter run --profile
```

## 配置说明

### pubspec.yaml配置
```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # 核心依赖
  flutter_window_manager: ^0.2.0
  permission_handler: ^11.3.1
  overlay_support: ^2.1.0
  flutter_native_view: ^0.0.5
  screen_capture_notifier: ^0.0.1
  
  # 状态管理和网络
  provider: ^6.1.2
  http: ^1.2.1
  dio: ^5.4.3+1
  
  # 存储和工具
  shared_preferences: ^2.2.3
  device_info_plus: ^9.1.2
```

### Android配置
```gradle
android {
    defaultConfig {
        applicationId "com.jikeai.jike_ai_agent"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
}
```

## 使用指南

### 基本使用
1. **启动应用**: 应用会自动检查权限并初始化服务
2. **AI对话**: 点击智能对话卡片开始对话
3. **图像识别**: 使用相机功能进行图像分析
4. **语音助手**: 启用语音交互功能

### 高级功能
1. **屏幕保护**: 应用会自动检测屏幕截图
2. **权限管理**: 在设置中管理应用权限
3. **后台服务**: 确保应用持续运行
4. **数据同步**: 支持云端数据同步

## 常见问题

### 权限相关
**Q: 应用请求权限被拒绝怎么办？**
A: 请在应用设置中手动开启所需权限，特别是悬浮窗和设备管理员权限。

**Q: 如何开启悬浮窗权限？**
A: 进入设置 → 应用 → 极客AI助手 → 权限 → 允许显示在其他应用上层。

### 性能优化
**Q: 应用耗电过多怎么办？**
A: 请将应用加入电池优化白名单，在设置 → 电池 → 电池优化中设置。

**Q: 应用被系统杀死怎么办？**
A: 启用设备管理员权限，并确保应用在后台应用管理中不被限制。

## 开发指南

### 添加新功能
1. 在相应目录创建文件
2. 更新依赖配置
3. 添加必要的权限
4. 编写测试代码

### 自定义组件
- 所有组件位于 `lib/widgets/` 目录
- 遵循Material Design规范
- 支持深色模式

### 状态管理
- 使用Provider进行状态管理
- 全局状态在 `AppProvider` 中管理
- 本地状态在各组件内部管理

## 贡献指南

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 推送到分支
5. 创建Pull Request

## 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 联系方式

- 项目维护者: [Your Name]
- 邮箱: [your.email@example.com]
- 项目地址: [GitHub Repository URL]

---

**注意**: 本应用涉及敏感权限，请合理使用并遵守相关法律法规。