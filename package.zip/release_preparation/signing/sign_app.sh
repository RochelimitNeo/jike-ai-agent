#!/bin/bash
# Android应用签名脚本
# Android App Signing Script

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查必要工具
check_prerequisites() {
    log_info "检查必要工具..."
    
    if ! command -v keytool &> /dev/null; then
        log_error "keytool 未找到，请安装 JDK"
        exit 1
    fi
    
    if ! command -v jarsigner &> /dev/null; then
        log_error "jarsigner 未找到，请安装 JDK"
        exit 1
    fi
    
    log_info "工具检查完成"
}

# 生成密钥库
generate_keystore() {
    local keystore_path=$1
    local keystore_alias=$2
    local keystore_password=$3
    local key_password=$4
    local validity_days=$5
    
    log_info "生成密钥库: $keystore_path"
    
    keytool -genkeypair \
        -alias "$keystore_alias" \
        -keyalg RSA \
        -keysize 2048 \
        -validity $validity_days \
        -keystore "$keystore_path" \
        -storepass "$keystore_password" \
        -keypass "$key_password" \
        -dname "CN=Your App Name, OU=Mobile Development, O=Your Company, L=Beijing, S=Beijing, C=CN" \
        -v
    
    log_info "密钥库生成完成: $keystore_path"
}

# 签名APK
sign_apk() {
    local apk_path=$1
    local keystore_path=$2
    local keystore_alias=$3
    local keystore_password=$4
    local key_password=$5
    
    log_info "签名APK: $apk_path"
    
    jarsigner -verbose \
        -sigalg SHA256withRSA \
        -digestalg SHA256 \
        -keystore "$keystore_path" \
        -storepass "$keystore_password" \
        -keypass "$key_password" \
        "$apk_path" \
        "$keystore_alias"
    
    log_info "APK签名完成: $apk_path"
}

# 验证签名
verify_signature() {
    local apk_path=$1
    
    log_info "验证签名: $apk_path"
    
    jarsigner -verify -verbose -certs "$apk_path"
    
    if [ $? -eq 0 ]; then
        log_info "签名验证成功"
    else
        log_error "签名验证失败"
        exit 1
    fi
}

# 对齐APK
align_apk() {
    local input_apk=$1
    local output_apk=$2
    
    log_info "对齐APK: $input_apk -> $output_apk"
    
    if command -v zipalign &> /dev/null; then
        zipalign -v 4 "$input_apk" "$output_apk"
        log_info "APK对齐完成"
    else
        log_warn "zipalign 未找到，跳过对齐步骤"
        cp "$input_apk" "$output_apk"
    fi
}

# 清理敏感文件
cleanup() {
    log_info "清理敏感文件..."
    
    # 删除包含密码的临时文件
    find . -name "*.tmp" -delete
    find . -name "*password*" -delete 2>/dev/null || true
}

# 主函数
main() {
    local action=$1
    local keystore_path=${2:-"keystore/app_keystore.jks"}
    local keystore_alias=${3:-"app_key"}
    local keystore_password=${4:-""}
    local key_password=${5:-""}
    
    log_info "Android应用签名工具"
    
    case $action in
        "generate-keystore")
            if [ -z "$keystore_password" ] || [ -z "$key_password" ]; then
                log_error "生成密钥库需要提供密码参数"
                echo "使用方法: $0 generate-keystore <keystore_path> <keystore_alias> <keystore_password> <key_password> <validity_days>"
                exit 1
            fi
            
            generate_keystore "$keystore_path" "$keystore_alias" "$keystore_password" "$key_password" 9125  # 25 years
            ;;
            
        "sign")
            if [ -z "$keystore_password" ] || [ -z "$key_password" ]; then
                log_error "签名需要提供密码参数"
                echo "使用方法: $0 sign <apk_path> <keystore_path> <keystore_alias> <keystore_password> <key_password>"
                exit 1
            fi
            
            local apk_path=$2
            if [ ! -f "$apk_path" ]; then
                log_error "APK文件不存在: $apk_path"
                exit 1
            fi
            
            # 签名
            sign_apk "$apk_path" "$keystore_path" "$keystore_alias" "$keystore_password" "$key_password"
            
            # 验证签名
            verify_signature "$apk_path"
            
            # 清理
            cleanup
            
            log_info "签名流程完成"
            ;;
            
        "verify")
            local apk_path=$2
            if [ ! -f "$apk_path" ]; then
                log_error "APK文件不存在: $apk_path"
                exit 1
            fi
            
            verify_signature "$apk_path"
            ;;
            
        "help")
            echo "Android应用签名工具"
            echo ""
            echo "使用方法:"
            echo "  $0 generate-keystore <keystore_path> <keystore_alias> <keystore_password> <key_password> [validity_days]"
            echo "  $0 sign <apk_path> <keystore_path> <keystore_alias> <keystore_password> <key_password>"
            echo "  $0 verify <apk_path>"
            echo "  $0 help"
            echo ""
            echo "示例:"
            echo "  # 生成密钥库"
            echo "  $0 generate-keystore keystore/app.jks app_key mypass123 keypass123"
            echo ""
            echo "  # 签名APK"
            echo "  $0 sign app-release.apk keystore/app.jks app_key mypass123 keypass123"
            ;;
            
        *)
            log_error "未知操作: $action"
            echo "使用方法: $0 help"
            exit 1
            ;;
    esac
}

# 检查必要工具
check_prerequisites

# 执行主函数
main "$@"