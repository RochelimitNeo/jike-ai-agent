import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:isolate';
import 'dart:developer';
import 'test_config.dart';

/// 性能测试工具类
/// 提供通用的测试功能和辅助方法
class TestUtils {
  /// 获取当前内存使用情况
  static Map<String, dynamic> getMemoryUsage() {
    final info = ProcessInfo.currentRss;
    return {
      'timestamp': DateTime.now().toIso8601String(),
      'memoryRss': info,
      'memoryMB': info / (1024 * 1024),
    };
  }

  /// 获取CPU使用率
  static Future<Map<String, dynamic>> getCpuUsage() async {
    try {
      final result = await Process.run('top', ['-bn1', '-o', '%CPU']);
      if (result.exitCode == 0) {
        final lines = result.stdout.toString().split('\n');
        double totalCpu = 0;
        int count = 0;
        
        for (final line in lines) {
          if (line.contains('%CPU') || line.trim().isEmpty) continue;
          
          final parts = line.trim().split(RegExp(r'\s+'));
          if (parts.length > 8) {
            final cpuValue = double.tryParse(parts[8]);
            if (cpuValue != null) {
              totalCpu += cpuValue;
              count++;
            }
          }
        }
        
        return {
          'timestamp': DateTime.now().toIso8601String(),
          'cpuUsage': count > 0 ? totalCpu / count : 0,
          'cpuPercent': (count > 0 ? totalCpu / count : 0) / 100.0,
        };
      }
    } catch (e) {
      // 在某些环境中top命令不可用，使用模拟数据
    }
    
    return {
      'timestamp': DateTime.now().toIso8601String(),
      'cpuUsage': Random().nextDouble() * 50, // 模拟数据
      'cpuPercent': Random().nextDouble() * 0.5,
    };
  }

  /// 延迟执行
  static Future<void> delay(int milliseconds) {
    return Future.delayed(Duration(milliseconds: milliseconds));
  }

  /// 执行CPU密集型任务
  static double cpuIntensiveTask() {
    double result = 0;
    for (int i = 0; i < 100000; i++) {
      result += sqrt(i) * log(i + 1);
    }
    return result;
  }

  /// 执行内存密集型任务
  static List<int> memoryIntensiveTask(int size) {
    final list = <int>[];
    for (int i = 0; i < size; i++) {
      list.add(i);
    }
    return list;
  }

  /// 创建随机字符串
  static String createRandomString(int length) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    return String.fromCharCodes(
      Iterable.generate(length, (_) => chars.codeUnitAt(random.nextInt(chars.length))),
    );
  }

  /// 格式化字节数
  static String formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  /// 格式化时间
  static String formatDuration(Duration duration) {
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}m ${duration.inSeconds % 60}s';
    } else if (duration.inMinutes > 0) {
      return '${duration.inMinutes}m ${duration.inSeconds % 60}s';
    } else {
      return '${duration.inSeconds}s';
    }
  }

  /// 计算百分比
  static double calculatePercentage(double value, double total) {
    if (total == 0) return 0;
    return (value / total) * 100;
  }

  /// 检查条件
  static bool checkThreshold(double value, double threshold, {bool above = true}) {
    return above ? value >= threshold : value <= threshold;
  }

  /// 保存数据到文件
  static Future<void> saveToFile(String filePath, String content) async {
    try {
      final file = File(filePath);
      await file.writeAsString(content);
    } catch (e) {
      print('Error saving to file: $e');
    }
  }

  /// 读取文件内容
  static Future<String> readFromFile(String filePath) async {
    try {
      final file = File(filePath);
      return await file.readAsString();
    } catch (e) {
      print('Error reading from file: $e');
      return '';
    }
  }

  /// 创建JSON报告
  static String createJsonReport(Map<String, dynamic> data) {
    return JsonEncoder.withIndent('  ').convert(data);
  }

  /// 监控资源使用
  static Stream<Map<String, dynamic>> monitorResourceUsage({int intervalMs = 1000}) {
    return Stream.periodic(Duration(milliseconds: intervalMs), (_) {
      return {
        'timestamp': DateTime.now(),
        'memory': getMemoryUsage(),
        'cpu': getCpuUsage(),
      };
    });
  }

  /// 执行异步任务并测量时间
  static Future<Map<String, dynamic>> measureAsyncTask(Future<void> Function() task) async {
    final startTime = DateTime.now();
    try {
      await task();
      final endTime = DateTime.now();
      return {
        'success': true,
        'duration': endTime.difference(startTime).inMilliseconds,
        'error': null,
      };
    } catch (e) {
      final endTime = DateTime.now();
      return {
        'success': false,
        'duration': endTime.difference(startTime).inMilliseconds,
        'error': e.toString(),
      };
    }
  }

  /// 生成测试数据
  static List<Map<String, dynamic>> generateTestData(int count) {
    final data = <Map<String, dynamic>>[];
    for (int i = 0; i < count; i++) {
      data.add({
        'id': i,
        'timestamp': DateTime.now().add(Duration(seconds: i)).toIso8601String(),
        'value': Random().nextDouble() * 100,
        'category': ['A', 'B', 'C', 'D'][Random().nextInt(4)],
        'description': createRandomString(50),
      });
    }
    return data;
  }

  /// 计算统计信息
  static Map<String, double> calculateStatistics(List<double> values) {
    if (values.isEmpty) {
      return {
        'mean': 0,
        'median': 0,
        'min': 0,
        'max': 0,
        'stdDev': 0,
      };
    }

    values.sort();
    final sum = values.reduce((a, b) => a + b);
    final mean = sum / values.length;
    final median = values.length % 2 == 0
        ? (values[values.length ~/ 2 - 1] + values[values.length ~/ 2]) / 2
        : values[values.length ~/ 2];
    final min = values.first;
    final max = values.last;
    
    final variance = values.map((x) => pow(x - mean, 2)).reduce((a, b) => a + b) / values.length;
    final stdDev = sqrt(variance);

    return {
      'mean': mean,
      'median': median,
      'min': min,
      'max': max,
      'stdDev': stdDev,
    };
  }

  /// 模拟网络请求
  static Future<Map<String, dynamic>> simulateNetworkRequest({
    int delayMs = 100,
    bool shouldFail = false,
    int responseSize = 1024,
  }) async {
    await TestUtils.delay(delayMs);
    
    if (shouldFail) {
      throw Exception('Network request failed');
    }

    return {
      'statusCode': 200,
      'responseTime': delayMs,
      'responseSize': responseSize,
      'data': createRandomString(responseSize),
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  /// 创建并发任务
  static Future<Map<String, dynamic>> createConcurrentTask(int taskId) async {
    final startTime = DateTime.now();
    
    // 模拟一些计算
    final result = cpuIntensiveTask();
    
    final endTime = DateTime.now();
    
    return {
      'taskId': taskId,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': endTime.difference(startTime).inMilliseconds,
      'result': result,
    };
  }

  /// 清理资源
  static void cleanup() {
    // 清理临时文件、缓存等
    print('Cleaning up test resources...');
  }
}