/// 测试配置类
/// 用于配置各种测试参数
class TestConfig {
  // 通用配置
  static const int defaultTestDuration = 30000; // 30秒
  static const int sampleInterval = 1000; // 1秒采样间隔
  
  // 内存测试配置
  static const int memoryTestDuration = 60000; // 1分钟
  static const int memoryLeakCheckInterval = 5000; // 5秒检查间隔
  static const double memoryThreshold = 0.8; // 80%内存使用阈值
  
  // CPU测试配置
  static const int cpuTestDuration = 30000; // 30秒
  static const int cpuCoreCount = 4; // CPU核心数
  static const double cpuThreshold = 0.7; // 70%CPU使用阈值
  
  // 电池测试配置
  static const int batteryTestDuration = 300000; // 5分钟
  static const int batterySampleInterval = 10000; // 10秒采样间隔
  static const double batteryDrainThreshold = 0.1; // 10%电池消耗阈值
  
  // 网络测试配置
  static const int networkRequestCount = 100; // 网络请求数量
  static const int networkTimeout = 5000; // 5秒超时
  static const double networkErrorThreshold = 0.05; // 5%错误率阈值
  
  // 并发测试配置
  static const int concurrentThreadCount = 10; // 并发线程数
  static const int concurrentTaskCount = 1000; // 并发任务数
  static const double concurrentPerformanceThreshold = 0.8; // 80%性能阈值
  
  // 压力测试配置
  static const int stressTestDuration = 60000; // 1分钟
  static const int stressThreadCount = 50; // 压力线程数
  static const double stressCpuThreshold = 0.9; // 90%CPU阈值
  static const double stressMemoryThreshold = 0.95; // 95%内存阈值
  
  // 报告配置
  static const String reportFormat = 'html'; // html, json, csv, pdf
  static const bool includeCharts = true; // 是否包含图表
  static const bool includeRecommendations = true; // 是否包含优化建议
}

/// 测试结果类
class TestResult {
  final String testName;
  final DateTime startTime;
  final DateTime endTime;
  final bool passed;
  final Map<String, dynamic> metrics;
  final String? errorMessage;
  final List<String> recommendations;

  TestResult({
    required this.testName,
    required this.startTime,
    required this.endTime,
    required this.passed,
    required this.metrics,
    this.errorMessage,
    this.recommendations = const [],
  });

  Map<String, dynamic> toJson() {
    return {
      'testName': testName,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': endTime.difference(startTime).inMilliseconds,
      'passed': passed,
      'metrics': metrics,
      'errorMessage': errorMessage,
      'recommendations': recommendations,
    };
  }
}

/// 测试类型枚举
enum TestType {
  memory,
  cpu,
  battery,
  network,
  concurrent,
  stress,
  all,
}

/// 测试状态枚举
enum TestStatus {
  pending,
  running,
  completed,
  failed,
}