import 'dart:async';
import 'dart:developer';
import 'dart:math';
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// CPU测试类
/// 用于测试CPU使用率和性能瓶颈
class CpuTest {
  static const String _testName = 'CPU Test';
  Timer? _monitoringTimer;
  List<Map<String, dynamic>> _cpuSnapshots = [];
  List<String> _recommendations = [];

  /// 运行CPU测试
  Future<TestResult> runCpuTest() async {
    final startTime = DateTime.now();
    _recommendations.clear();
    _cpuSnapshots.clear();
    
    try {
      print('Starting CPU Test...');
      
      // 1. 单线程CPU性能测试
      await _testSingleThreadPerformance();
      
      // 2. 多线程CPU性能测试
      await _testMultiThreadPerformance();
      
      // 3. CPU密集型算法测试
      await _testCpuIntensiveAlgorithms();
      
      // 4. CPU使用率监控
      await _testCpuUsageMonitoring();
      
      // 5. 浮点运算性能测试
      await _testFloatingPointPerformance();
      
      // 6. 整数运算性能测试
      await _testIntegerPerformance();
      
      final endTime = DateTime.now();
      final metrics = _analyzeCpuResults();
      final passed = _evaluateCpuTest(metrics);
      
      // 生成优化建议
      _generateCpuRecommendations(metrics);
      
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: passed,
        metrics: metrics,
        recommendations: _recommendations,
      );
      
    } catch (e) {
      final endTime = DateTime.now();
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: false,
        metrics: {},
        errorMessage: e.toString(),
        recommendations: _recommendations,
      );
    } finally {
      _monitoringTimer?.cancel();
    }
  }

  /// 测试单线程CPU性能
  Future<void> _testSingleThreadPerformance() async {
    print('Testing single thread CPU performance...');
    
    final results = <Map<String, dynamic>>[];
    
    // 测试不同复杂度的计算
    final testSizes = [10000, 50000, 100000, 500000];
    
    for (final size in testSizes) {
      final startTime = DateTime.now();
      final cpuBefore = await TestUtils.getCpuUsage();
      
      // 执行计算密集型任务
      double result = 0;
      for (int i = 0; i < size; i++) {
        result += sqrt(i) * sin(i.toDouble()) * cos(i.toDouble());
        result = result % 1000000; // 防止数值过大
      }
      
      final endTime = DateTime.now();
      final cpuAfter = await TestUtils.getCpuUsage();
      
      results.add({
        'testSize': size,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'cpuBefore': cpuBefore,
        'cpuAfter': cpuAfter,
        'cpuDelta': (cpuAfter['cpuUsage'] as double) - (cpuBefore['cpuUsage'] as double),
        'operationsPerSecond': size / (endTime.difference(startTime).inMilliseconds / 1000),
        'result': result,
      });
    }
    
    _cpuSnapshots.add({
      'type': 'single_thread_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试多线程CPU性能
  Future<void> _testMultiThreadPerformance() async {
    print('Testing multi thread CPU performance...');
    
    final threadCounts = [2, 4, 8, 16];
    final results = <Map<String, dynamic>>[];
    
    for (final threadCount in threadCounts) {
      final startTime = DateTime.now();
      final cpuBefore = await TestUtils.getCpuUsage();
      
      // 创建多个并发任务
      final tasks = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < threadCount; i++) {
        tasks.add(_runCpuTask(i, 25000)); // 每个任务执行25000次计算
      }
      
      // 等待所有任务完成
      final taskResults = await Future.wait(tasks);
      
      final endTime = DateTime.now();
      final cpuAfter = await TestUtils.getCpuUsage();
      
      results.add({
        'threadCount': threadCount,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'cpuBefore': cpuBefore,
        'cpuAfter': cpuAfter,
        'cpuDelta': (cpuAfter['cpuUsage'] as double) - (cpuBefore['cpuUsage'] as double),
        'taskResults': taskResults,
        'throughput': threadCount * 25000 / (endTime.difference(startTime).inMilliseconds / 1000),
      });
    }
    
    _cpuSnapshots.add({
      'type': 'multi_thread_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试CPU密集型算法
  Future<void> _testCpuIntensiveAlgorithms() async {
    print('Testing CPU intensive algorithms...');
    
    final algorithms = [
      _primeNumberCalculation,
      _fibonacciCalculation,
      _matrixMultiplication,
      _sortingAlgorithm,
    ];
    
    final results = <Map<String, dynamic>>[];
    
    for (final algorithm in algorithms) {
      final startTime = DateTime.now();
      final cpuBefore = await TestUtils.getCpuUsage();
      
      final result = await algorithm();
      
      final endTime = DateTime.now();
      final cpuAfter = await TestUtils.getCpuUsage();
      
      results.add({
        'algorithm': algorithm.toString(),
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'cpuBefore': cpuBefore,
        'cpuAfter': cpuAfter,
        'cpuDelta': (cpuAfter['cpuUsage'] as double) - (cpuBefore['cpuUsage'] as double),
        'result': result,
      });
    }
    
    _cpuSnapshots.add({
      'type': 'cpu_intensive_algorithms',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试CPU使用率监控
  Future<void> _testCpuUsageMonitoring() async {
    print('Testing CPU usage monitoring...');
    
    final monitoringResults = <Map<String, dynamic>>[];
    
    // 启动CPU监控
    startCpuMonitoring();
    
    // 运行一些CPU密集型任务
    final tasks = <Future<void>>[];
    for (int i = 0; i < 4; i++) {
      tasks.add(_runCpuIntensiveTask(5000));
    }
    
    await Future.wait(tasks);
    
    // 等待一段时间收集监控数据
    await TestUtils.delay(2000);
    
    // 停止监控
    stopCpuMonitoring();
    
    _cpuSnapshots.add({
      'type': 'cpu_monitoring',
      'monitoringResults': _cpuSnapshots.where((s) => s['type'] == 'monitoring').toList(),
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试浮点运算性能
  Future<void> _testFloatingPointPerformance() async {
    print('Testing floating point performance...');
    
    final operations = [
      ('Addition', (int iterations) => _testFloatOperation(iterations, (a, b) => a + b)),
      ('Multiplication', (int iterations) => _testFloatOperation(iterations, (a, b) => a * b)),
      ('Division', (int iterations) => _testFloatOperation(iterations, (a, b) => a / b)),
      ('Square Root', (int iterations) => _testFloatOperation(iterations, (a, b) => sqrt(a))),
      ('Trigonometric', (int iterations) => _testFloatOperation(iterations, (a, b) => sin(a) + cos(b))),
    ];
    
    final results = <Map<String, dynamic>>[];
    
    for (final (name, operation) in operations) {
      final startTime = DateTime.now();
      final cpuBefore = await TestUtils.getCpuUsage();
      
      final operationsPerSecond = await operation(100000);
      
      final endTime = DateTime.now();
      final cpuAfter = await TestUtils.getCpuUsage();
      
      results.add({
        'operation': name,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'cpuBefore': cpuBefore,
        'cpuAfter': cpuAfter,
        'cpuDelta': (cpuAfter['cpuUsage'] as double) - (cpuBefore['cpuUsage'] as double),
        'operationsPerSecond': operationsPerSecond,
      });
    }
    
    _cpuSnapshots.add({
      'type': 'floating_point_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试整数运算性能
  Future<void> _testIntegerPerformance() async {
    print('Testing integer performance...');
    
    final operations = [
      ('Addition', (int iterations) => _testIntOperation(iterations, (a, b) => a + b)),
      ('Multiplication', (int iterations) => _testIntOperation(iterations, (a, b) => a * b)),
      ('Division', (int iterations) => _testIntOperation(iterations, (a, b) => a ~/ b)),
      ('Modulo', (int iterations) => _testIntOperation(iterations, (a, b) => a % b)),
      ('Bit Operations', (int iterations) => _testIntOperation(iterations, (a, b) => (a & b) | (a ^ b))),
    ];
    
    final results = <Map<String, dynamic>>[];
    
    for (final (name, operation) in operations) {
      final startTime = DateTime.now();
      final cpuBefore = await TestUtils.getCpuUsage();
      
      final operationsPerSecond = await operation(100000);
      
      final endTime = DateTime.now();
      final cpuAfter = await TestUtils.getCpuUsage();
      
      results.add({
        'operation': name,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'cpuBefore': cpuBefore,
        'cpuAfter': cpuAfter,
        'cpuDelta': (cpuAfter['cpuUsage'] as double) - (cpuBefore['cpuUsage'] as double),
        'operationsPerSecond': operationsPerSecond,
      });
    }
    
    _cpuSnapshots.add({
      'type': 'integer_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 运行CPU任务
  Future<Map<String, dynamic>> _runCpuTask(int taskId, int iterations) async {
    final startTime = DateTime.now();
    
    double result = 0;
    for (int i = 0; i < iterations; i++) {
      result += sqrt(i) * sin(i.toDouble()) * cos(i.toDouble());
      result = result % 1000000;
    }
    
    final endTime = DateTime.now();
    
    return {
      'taskId': taskId,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': endTime.difference(startTime).inMilliseconds,
      'iterations': iterations,
      'operationsPerSecond': iterations / (endTime.difference(startTime).inMilliseconds / 1000),
      'result': result,
    };
  }

  /// 运行CPU密集型任务
  Future<void> _runCpuIntensiveTask(int durationMs) async {
    final endTime = DateTime.now().add(Duration(milliseconds: durationMs));
    
    while (DateTime.now().isBefore(endTime)) {
      TestUtils.cpuIntensiveTask();
    }
  }

  /// 素数计算算法
  Future<Map<String, dynamic>> _primeNumberCalculation() async {
    int count = 0;
    final primes = <int>[];
    
    for (int i = 2; i < 10000; i++) {
      bool isPrime = true;
      for (int j = 2; j * j <= i; j++) {
        if (i % j == 0) {
          isPrime = false;
          break;
        }
      }
      if (isPrime) {
        primes.add(i);
        count++;
      }
    }
    
    return {'primeCount': count, 'primes': primes.take(10).toList()};
  }

  /// 斐波那契计算
  Future<Map<String, dynamic>> _fibonacciCalculation() async {
    int fib(int n) {
      if (n <= 1) return n;
      return fib(n - 1) + fib(n - 2);
    }
    
    final startTime = DateTime.now();
    final result = fib(30);
    final endTime = DateTime.now();
    
    return {
      'fibonacci30': result,
      'duration': endTime.difference(startTime).inMilliseconds,
    };
  }

  /// 矩阵乘法
  Future<Map<String, dynamic>> _matrixMultiplication() async {
    final size = 100;
    final matrixA = List.generate(size, (i) => List.generate(size, (j) => Random().nextDouble()));
    final matrixB = List.generate(size, (i) => List.generate(size, (j) => Random().nextDouble()));
    final result = List.generate(size, (i) => List.generate(size, (j) => 0.0));
    
    final startTime = DateTime.now();
    
    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        for (int k = 0; k < size; k++) {
          result[i][j] += matrixA[i][k] * matrixB[k][j];
        }
      }
    }
    
    final endTime = DateTime.now();
    
    return {
      'matrixSize': size,
      'duration': endTime.difference(startTime).inMilliseconds,
      'sampleResult': result[0][0],
    };
  }

  /// 排序算法
  Future<Map<String, dynamic>> _sortingAlgorithm() async {
    final data = List.generate(10000, (i) => Random().nextInt(10000));
    
    final startTime = DateTime.now();
    data.sort();
    final endTime = DateTime.now();
    
    return {
      'arraySize': data.length,
      'duration': endTime.difference(startTime).inMilliseconds,
      'isSorted': _isSorted(data),
      'sampleElements': data.take(10).toList(),
    };
  }

  /// 检查数组是否已排序
  bool _isSorted(List<int> data) {
    for (int i = 1; i < data.length; i++) {
      if (data[i] < data[i - 1]) return false;
    }
    return true;
  }

  /// 测试浮点运算
  Future<double> _testFloatOperation(int iterations, double Function(double, double) operation) async {
    double result = 0;
    for (int i = 0; i < iterations; i++) {
      result = operation(result, i.toDouble());
    }
    return iterations / (result + 1); // 避免除零
  }

  /// 测试整数运算
  Future<double> _testIntOperation(int iterations, int Function(int, int) operation) async {
    int result = 0;
    for (int i = 0; i < iterations; i++) {
      result = operation(result, i);
    }
    return iterations / (result.abs() + 1); // 避免除零
  }

  /// 启动CPU监控
  void startCpuMonitoring() {
    _monitoringTimer = Timer.periodic(
      Duration(milliseconds: TestConfig.sampleInterval),
      (timer) async {
        final cpu = await TestUtils.getCpuUsage();
        _cpuSnapshots.add({
          'type': 'monitoring',
          'cpu': cpu,
          'timestamp': DateTime.now().toIso8601String(),
        });
      },
    );
  }

  /// 停止CPU监控
  void stopCpuMonitoring() {
    _monitoringTimer?.cancel();
  }

  /// 分析CPU测试结果
  Map<String, dynamic> _analyzeCpuResults() {
    final analysis = {
      'snapshots': _cpuSnapshots,
      'summary': <String, dynamic>{},
    };
    
    // 分析单线程性能
    final singleThreadResults = _cpuSnapshots
        .where((s) => s['type'] == 'single_thread_performance')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (singleThreadResults.isNotEmpty) {
      final operationsPerSecond = singleThreadResults
          .map((r) => r['operationsPerSecond'] as double)
          .toList();
      
      analysis['summary']['singleThreadPerformance'] = {
        'averageOpsPerSecond': operationsPerSecond.isNotEmpty ? 
            operationsPerSecond.reduce((a, b) => a + b) / operationsPerSecond.length : 0,
        'maxOpsPerSecond': operationsPerSecond.isNotEmpty ? 
            operationsPerSecond.reduce((a, b) => a > b ? a : b) : 0,
        'minOpsPerSecond': operationsPerSecond.isNotEmpty ? 
            operationsPerSecond.reduce((a, b) => a < b ? a : b) : 0,
      };
    }
    
    // 分析多线程性能
    final multiThreadResults = _cpuSnapshots
        .where((s) => s['type'] == 'multi_thread_performance')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (multiThreadResults.isNotEmpty) {
      analysis['summary']['multiThreadPerformance'] = {
        'threadCounts': multiThreadResults.map((r) => r['threadCount'] as int).toList(),
        'throughputs': multiThreadResults.map((r) => r['throughput'] as double).toList(),
        'scalability': _calculateScalability(multiThreadResults),
      };
    }
    
    return analysis;
  }

  /// 计算可扩展性
  Map<String, double> _calculateScalability(List<Map<String, dynamic>> results) {
    final throughputs = results.map((r) => r['throughput'] as double).toList();
    final threadCounts = results.map((r) => r['threadCount'] as int).toList();
    
    if (throughputs.length >= 2) {
      final firstThroughput = throughputs[0];
      final lastThroughput = throughputs.last;
      final firstThread = threadCounts[0];
      final lastThread = threadCounts.last;
      
      final speedup = lastThroughput / firstThroughput;
      final efficiency = speedup / (lastThread / firstThread);
      
      return {
        'speedup': speedup,
        'efficiency': efficiency,
      };
    }
    
    return {'speedup': 0, 'efficiency': 0};
  }

  /// 评估CPU测试结果
  bool _evaluateCpuTest(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    final singleThread = summary['singleThreadPerformance'] as Map<String, dynamic>? ?? {};
    
    // 检查单线程性能
    final avgOps = singleThread['averageOpsPerSecond'] as double? ?? 0;
    if (avgOps < 100000) { // 每秒少于10万次操作
      _recommendations.add('单线程CPU性能较低：${avgOps.toStringAsFixed(0)} ops/sec，建议优化算法复杂度');
      return false;
    }
    
    // 检查多线程可扩展性
    final multiThread = summary['multiThreadPerformance'] as Map<String, dynamic>? ?? {};
    final scalability = multiThread['scalability'] as Map<String, double>? ?? {};
    final efficiency = scalability['efficiency'] ?? 0;
    
    if (efficiency < 0.7) { // 效率低于70%
      _recommendations.add('多线程可扩展性较差，效率：${(efficiency * 100).toStringAsFixed(1)}%，建议优化线程使用');
      return false;
    }
    
    return true;
  }

  /// 生成CPU优化建议
  void _generateCpuRecommendations(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    final singleThread = summary['singleThreadPerformance'] as Map<String, dynamic>? ?? {};
    final avgOps = singleThread['averageOpsPerSecond'] as double? ?? 0;
    
    if (avgOps < 200000) {
      _recommendations.add('考虑使用更高效的算法或数据结构');
    }
    
    _recommendations.add('使用并发处理来充分利用多核CPU');
    _recommendations.add('避免频繁的上下文切换，减少线程数量');
    _recommendations.add('对于计算密集型任务，考虑使用异步编程模式');
    _recommendations.add('使用CPU缓存友好的数据布局');
  }
}