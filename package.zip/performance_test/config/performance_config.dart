/// 性能测试配置文件
/// 
/// 可以通过修改此文件来自定义测试参数和设置

class PerformanceTestConfig {
  // 通用测试设置
  static const bool enableDetailedLogging = true;
  static const bool enablePerformanceMonitoring = true;
  static const bool generateReports = true;
  static const String defaultReportFormat = 'html'; // html, json, csv, pdf
  
  // 内存测试配置
  static const int memoryTestIterations = 5;
  static const double memoryUsageThreshold = 0.8; // 80%
  static const int memoryAllocationSize = 1024 * 1024; // 1MB
  static const Duration memoryTestTimeout = Duration(minutes: 2);
  
  // CPU测试配置
  static const int cpuTestIterations = 3;
  static const double cpuUsageThreshold = 0.7; // 70%
  static const int cpuIntensiveIterations = 100000;
  static const Duration cpuTestTimeout = Duration(minutes: 1);
  
  // 电池测试配置
  static const int batteryTestIterations = 3;
  static const double batteryDrainThreshold = 0.05; // 5%
  static const Duration batteryTestDuration = Duration(seconds: 30);
  static const Duration batteryTestTimeout = Duration(minutes: 5);
  
  // 网络测试配置
  static const int networkTestIterations = 10;
  static const double networkErrorThreshold = 0.05; // 5%
  static const int networkRequestCount = 100;
  static const Duration networkTimeout = Duration(seconds: 30);
  
  // 并发测试配置
  static const int concurrentTestIterations = 3;
  static const int maxConcurrentThreads = 50;
  static const double concurrentPerformanceThreshold = 0.8; // 80%
  static const Duration concurrentTestTimeout = Duration(minutes: 2);
  
  // 压力测试配置
  static const int stressTestIterations = 1;
  static const double stressCpuThreshold = 0.9; // 90%
  static const double stressMemoryThreshold = 0.95; // 95%
  static const Duration stressTestTimeout = Duration(minutes: 5);
  
  // 报告配置
  static const bool includeChartsInReports = true;
  static const bool includeRecommendations = true;
  static const bool includeHistoricalComparison = true;
  static const int maxRecommendations = 10;
  
  // 输出配置
  static const String outputDirectory = 'reports';
  static const bool saveRawData = true;
  static const bool saveTestLogs = true;
  
  /// 获取自定义测试配置
  static Map<String, dynamic> getCustomTestConfig() {
    return {
      'memory': {
        'iterations': memoryTestIterations,
        'usageThreshold': memoryUsageThreshold,
        'allocationSize': memoryAllocationSize,
        'timeout': memoryTestTimeout.inSeconds,
      },
      'cpu': {
        'iterations': cpuTestIterations,
        'usageThreshold': cpuUsageThreshold,
        'intensiveIterations': cpuIntensiveIterations,
        'timeout': cpuTestTimeout.inSeconds,
      },
      'battery': {
        'iterations': batteryTestIterations,
        'drainThreshold': batteryDrainThreshold,
        'testDuration': batteryTestDuration.inSeconds,
        'timeout': batteryTestTimeout.inSeconds,
      },
      'network': {
        'iterations': networkTestIterations,
        'errorThreshold': networkErrorThreshold,
        'requestCount': networkRequestCount,
        'timeout': networkTimeout.inSeconds,
      },
      'concurrent': {
        'iterations': concurrentTestIterations,
        'maxThreads': maxConcurrentThreads,
        'performanceThreshold': concurrentPerformanceThreshold,
        'timeout': concurrentTestTimeout.inSeconds,
      },
      'stress': {
        'iterations': stressTestIterations,
        'cpuThreshold': stressCpuThreshold,
        'memoryThreshold': stressMemoryThreshold,
        'timeout': stressTestTimeout.inSeconds,
      },
      'reporting': {
        'includeCharts': includeChartsInReports,
        'includeRecommendations': includeRecommendations,
        'includeHistoricalComparison': includeHistoricalComparison,
        'maxRecommendations': maxRecommendations,
      },
      'output': {
        'directory': outputDirectory,
        'saveRawData': saveRawData,
        'saveTestLogs': saveTestLogs,
      },
    };
  }
  
  /// 验证配置
  static bool validateConfig() {
    if (memoryUsageThreshold < 0 || memoryUsageThreshold > 1) {
      print('错误: 内存使用阈值必须在0-1之间');
      return false;
    }
    
    if (cpuUsageThreshold < 0 || cpuUsageThreshold > 1) {
      print('错误: CPU使用阈值必须在0-1之间');
      return false;
    }
    
    if (batteryDrainThreshold < 0 || batteryDrainThreshold > 1) {
      print('错误: 电池消耗阈值必须在0-1之间');
      return false;
    }
    
    if (networkErrorThreshold < 0 || networkErrorThreshold > 1) {
      print('错误: 网络错误阈值必须在0-1之间');
      return false;
    }
    
    if (maxConcurrentThreads <= 0) {
      print('错误: 最大并发线程数必须大于0');
      return false;
    }
    
    return true;
  }
  
  /// 打印配置信息
  static void printConfig() {
    print('📋 性能测试配置:');
    print('=' * 50);
    print('内存测试:');
    print('  迭代次数: $memoryTestIterations');
    print('  使用阈值: ${(memoryUsageThreshold * 100).toStringAsFixed(1)}%');
    print('  分配大小: ${(memoryAllocationSize / 1024 / 1024).toStringAsFixed(1)}MB');
    print('  超时时间: ${memoryTestTimeout.inMinutes}分钟');
    print();
    print('CPU测试:');
    print('  迭代次数: $cpuTestIterations');
    print('  使用阈值: ${(cpuUsageThreshold * 100).toStringAsFixed(1)}%');
    print('  密集迭代: $cpuIntensiveIterations');
    print('  超时时间: ${cpuTestTimeout.inMinutes}分钟');
    print();
    print('电池测试:');
    print('  迭代次数: $batteryTestIterations');
    print('  消耗阈值: ${(batteryDrainThreshold * 100).toStringAsFixed(1)}%');
    print('  测试时长: ${batteryTestDuration.inSeconds}秒');
    print('  超时时间: ${batteryTestTimeout.inMinutes}分钟');
    print();
    print('网络测试:');
    print('  迭代次数: $networkTestIterations');
    print('  错误阈值: ${(networkErrorThreshold * 100).toStringAsFixed(1)}%');
    print('  请求数量: $networkRequestCount');
    print('  超时时间: ${networkTimeout.inSeconds}秒');
    print();
    print('并发测试:');
    print('  迭代次数: $concurrentTestIterations');
    print('  最大线程: $maxConcurrentThreads');
    print('  性能阈值: ${(concurrentPerformanceThreshold * 100).toStringAsFixed(1)}%');
    print('  超时时间: ${concurrentTestTimeout.inMinutes}分钟');
    print();
    print('压力测试:');
    print('  迭代次数: $stressTestIterations');
    print('  CPU阈值: ${(stressCpuThreshold * 100).toStringAsFixed(1)}%');
    print('  内存阈值: ${(stressMemoryThreshold * 100).toStringAsFixed(1)}%');
    print('  超时时间: ${stressTestTimeout.inMinutes}分钟');
    print();
    print('报告设置:');
    print('  包含图表: $includeChartsInReports');
    print('  包含建议: $includeRecommendations');
    print('  历史比较: $includeHistoricalComparison');
    print('  最大建议数: $maxRecommendations');
    print();
    print('输出设置:');
    print('  输出目录: $outputDirectory');
    print('  保存原始数据: $saveRawData');
    print('  保存测试日志: $saveTestLogs');
    print('=' * 50);
  }
}

/// 预设配置
class PerformanceTestPresets {
  /// 快速测试配置
  static Map<String, dynamic> get quickTestPreset() {
    return {
      'memory': {
        'iterations': 2,
        'timeout': 30,
      },
      'cpu': {
        'iterations': 2,
        'timeout': 30,
      },
      'network': {
        'iterations': 5,
        'timeout': 15,
      },
    };
  }
  
  /// 完整测试配置
  static Map<String, dynamic> get fullTestPreset() {
    return {
      'memory': {
        'iterations': 10,
        'timeout': 300,
      },
      'cpu': {
        'iterations': 5,
        'timeout': 180,
      },
      'battery': {
        'iterations': 5,
        'timeout': 300,
      },
      'network': {
        'iterations': 20,
        'timeout': 60,
      },
      'concurrent': {
        'iterations': 5,
        'timeout': 180,
      },
      'stress': {
        'iterations': 3,
        'timeout': 600,
      },
    };
  }
  
  /// 压力测试配置
  static Map<String, dynamic> get stressTestPreset() {
    return {
      'memory': {
        'iterations': 1,
        'usageThreshold': 0.95,
      },
      'cpu': {
        'iterations': 1,
        'usageThreshold': 0.95,
      },
      'network': {
        'iterations': 1,
        'requestCount': 1000,
      },
      'concurrent': {
        'iterations': 1,
        'maxThreads': 100,
      },
      'stress': {
        'iterations': 1,
        'cpuThreshold': 0.95,
        'memoryThreshold': 0.98,
      },
    };
  }
  
  /// 开发测试配置（快速迭代）
  static Map<String, dynamic> get developmentPreset() {
    return {
      'memory': {
        'iterations': 1,
        'timeout': 15,
      },
      'cpu': {
        'iterations': 1,
        'timeout': 15,
      },
      'network': {
        'iterations': 2,
        'timeout': 10,
      },
    };
  }
}

/// 测试环境配置
class TestEnvironmentConfig {
  /// 开发环境
  static const String development = 'development';
  
  /// 测试环境
  static const String testing = 'testing';
  
  /// 生产环境
  static const String production = 'production';
  
  /// 根据环境获取配置
  static Map<String, dynamic> getConfigForEnvironment(String environment) {
    switch (environment.toLowerCase()) {
      case development:
        return PerformanceTestPresets.developmentPreset;
      case testing:
        return PerformanceTestPresets.quickTestPreset;
      case production:
        return PerformanceTestPresets.fullTestPreset;
      default:
        return PerformanceTestPresets.quickTestPreset;
    }
  }
  
  /// 自动检测环境
  static String detectEnvironment() {
    // 这里可以根据实际需求检测当前环境
    // 比如检查环境变量、配置文件等
    
    final env = Platform.environment;
    
    if (env.containsKey('PERFORMANCE_TEST_ENV')) {
      return env['PERFORMANCE_TEST_ENV']!;
    }
    
    // 默认返回开发环境
    return development;
  }
}

/// 平台相关配置
class PlatformConfig {
  /// 检查是否为移动平台
  static bool get isMobile {
    // 这里可以根据实际的平台检测逻辑来判断
    return false; // 在服务器端运行
  }
  
  /// 检查是否为桌面平台
  static bool get isDesktop {
    return !isMobile;
  }
  
  /// 获取平台特定的配置
  static Map<String, dynamic> getPlatformSpecificConfig() {
    if (isMobile) {
      return {
        'battery': {
          'enabled': true,
          'testDuration': 60, // 1分钟
        },
        'memory': {
          'allocationSize': 512 * 1024, // 512KB
        },
      };
    } else {
      return {
        'battery': {
          'enabled': false, // 桌面平台不需要电池测试
        },
        'memory': {
          'allocationSize': 2 * 1024 * 1024, // 2MB
        },
      };
    }
  }
}