/// 性能测试和压力测试套件
/// 
/// 这是一个全面的性能测试套件，提供了多种测试类型和详细报告功能。
/// 
/// ## 功能特性
/// 
/// - ✅ 内存测试：内存使用监控、内存泄漏检测、内存分配性能
/// - ✅ CPU测试：CPU使用率监控、性能瓶颈分析、多核处理器性能
/// - ✅ 电池测试：电池消耗监控、续航能力测试、电源优化建议
/// - ✅ 网络测试：网络请求性能、缓存效果分析、带宽利用率
/// - ✅ 并发测试：多线程性能、并发处理能力、线程池性能
/// - ✅ 压力测试：极限负载测试、系统稳定性验证、故障恢复测试
/// - ✅ 性能报告：详细性能分析、优化建议生成、历史数据对比
/// 
/// ## 使用方法
/// 
/// ```dart
/// import 'package:performance_test/performance_test.dart';
/// 
/// void main() async {
///   // 创建性能测试实例
///   final performanceTest = PerformanceTestSuite();
///   
///   // 运行所有测试
///   final result = await performanceTest.runAllTests();
///   
///   // 检查结果
///   print('测试成功率: ${result.successRate * 100}%');
/// }
/// ```
/// 
/// ## 快速开始
/// 
/// 1. 运行所有测试：
/// ```dart
/// final result = await performanceTest.runAllTests();
/// ```
/// 
/// 2. 运行快速测试：
/// ```dart
/// final result = await performanceTest.runQuickTest();
/// ```
/// 
/// 3. 运行单个测试：
/// ```dart
/// final result = await performanceTest.runTestType(TestType.memory);
/// ```
/// 
/// 4. 获取测试结果：
/// ```dart
/// final results = performanceTest.getTestResults();
/// for (final result in results) {
///   print('${result.testName}: ${result.passed ? "通过" : "失败"}');
/// }
/// ```
/// 
/// ## 配置选项
/// 
/// 可以通过 `TestConfig` 类配置测试参数：
/// 
/// ```dart
/// // 自定义测试时长
/// TestConfig.defaultTestDuration = 60000; // 60秒
/// 
/// // 自定义内存阈值
/// TestConfig.memoryThreshold = 0.9; // 90%
/// ```
/// 
/// ## 报告生成
/// 
/// 测试完成后会自动生成多种格式的报告：
/// 
/// - HTML 报告：包含图表和详细分析
/// - JSON 报告：机器可读的详细数据
/// - CSV 报告：表格格式的原始数据
/// - PDF 报告：便于分享的文档格式
/// 
/// ## 示例
/// 
/// 查看 `examples/performance_test_example.dart` 文件获取更多使用示例。
library performance_test;

export 'performance_test_suite.dart';
export 'utils/test_config.dart';
export 'utils/test_utils.dart';
export 'memory/memory_test.dart';
export 'cpu/cpu_test.dart';
export 'battery/battery_test.dart';
export 'network/network_test.dart';
export 'concurrent/concurrent_test.dart';
export 'stress/stress_test.dart';
export 'reports/report_generator.dart';