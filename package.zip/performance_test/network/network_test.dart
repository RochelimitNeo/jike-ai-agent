import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// 网络测试类
/// 用于测试网络请求性能和缓存效果
class NetworkTest {
  static const String _testName = 'Network Test';
  Timer? _monitoringTimer;
  List<Map<String, dynamic>> _networkSnapshots = [];
  List<String> _recommendations = [];
  
  // 网络缓存数据
  final Map<String, dynamic> _cache = {};
  
  // 网络统计数据
  int _totalRequests = 0;
  int _successfulRequests = 0;
  int _failedRequests = 0;
  List<int> _responseTimes = [];
  List<int> _requestSizes = [];
  List<int> _responseSizes = [];

  /// 运行网络测试
  Future<TestResult> runNetworkTest() async {
    final startTime = DateTime.now();
    _recommendations.clear();
    _networkSnapshots.clear();
    _resetStatistics();
    
    try {
      print('Starting Network Test...');
      
      // 1. 基础网络性能测试
      await _testBasicNetworkPerformance();
      
      // 2. 并发请求测试
      await _testConcurrentRequests();
      
      // 3. 缓存效果测试
      await _testCacheEffectiveness();
      
      // 4. 网络错误处理测试
      await _testNetworkErrorHandling();
      
      // 5. 大文件传输测试
      await _testLargeFileTransfer();
      
      // 6. 网络带宽测试
      await _testBandwidthUtilization();
      
      final endTime = DateTime.now();
      final metrics = _analyzeNetworkResults();
      final passed = _evaluateNetworkTest(metrics);
      
      // 生成优化建议
      _generateNetworkRecommendations(metrics);
      
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: passed,
        metrics: metrics,
        recommendations: _recommendations,
      );
      
    } catch (e) {
      final endTime = DateTime.now();
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: false,
        metrics: {},
        errorMessage: e.toString(),
        recommendations: _recommendations,
      );
    } finally {
      _monitoringTimer?.cancel();
    }
  }

  /// 测试基础网络性能
  Future<void> _testBasicNetworkPerformance() async {
    print('Testing basic network performance...');
    
    final results = <Map<String, dynamic>>[];
    
    // 测试不同类型的请求
    final testCases = [
      {'type': 'GET', 'endpoint': '/api/status', 'size': 1024},
      {'type': 'POST', 'endpoint': '/api/data', 'size': 2048},
      {'type': 'PUT', 'endpoint': '/api/update', 'size': 3072},
      {'type': 'DELETE', 'endpoint': '/api/delete', 'size': 512},
    ];
    
    for (int i = 0; i < 10; i++) {
      for (final testCase in testCases) {
        final startTime = DateTime.now();
        
        try {
          final result = await _simulateHttpRequest(
            method: testCase['type'] as String,
            endpoint: testCase['endpoint'] as String,
            size: testCase['size'] as int,
            shouldFail: false,
          );
          
          final endTime = DateTime.now();
          final responseTime = endTime.difference(startTime).inMilliseconds;
          
          results.add({
            'testCase': testCase,
            'startTime': startTime.toIso8601String(),
            'endTime': endTime.toIso8601String(),
            'responseTime': responseTime,
            'success': true,
            'result': result,
            'timestamp': DateTime.now().toIso8601String(),
          });
          
          _recordSuccess(responseTime, testCase['size'] as int, result['responseSize'] as int);
          
        } catch (e) {
          final endTime = DateTime.now();
          final responseTime = endTime.difference(startTime).inMilliseconds;
          
          results.add({
            'testCase': testCase,
            'startTime': startTime.toIso8601String(),
            'endTime': endTime.toIso8601String(),
            'responseTime': responseTime,
            'success': false,
            'error': e.toString(),
            'timestamp': DateTime.now().toIso8601String(),
          });
          
          _recordFailure(responseTime, testCase['size'] as int);
        }
      }
      
      await TestUtils.delay(100); // 避免请求过于频繁
    }
    
    _networkSnapshots.add({
      'type': 'basic_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试并发请求
  Future<void> _testConcurrentRequests() async {
    print('Testing concurrent requests...');
    
    final concurrentLevels = [5, 10, 20, 50];
    final results = <Map<String, dynamic>>[];
    
    for (final level in concurrentLevels) {
      final startTime = DateTime.now();
      
      // 创建并发请求
      final requests = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < level; i++) {
        requests.add(_simulateHttpRequest(
          method: 'GET',
          endpoint: '/api/concurrent/test/$i',
          size: 1024,
          shouldFail: false,
        ));
      }
      
      try {
        final responseResults = await Future.wait(requests);
        final endTime = DateTime.now();
        final totalTime = endTime.difference(startTime).inMilliseconds;
        
        final responseTimes = responseResults.map((r) => r['responseTime'] as int).toList();
        final avgResponseTime = responseTimes.isNotEmpty 
            ? responseTimes.reduce((a, b) => a + b) / responseTimes.length 
            : 0;
        
        results.add({
          'concurrentLevel': level,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'totalTime': totalTime,
          'successfulRequests': responseResults.length,
          'averageResponseTime': avgResponseTime,
          'throughput': level / (totalTime / 1000), // 请求/秒
          'success': true,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordSuccess(avgResponseTime, level * 1024, responseResults.length * 2048);
        
      } catch (e) {
        final endTime = DateTime.now();
        final totalTime = endTime.difference(startTime).inMilliseconds;
        
        results.add({
          'concurrentLevel': level,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'totalTime': totalTime,
          'successfulRequests': 0,
          'error': e.toString(),
          'success': false,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordFailure(totalTime, level * 1024);
      }
    }
    
    _networkSnapshots.add({
      'type': 'concurrent_requests',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试缓存效果
  Future<void> _testCacheEffectiveness() async {
    print('Testing cache effectiveness...');
    
    final cacheTests = <Map<String, dynamic>>[];
    
    // 测试数据
    final testData = {
      'users': TestUtils.generateTestData(100),
      'products': TestUtils.generateTestData(200),
      'settings': TestUtils.generateTestData(50),
    };
    
    // 预填充缓存
    for (final entry in testData.entries) {
      _cache[entry.key] = entry.value;
    }
    
    // 测试有缓存的请求
    final startTimeWithCache = DateTime.now();
    for (int i = 0; i < 20; i++) {
      final startTime = DateTime.now();
      final result = await _simulateCachedRequest('users');
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime).inMilliseconds;
      
      cacheTests.add({
        'type': 'cached',
        'key': 'users',
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'responseTime': responseTime,
        'success': true,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordSuccess(responseTime, 1024, 2048);
    }
    final endTimeWithCache = DateTime.now();
    
    // 清空缓存，测试无缓存的请求
    _cache.clear();
    final startTimeWithoutCache = DateTime.now();
    for (int i = 0; i < 20; i++) {
      final startTime = DateTime.now();
      final result = await _simulateCachedRequest('users');
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime).inMilliseconds;
      
      cacheTests.add({
        'type': 'uncached',
        'key': 'users',
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'responseTime': responseTime,
        'success': true,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordSuccess(responseTime, 1024, 2048);
    }
    final endTimeWithoutCache = DateTime.now();
    
    // 计算缓存效果
    final cachedTimes = cacheTests
        .where((t) => t['type'] == 'cached')
        .map((t) => t['responseTime'] as int)
        .toList();
    final uncachedTimes = cacheTests
        .where((t) => t['type'] == 'uncached')
        .map((t) => t['responseTime'] as int)
        .toList();
    
    final avgCachedTime = cachedTimes.isNotEmpty 
        ? cachedTimes.reduce((a, b) => a + b) / cachedTimes.length 
        : 0;
    final avgUncachedTime = uncachedTimes.isNotEmpty 
        ? uncachedTimes.reduce((a, b) => a + b) / uncachedTimes.length 
        : 0;
    
    final cacheImprovement = avgUncachedTime > 0 
        ? ((avgUncachedTime - avgCachedTime) / avgUncachedTime) * 100 
        : 0;
    
    _networkSnapshots.add({
      'type': 'cache_effectiveness',
      'results': cacheTests,
      'cacheImprovement': cacheImprovement,
      'averageCachedTime': avgCachedTime,
      'averageUncachedTime': avgUncachedTime,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试网络错误处理
  Future<void> _testNetworkErrorHandling() async {
    print('Testing network error handling...');
    
    final errorTests = <Map<String, dynamic>>[];
    
    // 测试不同类型的错误
    final errorTypes = [
      {'type': 'timeout', 'failRate': 0.2, 'delay': 6000},
      {'type': 'server_error', 'failRate': 0.1, 'delay': 1000},
      {'type': 'connection_lost', 'failRate': 0.05, 'delay': 500},
      {'type': 'invalid_response', 'failRate': 0.15, 'delay': 2000},
    ];
    
    for (final errorType in errorTypes) {
      final startTime = DateTime.now();
      
      final requests = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < 20; i++) {
        requests.add(_simulateHttpRequest(
          method: 'GET',
          endpoint: '/api/error/test/${errorType['type']}',
          size: 1024,
          shouldFail: true,
          errorType: errorType['type'] as String,
          delay: errorType['delay'] as int,
        ));
      }
      
      final results = await Future.wait(requests);
      final endTime = DateTime.now();
      
      final successfulCount = results.where((r) => r['success'] == true).length;
      final failedCount = results.length - successfulCount;
      final errorRate = failedCount / results.length;
      
      errorTests.add({
        'errorType': errorType['type'],
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'totalRequests': results.length,
        'successfulRequests': successfulCount,
        'failedRequests': failedCount,
        'errorRate': errorRate,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      // 记录统计数据
      for (final result in results) {
        if (result['success'] == true) {
          _recordSuccess(result['responseTime'] as int, 1024, 2048);
        } else {
          _recordFailure(result['responseTime'] as int, 1024);
        }
      }
    }
    
    _networkSnapshots.add({
      'type': 'error_handling',
      'results': errorTests,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试大文件传输
  Future<void> _testLargeFileTransfer() async {
    print('Testing large file transfer...');
    
    final fileSizes = [1024, 10240, 102400, 1048576]; // 1KB, 10KB, 100KB, 1MB
    final results = <Map<String, dynamic>>[];
    
    for (final size in fileSizes) {
      final startTime = DateTime.now();
      
      try {
        final result = await _simulateFileTransfer(size);
        final endTime = DateTime.now();
        final transferTime = endTime.difference(startTime).inMilliseconds;
        final throughput = size / (transferTime / 1000); // 字节/秒
        
        results.add({
          'fileSize': size,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'transferTime': transferTime,
          'throughput': throughput,
          'success': true,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordSuccess(transferTime, size, size);
        
      } catch (e) {
        final endTime = DateTime.now();
        final transferTime = endTime.difference(startTime).inMilliseconds;
        
        results.add({
          'fileSize': size,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'transferTime': transferTime,
          'error': e.toString(),
          'success': false,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordFailure(transferTime, size);
      }
    }
    
    _networkSnapshots.add({
      'type': 'large_file_transfer',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试网络带宽利用
  Future<void> _testBandwidthUtilization() async {
    print('Testing bandwidth utilization...');
    
    final utilizationTests = <Map<String, dynamic>>[];
    
    // 测试不同的数据传输模式
    final transferModes = [
      {'name': 'burst', 'pattern': 'burst'},
      {'name': 'continuous', 'pattern': 'continuous'},
      {'name': 'chunked', 'pattern': 'chunked'},
    ];
    
    for (final mode in transferModes) {
      final startTime = DateTime.now();
      
      try {
        final result = await _simulateBandwidthTest(mode['pattern'] as String);
        final endTime = DateTime.now();
        final testTime = endTime.difference(startTime).inMilliseconds;
        
        utilizationTests.add({
          'transferMode': mode['name'],
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'testTime': testTime,
          'totalBytes': result['totalBytes'] as int,
          'averageThroughput': result['averageThroughput'] as double,
          'peakThroughput': result['peakThroughput'] as double,
          'efficiency': result['efficiency'] as double,
          'success': true,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordSuccess(testTime, result['totalBytes'] as int, result['totalBytes'] as int);
        
      } catch (e) {
        final endTime = DateTime.now();
        final testTime = endTime.difference(startTime).inMilliseconds;
        
        utilizationTests.add({
          'transferMode': mode['name'],
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'testTime': testTime,
          'error': e.toString(),
          'success': false,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordFailure(testTime, 1024);
      }
    }
    
    _networkSnapshots.add({
      'type': 'bandwidth_utilization',
      'results': utilizationTests,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 模拟HTTP请求
  Future<Map<String, dynamic>> _simulateHttpRequest({
    required String method,
    required String endpoint,
    required int size,
    required bool shouldFail,
    String? errorType,
    int delay = 1000,
  }) async {
    final startTime = DateTime.now();
    
    // 模拟网络延迟
    await TestUtils.delay(delay + (100 - Random().nextInt(200)));
    
    final endTime = DateTime.now();
    final responseTime = endTime.difference(startTime).inMilliseconds;
    
    if (shouldFail && Random().nextDouble() < 0.1) {
      throw Exception('Simulated $errorType error');
    }
    
    return {
      'method': method,
      'endpoint': endpoint,
      'responseTime': responseTime,
      'requestSize': size,
      'responseSize': size + Random().nextInt(1024),
      'statusCode': 200,
      'success': true,
    };
  }

  /// 模拟缓存请求
  Future<Map<String, dynamic>> _simulateCachedRequest(String key) async {
    final startTime = DateTime.now();
    
    // 检查缓存
    if (_cache.containsKey(key)) {
      // 缓存命中
      await TestUtils.delay(10 + Random().nextInt(20)); // 模拟快速缓存响应
    } else {
      // 缓存未命中，需要模拟网络请求
      await TestUtils.delay(100 + Random().nextInt(100));
      // 重新填充缓存
      _cache[key] = TestUtils.generateTestData(100);
    }
    
    final endTime = DateTime.now();
    final responseTime = endTime.difference(startTime).inMilliseconds;
    
    return {
      'cached': _cache.containsKey(key),
      'key': key,
      'responseTime': responseTime,
      'dataSize': 2048,
      'success': true,
    };
  }

  /// 模拟文件传输
  Future<Map<String, dynamic>> _simulateFileTransfer(int fileSize) async {
    final startTime = DateTime.now();
    
    // 模拟文件传输
    final chunks = (fileSize / 1024).ceil();
    for (int i = 0; i < chunks; i++) {
      await TestUtils.delay(10 + Random().nextInt(20));
    }
    
    final endTime = DateTime.now();
    final transferTime = endTime.difference(startTime).inMilliseconds;
    
    return {
      'fileSize': fileSize,
      'transferTime': transferTime,
      'throughput': fileSize / (transferTime / 1000),
      'success': true,
    };
  }

  /// 模拟带宽测试
  Future<Map<String, dynamic>> _simulateBandwidthTest(String pattern) async {
    final startTime = DateTime.now();
    int totalBytes = 0;
    int peakBytes = 0;
    List<int> throughputSamples = [];
    
    switch (pattern) {
      case 'burst':
        // 突发传输模式
        for (int i = 0; i < 10; i++) {
          final sampleStart = DateTime.now();
          final bytesTransferred = 10240 + Random().nextInt(10240);
          totalBytes += bytesTransferred;
          peakBytes = bytesTransferred > peakBytes ? bytesTransferred : peakBytes;
          await TestUtils.delay(100);
          final sampleEnd = DateTime.now();
          throughputSamples.add(bytesTransferred * 10); // 转换为字节/秒
        }
        break;
        
      case 'continuous':
        // 连续传输模式
        for (int i = 0; i < 50; i++) {
          final bytesTransferred = 1024 + Random().nextInt(512);
          totalBytes += bytesTransferred;
          peakBytes = bytesTransferred > peakBytes ? bytesTransferred : peakBytes;
          await TestUtils.delay(20);
          throughputSamples.add(bytesTransferred * 50); // 转换为字节/秒
        }
        break;
        
      case 'chunked':
        // 分块传输模式
        for (int i = 0; i < 20; i++) {
          final chunkSize = 2048 + Random().nextInt(1024);
          await TestUtils.delay(50);
          totalBytes += chunkSize;
          peakBytes = chunkSize > peakBytes ? chunkSize : peakBytes;
          throughputSamples.add(chunkSize * 20); // 转换为字节/秒
        }
        break;
    }
    
    final endTime = DateTime.now();
    final testDuration = endTime.difference(startTime).inMilliseconds / 1000;
    
    final averageThroughput = totalBytes / testDuration;
    final peakThroughput = throughputSamples.isNotEmpty 
        ? throughputSamples.reduce((a, b) => a > b ? a : b) / 1000.0 
        : 0;
    final efficiency = peakThroughput > 0 ? (averageThroughput / peakThroughput) * 100 : 0;
    
    return {
      'totalBytes': totalBytes,
      'averageThroughput': averageThroughput,
      'peakThroughput': peakThroughput,
      'efficiency': efficiency,
      'pattern': pattern,
    };
  }

  /// 重置统计数据
  void _resetStatistics() {
    _totalRequests = 0;
    _successfulRequests = 0;
    _failedRequests = 0;
    _responseTimes.clear();
    _requestSizes.clear();
    _responseSizes.clear();
  }

  /// 记录成功请求
  void _recordSuccess(int responseTime, int requestSize, int responseSize) {
    _totalRequests++;
    _successfulRequests++;
    _responseTimes.add(responseTime);
    _requestSizes.add(requestSize);
    _responseSizes.add(responseSize);
  }

  /// 记录失败请求
  void _recordFailure(int responseTime, int requestSize) {
    _totalRequests++;
    _failedRequests++;
    _responseTimes.add(responseTime);
    _requestSizes.add(requestSize);
  }

  /// 启动网络监控
  void startNetworkMonitoring() {
    _monitoringTimer = Timer.periodic(
      Duration(milliseconds: TestConfig.sampleInterval),
      (timer) {
        // 收集网络监控数据
        _networkSnapshots.add({
          'type': 'monitoring',
          'timestamp': DateTime.now().toIso8601String(),
          'totalRequests': _totalRequests,
          'successRate': _totalRequests > 0 ? _successfulRequests / _totalRequests : 0,
          'averageResponseTime': _responseTimes.isNotEmpty 
              ? _responseTimes.reduce((a, b) => a + b) / _responseTimes.length 
              : 0,
        });
      },
    );
  }

  /// 停止网络监控
  void stopNetworkMonitoring() {
    _monitoringTimer?.cancel();
  }

  /// 分析网络测试结果
  Map<String, dynamic> _analyzeNetworkResults() {
    final analysis = {
      'snapshots': _networkSnapshots,
      'statistics': {
        'totalRequests': _totalRequests,
        'successfulRequests': _successfulRequests,
        'failedRequests': _failedRequests,
        'successRate': _totalRequests > 0 ? _successfulRequests / _totalRequests : 0,
        'averageResponseTime': _responseTimes.isNotEmpty 
            ? _responseTimes.reduce((a, b) => a + b) / _responseTimes.length 
            : 0,
        'totalRequestSize': _requestSizes.fold(0, (a, b) => a + b),
        'totalResponseSize': _responseSizes.fold(0, (a, b) => a + b),
      },
      'summary': <String, dynamic>{},
    };
    
    // 分析基础性能
    final basicPerformance = _networkSnapshots
        .where((s) => s['type'] == 'basic_performance')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (basicPerformance.isNotEmpty) {
      final responseTimes = basicPerformance
          .where((r) => r['success'] == true)
          .map((r) => r['responseTime'] as int)
          .toList();
      
      analysis['summary']['basicPerformance'] = {
        'averageResponseTime': responseTimes.isNotEmpty 
            ? responseTimes.reduce((a, b) => a + b) / responseTimes.length 
            : 0,
        'minResponseTime': responseTimes.isNotEmpty ? responseTimes.reduce((a, b) => a < b ? a : b) : 0,
        'maxResponseTime': responseTimes.isNotEmpty ? responseTimes.reduce((a, b) => a > b ? a : b) : 0,
        'successRate': basicPerformance.where((r) => r['success'] == true).length / basicPerformance.length,
      };
    }
    
    // 分析缓存效果
    final cacheTests = _networkSnapshots
        .where((s) => s['type'] == 'cache_effectiveness')
        .toList();
    
    if (cacheTests.isNotEmpty) {
      final cacheTest = cacheTests.first;
      analysis['summary']['cacheEffectiveness'] = {
        'cacheImprovement': cacheTest['cacheImprovement'] as double,
        'averageCachedTime': cacheTest['averageCachedTime'] as double,
        'averageUncachedTime': cacheTest['averageUncachedTime'] as double,
      };
    }
    
    return analysis;
  }

  /// 评估网络测试结果
  bool _evaluateNetworkTest(Map<String, dynamic> metrics) {
    final statistics = metrics['statistics'] as Map<String, dynamic>;
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    // 检查成功率
    final successRate = statistics['successRate'] as double;
    if (successRate < 0.95) { // 成功率低于95%
      _recommendations.add('网络请求成功率较低：${(successRate * 100).toStringAsFixed(1)}%，建议检查网络连接和服务器状态');
      return false;
    }
    
    // 检查平均响应时间
    final basicPerformance = summary['basicPerformance'] as Map<String, dynamic>? ?? {};
    final avgResponseTime = basicPerformance['averageResponseTime'] as double? ?? 0;
    
    if (avgResponseTime > 1000) { // 平均响应时间超过1秒
      _recommendations.add('网络响应时间过长：${avgResponseTime.toStringAsFixed(0)}ms，建议优化网络请求和服务器性能');
      return false;
    }
    
    // 检查缓存效果
    final cacheEffectiveness = summary['cacheEffectiveness'] as Map<String, dynamic>? ?? {};
    final cacheImprovement = cacheEffectiveness['cacheImprovement'] as double? ?? 0;
    
    if (cacheImprovement < 50) { // 缓存改进小于50%
      _recommendations.add('缓存效果不明显：${cacheImprovement.toStringAsFixed(1)}%，建议优化缓存策略');
    }
    
    return true;
  }

  /// 生成网络优化建议
  void _generateNetworkRecommendations(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    final statistics = metrics['statistics'] as Map<String, dynamic>;
    
    final successRate = statistics['successRate'] as double;
    final avgResponseTime = summary['basicPerformance']['averageResponseTime'] as double? ?? 0;
    
    if (successRate < 0.98) {
      _recommendations.add('实现网络重试机制和超时处理，提高请求成功率');
    }
    
    if (avgResponseTime > 500) {
      _recommendations.add('优化API响应时间，使用数据库查询优化和缓存策略');
    }
    
    _recommendations.add('使用HTTP/2和压缩技术减少数据传输量');
    _recommendations.add('实现智能缓存策略，根据数据特性设置不同的缓存时间');
    _recommendations.add('使用CDN加速静态资源加载');
    _recommendations.add('实施网络请求合并，减少HTTP连接开销');
    _recommendations.add('监控网络质量，根据网络状况调整请求策略');
  }
}