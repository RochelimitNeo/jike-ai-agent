import 'dart:async';
import 'dart:developer';
import '../utils/test_config.dart';
import '../utils/test_utils.dart';
import '../memory/memory_test.dart';
import '../cpu/cpu_test.dart';
import '../battery/battery_test.dart';
import '../network/network_test.dart';
import '../concurrent/concurrent_test.dart';
import '../stress/stress_test.dart';
import '../reports/report_generator.dart';

/// 性能测试套件主类
/// 整合所有性能测试模块，提供统一的测试接口
class PerformanceTestSuite {
  late final MemoryTest _memoryTest;
  late final CpuTest _cpuTest;
  late final BatteryTest _batteryTest;
  late final NetworkTest _networkTest;
  late final ConcurrentTest _concurrentTest;
  late final StressTest _stressTest;
  late final ReportGenerator _reportGenerator;
  
  bool _isRunning = false;
  final List<TestResult> _testResults = [];

  /// 构造函数
  PerformanceTestSuite() {
    _initializeTests();
  }

  /// 初始化测试模块
  void _initializeTests() {
    _memoryTest = MemoryTest();
    _cpuTest = CpuTest();
    _batteryTest = BatteryTest();
    _networkTest = NetworkTest();
    _concurrentTest = ConcurrentTest();
    _stressTest = StressTest();
    _reportGenerator = ReportGenerator();
  }

  /// 运行所有测试
  Future<TestSuiteResult> runAllTests({
    List<TestType> testTypes = const [TestType.all],
    bool generateReports = true,
    String? customReportName,
  }) async {
    if (_isRunning) {
      throw Exception('测试正在运行中，请等待当前测试完成');
    }

    _isRunning = true;
    _testResults.clear();

    print('🚀 开始运行性能测试套件...');
    print('测试类型: ${testTypes.map((t) => t.name).join(', ')}');
    print('生成报告: $generateReports');
    print('=' * 60);

    final suiteStartTime = DateTime.now();

    try {
      // 确定要运行的测试
      final testsToRun = _determineTestsToRun(testTypes);

      // 运行各个测试
      for (final testType in testsToRun) {
        print('\n📊 正在运行: ${_getTestDisplayName(testType)}');
        
        final result = await _runTest(testType);
        _testResults.add(result);
        
        print('✅ ${result.testName} 完成 - 状态: ${result.passed ? "通过" : "失败"}');
        if (!result.passed && result.errorMessage != null) {
          print('❌ 错误: ${result.errorMessage}');
        }
        
        // 测试间隔
        await TestUtils.delay(1000);
      }

      final suiteEndTime = DateTime.now();
      final suiteDuration = suiteEndTime.difference(suiteStartTime);

      print('\n' + '=' * 60);
      print('🎉 性能测试套件执行完成!');
      print('总耗时: ${TestUtils.formatDuration(suiteDuration)}');
      print('测试总数: ${_testResults.length}');
      print('通过测试: ${_testResults.where((r) => r.passed).length}');
      print('失败测试: ${_testResults.where((r) => !r.passed).length}');
      print('成功率: ${(_testResults.where((r) => r.passed).length / _testResults.length * 100).toStringAsFixed(1)}%');

      // 生成报告
      if (generateReports) {
        print('\n📈 正在生成性能报告...');
        await _reportGenerator.generateComprehensiveReport(_testResults);
        print('✅ 性能报告生成完成!');
      }

      return TestSuiteResult(
        startTime: suiteStartTime,
        endTime: suiteEndTime,
        testResults: _testResults,
        passed: _testResults.isNotEmpty && _testResults.every((r) => r.passed),
      );

    } catch (e) {
      print('❌ 测试执行过程中发生错误: $e');
      rethrow;
    } finally {
      _isRunning = false;
      TestUtils.cleanup();
    }
  }

  /// 运行单个测试
  Future<TestResult> _runTest(TestType testType) async {
    switch (testType) {
      case TestType.memory:
        return await _memoryTest.runMemoryTest();
      case TestType.cpu:
        return await _cpuTest.runCpuTest();
      case TestType.battery:
        return await _batteryTest.runBatteryTest();
      case TestType.network:
        return await _networkTest.runNetworkTest();
      case TestType.concurrent:
        return await _concurrentTest.runConcurrentTest();
      case TestType.stress:
        return await _stressTest.runStressTest();
      default:
        throw Exception('未知的测试类型: $testType');
    }
  }

  /// 确定要运行的测试
  List<TestType> _determineTestsToRun(List<TestType> testTypes) {
    if (testTypes.contains(TestType.all)) {
      return [
        TestType.memory,
        TestType.cpu,
        TestType.battery,
        TestType.network,
        TestType.concurrent,
        TestType.stress,
      ];
    }
    return testTypes;
  }

  /// 获取测试显示名称
  String _getTestDisplayName(TestType testType) {
    switch (testType) {
      case TestType.memory:
        return '内存测试';
      case TestType.cpu:
        return 'CPU测试';
      case TestType.battery:
        return '电池测试';
      case TestType.network:
        return '网络测试';
      case TestType.concurrent:
        return '并发测试';
      case TestType.stress:
        return '压力测试';
      default:
        return '未知测试';
    }
  }

  /// 运行快速性能测试（仅运行基础测试）
  Future<TestSuiteResult> runQuickTest() async {
    return await runAllTests(
      testTypes: [
        TestType.memory,
        TestType.cpu,
        TestType.network,
      ],
      generateReports: true,
    );
  }

  /// 运行特定类型的测试
  Future<TestResult> runTestType(TestType testType) async {
    return await _runTest(testType);
  }

  /// 获取测试结果
  List<TestResult> getTestResults() {
    return List.unmodifiable(_testResults);
  }

  /// 获取特定测试类型的结果
  TestResult? getTestResult(TestType testType) {
    return _testResults.firstWhere(
      (result) => result.testName.contains(_getTestDisplayName(testType)),
      orElse: () => null as TestResult,
    );
  }

  /// 检查测试是否正在运行
  bool get isRunning => _isRunning;

  /// 生成自定义报告
  Future<void> generateCustomReport(String name) async {
    if (_testResults.isEmpty) {
      throw Exception('没有可用的测试结果，请先运行测试');
    }
    await _reportGenerator.generateComprehensiveReport(_testResults);
  }

  /// 导出测试结果
  Future<Map<String, dynamic>> exportTestResults() async {
    return {
      'exportInfo': {
        'exportedAt': DateTime.now().toIso8601String(),
        'totalTests': _testResults.length,
        'version': '1.0.0',
      },
      'summary': _calculateSuiteSummary(),
      'testResults': _testResults.map((result) => result.toJson()).toList(),
      'recommendations': _collectAllRecommendations(),
    };
  }

  /// 计算测试套件总结
  Map<String, dynamic> _calculateSuiteSummary() {
    final totalTests = _testResults.length;
    final passedTests = _testResults.where((result) => result.passed).length;
    final failedTests = totalTests - passedTests;
    final successRate = totalTests > 0 ? passedTests / totalTests : 0;

    final totalDuration = _testResults.fold<int>(
      0,
      (sum, result) => sum + result.endTime.difference(result.startTime).inMilliseconds,
    );

    return {
      'totalTests': totalTests,
      'passedTests': passedTests,
      'failedTests': failedTests,
      'successRate': successRate,
      'totalDuration': totalDuration,
      'averageTestDuration': totalTests > 0 ? totalDuration / totalTests : 0,
    };
  }

  /// 收集所有建议
  List<String> _collectAllRecommendations() {
    final allRecommendations = <String>[];
    for (final result in _testResults) {
      allRecommendations.addAll(result.recommendations);
    }
    return allRecommendations.toSet().toList();
  }

  /// 获取性能基线
  Future<Map<String, dynamic>> getPerformanceBaseline() async {
    // 运行基线测试
    await runAllTests(generateReports: false);
    
    final baseline = <String, dynamic>{};
    
    // 收集各个测试的关键指标
    for (final result in _testResults) {
      if (result.metrics.isNotEmpty) {
        baseline[result.testName] = result.metrics;
      }
    }
    
    baseline['baselineDate'] = DateTime.now().toIso8601String();
    baseline['testConditions'] = {
      'platform': 'unknown',
      'dartVersion': 'unknown',
    };
    
    return baseline;
  }

  /// 与基线比较性能
  Future<Map<String, dynamic>> compareWithBaseline(Map<String, dynamic> baseline) async {
    // 运行当前测试
    await runAllTests(generateReports: false);
    
    // 生成比较报告
    await _reportGenerator.generateBenchmarkComparison(
      await exportTestResults(),
      baseline,
    );
    
    // 返回比较结果
    return {
      'comparisonDate': DateTime.now().toIso8601String(),
      'baselineDate': baseline['baselineDate'],
      'currentResults': _testResults.map((r) => r.metrics).toList(),
      'improved': <String>[],
      'degraded': <String>[],
      'stable': <String>[],
    };
  }

  /// 清理资源
  void dispose() {
    _memoryTest = null as MemoryTest;
    _cpuTest = null as CpuTest;
    _batteryTest = null as BatteryTest;
    _networkTest = null as NetworkTest;
    _concurrentTest = null as ConcurrentTest;
    _stressTest = null as StressTest;
    _reportGenerator = null as ReportGenerator;
  }
}

/// 测试套件结果类
class TestSuiteResult {
  final DateTime startTime;
  final DateTime endTime;
  final List<TestResult> testResults;
  final bool passed;

  TestSuiteResult({
    required this.startTime,
    required this.endTime,
    required this.testResults,
    required this.passed,
  });

  Duration get duration => endTime.difference(startTime);
  
  int get totalTests => testResults.length;
  
  int get passedTests => testResults.where((r) => r.passed).length;
  
  int get failedTests => testResults.where((r) => !r.passed).length;
  
  double get successRate => totalTests > 0 ? passedTests / totalTests : 0;
  
  Map<String, dynamic> toJson() {
    return {
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': duration.inMilliseconds,
      'totalTests': totalTests,
      'passedTests': passedTests,
      'failedTests': failedTests,
      'successRate': successRate,
      'passed': passed,
      'testResults': testResults.map((r) => r.toJson()).toList(),
    };
  }
}