import 'dart:async';
import 'dart:developer';
import 'dart:math';
import 'dart:isolate';
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// 并发测试类
/// 用于测试多线程和并发处理能力
class ConcurrentTest {
  static const String _testName = 'Concurrent Test';
  Timer? _monitoringTimer;
  List<Map<String, dynamic>> _concurrentSnapshots = [];
  List<String> _recommendations = [];
  
  // 并发统计数据
  int _totalTasks = 0;
  int _completedTasks = 0;
  int _failedTasks = 0;
  List<int> _taskDurations = [];
  List<String> _taskResults = [];

  /// 运行并发测试
  Future<TestResult> runConcurrentTest() async {
    final startTime = DateTime.now();
    _recommendations.clear();
    _concurrentSnapshots.clear();
    _resetStatistics();
    
    try {
      print('Starting Concurrent Test...');
      
      // 1. 基础并发性能测试
      await _testBasicConcurrency();
      
      // 2. 线程池性能测试
      await _testThreadPoolPerformance();
      
      // 3. 同步机制测试
      await _testSynchronizationMechanisms();
      
      // 4. 异步编程测试
      await _testAsyncProgramming();
      
      // 5. 负载均衡测试
      await _testLoadBalancing();
      
      // 6. 并发安全性测试
      await _testConcurrencySafety();
      
      final endTime = DateTime.now();
      final metrics = _analyzeConcurrentResults();
      final passed = _evaluateConcurrentTest(metrics);
      
      // 生成优化建议
      _generateConcurrentRecommendations(metrics);
      
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: passed,
        metrics: metrics,
        recommendations: _recommendations,
      );
      
    } catch (e) {
      final endTime = DateTime.now();
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: false,
        metrics: {},
        errorMessage: e.toString(),
        recommendations: _recommendations,
      );
    } finally {
      _monitoringTimer?.cancel();
    }
  }

  /// 测试基础并发性能
  Future<void> _testBasicConcurrency() async {
    print('Testing basic concurrency performance...');
    
    final threadCounts = [1, 2, 4, 8, 16];
    final results = <Map<String, dynamic>>[];
    
    for (final threadCount in threadCounts) {
      final startTime = DateTime.now();
      
      // 创建并发任务
      final tasks = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < threadCount * 10; i++) {
        tasks.add(_executeConcurrentTask(i, 1000)); // 每个任务1000ms
      }
      
      final taskResults = await Future.wait(tasks);
      final endTime = DateTime.now();
      final totalDuration = endTime.difference(startTime).inMilliseconds;
      
      final successfulTasks = taskResults.where((r) => r['success'] == true).length;
      final failedTasks = taskResults.length - successfulTasks;
      final taskDurations = taskResults.map((r) => r['duration'] as int).toList();
      final avgDuration = taskDurations.isNotEmpty 
          ? taskDurations.reduce((a, b) => a + b) / taskDurations.length 
          : 0;
      
      results.add({
        'threadCount': threadCount,
        'taskCount': tasks.length,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'totalDuration': totalDuration,
        'successfulTasks': successfulTasks,
        'failedTasks': failedTasks,
        'averageTaskDuration': avgDuration,
        'throughput': tasks.length / (totalDuration / 1000), // 任务/秒
        'efficiency': (tasks.length / threadCount) / (totalDuration / 1000), // 效率
        'taskResults': taskResults,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordConcurrentStats(successfulTasks, failedTasks, taskDurations);
    }
    
    _concurrentSnapshots.add({
      'type': 'basic_concurrency',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试线程池性能
  Future<void> _testThreadPoolPerformance() async {
    print('Testing thread pool performance...');
    
    final poolSizes = [2, 4, 8, 16];
    final taskCounts = [20, 50, 100, 200];
    final results = <Map<String, dynamic>>[];
    
    for (final poolSize in poolSizes) {
      for (final taskCount in taskCounts) {
        final startTime = DateTime.now();
        
        // 创建线程池模拟
        final pool = await _createThreadPool(poolSize);
        final tasks = <Future<Map<String, dynamic>>>[];
        
        // 提交任务到线程池
        for (int i = 0; i < taskCount; i++) {
          tasks.add(_submitTaskToPool(pool, i, 500)); // 每个任务500ms
        }
        
        final taskResults = await Future.wait(tasks);
        final endTime = DateTime.now();
        final totalDuration = endTime.difference(startTime).inMilliseconds;
        
        final successfulTasks = taskResults.where((r) => r['success'] == true).length;
        final failedTasks = taskResults.length - successfulTasks;
        
        // 计算线程池利用率
        final theoreticalMinTime = 500; // 单个任务的最短时间
        final actualTimePerTask = totalDuration / taskCount;
        final utilization = theoreticalMinTime / actualTimePerTask;
        
        results.add({
          'poolSize': poolSize,
          'taskCount': taskCount,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'totalDuration': totalDuration,
          'successfulTasks': successfulTasks,
          'failedTasks': failedTasks,
          'utilization': utilization,
          'throughput': taskCount / (totalDuration / 1000),
          'taskResults': taskResults,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordConcurrentStats(successfulTasks, failedTasks, []);
        
        // 清理线程池
        await _shutdownThreadPool(pool);
        
        await TestUtils.delay(100); // 避免过于频繁的测试
      }
    }
    
    _concurrentSnapshots.add({
      'type': 'thread_pool_performance',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试同步机制
  Future<void> _testSynchronizationMechanisms() async {
    print('Testing synchronization mechanisms...');
    
    final mechanisms = ['lock', 'mutex', 'semaphore', 'atomic'];
    final results = <Map<String, dynamic>>[];
    
    for (final mechanism in mechanisms) {
      final startTime = DateTime.now();
      
      final mechanismResults = await _testSynchronizationMechanism(mechanism);
      final endTime = DateTime.now();
      
      results.add({
        'mechanism': mechanism,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'results': mechanismResults,
        'timestamp': DateTime.now().toIso8601String(),
      });
    }
    
    _concurrentSnapshots.add({
      'type': 'synchronization_mechanisms',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试异步编程
  Future<void> _testAsyncProgramming() async {
    print('Testing async programming...');
    
    final results = <Map<String, dynamic>>[];
    
    // 测试不同类型的异步操作
    final asyncTests = [
      {'name': 'cpu_bound', 'operation': _cpuBoundAsyncTask},
      {'name': 'io_bound', 'operation': _ioBoundAsyncTask},
      {'name': 'mixed', 'operation': _mixedAsyncTask},
    ];
    
    for (final test in asyncTests) {
      final startTime = DateTime.now();
      
      // 执行异步任务
      final taskResults = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < 20; i++) {
        taskResults.add((test['operation'] as Function)(i));
      }
      
      final asyncResults = await Future.wait(taskResults);
      final endTime = DateTime.now();
      
      final durations = asyncResults.map((r) => r['duration'] as int).toList();
      final avgDuration = durations.isNotEmpty 
          ? durations.reduce((a, b) => a + b) / durations.length 
          : 0;
      
      results.add({
        'testType': test['name'],
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'taskCount': taskResults.length,
        'averageDuration': avgDuration,
        'throughput': taskResults.length / (endTime.difference(startTime).inMilliseconds / 1000),
        'asyncResults': asyncResults,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordConcurrentStats(taskResults.length, 0, durations);
    }
    
    _concurrentSnapshots.add({
      'type': 'async_programming',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试负载均衡
  Future<void> _testLoadBalancing() async {
    print('Testing load balancing...');
    
    final workerCounts = [2, 4, 8, 16];
    final taskSizes = [10, 50, 100, 200];
    final results = <Map<String, dynamic>>[];
    
    for (final workerCount in workerCounts) {
      for (final taskSize in taskSizes) {
        final startTime = DateTime.now();
        
        // 创建工作队列
        final workQueue = <Map<String, dynamic>>[];
        for (int i = 0; i < taskSize; i++) {
          workQueue.add({
            'taskId': i,
            'complexity': Random().nextInt(100) + 1, // 1-100的复杂度
            'estimatedTime': Random().nextInt(200) + 50, // 50-250ms估计时间
          });
        }
        
        // 创建工作者
        final workers = <Future<List<Map<String, dynamic>>>>[];
        for (int i = 0; i < workerCount; i++) {
          workers.add(_workerProcess(workQueue, i));
        }
        
        final workerResults = await Future.wait(workers);
        final endTime = DateTime.now();
        final totalDuration = endTime.difference(startTime).inMilliseconds;
        
        // 统计结果
        final allResults = workerResults.expand((r) => r).toList();
        final successfulTasks = allResults.where((r) => r['success'] == true).length;
        final failedTasks = allResults.length - successfulTasks;
        
        // 计算负载均衡度
        final workerDurations = workerResults.map((worker) {
          return worker.isNotEmpty 
              ? worker.map((r) => r['duration'] as int).reduce((a, b) => a + b)
              : 0;
        }).toList();
        
        final avgWorkerDuration = workerDurations.isNotEmpty 
            ? workerDurations.reduce((a, b) => a + b) / workerDurations.length 
            : 0;
        final maxWorkerDuration = workerDurations.isNotEmpty 
            ? workerDurations.reduce((a, b) => a > b ? a : b) 
            : 0;
        final loadBalanceRatio = avgWorkerDuration / maxWorkerDuration;
        
        results.add({
          'workerCount': workerCount,
          'taskSize': taskSize,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'totalDuration': totalDuration,
          'successfulTasks': successfulTasks,
          'failedTasks': failedTasks,
          'loadBalanceRatio': loadBalanceRatio,
          'throughput': taskSize / (totalDuration / 1000),
          'workerDurations': workerDurations,
          'workerResults': workerResults,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordConcurrentStats(successfulTasks, failedTasks, []);
      }
    }
    
    _concurrentSnapshots.add({
      'type': 'load_balancing',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试并发安全性
  Future<void> _testConcurrencySafety() async {
    print('Testing concurrency safety...');
    
    final testCases = [
      {'name': 'counter_race', 'operation': _testCounterRace},
      {'name': 'shared_resource', 'operation': _testSharedResource},
      {'name': 'deadlock', 'operation': _testDeadlock},
    ];
    
    final results = <Map<String, dynamic>>[];
    
    for (final testCase in testCases) {
      final startTime = DateTime.now();
      
      final testResult = await (testCase['operation'] as Function)();
      final endTime = DateTime.now();
      
      results.add({
        'testCase': testCase['name'],
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'result': testResult,
        'timestamp': DateTime.now().toIso8601String(),
      });
    }
    
    _concurrentSnapshots.add({
      'type': 'concurrency_safety',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 执行并发任务
  Future<Map<String, dynamic>> _executeConcurrentTask(int taskId, int duration) async {
    final startTime = DateTime.now();
    
    try {
      // 模拟任务执行
      await TestUtils.delay(duration + Random().nextInt(100) - 50); // 添加随机延迟
      
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': actualDuration,
        'success': true,
        'result': 'Task $taskId completed',
      };
    } catch (e) {
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': actualDuration,
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// 创建线程池模拟
  Future<Map<String, dynamic>> _createThreadPool(int poolSize) async {
    return {
      'size': poolSize,
      'activeWorkers': 0,
      'taskQueue': <Map<String, dynamic>>[],
      'workers': <Future>[],
    };
  }

  /// 提交任务到线程池
  Future<Map<String, dynamic>> _submitTaskToPool(Map<String, dynamic> pool, int taskId, int duration) async {
    final startTime = DateTime.now();
    
    try {
      // 模拟任务执行
      await TestUtils.delay(duration + Random().nextInt(50));
      
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': actualDuration,
        'success': true,
        'result': 'Pool task $taskId completed',
      };
    } catch (e) {
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': actualDuration,
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// 关闭线程池
  Future<void> _shutdownThreadPool(Map<String, dynamic> pool) async {
    // 模拟关闭线程池
    await TestUtils.delay(100);
  }

  /// 测试同步机制
  Future<List<Map<String, dynamic>>> _testSynchronizationMechanism(String mechanism) async {
    final results = <Map<String, dynamic>>[];
    int sharedCounter = 0;
    final threadCount = 10;
    final operationsPerThread = 100;
    
    final tasks = <Future<void>>[];
    for (int i = 0; i < threadCount; i++) {
      tasks.add(() async {
        for (int j = 0; j < operationsPerThread; j++) {
          switch (mechanism) {
            case 'lock':
              // 模拟锁机制
              await TestUtils.delay(1);
              sharedCounter++;
              break;
            case 'mutex':
              // 模拟互斥锁
              await TestUtils.delay(2);
              sharedCounter++;
              break;
            case 'semaphore':
              // 模拟信号量
              await TestUtils.delay(1);
              sharedCounter++;
              break;
            case 'atomic':
              // 模拟原子操作
              await TestUtils.delay(0);
              sharedCounter++;
              break;
          }
        }
      }());
    }
    
    await Future.wait(tasks);
    
    results.add({
      'mechanism': mechanism,
      'expectedValue': threadCount * operationsPerThread,
      'actualValue': sharedCounter,
      'isCorrect': sharedCounter == threadCount * operationsPerThread,
      'threadCount': threadCount,
      'operationsPerThread': operationsPerThread,
    });
    
    return results;
  }

  /// CPU密集型异步任务
  Future<Map<String, dynamic>> _cpuBoundAsyncTask(int taskId) async {
    final startTime = DateTime.now();
    
    // 执行CPU密集型计算
    double result = 0;
    for (int i = 0; i < 10000; i++) {
      result += sqrt(i) * sin(i.toDouble());
    }
    
    final endTime = DateTime.now();
    final duration = endTime.difference(startTime).inMilliseconds;
    
    return {
      'taskId': taskId,
      'type': 'cpu_bound',
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': duration,
      'success': true,
      'result': result,
    };
  }

  /// I/O密集型异步任务
  Future<Map<String, dynamic>> _ioBoundAsyncTask(int taskId) async {
    final startTime = DateTime.now();
    
    // 模拟I/O操作
    await TestUtils.delay(100 + Random().nextInt(200));
    
    final endTime = DateTime.now();
    final duration = endTime.difference(startTime).inMilliseconds;
    
    return {
      'taskId': taskId,
      'type': 'io_bound',
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': duration,
      'success': true,
      'result': 'I/O task $taskId completed',
    };
  }

  /// 混合异步任务
  Future<Map<String, dynamic>> _mixedAsyncTask(int taskId) async {
    final startTime = DateTime.now();
    
    // 混合CPU和I/O操作
    double result = 0;
    for (int i = 0; i < 5000; i++) {
      result += sqrt(i) * sin(i.toDouble());
      if (i % 1000 == 0) {
        await TestUtils.delay(10); // 模拟I/O
      }
    }
    
    final endTime = DateTime.now();
    final duration = endTime.difference(startTime).inMilliseconds;
    
    return {
      'taskId': taskId,
      'type': 'mixed',
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'duration': duration,
      'success': true,
      'result': result,
    };
  }

  /// 工作者处理任务
  Future<List<Map<String, dynamic>>> _workerProcess(List<Map<String, dynamic>> workQueue, int workerId) async {
    final results = <Map<String, dynamic>>[];
    
    while (workQueue.isNotEmpty) {
      final task = workQueue.removeAt(0);
      final startTime = DateTime.now();
      
      try {
        // 模拟任务执行
        final complexity = task['complexity'] as int;
        final estimatedTime = task['estimatedTime'] as int;
        final actualTime = estimatedTime + Random().nextInt(100) - 50;
        
        await TestUtils.delay(actualTime);
        
        final endTime = DateTime.now();
        final duration = endTime.difference(startTime).inMilliseconds;
        
        results.add({
          'workerId': workerId,
          'taskId': task['taskId'],
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'duration': duration,
          'estimatedTime': estimatedTime,
          'actualTime': actualTime,
          'success': true,
        });
        
      } catch (e) {
        final endTime = DateTime.now();
        final duration = endTime.difference(startTime).inMilliseconds;
        
        results.add({
          'workerId': workerId,
          'taskId': task['taskId'],
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'duration': duration,
          'success': false,
          'error': e.toString(),
        });
      }
    }
    
    return results;
  }

  /// 测试计数器竞态条件
  Future<Map<String, dynamic>> _testCounterRace() async {
    int counter = 0;
    final threadCount = 10;
    final incrementsPerThread = 1000;
    
    final tasks = <Future<void>>[];
    for (int i = 0; i < threadCount; i++) {
      tasks.add(() async {
        for (int j = 0; j < incrementsPerThread; j++) {
          counter++; // 非原子操作
        }
      }());
    }
    
    await Future.wait(tasks);
    
    return {
      'testName': 'counter_race',
      'expectedValue': threadCount * incrementsPerThread,
      'actualValue': counter,
      'hasRaceCondition': counter != threadCount * incrementsPerThread,
      'threadCount': threadCount,
      'incrementsPerThread': incrementsPerThread,
    };
  }

  /// 测试共享资源访问
  Future<Map<String, dynamic>> _testSharedResource() async {
    final sharedData = <String>[];
    final threadCount = 5;
    final operationsPerThread = 100;
    
    final tasks = <Future<void>>[];
    for (int i = 0; i < threadCount; i++) {
      tasks.add(() async {
        for (int j = 0; j < operationsPerThread; j++) {
          final data = 'Thread-$i-Operation-$j';
          sharedData.add(data);
          if (j % 10 == 0) {
            await TestUtils.delay(1); // 模拟处理时间
          }
        }
      }());
    }
    
    await Future.wait(tasks);
    
    return {
      'testName': 'shared_resource',
      'expectedOperations': threadCount * operationsPerThread,
      'actualOperations': sharedData.length,
      'threadCount': threadCount,
      'operationsPerThread': operationsPerThread,
    };
  }

  /// 测试死锁
  Future<Map<String, dynamic>> _testDeadlock() async {
    final resourceA = 'ResourceA';
    final resourceB = 'ResourceB';
    bool deadlockOccurred = false;
    
    final tasks = <Future<void>>[];
    
    // 任务1：先获取A，再获取B
    tasks.add(() async {
      // 获取A
      await TestUtils.delay(50);
      // 获取B
      await TestUtils.delay(50);
    }());
    
    // 任务2：先获取B，再获取A（可能造成死锁）
    tasks.add(() async {
      // 获取B
      await TestUtils.delay(50);
      // 获取A
      await TestUtils.delay(50);
    }());
    
    // 等待一段时间看是否发生死锁
    try {
      await Future.wait(tasks).timeout(const Duration(seconds: 2));
    } catch (e) {
      deadlockOccurred = true;
    }
    
    return {
      'testName': 'deadlock',
      'deadlockOccurred': deadlockOccurred,
      'description': 'Two tasks competing for two resources in different order',
    };
  }

  /// 重置统计数据
  void _resetStatistics() {
    _totalTasks = 0;
    _completedTasks = 0;
    _failedTasks = 0;
    _taskDurations.clear();
    _taskResults.clear();
  }

  /// 记录并发统计数据
  void _recordConcurrentStats(int completed, int failed, List<int> durations) {
    _totalTasks += completed + failed;
    _completedTasks += completed;
    _failedTasks += failed;
    _taskDurations.addAll(durations);
  }

  /// 启动并发监控
  void startConcurrentMonitoring() {
    _monitoringTimer = Timer.periodic(
      Duration(milliseconds: TestConfig.sampleInterval),
      (timer) {
        _concurrentSnapshots.add({
          'type': 'monitoring',
          'timestamp': DateTime.now().toIso8601String(),
          'totalTasks': _totalTasks,
          'completedTasks': _completedTasks,
          'failedTasks': _failedTasks,
          'successRate': _totalTasks > 0 ? _completedTasks / _totalTasks : 0,
          'averageDuration': _taskDurations.isNotEmpty 
              ? _taskDurations.reduce((a, b) => a + b) / _taskDurations.length 
              : 0,
        });
      },
    );
  }

  /// 停止并发监控
  void stopConcurrentMonitoring() {
    _monitoringTimer?.cancel();
  }

  /// 分析并发测试结果
  Map<String, dynamic> _analyzeConcurrentResults() {
    final analysis = {
      'snapshots': _concurrentSnapshots,
      'statistics': {
        'totalTasks': _totalTasks,
        'completedTasks': _completedTasks,
        'failedTasks': _failedTasks,
        'successRate': _totalTasks > 0 ? _completedTasks / _totalTasks : 0,
        'averageTaskDuration': _taskDurations.isNotEmpty 
            ? _taskDurations.reduce((a, b) => a + b) / _taskDurations.length 
            : 0,
      },
      'summary': <String, dynamic>{},
    };
    
    // 分析基础并发性能
    final basicConcurrency = _concurrentSnapshots
        .where((s) => s['type'] == 'basic_concurrency')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (basicConcurrency.isNotEmpty) {
      final threadCounts = basicConcurrency.map((r) => r['threadCount'] as int).toList();
      final throughputs = basicConcurrency.map((r) => r['throughput'] as double).toList();
      final efficiencies = basicConcurrency.map((r) => r['efficiency'] as double).toList();
      
      analysis['summary']['basicConcurrency'] = {
        'threadCounts': threadCounts,
        'throughputs': throughputs,
        'efficiencies': efficiencies,
        'scalability': _calculateScalability(threadCounts, throughputs),
      };
    }
    
    // 分析线程池性能
    final threadPoolPerformance = _concurrentSnapshots
        .where((s) => s['type'] == 'thread_pool_performance')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (threadPoolPerformance.isNotEmpty) {
      final utilizations = threadPoolPerformance.map((r) => r['utilization'] as double).toList();
      final poolSizes = threadPoolPerformance.map((r) => r['poolSize'] as int).toList();
      
      analysis['summary']['threadPoolPerformance'] = {
        'poolSizes': poolSizes,
        'utilizations': utilizations,
        'optimalPoolSize': _findOptimalPoolSize(poolSizes, utilizations),
      };
    }
    
    // 分析负载均衡
    final loadBalancing = _concurrentSnapshots
        .where((s) => s['type'] == 'load_balancing')
        .expand((s) => s['results'] as List)
        .toList();
    
    if (loadBalancing.isNotEmpty) {
      final balanceRatios = loadBalancing.map((r) => r['loadBalanceRatio'] as double).toList();
      final workerCounts = loadBalancing.map((r) => r['workerCount'] as int).toList();
      
      analysis['summary']['loadBalancing'] = {
        'workerCounts': workerCounts,
        'balanceRatios': balanceRatios,
        'averageBalanceRatio': balanceRatios.isNotEmpty 
            ? balanceRatios.reduce((a, b) => a + b) / balanceRatios.length 
            : 0,
      };
    }
    
    return analysis;
  }

  /// 计算可扩展性
  Map<String, double> _calculateScalability(List<int> threadCounts, List<double> throughputs) {
    if (threadCounts.length < 2 || throughputs.length < 2) {
      return {'speedup': 0, 'efficiency': 0};
    }
    
    final firstThroughput = throughputs.first;
    final lastThroughput = throughputs.last;
    final firstThread = threadCounts.first;
    final lastThread = threadCounts.last;
    
    final speedup = lastThroughput / firstThroughput;
    final efficiency = speedup / (lastThread / firstThread);
    
    return {'speedup': speedup, 'efficiency': efficiency};
  }

  /// 找到最优线程池大小
  int _findOptimalPoolSize(List<int> poolSizes, List<double> utilizations) {
    if (poolSizes.isEmpty || utilizations.isEmpty) return 4;
    
    // 找到利用率最高的配置
    double maxUtilization = 0;
    int optimalSize = poolSizes.first;
    
    for (int i = 0; i < poolSizes.length; i++) {
      if (utilizations[i] > maxUtilization) {
        maxUtilization = utilizations[i];
        optimalSize = poolSizes[i];
      }
    }
    
    return optimalSize;
  }

  /// 评估并发测试结果
  bool _evaluateConcurrentTest(Map<String, dynamic> metrics) {
    final statistics = metrics['statistics'] as Map<String, dynamic>;
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    // 检查任务成功率
    final successRate = statistics['successRate'] as double;
    if (successRate < 0.95) {
      _recommendations.add('并发任务成功率较低：${(successRate * 100).toStringAsFixed(1)}%，建议优化同步机制');
      return false;
    }
    
    // 检查可扩展性
    final basicConcurrency = summary['basicConcurrency'] as Map<String, dynamic>? ?? {};
    final scalability = basicConcurrency['scalability'] as Map<String, double>? ?? {};
    final efficiency = scalability['efficiency'] ?? 0;
    
    if (efficiency < 0.7) {
      _recommendations.add('并发可扩展性较差，效率：${(efficiency * 100).toStringAsFixed(1)}%，建议优化线程使用');
      return false;
    }
    
    // 检查负载均衡
    final loadBalancing = summary['loadBalancing'] as Map<String, dynamic>? ?? {};
    final avgBalanceRatio = loadBalancing['averageBalanceRatio'] as double? ?? 0;
    
    if (avgBalanceRatio < 0.8) {
      _recommendations.add('负载均衡效果较差，均衡度：${(avgBalanceRatio * 100).toStringAsFixed(1)}%，建议改进任务分配策略');
    }
    
    return true;
  }

  /// 生成并发优化建议
  void _generateConcurrentRecommendations(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    final basicConcurrency = summary['basicConcurrency'] as Map<String, dynamic>? ?? {};
    final scalability = basicConcurrency['scalability'] as Map<String, double>? ?? {};
    final efficiency = scalability['efficiency'] ?? 0;
    
    if (efficiency < 0.8) {
      _recommendations.add('考虑使用更高效的并发模式，如Actor模型或响应式编程');
    }
    
    _recommendations.add('根据CPU核心数调整线程池大小，避免过多上下文切换');
    _recommendations.add('使用适当的同步机制，避免死锁和竞态条件');
    _recommendations.add('实施任务优先级队列，优化负载均衡');
    _recommendations.add('考虑使用无锁数据结构减少锁竞争');
    _recommendations.add('监控并发性能指标，及时调整并发策略');
  }
}