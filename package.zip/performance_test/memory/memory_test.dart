import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// 内存测试类
/// 用于测试内存使用和泄漏检测
class MemoryTest {
  static const String _testName = 'Memory Test';
  Timer? _monitoringTimer;
  List<Map<String, dynamic>> _memorySnapshots = [];
  Map<String, dynamic> _initialMemory = {};
  List<String> _recommendations = [];

  /// 运行内存测试
  Future<TestResult> runMemoryTest() async {
    final startTime = DateTime.now();
    _recommendations.clear();
    _memorySnapshots.clear();
    
    try {
      print('Starting Memory Test...');
      
      // 记录初始内存状态
      _initialMemory = TestUtils.getMemoryUsage();
      
      // 1. 基础内存使用测试
      await _testBasicMemoryUsage();
      
      // 2. 内存分配性能测试
      await _testMemoryAllocationPerformance();
      
      // 3. 内存泄漏检测
      await _testMemoryLeakDetection();
      
      // 4. 垃圾回收性能测试
      await _testGarbageCollectionPerformance();
      
      // 5. 大量数据处理测试
      await _testLargeDataProcessing();
      
      // 6. 内存压力测试
      await _testMemoryPressure();
      
      final endTime = DateTime.now();
      final metrics = _analyzeMemoryResults();
      final passed = _evaluateMemoryTest(metrics);
      
      // 生成优化建议
      _generateMemoryRecommendations(metrics);
      
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: passed,
        metrics: metrics,
        recommendations: _recommendations,
      );
      
    } catch (e) {
      final endTime = DateTime.now();
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: false,
        metrics: {},
        errorMessage: e.toString(),
        recommendations: _recommendations,
      );
    } finally {
      _monitoringTimer?.cancel();
    }
  }

  /// 测试基础内存使用
  Future<void> _testBasicMemoryUsage() async {
    print('Testing basic memory usage...');
    
    final memoryBefore = TestUtils.getMemoryUsage();
    
    // 创建一些对象
    final objects = <List<int>>[];
    for (int i = 0; i < 100; i++) {
      objects.add(TestUtils.memoryIntensiveTask(1000));
    }
    
    final memoryAfter = TestUtils.getMemoryUsage();
    
    final memoryDelta = (memoryAfter['memoryMB'] as double) - (memoryBefore['memoryMB'] as double);
    
    _memorySnapshots.add({
      'type': 'basic_usage',
      'memoryBefore': memoryBefore,
      'memoryAfter': memoryAfter,
      'memoryDelta': memoryDelta,
      'timestamp': DateTime.now().toIso8601String(),
    });
    
    // 清理对象
    objects.clear();
  }

  /// 测试内存分配性能
  Future<void> _testMemoryAllocationPerformance() async {
    print('Testing memory allocation performance...');
    
    final allocations = <Map<String, dynamic>>[];
    
    for (int i = 0; i < 10; i++) {
      final startTime = DateTime.now();
      final memoryBefore = TestUtils.getMemoryUsage();
      
      // 分配大量内存
      final data = TestUtils.memoryIntensiveTask(10000);
      
      final endTime = DateTime.now();
      final memoryAfter = TestUtils.getMemoryUsage();
      
      allocations.add({
        'allocationIndex': i,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'memoryBefore': memoryBefore,
        'memoryAfter': memoryAfter,
        'dataSize': data.length,
      });
      
      // 立即释放
      data.clear();
      await TestUtils.delay(100);
    }
    
    _memorySnapshots.add({
      'type': 'allocation_performance',
      'allocations': allocations,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试内存泄漏检测
  Future<void> _testMemoryLeakDetection() async {
    print('Testing memory leak detection...');
    
    final leakTestResults = <Map<String, dynamic>>[];
    
    for (int cycle = 0; cycle < 5; cycle++) {
      final memoryBefore = TestUtils.getMemoryUsage();
      
      // 创建一些应该被垃圾回收的对象
      for (int i = 0; i < 50; i++) {
        final tempObject = TestUtils.memoryIntensiveTask(1000);
        // 立即释放引用
      }
      
      // 强制垃圾回收（如果可能）
      await _forceGarbageCollection();
      
      await TestUtils.delay(1000);
      
      final memoryAfter = TestUtils.getMemoryUsage();
      
      final memoryDelta = (memoryAfter['memoryMB'] as double) - (memoryBefore['memoryMB'] as double);
      
      leakTestResults.add({
        'cycle': cycle,
        'memoryBefore': memoryBefore,
        'memoryAfter': memoryAfter,
        'memoryDelta': memoryDelta,
        'shouldBeCollected': memoryDelta < 1.0, // 允许1MB的误差
      });
    }
    
    _memorySnapshots.add({
      'type': 'leak_detection',
      'leakTestResults': leakTestResults,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试垃圾回收性能
  Future<void> _testGarbageCollectionPerformance() async {
    print('Testing garbage collection performance...');
    
    final gcResults = <Map<String, dynamic>>[];
    
    for (int i = 0; i < 5; i++) {
      // 创建大量对象
      final objects = <List<int>>[];
      for (int j = 0; j < 1000; j++) {
        objects.add(TestUtils.memoryIntensiveTask(100));
      }
      
      final memoryBeforeGc = TestUtils.getMemoryUsage();
      final startTime = DateTime.now();
      
      // 清空对象列表（触发垃圾回收）
      objects.clear();
      await _forceGarbageCollection();
      
      final endTime = DateTime.now();
      final memoryAfterGc = TestUtils.getMemoryUsage();
      
      gcResults.add({
        'testIndex': i,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'memoryBeforeGc': memoryBeforeGc,
        'memoryAfterGc': memoryAfterGc,
        'memoryFreed': (memoryBeforeGc['memoryMB'] as double) - (memoryAfterGc['memoryMB'] as double),
      });
    }
    
    _memorySnapshots.add({
      'type': 'garbage_collection',
      'gcResults': gcResults,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试大量数据处理
  Future<void> _testLargeDataProcessing() async {
    print('Testing large data processing...');
    
    final memorySnapshots = <Map<String, dynamic>>[];
    
    // 处理不同大小的数据集
    final dataSizes = [1000, 5000, 10000, 20000];
    
    for (final size in dataSizes) {
      final memoryBefore = TestUtils.getMemoryUsage();
      final startTime = DateTime.now();
      
      // 模拟数据处理
      final data = TestUtils.generateTestData(size);
      
      // 模拟一些计算密集型操作
      var processedData = data.map((item) {
        item['processed'] = true;
        item['valueSquared'] = (item['value'] as double) * (item['value'] as double);
        return item;
      }).toList();
      
      final endTime = DateTime.now();
      final memoryAfter = TestUtils.getMemoryUsage();
      
      memorySnapshots.add({
        'dataSize': size,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'memoryBefore': memoryBefore,
        'memoryAfter': memoryAfter,
        'memoryDelta': (memoryAfter['memoryMB'] as double) - (memoryBefore['memoryMB'] as double),
      });
      
      // 清理数据
      processedData.clear();
      await TestUtils.delay(500);
    }
    
    _memorySnapshots.add({
      'type': 'large_data_processing',
      'processingResults': memorySnapshots,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试内存压力
  Future<void> _testMemoryPressure() async {
    print('Testing memory pressure...');
    
    final pressureResults = <Map<String, dynamic>>[];
    
    for (int pressureLevel = 1; pressureLevel <= 5; pressureLevel++) {
      final memoryBefore = TestUtils.getMemoryUsage();
      final startTime = DateTime.now();
      
      // 创建不同级别的内存压力
      final allocations = <List<int>>[];
      for (int i = 0; i < pressureLevel * 1000; i++) {
        allocations.add(TestUtils.memoryIntensiveTask(100));
      }
      
      final endTime = DateTime.now();
      final memoryDuring = TestUtils.getMemoryUsage();
      
      // 释放内存
      allocations.clear();
      final memoryAfter = TestUtils.getMemoryUsage();
      
      pressureResults.add({
        'pressureLevel': pressureLevel,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'memoryBefore': memoryBefore,
        'memoryDuring': memoryDuring,
        'memoryAfter': memoryAfter,
        'memoryPeak': (memoryDuring['memoryMB'] as double) - (memoryBefore['memoryMB'] as double),
        'memoryRecovered': (memoryDuring['memoryMB'] as double) - (memoryAfter['memoryMB'] as double),
      });
      
      await TestUtils.delay(1000);
    }
    
    _memorySnapshots.add({
      'type': 'memory_pressure',
      'pressureResults': pressureResults,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 强制垃圾回收
  Future<void> _forceGarbageCollection() async {
    // 在Dart中，我们无法直接强制垃圾回收
    // 但我们可以创建多个引用作用域来帮助垃圾回收器工作
    for (int i = 0; i < 3; i++) {
      await TestUtils.delay(100);
    }
  }

  /// 分析内存测试结果
  Map<String, dynamic> _analyzeMemoryResults() {
    final analysis = {
      'initialMemory': _initialMemory,
      'snapshots': _memorySnapshots,
      'summary': <String, dynamic>{},
    };
    
    // 计算总结统计
    final allocationTests = _memorySnapshots
        .where((s) => s['type'] == 'allocation_performance')
        .expand((s) => s['allocations'] as List)
        .toList();
    
    if (allocationTests.isNotEmpty) {
      final durations = allocationTests
          .map((a) => a['duration'] as int)
          .toList();
      final memoryDeltas = allocationTests
          .map((a) => ((a['memoryAfter'] as Map)['memoryMB'] as double) - 
                      ((a['memoryBefore'] as Map)['memoryMB'] as double))
          .toList();
      
      analysis['summary'] = {
        'averageAllocationTime': durations.isNotEmpty ? durations.reduce((a, b) => a + b) / durations.length : 0,
        'maxMemoryUsage': memoryDeltas.isNotEmpty ? memoryDeltas.reduce((a, b) => a > b ? a : b) : 0,
        'totalMemoryAllocated': memoryDeltas.isNotEmpty ? memoryDeltas.reduce((a, b) => a + b) : 0,
        'memoryEfficiency': memoryDeltas.isNotEmpty ? (memoryDeltas.reduce((a, b) => a + b) / allocationTests.length) : 0,
      };
    }
    
    return analysis;
  }

  /// 评估内存测试结果
  bool _evaluateMemoryTest(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    // 检查平均分配时间
    final avgTime = summary['averageAllocationTime'] as double? ?? 0;
    if (avgTime > 100) { // 超过100ms
      _recommendations.add('内存分配时间过长：${avgTime.toStringAsFixed(2)}ms，建议优化内存分配策略');
      return false;
    }
    
    // 检查内存使用效率
    final efficiency = summary['memoryEfficiency'] as double? ?? 0;
    if (efficiency > 50) { // 超过50MB
      _recommendations.add('内存使用效率较低：${efficiency.toStringAsFixed(2)}MB，建议检查内存泄漏');
      return false;
    }
    
    return true;
  }

  /// 生成内存优化建议
  void _generateMemoryRecommendations(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    final avgTime = summary['averageAllocationTime'] as double? ?? 0;
    final efficiency = summary['memoryEfficiency'] as double? ?? 0;
    
    if (avgTime > 50) {
      _recommendations.add('考虑使用对象池模式来减少频繁的内存分配');
    }
    
    if (efficiency > 20) {
      _recommendations.add('建议实现内存池来复用对象，减少垃圾回收压力');
    }
    
    _recommendations.add('定期监控内存使用情况，及时发现内存泄漏');
    _recommendations.add('使用弱引用来处理可回收的对象，避免内存泄漏');
    _recommendations.add('对于大量数据处理，考虑分批处理减少内存峰值');
  }

  /// 启动内存监控
  void startMemoryMonitoring() {
    _monitoringTimer = Timer.periodic(
      Duration(milliseconds: TestConfig.memoryLeakCheckInterval),
      (timer) {
        final memory = TestUtils.getMemoryUsage();
        _memorySnapshots.add({
          'type': 'monitoring',
          'memory': memory,
          'timestamp': DateTime.now().toIso8601String(),
        });
      },
    );
  }

  /// 停止内存监控
  void stopMemoryMonitoring() {
    _monitoringTimer?.cancel();
  }
}