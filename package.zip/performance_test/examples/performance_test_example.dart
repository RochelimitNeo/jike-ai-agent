import 'dart:async';
import 'dart:developer';
import '../performance_test_suite.dart';
import '../utils/test_config.dart';

/// 性能测试示例
/// 展示如何使用性能测试套件
void main() async {
  print('🚀 性能测试套件示例');
  print('=' * 50);
  
  try {
    // 创建性能测试实例
    final performanceTest = PerformanceTestSuite();
    
    // 示例1: 运行所有测试
    print('\n📋 示例1: 运行所有测试');
    print('-' * 30);
    final allTestsResult = await performanceTest.runAllTests(
      testTypes: [TestType.all],
      generateReports: true,
    );
    
    print('\n📊 测试结果摘要:');
    print('总测试数: ${allTestsResult.totalTests}');
    print('通过测试: ${allTestsResult.passedTests}');
    print('失败测试: ${allTestsResult.failedTests}');
    print('成功率: ${(allTestsResult.successRate * 100).toStringAsFixed(1)}%');
    print('总耗时: ${TestUtils.formatDuration(allTestsResult.duration)}');
    
    // 示例2: 运行快速测试
    print('\n⚡ 示例2: 运行快速测试');
    print('-' * 30);
    final quickTestResult = await performanceTest.runQuickTest();
    
    print('\n📊 快速测试结果:');
    print('总测试数: ${quickTestResult.totalTests}');
    print('通过测试: ${quickTestResult.passedTests}');
    print('失败测试: ${quickTestResult.failedTests}');
    print('成功率: ${(quickTestResult.successRate * 100).toStringAsFixed(1)}%');
    print('总耗时: ${TestUtils.formatDuration(quickTestResult.duration)}');
    
    // 示例3: 运行单个测试
    print('\n🎯 示例3: 运行单个测试');
    print('-' * 30);
    final memoryTestResult = await performanceTest.runTestType(TestType.memory);
    
    print('\n📊 内存测试结果:');
    print('测试名称: ${memoryTestResult.testName}');
    print('测试状态: ${memoryTestResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(memoryTestResult.endTime.difference(memoryTestResult.startTime))}');
    
    if (memoryTestResult.metrics.isNotEmpty) {
      print('\n关键指标:');
      memoryTestResult.metrics.forEach((key, value) {
        print('  $key: $value');
      });
    }
    
    if (memoryTestResult.recommendations.isNotEmpty) {
      print('\n优化建议:');
      for (final recommendation in memoryTestResult.recommendations) {
        print('  • $recommendation');
      }
    }
    
    // 示例4: 导出测试结果
    print('\n💾 示例4: 导出测试结果');
    print('-' * 30);
    final exportedResults = await performanceTest.exportTestResults();
    
    print('\n📊 导出信息:');
    print('导出时间: ${exportedResults['exportInfo']['exportedAt']}');
    print('测试总数: ${exportedResults['exportInfo']['totalTests']}');
    print('版本: ${exportedResults['exportInfo']['version']}');
    
    final summary = exportedResults['summary'] as Map<String, dynamic>;
    print('\n总结统计:');
    print('总测试数: ${summary['totalTests']}');
    print('通过测试: ${summary['passedTests']}');
    print('失败测试: ${summary['failedTests']}');
    print('成功率: ${(summary['successRate'] * 100).toStringAsFixed(1)}%');
    print('平均测试时长: ${summary['averageTestDuration']}ms');
    
    // 示例5: 获取性能基线
    print('\n📈 示例5: 获取性能基线');
    print('-' * 30);
    print('正在运行基线测试...');
    final baseline = await performanceTest.getPerformanceBaseline();
    
    print('\n📊 基线信息:');
    print('基线日期: ${baseline['baselineDate']}');
    print('测试条件: ${baseline['testConditions']}');
    
    print('\n基线测试项目:');
    for (final testName in baseline.keys) {
      if (testName != 'baselineDate' && testName != 'testConditions') {
        print('  • $testName');
      }
    }
    
    // 示例6: 自定义测试流程
    print('\n🔧 示例6: 自定义测试流程');
    print('-' * 30);
    await _runCustomTestFlow();
    
    print('\n🎉 所有示例运行完成!');
    
    // 清理资源
    performanceTest.dispose();
    
  } catch (e, stackTrace) {
    print('\n❌ 运行示例时发生错误: $e');
    print('堆栈跟踪: $stackTrace');
  }
}

/// 自定义测试流程示例
Future<void> _runCustomTestFlow() async {
  print('\n开始自定义测试流程...');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 步骤1: 仅运行内存和CPU测试
    print('\n步骤1: 运行内存和CPU测试');
    final step1Result = await performanceTest.runAllTests(
      testTypes: [TestType.memory, TestType.cpu],
      generateReports: false,
    );
    
    print('步骤1完成: ${step1Result.passedTests}/${step1Result.totalTests} 测试通过');
    
    // 步骤2: 如果前面的测试都通过，继续运行网络测试
    if (step1Result.passed) {
      print('\n步骤2: 运行网络测试');
      final step2Result = await performanceTest.runTestType(TestType.network);
      print('步骤2完成: 网络测试${step2Result.passed ? "通过" : "失败"}');
    }
    
    // 步骤3: 生成报告
    print('\n步骤3: 生成自定义报告');
    await performanceTest.generateCustomReport('custom_test_report');
    print('自定义报告生成完成');
    
  } catch (e) {
    print('自定义测试流程出错: $e');
  } finally {
    performanceTest.dispose();
  }
}

/// 压力测试示例
Future<void> _runStressTestExample() async {
  print('\n开始压力测试示例...');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行压力测试
    final stressResult = await performanceTest.runTestType(TestType.stress);
    
    print('\n压力测试结果:');
    print('测试名称: ${stressResult.testName}');
    print('测试状态: ${stressResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(stressResult.endTime.difference(stressResult.startTime))}');
    
    if (stressResult.metrics.isNotEmpty) {
      print('\n关键压力指标:');
      // 提取压力测试特有的指标
      if (stressResult.metrics.containsKey('statistics')) {
        final stats = stressResult.metrics['statistics'] as Map<String, dynamic>;
        print('总请求数: ${stats['totalRequests']}');
        print('成功请求数: ${stats['successfulRequests']}');
        print('失败请求数: ${stats['failedRequests']}');
        print('成功率: ${(stats['successRate'] * 100).toStringAsFixed(1)}%');
        print('平均响应时间: ${stats['averageResponseTime']}ms');
      }
    }
    
  } catch (e) {
    print('压力测试出错: $e');
  } finally {
    performanceTest.dispose();
  }
}

/// 并发测试示例
Future<void> _runConcurrentTestExample() async {
  print('\n开始并发测试示例...');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行并发测试
    final concurrentResult = await performanceTest.runTestType(TestType.concurrent);
    
    print('\n并发测试结果:');
    print('测试名称: ${concurrentResult.testName}');
    print('测试状态: ${concurrentResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(concurrentResult.endTime.difference(concurrentResult.startTime))}');
    
    if (concurrentResult.metrics.isNotEmpty) {
      print('\n关键并发指标:');
      if (concurrentResult.metrics.containsKey('summary')) {
        final summary = concurrentResult.metrics['summary'] as Map<String, dynamic>;
        
        if (summary.containsKey('basicConcurrency')) {
          final basicConcurrency = summary['basicConcurrency'] as Map<String, dynamic>;
          final scalability = basicConcurrency['scalability'] as Map<String, dynamic>;
          print('加速比: ${scalability['speedup']}');
          print('效率: ${(scalability['efficiency'] * 100).toStringAsFixed(1)}%');
        }
      }
    }
    
  } catch (e) {
    print('并发测试出错: $e');
  } finally {
    performanceTest.dispose();
  }
}

/// 电池测试示例
Future<void> _runBatteryTestExample() async {
  print('\n开始电池测试示例...');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行电池测试
    final batteryResult = await performanceTest.runTestType(TestType.battery);
    
    print('\n电池测试结果:');
    print('测试名称: ${batteryResult.testName}');
    print('测试状态: ${batteryResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(batteryResult.endTime.difference(batteryResult.startTime))}');
    
    if (batteryResult.recommendations.isNotEmpty) {
      print('\n电池优化建议:');
      for (final recommendation in batteryResult.recommendations) {
        print('  • $recommendation');
      }
    }
    
  } catch (e) {
    print('电池测试出错: $e');
  } finally {
    performanceTest.dispose();
  }
}