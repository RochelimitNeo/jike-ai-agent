#!/usr/bin/env dart

/// 性能测试套件快速启动脚本
/// 
/// 这个脚本演示了如何使用性能测试套件的基本功能

import 'dart:async';
import 'dart:developer';
import '../performance_test.dart';
import '../config/performance_config.dart';

void main() async {
  print('🚀 性能测试套件快速启动');
  print('=' * 50);
  
  try {
    // 1. 显示配置信息
    print('\n📋 1. 当前配置信息');
    PerformanceTestConfig.printConfig();
    
    // 2. 验证配置
    print('\n✅ 2. 验证配置');
    if (PerformanceTestConfig.validateConfig()) {
      print('✅ 配置验证通过');
    } else {
      print('❌ 配置验证失败');
      return;
    }
    
    // 3. 创建测试实例
    print('\n🔧 3. 创建性能测试实例');
    final performanceTest = PerformanceTestSuite();
    print('✅ 测试实例创建成功');
    
    // 4. 运行快速测试
    print('\n⚡ 4. 运行快速性能测试');
    print('正在运行内存、CPU、网络测试...');
    
    final quickResult = await performanceTest.runQuickTest();
    
    print('\n📊 快速测试结果:');
    print('总测试数: ${quickResult.totalTests}');
    print('通过测试: ${quickResult.passedTests}');
    print('失败测试: ${quickResult.failedTests}');
    print('成功率: ${(quickResult.successRate * 100).toStringAsFixed(1)}%');
    print('总耗时: ${TestUtils.formatDuration(quickResult.duration)}');
    
    // 5. 查看详细结果
    print('\n📋 5. 查看详细测试结果');
    final detailedResults = performanceTest.getTestResults();
    
    for (final result in detailedResults) {
      print('\n🔍 ${result.testName}:');
      print('  状态: ${result.passed ? "✅ 通过" : "❌ 失败"}');
      print('  耗时: ${TestUtils.formatDuration(result.endTime.difference(result.startTime))}');
      
      if (result.metrics.isNotEmpty) {
        print('  关键指标:');
        result.metrics.forEach((key, value) {
          print('    $key: $value');
        });
      }
      
      if (result.recommendations.isNotEmpty) {
        print('  优化建议:');
        for (final recommendation in result.recommendations.take(3)) {
          print('    • $recommendation');
        }
        if (result.recommendations.length > 3) {
          print('    ... 还有 ${result.recommendations.length - 3} 条建议');
        }
      }
    }
    
    // 6. 导出测试结果
    print('\n💾 6. 导出测试结果');
    final exportedResults = await performanceTest.exportTestResults();
    
    print('✅ 测试结果导出成功');
    print('导出信息:');
    final exportInfo = exportedResults['exportInfo'] as Map<String, dynamic>;
    print('  导出时间: ${exportInfo['exportedAt']}');
    print('  测试总数: ${exportInfo['totalTests']}');
    print('  版本: ${exportInfo['version']}');
    
    // 7. 获取基线数据
    print('\n📈 7. 建立性能基线');
    print('正在运行基线测试...');
    final baseline = await performanceTest.getPerformanceBaseline();
    
    print('✅ 基线测试完成');
    print('基线信息:');
    print('  日期: ${baseline['baselineDate']}');
    print('  测试项目: ${baseline.length - 2} 项'); // 减去基线日期和测试条件
    
    // 8. 演示其他功能
    print('\n🎯 8. 演示其他功能');
    
    // 运行单个测试
    print('正在运行内存测试...');
    final memoryResult = await performanceTest.runTestType(TestType.memory);
    print('内存测试: ${memoryResult.passed ? "✅ 通过" : "❌ 失败"}');
    
    // 9. 清理资源
    print('\n🧹 9. 清理资源');
    performanceTest.dispose();
    print('✅ 资源清理完成');
    
    print('\n🎉 快速启动完成!');
    print('性能测试套件已验证可以正常工作。');
    
    print('\n📚 下一步建议:');
    print('1. 查看 examples/performance_test_example.dart 获取更多示例');
    print('2. 运行 examples/validation_script.dart 进行完整验证');
    print('3. 修改 config/performance_config.dart 自定义测试参数');
    print('4. 查看 reports/ 目录中的生成的测试报告');
    
  } catch (e, stackTrace) {
    print('\n❌ 快速启动过程中发生错误: $e');
    print('堆栈跟踪: $stackTrace');
    print('\n请检查:');
    print('1. Dart SDK版本是否兼容');
    print('2. 是否有必要的文件权限');
    print('3. 系统资源是否充足');
    
    exit(1);
  }
}

/// 演示高级功能
Future<void> demonstrateAdvancedFeatures() async {
  print('\n🚀 演示高级功能');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 使用自定义配置运行测试
    print('使用快速测试配置...');
    final customConfig = PerformanceTestPresets.quickTestPreset;
    print('自定义配置: $customConfig');
    
    // 运行完整测试
    print('运行完整性能测试...');
    final fullResult = await performanceTest.runAllTests(
      testTypes: [TestType.memory, TestType.cpu, TestType.network],
      generateReports: true,
    );
    
    print('\n📊 完整测试结果:');
    print('总测试数: ${fullResult.totalTests}');
    print('通过测试: ${fullResult.passedTests}');
    print('成功率: ${(fullResult.successRate * 100).toStringAsFixed(1)}%');
    print('总耗时: ${TestUtils.formatDuration(fullResult.duration)}');
    
    // 生成自定义报告
    print('生成自定义报告...');
    await performanceTest.generateCustomReport('advanced_demo_report');
    
  } finally {
    performanceTest.dispose();
  }
}

/// 性能基准对比示例
Future<void> demonstrateBenchmarkComparison() async {
  print('\n📊 演示性能基准对比');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 建立基线
    print('1. 建立性能基线...');
    final baseline = await performanceTest.getPerformanceBaseline();
    print('✅ 基线建立完成');
    
    // 运行当前测试
    print('2. 运行当前测试...');
    final currentResults = await performanceTest.runAllTests(generateReports: false);
    print('✅ 当前测试完成');
    
    // 进行比较
    print('3. 生成比较报告...');
    await performanceTest.compareWithBaseline(baseline);
    print('✅ 比较报告生成完成');
    
  } finally {
    performanceTest.dispose();
  }
}

/// 压力测试示例
Future<void> demonstrateStressTesting() async {
  print('\n🔥 演示压力测试');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    print('运行压力测试...');
    final stressResult = await performanceTest.runTestType(TestType.stress);
    
    print('\n🔥 压力测试结果:');
    print('测试名称: ${stressResult.testName}');
    print('测试状态: ${stressResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(stressResult.endTime.difference(stressResult.startTime))}');
    
    if (stressResult.metrics.isNotEmpty) {
      print('\n压力测试关键指标:');
      if (stressResult.metrics.containsKey('statistics')) {
        final stats = stressResult.metrics['statistics'] as Map<String, dynamic>;
        print('  总请求数: ${stats['totalRequests']}');
        print('  成功请求数: ${stats['successfulRequests']}');
        print('  失败请求数: ${stats['failedRequests']}');
        print('  成功率: ${(stats['successRate'] * 100).toStringAsFixed(1)}%');
        if (stats.containsKey('averageResponseTime')) {
          print('  平均响应时间: ${stats['averageResponseTime']}ms');
        }
      }
    }
    
  } finally {
    performanceTest.dispose();
  }
}