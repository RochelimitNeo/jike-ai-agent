#!/usr/bin/env dart

/// 性能测试套件验证脚本
/// 用于验证性能测试套件的基本功能

import 'dart:async';
import 'dart:math';
import '../performance_test_suite.dart';
import '../utils/test_config.dart';

void main() async {
  print('🔧 性能测试套件验证');
  print('=' * 50);
  
  try {
    // 验证1: 创建测试实例
    print('\n✅ 验证1: 创建性能测试实例');
    final performanceTest = PerformanceTestSuite();
    print('✅ 性能测试实例创建成功');
    
    // 验证2: 运行单个快速测试
    print('\n✅ 验证2: 运行内存测试');
    final memoryTestResult = await performanceTest.runTestType(TestType.memory);
    print('✅ 内存测试完成: ${memoryTestResult.passed ? "通过" : "失败"}');
    
    // 验证3: 检查测试结果
    print('\n✅ 验证3: 检查测试结果');
    final results = performanceTest.getTestResults();
    print('✅ 获取到 ${results.length} 个测试结果');
    
    for (final result in results) {
      print('  • ${result.testName}: ${result.passed ? "通过" : "失败"}');
      print('    时间: ${TestUtils.formatDuration(result.endTime.difference(result.startTime))}');
      if (result.metrics.isNotEmpty) {
        print('    指标数: ${result.metrics.length}');
      }
    }
    
    // 验证4: 导出结果
    print('\n✅ 验证4: 导出测试结果');
    final exportedResults = await performanceTest.exportTestResults();
    print('✅ 测试结果导出成功');
    print('  导出信息: ${exportedResults['exportInfo']}');
    
    // 验证5: 清理资源
    print('\n✅ 验证5: 清理资源');
    performanceTest.dispose();
    print('✅ 资源清理完成');
    
    print('\n🎉 所有验证项目通过!');
    print('性能测试套件基本功能正常。');
    
  } catch (e, stackTrace) {
    print('\n❌ 验证过程中发生错误: $e');
    print('堆栈跟踪: $stackTrace');
    exit(1);
  }
}

/// 简单性能测试示例
Future<void> simplePerformanceTest() async {
  print('\n🚀 开始简单性能测试');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行快速测试
    final result = await performanceTest.runQuickTest();
    
    print('\n📊 测试结果摘要:');
    print('总测试数: ${result.totalTests}');
    print('通过测试: ${result.passedTests}');
    print('失败测试: ${result.failedTests}');
    print('成功率: ${(result.successRate * 100).toStringAsFixed(1)}%');
    print('总耗时: ${TestUtils.formatDuration(result.duration)}');
    
    // 获取详细的测试结果
    final detailedResults = performanceTest.getTestResults();
    for (final detailedResult in detailedResults) {
      print('\n📋 ${detailedResult.testName}:');
      print('  状态: ${detailedResult.passed ? "通过" : "失败"}');
      print('  耗时: ${TestUtils.formatDuration(detailedResult.endTime.difference(detailedResult.startTime))}');
      
      if (detailedResult.metrics.isNotEmpty) {
        print('  关键指标:');
        detailedResult.metrics.forEach((key, value) {
          print('    $key: $value');
        });
      }
      
      if (detailedResult.recommendations.isNotEmpty) {
        print('  优化建议:');
        for (final recommendation in detailedResult.recommendations) {
          print('    • $recommendation');
        }
      }
    }
    
  } finally {
    performanceTest.dispose();
  }
}

/// 基准测试示例
Future<Map<String, dynamic>> benchmarkTest() async {
  print('\n📈 开始基准测试');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行基准测试
    final result = await performanceTest.runAllTests(generateReports: false);
    
    // 收集基准数据
    final baseline = <String, dynamic>{};
    
    for (final testResult in result.testResults) {
      final metrics = <String, dynamic>{};
      
      if (testResult.metrics.isNotEmpty) {
        // 提取关键指标
        testResult.metrics.forEach((key, value) {
          if (value is num) {
            metrics[key] = value;
          }
        });
      }
      
      baseline[testResult.testName] = metrics;
    }
    
    baseline['baselineDate'] = DateTime.now().toIso8601String();
    baseline['testDuration'] = result.duration.inMilliseconds;
    baseline['successRate'] = result.successRate;
    
    print('✅ 基准测试完成');
    print('基准测试日期: ${baseline['baselineDate']}');
    print('测试持续时间: ${result.duration.inSeconds}秒');
    print('成功率: ${(result.successRate * 100).toStringAsFixed(1)}%');
    
    return baseline;
    
  } finally {
    performanceTest.dispose();
  }
}

/// 压力测试示例
Future<void> stressTestExample() async {
  print('\n🔥 开始压力测试');
  
  final performanceTest = PerformanceTestSuite();
  
  try {
    // 运行压力测试
    final stressResult = await performanceTest.runTestType(TestType.stress);
    
    print('\n🔥 压力测试结果:');
    print('测试名称: ${stressResult.testName}');
    print('测试状态: ${stressResult.passed ? "通过" : "失败"}');
    print('测试时间: ${TestUtils.formatDuration(stressResult.endTime.difference(stressResult.startTime))}');
    
    if (stressResult.metrics.isNotEmpty) {
      print('\n压力测试关键指标:');
      if (stressResult.metrics.containsKey('statistics')) {
        final stats = stressResult.metrics['statistics'] as Map<String, dynamic>;
        print('  总请求数: ${stats['totalRequests']}');
        print('  成功请求数: ${stats['successfulRequests']}');
        print('  失败请求数: ${stats['failedRequests']}');
        print('  成功率: ${(stats['successRate'] * 100).toStringAsFixed(1)}%');
        if (stats.containsKey('averageResponseTime')) {
          print('  平均响应时间: ${stats['averageResponseTime']}ms');
        }
      }
    }
    
    if (stressResult.recommendations.isNotEmpty) {
      print('\n压力测试优化建议:');
      for (final recommendation in stressResult.recommendations) {
        print('  • $recommendation');
      }
    }
    
  } finally {
    performanceTest.dispose();
  }
}