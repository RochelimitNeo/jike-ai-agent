import 'dart:async';
import 'dart:developer';
import 'dart:math';
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// 压力测试类
/// 用于测试极限负载下的系统稳定性
class StressTest {
  static const String _testName = 'Stress Test';
  Timer? _monitoringTimer;
  Timer? _stressTimer;
  List<Map<String, dynamic>> _stressSnapshots = [];
  List<String> _recommendations = [];
  
  // 压力测试统计数据
  int _totalRequests = 0;
  int _successfulRequests = 0;
  int _failedRequests = 0;
  int _timeoutRequests = 0;
  List<int> _responseTimes = [];
  List<String> _errorTypes = [];

  /// 运行压力测试
  Future<TestResult> runStressTest() async {
    final startTime = DateTime.now();
    _recommendations.clear();
    _stressSnapshots.clear();
    _resetStatistics();
    
    try {
      print('Starting Stress Test...');
      
      // 1. CPU压力测试
      await _testCpuStress();
      
      // 2. 内存压力测试
      await _testMemoryStress();
      
      // 3. 网络压力测试
      await _testNetworkStress();
      
      // 4. 并发压力测试
      await _testConcurrentStress();
      
      // 5. 混合负载测试
      await _testMixedLoad();
      
      // 6. 系统稳定性测试
      await _testSystemStability();
      
      final endTime = DateTime.now();
      final metrics = _analyzeStressResults();
      final passed = _evaluateStressTest(metrics);
      
      // 生成优化建议
      _generateStressRecommendations(metrics);
      
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: passed,
        metrics: metrics,
        recommendations: _recommendations,
      );
      
    } catch (e) {
      final endTime = DateTime.now();
      return TestResult(
        testName: _testName,
        startTime: startTime,
        endTime: endTime,
        passed: false,
        metrics: {},
        errorMessage: e.toString(),
        recommendations: _recommendations,
      );
    } finally {
      _stressTimer?.cancel();
      _monitoringTimer?.cancel();
    }
  }

  /// 测试CPU压力
  Future<void> _testCpuStress() async {
    print('Testing CPU stress...');
    
    final stressLevels = [50, 70, 85, 95, 100]; // CPU使用率百分比
    final results = <Map<String, dynamic>>[];
    
    for (final stressLevel in stressLevels) {
      final startTime = DateTime.now();
      
      // 启动CPU压力
      final stressTasks = <Future<void>>[];
      final taskCount = (stressLevel / 10).ceil(); // 每个任务占用约10%CPU
      
      for (int i = 0; i < taskCount; i++) {
        stressTasks.add(_generateCpuStress(5000)); // 5秒压力
      }
      
      // 监控系统资源
      final monitoringTask = _monitorResources();
      
      await Future.wait(stressTasks);
      await monitoringTask;
      
      final endTime = DateTime.now();
      
      results.add({
        'stressLevel': stressLevel,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'taskCount': taskCount,
        'success': true,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordRequest(5000);
      
      await TestUtils.delay(2000); // 等待系统恢复
    }
    
    _stressSnapshots.add({
      'type': 'cpu_stress',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试内存压力
  Future<void> _testMemoryStress() async {
    print('Testing memory stress...');
    
    final memoryLevels = [50, 70, 85, 95]; // 内存使用率百分比
    final results = <Map<String, dynamic>>[];
    
    for (final memoryLevel in memoryLevels) {
      final startTime = DateTime.now();
      
      // 计算需要分配的内存大小
      final memorySize = (memoryLevel / 100.0) * 500 * 1024 * 1024; // 最多500MB
      
      // 分配内存
      final memoryChunks = <List<int>>[];
      final chunkSize = 1024 * 1024; // 1MB块
      final chunkCount = (memorySize / chunkSize).floor();
      
      try {
        for (int i = 0; i < chunkCount; i++) {
          final chunk = TestUtils.memoryIntensiveTask(chunkSize ~/ 4);
          memoryChunks.add(chunk);
          
          if (i % 10 == 0) {
            await TestUtils.delay(10); // 避免过于频繁的分配
          }
        }
        
        // 保持内存分配一段时间
        await TestUtils.delay(3000);
        
        // 释放内存
        memoryChunks.clear();
        
        final endTime = DateTime.now();
        
        results.add({
          'memoryLevel': memoryLevel,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'duration': endTime.difference(startTime).inMilliseconds,
          'allocatedMemory': memorySize,
          'chunksAllocated': chunkCount,
          'success': true,
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordRequest(endTime.difference(startTime).inMilliseconds);
        
      } catch (e) {
        final endTime = DateTime.now();
        
        results.add({
          'memoryLevel': memoryLevel,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'duration': endTime.difference(startTime).inMilliseconds,
          'allocatedMemory': memorySize,
          'chunksAllocated': chunkCount,
          'success': false,
          'error': e.toString(),
          'timestamp': DateTime.now().toIso8601String(),
        });
        
        _recordError(endTime.difference(startTime).inMilliseconds, 'memory_exhaustion');
      }
      
      await TestUtils.delay(2000); // 等待系统恢复
    }
    
    _stressSnapshots.add({
      'type': 'memory_stress',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试网络压力
  Future<void> _testNetworkStress() async {
    print('Testing network stress...');
    
    final requestRates = [10, 50, 100, 200, 500]; // 每秒请求数
    final results = <Map<String, dynamic>>[];
    
    for (final rate in requestRates) {
      final startTime = DateTime.now();
      final duration = const Duration(seconds: 10);
      final endTime = startTime.add(duration);
      
      final requests = <Future<Map<String, dynamic>>>[];
      int requestCount = 0;
      
      // 启动压力循环
      _stressTimer = Timer.periodic(Duration(milliseconds: 1000 ~/ rate), (timer) {
        if (DateTime.now().isBefore(endTime)) {
          requestCount++;
          requests.add(_simulateStressRequest());
        } else {
          timer.cancel();
        }
      });
      
      // 等待所有请求完成
      final requestResults = await Future.wait(requests);
      _stressTimer?.cancel();
      
      final finalEndTime = DateTime.now();
      
      final successfulRequests = requestResults.where((r) => r['success'] == true).length;
      final failedRequests = requestResults.length - successfulRequests;
      final responseTimes = requestResults.map((r) => r['responseTime'] as int).toList();
      final avgResponseTime = responseTimes.isNotEmpty 
          ? responseTimes.reduce((a, b) => a + b) / responseTimes.length 
          : 0;
      
      results.add({
        'requestRate': rate,
        'startTime': startTime.toIso8601String(),
        'endTime': finalEndTime.toIso8601String(),
        'duration': finalEndTime.difference(startTime).inMilliseconds,
        'totalRequests': requestResults.length,
        'successfulRequests': successfulRequests,
        'failedRequests': failedRequests,
        'averageResponseTime': avgResponseTime,
        'throughput': requestResults.length / (finalEndTime.difference(startTime).inMilliseconds / 1000),
        'errorRate': failedRequests / requestResults.length,
        'requests': requestResults,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordRequest(avgResponseTime.toInt(), failedRequests);
      
      await TestUtils.delay(3000); // 等待系统恢复
    }
    
    _stressSnapshots.add({
      'type': 'network_stress',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试并发压力
  Future<void> _testConcurrentStress() async {
    print('Testing concurrent stress...');
    
    final concurrencyLevels = [50, 100, 200, 500, 1000];
    final results = <Map<String, dynamic>>[];
    
    for (final concurrency in concurrencyLevels) {
      final startTime = DateTime.now();
      
      // 创建大量并发任务
      final tasks = <Future<Map<String, dynamic>>>[];
      for (int i = 0; i < concurrency; i++) {
        tasks.add(_executeConcurrentStressTask(i, 2000)); // 2秒任务
      }
      
      final taskResults = await Future.wait(tasks);
      final endTime = DateTime.now();
      
      final successfulTasks = taskResults.where((r) => r['success'] == true).length;
      final failedTasks = taskResults.length - successfulTasks;
      final responseTimes = taskResults.map((r) => r['duration'] as int).toList();
      final avgResponseTime = responseTimes.isNotEmpty 
          ? responseTimes.reduce((a, b) => a + b) / responseTimes.length 
          : 0;
      
      results.add({
        'concurrencyLevel': concurrency,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'totalTasks': taskResults.length,
        'successfulTasks': successfulTasks,
        'failedTasks': failedTasks,
        'averageResponseTime': avgResponseTime,
        'throughput': taskResults.length / (endTime.difference(startTime).inMilliseconds / 1000),
        'errorRate': failedTasks / taskResults.length,
        'taskResults': taskResults,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordRequest(avgResponseTime.toInt(), failedTasks);
      
      await TestUtils.delay(5000); // 等待系统恢复
    }
    
    _stressSnapshots.add({
      'type': 'concurrent_stress',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试混合负载
  Future<void> _testMixedLoad() async {
    print('Testing mixed load...');
    
    final scenarios = [
      {'name': 'cpu_network', 'cpuWeight': 0.4, 'networkWeight': 0.6},
      {'name': 'memory_cpu', 'cpuWeight': 0.5, 'memoryWeight': 0.5},
      {'name': 'all_resources', 'cpuWeight': 0.33, 'memoryWeight': 0.33, 'networkWeight': 0.34},
    ];
    
    final results = <Map<String, dynamic>>[];
    
    for (final scenario in scenarios) {
      final startTime = DateTime.now();
      
      final tasks = <Future<void>>[];
      
      // CPU密集型任务
      if (scenario['cpuWeight'] != null) {
        final cpuTaskCount = (scenario['cpuWeight'] as double * 10).ceil();
        for (int i = 0; i < cpuTaskCount; i++) {
          tasks.add(_generateCpuStress(3000));
        }
      }
      
      // 内存密集型任务
      if (scenario['memoryWeight'] != null) {
        final memoryTaskCount = (scenario['memoryWeight'] as double * 5).ceil();
        tasks.add(_generateMemoryStress(memoryTaskCount * 1000));
      }
      
      // 网络密集型任务
      if (scenario['networkWeight'] != null) {
        final networkTaskCount = (scenario['networkWeight'] as double * 20).ceil();
        for (int i = 0; i < networkTaskCount; i++) {
          tasks.add(_generateNetworkStress());
        }
      }
      
      // 执行混合负载
      final mixedResults = await Future.wait(tasks);
      final endTime = DateTime.now();
      
      final successfulTasks = mixedResults.where((r) => r == true).length;
      final failedTasks = mixedResults.length - successfulTasks;
      
      results.add({
        'scenario': scenario['name'],
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': endTime.difference(startTime).inMilliseconds,
        'totalTasks': mixedResults.length,
        'successfulTasks': successfulTasks,
        'failedTasks': failedTasks,
        'throughput': mixedResults.length / (endTime.difference(startTime).inMilliseconds / 1000),
        'errorRate': failedTasks / mixedResults.length,
        'scenarioConfig': scenario,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      _recordRequest(endTime.difference(startTime).inMilliseconds, failedTasks);
      
      await TestUtils.delay(5000); // 等待系统恢复
    }
    
    _stressSnapshots.add({
      'type': 'mixed_load',
      'results': results,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 测试系统稳定性
  Future<void> _testSystemStability() async {
    print('Testing system stability...');
    
    final stabilityResults = <Map<String, dynamic>>[];
    
    // 长时间运行测试
    final startTime = DateTime.now();
    final testDuration = const Duration(seconds: 30);
    final endTime = startTime.add(testDuration);
    
    int cycleCount = 0;
    final cycles = <Map<String, dynamic>>[];
    
    while (DateTime.now().isBefore(endTime)) {
      final cycleStart = DateTime.now();
      
      // 执行一系列压力操作
      final cycleTasks = <Future>[
        _generateCpuStress(1000),
        _generateMemoryStress(1000),
        _generateNetworkStress(),
        _executeConcurrentStressTask(cycleCount, 500),
      ];
      
      await Future.wait(cycleTasks);
      final cycleEnd = DateTime.now();
      
      cycles.add({
        'cycle': cycleCount,
        'startTime': cycleStart.toIso8601String(),
        'endTime': cycleEnd.toIso8601String(),
        'duration': cycleEnd.difference(cycleStart).inMilliseconds,
        'success': true,
      });
      
      cycleCount++;
      await TestUtils.delay(500); // 500ms间隔
    }
    
    final finalEndTime = DateTime.now();
    
    // 分析稳定性
    final successfulCycles = cycles.where((c) => c['success'] == true).length;
    final totalCycles = cycles.length;
    final stabilityRatio = successfulCycles / totalCycles;
    
    stabilityResults.add({
      'testType': 'long_running',
      'startTime': startTime.toIso8601String(),
      'endTime': finalEndTime.toIso8601String(),
      'totalDuration': finalEndTime.difference(startTime).inMilliseconds,
      'totalCycles': totalCycles,
      'successfulCycles': successfulCycles,
      'stabilityRatio': stabilityRatio,
      'averageCycleTime': cycles.isNotEmpty 
          ? cycles.map((c) => c['duration'] as int).reduce((a, b) => a + b) / cycles.length 
          : 0,
      'cycles': cycles,
      'timestamp': DateTime.now().toIso8601String(),
    });
    
    // 资源耗尽测试
    final exhaustionStart = DateTime.now();
    final exhaustionTasks = <Future<bool>>[];
    
    // 创建大量任务直到系统无法处理
    for (int i = 0; i < 10000; i++) {
      exhaustionTasks.add(_executeResourceExhaustionTask(i));
      
      if (i % 100 == 0) {
        await TestUtils.delay(10);
      }
    }
    
    try {
      final exhaustionResults = await Future.wait(exhaustionTasks);
      final exhaustionEnd = DateTime.now();
      
      final successfulExhaustion = exhaustionResults.where((r) => r == true).length;
      final failedExhaustion = exhaustionResults.length - successfulExhaustion;
      
      stabilityResults.add({
        'testType': 'resource_exhaustion',
        'startTime': exhaustionStart.toIso8601String(),
        'endTime': exhaustionEnd.toIso8601String(),
        'duration': exhaustionEnd.difference(exhaustionStart).inMilliseconds,
        'totalTasks': exhaustionTasks.length,
        'successfulTasks': successfulExhaustion,
        'failedTasks': failedExhaustion,
        'exhaustionPoint': exhaustionTasks.length - successfulExhaustion,
        'errorRate': failedExhaustion / exhaustionTasks.length,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
    } catch (e) {
      final exhaustionEnd = DateTime.now();
      
      stabilityResults.add({
        'testType': 'resource_exhaustion',
        'startTime': exhaustionStart.toIso8601String(),
        'endTime': exhaustionEnd.toIso8601String(),
        'duration': exhaustionEnd.difference(exhaustionStart).inMilliseconds,
        'error': e.toString(),
        'success': false,
        'timestamp': DateTime.now().toIso8601String(),
      });
    }
    
    _stressSnapshots.add({
      'type': 'system_stability',
      'results': stabilityResults,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// 生成CPU压力
  Future<void> _generateCpuStress(int duration) async {
    final endTime = DateTime.now().add(Duration(milliseconds: duration));
    
    while (DateTime.now().isBefore(endTime)) {
      TestUtils.cpuIntensiveTask();
    }
  }

  /// 生成内存压力
  Future<void> _generateMemoryStress(int allocationSize) async {
    try {
      final chunks = <List<int>>[];
      final chunkSize = 1024 * 100; // 100KB块
      
      for (int i = 0; i < allocationSize ~/ chunkSize; i++) {
        chunks.add(TestUtils.memoryIntensiveTask(chunkSize ~/ 4));
        
        if (i % 10 == 0) {
          await TestUtils.delay(1);
        }
      }
      
      // 保持一段时间
      await TestUtils.delay(1000);
      
      // 释放
      chunks.clear();
      
    } catch (e) {
      rethrow;
    }
  }

  /// 生成网络压力
  Future<void> _generateNetworkStress() async {
    try {
      await TestUtils.simulateNetworkRequest(
        delayMs: 100 + Random().nextInt(200),
        shouldFail: Random().nextDouble() < 0.1, // 10%失败率
      );
    } catch (e) {
      // 网络请求失败是预期的
    }
  }

  /// 执行并发压力任务
  Future<Map<String, dynamic>> _executeConcurrentStressTask(int taskId, int duration) async {
    final startTime = DateTime.now();
    
    try {
      // 混合CPU和I/O操作
      TestUtils.cpuIntensiveTask();
      await TestUtils.delay(duration ~/ 4);
      TestUtils.cpuIntensiveTask();
      await TestUtils.delay(duration ~/ 4);
      TestUtils.cpuIntensiveTask();
      
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'duration': actualDuration,
        'success': true,
        'result': 'Stress task $taskId completed',
      };
    } catch (e) {
      final endTime = DateTime.now();
      final actualDuration = endTime.difference(startTime).inMilliseconds;
      
      return {
        'taskId': taskId,
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601(),
        'duration': actualDuration,
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// 模拟压力请求
  Future<Map<String, dynamic>> _simulateStressRequest() async {
    final startTime = DateTime.now();
    
    try {
      final result = await TestUtils.simulateNetworkRequest(
        delayMs: 50 + Random().nextInt(100),
        shouldFail: Random().nextDouble() < 0.05, // 5%失败率
      );
      
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime).inMilliseconds;
      
      return {
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'responseTime': responseTime,
        'success': true,
        'result': result,
      };
    } catch (e) {
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime).inMilliseconds;
      
      return {
        'startTime': startTime.toIso8601String(),
        'endTime': endTime.toIso8601String(),
        'responseTime': responseTime,
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// 执行资源耗尽任务
  Future<bool> _executeResourceExhaustionTask(int taskId) async {
    try {
      // 创建一些资源
      final data = TestUtils.memoryIntensiveTask(1000);
      data.clear(); // 立即释放
      
      // 执行计算
      TestUtils.cpuIntensiveTask();
      
      return true;
    } catch (e) {
      return false;
    }
  }

  /// 监控系统资源
  Future<void> _monitorResources() async {
    final monitoringDuration = const Duration(seconds: 5);
    final endTime = DateTime.now().add(monitoringDuration);
    
    while (DateTime.now().isBefore(endTime)) {
      final memory = TestUtils.getMemoryUsage();
      final cpu = await TestUtils.getCpuUsage();
      
      _stressSnapshots.add({
        'type': 'monitoring',
        'timestamp': DateTime.now().toIso8601String(),
        'memory': memory,
        'cpu': cpu,
      });
      
      await TestUtils.delay(1000);
    }
  }

  /// 重置统计数据
  void _resetStatistics() {
    _totalRequests = 0;
    _successfulRequests = 0;
    _failedRequests = 0;
    _timeoutRequests = 0;
    _responseTimes.clear();
    _errorTypes.clear();
  }

  /// 记录请求
  void _recordRequest(int responseTime, [int errors = 0]) {
    _totalRequests++;
    _successfulRequests++;
    _failedRequests += errors;
    _responseTimes.add(responseTime);
    
    for (int i = 0; i < errors; i++) {
      _errorTypes.add('timeout');
    }
  }

  /// 记录错误
  void _recordError(int responseTime, String errorType) {
    _totalRequests++;
    _failedRequests++;
    _responseTimes.add(responseTime);
    _errorTypes.add(errorType);
  }

  /// 启动压力监控
  void startStressMonitoring() {
    _monitoringTimer = Timer.periodic(
      Duration(milliseconds: TestConfig.sampleInterval),
      (timer) {
        _stressSnapshots.add({
          'type': 'stress_monitoring',
          'timestamp': DateTime.now().toIso8601String(),
          'totalRequests': _totalRequests,
          'successRate': _totalRequests > 0 ? _successfulRequests / _totalRequests : 0,
          'errorRate': _totalRequests > 0 ? _failedRequests / _totalRequests : 0,
          'averageResponseTime': _responseTimes.isNotEmpty 
              ? _responseTimes.reduce((a, b) => a + b) / _responseTimes.length 
              : 0,
        });
      },
    );
  }

  /// 停止压力监控
  void stopStressMonitoring() {
    _monitoringTimer?.cancel();
  }

  /// 分析压力测试结果
  Map<String, dynamic> _analyzeStressResults() {
    final analysis = {
      'snapshots': _stressSnapshots,
      'statistics': {
        'totalRequests': _totalRequests,
        'successfulRequests': _successfulRequests,
        'failedRequests': _failedRequests,
        'timeoutRequests': _timeoutRequests,
        'successRate': _totalRequests > 0 ? _successfulRequests / _totalRequests : 0,
        'errorRate': _totalRequests > 0 ? _failedRequests / _totalRequests : 0,
        'averageResponseTime': _responseTimes.isNotEmpty 
            ? _responseTimes.reduce((a, b) => a + b) / _responseTimes.length 
            : 0,
        'errorTypes': _errorTypes,
      },
      'summary': <String, dynamic>{},
    };
    
    // 分析不同类型的压力测试
    final cpuStress = _stressSnapshots.where((s) => s['type'] == 'cpu_stress').toList();
    final memoryStress = _stressSnapshots.where((s) => s['type'] == 'memory_stress').toList();
    final networkStress = _stressSnapshots.where((s) => s['type'] == 'network_stress').toList();
    final concurrentStress = _stressSnapshots.where((s) => s['type'] == 'concurrent_stress').toList();
    
    if (cpuStress.isNotEmpty) {
      final cpuResults = cpuStress.expand((s) => s['results'] as List).toList();
      analysis['summary']['cpuStress'] = {
        'stressLevels': cpuResults.map((r) => r['stressLevel'] as int).toList(),
        'successRate': cpuResults.where((r) => r['success'] == true).length / cpuResults.length,
        'maxStressLevel': cpuResults.isNotEmpty 
            ? cpuResults.map((r) => r['stressLevel'] as int).reduce((a, b) => a > b ? a : b)
            : 0,
      };
    }
    
    if (networkStress.isNotEmpty) {
      final networkResults = networkStress.expand((s) => s['results'] as List).toList();
      final requestRates = networkResults.map((r) => r['requestRate'] as int).toList();
      final throughputs = networkResults.map((r) => r['throughput'] as double).toList();
      final errorRates = networkResults.map((r) => r['errorRate'] as double).toList();
      
      analysis['summary']['networkStress'] = {
        'requestRates': requestRates,
        'throughputs': throughputs,
        'errorRates': errorRates,
        'maxSustainableRate': _findMaxSustainableRate(requestRates, errorRates),
      };
    }
    
    if (concurrentStress.isNotEmpty) {
      final concurrentResults = concurrentStress.expand((s) => s['results'] as List).toList();
      final concurrencyLevels = concurrentResults.map((r) => r['concurrencyLevel'] as int).toList();
      final errorRates = concurrentResults.map((r) => r['errorRate'] as double).toList();
      
      analysis['summary']['concurrentStress'] = {
        'concurrencyLevels': concurrencyLevels,
        'errorRates': errorRates,
        'maxConcurrency': _findMaxConcurrency(concurrencyLevels, errorRates),
      };
    }
    
    return analysis;
  }

  /// 找到最大可持续请求率
  int _findMaxSustainableRate(List<int> rates, List<double> errorRates) {
    for (int i = 0; i < rates.length; i++) {
      if (errorRates[i] > 0.1) { // 错误率超过10%
        return i > 0 ? rates[i - 1] : rates.first;
      }
    }
    return rates.isNotEmpty ? rates.last : 0;
  }

  /// 找到最大并发数
  int _findMaxConcurrency(List<int> concurrencyLevels, List<double> errorRates) {
    for (int i = 0; i < concurrencyLevels.length; i++) {
      if (errorRates[i] > 0.1) { // 错误率超过10%
        return i > 0 ? concurrencyLevels[i - 1] : concurrencyLevels.first;
      }
    }
    return concurrencyLevels.isNotEmpty ? concurrencyLevels.last : 0;
  }

  /// 评估压力测试结果
  bool _evaluateStressTest(Map<String, dynamic> metrics) {
    final statistics = metrics['statistics'] as Map<String, dynamic>;
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    // 检查整体成功率
    final successRate = statistics['successRate'] as double;
    if (successRate < 0.8) { // 成功率低于80%
      _recommendations.add('压力测试成功率较低：${(successRate * 100).toStringAsFixed(1)}%，系统可能在高负载下不稳定');
      return false;
    }
    
    // 检查网络压力
    final networkStress = summary['networkStress'] as Map<String, dynamic>? ?? {};
    final maxRate = networkStress['maxSustainableRate'] as int? ?? 0;
    
    if (maxRate < 100) { // 最大可持续请求率低于100/s
      _recommendations.add('网络处理能力不足，最大可持续请求率：${maxRate}/秒，建议优化网络处理');
      return false;
    }
    
    // 检查并发压力
    final concurrentStress = summary['concurrentStress'] as Map<String, dynamic>? ?? {};
    final maxConcurrency = concurrentStress['maxConcurrency'] as int? ?? 0;
    
    if (maxConcurrency < 100) { // 最大并发数低于100
      _recommendations.add('并发处理能力不足，最大并发数：${maxConcurrency}，建议优化并发机制');
      return false;
    }
    
    // 检查错误类型分布
    final errorTypes = statistics['errorTypes'] as List<String>? ?? [];
    final timeoutCount = errorTypes.where((type) => type == 'timeout').length;
    final timeoutRatio = errorTypes.isNotEmpty ? timeoutCount / errorTypes.length : 0;
    
    if (timeoutRatio > 0.5) { // 超时错误占比超过50%
      _recommendations.add('超时错误较多：${(timeoutRatio * 100).toStringAsFixed(1)}%，建议增加超时时间或优化响应速度');
    }
    
    return true;
  }

  /// 生成压力优化建议
  void _generateStressRecommendations(Map<String, dynamic> metrics) {
    final summary = metrics['summary'] as Map<String, dynamic>;
    
    final networkStress = summary['networkStress'] as Map<String, dynamic>? ?? {};
    final maxRate = networkStress['maxSustainableRate'] as int? ?? 0;
    
    if (maxRate < 500) {
      _recommendations.add('实施负载均衡和连接池技术，提高网络处理能力');
    }
    
    _recommendations.add('实施优雅降级策略，在高负载时优先保证核心功能');
    _recommendations.add('使用限流和熔断机制，防止系统过载');
    _recommendations.add('实施缓存策略，减少数据库和外部服务压力');
    _recommendations.add('优化资源管理，及时释放不再使用的资源');
    _recommendations.add('实施监控和告警系统，及时发现和处理性能问题');
    _recommendations.add('考虑水平扩展，提高系统整体处理能力');
  }
}