import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:math' as math;
import '../utils/test_utils.dart';
import '../utils/test_config.dart';

/// 报告生成器类
/// 用于生成详细的性能分析和优化建议报告
class ReportGenerator {
  static const String _reportsDir = 'reports';
  
  /// 生成综合性能报告
  Future<void> generateComprehensiveReport(List<TestResult> testResults) async {
    print('Generating comprehensive performance report...');
    
    // 确保报告目录存在
    await _ensureReportsDirectory();
    
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
    
    // 生成不同格式的报告
    await _generateHtmlReport(testResults, 'comprehensive_report_$timestamp.html');
    await _generateJsonReport(testResults, 'comprehensive_report_$timestamp.json');
    await _generateCsvReport(testResults, 'comprehensive_report_$timestamp.csv');
    await _generatePdfReport(testResults, 'comprehensive_report_$timestamp.pdf');
    
    print('Comprehensive performance report generated successfully!');
  }

  /// 生成HTML报告
  Future<void> _generateHtmlReport(List<TestResult> testResults, String filename) async {
    final html = StringBuffer();
    
    html.writeln('''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>性能测试综合报告</title>
    <style>
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #2196F3;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #2196F3;
            margin: 0;
            font-size: 2.5em;
        }
        .header .subtitle {
            color: #666;
            font-size: 1.2em;
            margin-top: 10px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .summary-card h3 {
            margin: 0 0 10px 0;
            font-size: 1.1em;
        }
        .summary-card .value {
            font-size: 2em;
            font-weight: bold;
        }
        .test-section {
            margin-bottom: 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }
        .test-header {
            background-color: #2196F3;
            color: white;
            padding: 15px 20px;
            font-size: 1.3em;
            font-weight: bold;
        }
        .test-content {
            padding: 20px;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .metric-item {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #2196F3;
        }
        .metric-label {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .metric-value {
            font-size: 1.1em;
            color: #666;
        }
        .status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9em;
        }
        .status-pass {
            background-color: #4CAF50;
            color: white;
        }
        .status-fail {
            background-color: #f44336;
            color: white;
        }
        .recommendations {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
        }
        .recommendations h4 {
            color: #856404;
            margin-top: 0;
        }
        .recommendations ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        .recommendations li {
            margin-bottom: 8px;
            color: #856404;
        }
        .chart-container {
            margin: 20px 0;
            text-align: center;
        }
        .chart {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #666;
        }
        .timestamp {
            color: #999;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 性能测试综合报告</h1>
            <div class="subtitle">全面的性能分析和优化建议</div>
            <div class="timestamp">生成时间: ${DateTime.now().toLocal().toString()}</div>
        </div>''');

    // 添加总结统计
    final summaryStats = _calculateSummaryStats(testResults);
    html.writeln('''
        <div class="summary">
            <div class="summary-card">
                <h3>总测试数</h3>
                <div class="value">${testResults.length}</div>
            </div>
            <div class="summary-card">
                <h3>通过测试</h3>
                <div class="value">${summaryStats['passedTests']}</div>
            </div>
            <div class="summary-card">
                <h3>失败测试</h3>
                <div class="value">${summaryStats['failedTests']}</div>
            </div>
            <div class="summary-card">
                <h3>成功率</h3>
                <div class="value">${(summaryStats['successRate'] * 100).toStringAsFixed(1)}%</div>
            </div>
        </div>''');

    // 为每个测试结果生成详细报告
    for (final result in testResults) {
      html.write(_generateTestSectionHtml(result));
    }

    // 添加优化建议
    final allRecommendations = _collectAllRecommendations(testResults);
    if (allRecommendations.isNotEmpty) {
      html.writeln('''
        <div class="recommendations">
            <h4>💡 综合优化建议</h4>
            <ul>''');
      for (final recommendation in allRecommendations) {
        html.writeln('                <li>$recommendation</li>');
      }
      html.writeln('''            </ul>
        </div>''');
    }

    html.writeln('''
        <div class="footer">
            <p>本报告由性能测试套件自动生成</p>
            <p>建议定期运行性能测试以监控系统健康状况</p>
        </div>
    </div>
</body>
</html>''');

    await TestUtils.saveToFile('$_reportsDir/$filename', html.toString());
  }

  /// 生成JSON报告
  Future<void> _generateJsonReport(List<TestResult> testResults, String filename) async {
    final jsonData = {
      'reportInfo': {
        'title': '性能测试综合报告',
        'generatedAt': DateTime.now().toIso8601String(),
        'version': '1.0.0',
      },
      'summary': _calculateSummaryStats(testResults),
      'testResults': testResults.map((result) => result.toJson()).toList(),
      'recommendations': _collectAllRecommendations(testResults),
      'systemInfo': {
        'platform': Platform.operatingSystem,
        'dartVersion': Platform.version,
        'processorCount': Platform.numberOfProcessors,
      },
    };

    final jsonString = TestUtils.createJsonReport(jsonData);
    await TestUtils.saveToFile('$_reportsDir/$filename', jsonString);
  }

  /// 生成CSV报告
  Future<void> _generateCsvReport(List<TestResult> testResults, String filename) async {
    final csv = StringBuffer();
    
    // CSV头部
    csv.writeln('测试名称,开始时间,结束时间,持续时间(ms),测试状态,错误信息');
    
    // 数据行
    for (final result in testResults) {
      final duration = result.endTime.difference(result.startTime).inMilliseconds;
      csv.writeln([
        '"${result.testName}"',
        '"${result.startTime.toIso8601String()}"',
        '"${result.endTime.toIso8601String()}"',
        duration.toString(),
        result.passed ? 'PASS' : 'FAIL',
        '"${result.errorMessage ?? ''}"',
      ].join(','));
    }
    
    await TestUtils.saveToFile('$_reportsDir/$filename', csv.toString());
  }

  /// 生成PDF报告（简单版本，实际应用中可能需要使用PDF库）
  Future<void> _generatePdfReport(List<TestResult> testResults, String filename) async {
    final pdfContent = StringBuffer();
    
    pdfContent.writeln('性能测试综合报告');
    pdfContent.writeln('=' * 50);
    pdfContent.writeln();
    pdfContent.writeln('生成时间: ${DateTime.now().toLocal().toString()}');
    pdfContent.writeln();
    
    // 总结统计
    final summaryStats = _calculateSummaryStats(testResults);
    pdfContent.writeln('总结统计:');
    pdfContent.writeln('  总测试数: ${summaryStats['totalTests']}');
    pdfContent.writeln('  通过测试: ${summaryStats['passedTests']}');
    pdfContent.writeln('  失败测试: ${summaryStats['failedTests']}');
    pdfContent.writeln('  成功率: ${(summaryStats['successRate'] * 100).toStringAsFixed(1)}%');
    pdfContent.writeln();
    
    // 测试结果详情
    pdfContent.writeln('测试结果详情:');
    pdfContent.writeln('-' * 30);
    
    for (final result in testResults) {
      final duration = result.endTime.difference(result.startTime).inMilliseconds;
      pdfContent.writeln();
      pdfContent.writeln('测试名称: ${result.testName}');
      pdfContent.writeln('  状态: ${result.passed ? "通过" : "失败"}');
      pdfContent.writeln('  持续时间: ${duration}ms');
      pdfContent.writeln('  开始时间: ${result.startTime.toIso8601String()}');
      pdfContent.writeln('  结束时间: ${result.endTime.toIso8601String()}');
      
      if (result.errorMessage != null) {
        pdfContent.writeln('  错误信息: ${result.errorMessage}');
      }
      
      if (result.metrics.isNotEmpty) {
        pdfContent.writeln('  关键指标:');
        for (final entry in result.metrics.entries.take(5)) {
          pdfContent.writeln('    ${entry.key}: ${entry.value}');
        }
      }
    }
    
    // 优化建议
    final allRecommendations = _collectAllRecommendations(testResults);
    if (allRecommendations.isNotEmpty) {
      pdfContent.writeln();
      pdfContent.writeln('优化建议:');
      pdfContent.writeln('-' * 20);
      for (int i = 0; i < allRecommendations.length; i++) {
        pdfContent.writeln('${i + 1}. ${allRecommendations[i]}');
      }
    }
    
    await TestUtils.saveToFile('$_reportsDir/$filename', pdfContent.toString());
  }

  /// 生成测试部分的HTML
  String _generateTestSectionHtml(TestResult result) {
    final duration = result.endTime.difference(result.startTime).inMilliseconds;
    final status = result.passed ? 'PASS' : 'FAIL';
    final statusClass = result.passed ? 'status-pass' : 'status-fail';
    
    final section = StringBuffer();
    
    section.writeln('''
        <div class="test-section">
            <div class="test-header">
                ${result.testName}
                <span class="status $statusClass" style="float: right;">$status</span>
            </div>
            <div class="test-content">
                <div class="metrics-grid">''');
    
    // 添加基本指标
    section.writeln('''
                    <div class="metric-item">
                        <div class="metric-label">测试状态</div>
                        <div class="metric-value">${result.passed ? '通过' : '失败'}</div>
                    </div>
                    <div class="metric-item">
                        <div class="metric-label">持续时间</div>
                        <div class="metric-value">${TestUtils.formatDuration(Duration(milliseconds: duration))}</div>
                    </div>
                    <div class="metric-item">
                        <div class="metric-label">开始时间</div>
                        <div class="metric-value">${result.startTime.toLocal().toString()}</div>
                    </div>
                    <div class="metric-item">
                        <div class="metric-label">结束时间</div>
                        <div class="metric-value">${result.endTime.toLocal().toString()}</div>
                    </div>''');
    
    // 添加具体指标
    if (result.metrics.isNotEmpty) {
      section.writeln('                    <div class="metric-item">');
      section.writeln('                        <div class="metric-label">关键指标</div>');
      section.writeln('                        <div class="metric-value">');
      
      final metricsToShow = result.metrics.entries.take(3);
      for (final entry in metricsToShow) {
        section.writeln('                            ${entry.key}: ${entry.value}<br>');
      }
      
      section.writeln('                        </div>');
      section.writeln('                    </div>');
    }
    
    // 添加错误信息
    if (result.errorMessage != null) {
      section.writeln('''
                    <div class="metric-item">
                        <div class="metric-label">错误信息</div>
                        <div class="metric-value" style="color: #f44336;">${result.errorMessage}</div>
                    </div>''');
    }
    
    section.writeln('''                </div>''');
    
    // 添加优化建议
    if (result.recommendations.isNotEmpty) {
      section.writeln('''
                <div class="recommendations">
                    <h4>💡 优化建议</h4>
                    <ul>''');
      
      for (final recommendation in result.recommendations) {
        section.writeln('                        <li>$recommendation</li>');
      }
      
      section.writeln('''                    </ul>
                </div>''');
    }
    
    section.writeln('''            </div>
        </div>''');
    
    return section.toString();
  }

  /// 计算总结统计
  Map<String, dynamic> _calculateSummaryStats(List<TestResult> testResults) {
    final totalTests = testResults.length;
    final passedTests = testResults.where((result) => result.passed).length;
    final failedTests = totalTests - passedTests;
    final successRate = totalTests > 0 ? passedTests / totalTests : 0;
    
    // 计算平均测试时间
    final totalDuration = testResults.fold<int>(
      0,
      (sum, result) => sum + result.endTime.difference(result.startTime).inMilliseconds,
    );
    final averageDuration = totalTests > 0 ? totalDuration / totalTests : 0;
    
    return {
      'totalTests': totalTests,
      'passedTests': passedTests,
      'failedTests': failedTests,
      'successRate': successRate,
      'averageDuration': averageDuration,
      'totalDuration': totalDuration,
    };
  }

  /// 收集所有优化建议
  List<String> _collectAllRecommendations(List<TestResult> testResults) {
    final allRecommendations = <String>[];
    
    for (final result in testResults) {
      allRecommendations.addAll(result.recommendations);
    }
    
    // 去重并按优先级排序
    final uniqueRecommendations = allRecommendations.toSet().toList();
    
    return uniqueRecommendations;
  }

  /// 确保报告目录存在
  Future<void> _ensureReportsDirectory() async {
    final directory = Directory(_reportsDir);
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
  }

  /// 生成可视化图表数据
  Map<String, dynamic> _generateChartData(List<TestResult> testResults) {
    final chartData = {
      'testDurations': testResults.map((result) {
        return {
          'testName': result.testName,
          'duration': result.endTime.difference(result.startTime).inMilliseconds,
          'passed': result.passed,
        };
      }).toList(),
      'testSuccessRates': _calculateSuccessRates(testResults),
      'performanceMetrics': _extractPerformanceMetrics(testResults),
    };
    
    return chartData;
  }

  /// 计算成功率数据
  List<Map<String, dynamic>> _calculateSuccessRates(List<TestResult> testResults) {
    final testTypes = <String>{};
    for (final result in testResults) {
      // 从测试名称中提取测试类型
      if (result.testName.contains('Memory')) {
        testTypes.add('Memory');
      } else if (result.testName.contains('CPU')) {
        testTypes.add('CPU');
      } else if (result.testName.contains('Battery')) {
        testTypes.add('Battery');
      } else if (result.testName.contains('Network')) {
        testTypes.add('Network');
      } else if (result.testName.contains('Concurrent')) {
        testTypes.add('Concurrent');
      } else if (result.testName.contains('Stress')) {
        testTypes.add('Stress');
      }
    }
    
    final rates = <Map<String, dynamic>>[];
    
    for (final testType in testTypes) {
      final typeResults = testResults.where((r) => r.testName.contains(testType)).toList();
      final passedCount = typeResults.where((r) => r.passed).length;
      final totalCount = typeResults.length;
      final rate = totalCount > 0 ? passedCount / totalCount : 0;
      
      rates.add({
        'testType': testType,
        'passed': passedCount,
        'total': totalCount,
        'rate': rate,
      });
    }
    
    return rates;
  }

  /// 提取性能指标
  Map<String, dynamic> _extractPerformanceMetrics(List<TestResult> testResults) {
    final metrics = <String, dynamic>{};
    
    for (final result in testResults) {
      if (result.metrics.isNotEmpty) {
        // 提取数值类型的指标
        for (final entry in result.metrics.entries) {
          if (entry.value is num) {
            if (!metrics.containsKey(entry.key)) {
              metrics[entry.key] = <num>[];
            }
            metrics[entry.key].add(entry.value as num);
          }
        }
      }
    }
    
    // 计算统计值
    final processedMetrics = <String, dynamic>{};
    for (final entry in metrics.entries) {
      final values = entry.value as List<num>;
      if (values.isNotEmpty) {
        processedMetrics[entry.key] = {
          'min': values.reduce(math.min),
          'max': values.reduce(math.max),
          'average': values.reduce((a, b) => a + b) / values.length,
          'count': values.length,
        };
      }
    }
    
    return processedMetrics;
  }

  /// 生成性能基准比较
  Future<void> generateBenchmarkComparison(Map<String, dynamic> currentResults, Map<String, dynamic> baselineResults) async {
    await _ensureReportsDirectory();
    
    final comparison = {
      'comparisonInfo': {
        'title': '性能基准比较报告',
        'generatedAt': DateTime.now().toIso8601String(),
        'baselineDate': baselineResults['baselineDate'] ?? 'Unknown',
        'currentDate': DateTime.now().toIso8601String(),
      },
      'performanceComparison': _comparePerformance(currentResults, baselineResults),
      'trends': _analyzePerformanceTrends(currentResults, baselineResults),
      'recommendations': _generateComparisonRecommendations(currentResults, baselineResults),
    };
    
    final jsonString = TestUtils.createJsonReport(comparison);
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
    await TestUtils.saveToFile('$_reportsDir/benchmark_comparison_$timestamp.json', jsonString);
    
    print('Benchmark comparison report generated successfully!');
  }

  /// 比较性能数据
  Map<String, dynamic> _comparePerformance(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final comparison = <String, dynamic>{};
    
    // 比较各个指标
    final metrics = ['responseTime', 'throughput', 'errorRate', 'cpuUsage', 'memoryUsage'];
    
    for (final metric in metrics) {
      final currentValue = current[metric] as num?;
      final baselineValue = baseline[metric] as num?;
      
      if (currentValue != null && baselineValue != null && baselineValue != 0) {
        final changePercent = ((currentValue - baselineValue) / baselineValue) * 100;
        comparison[metric] = {
          'current': currentValue,
          'baseline': baselineValue,
          'change': currentValue - baselineValue,
          'changePercent': changePercent,
          'status': changePercent > 5 ? 'improved' : (changePercent < -5 ? 'degraded' : 'stable'),
        };
      }
    }
    
    return comparison;
  }

  /// 分析性能趋势
  Map<String, dynamic> _analyzePerformanceTrends(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final trends = <String, dynamic>{};
    
    // 分析各个方面的趋势
    trends['overall'] = _calculateOverallTrend(current, baseline);
    trends['stability'] = _analyzeStabilityTrend(current, baseline);
    trends['scalability'] = _analyzeScalabilityTrend(current, baseline);
    
    return trends;
  }

  /// 计算整体趋势
  Map<String, dynamic> _calculateOverallTrend(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final metrics = ['responseTime', 'throughput', 'errorRate'];
    final changes = <double>[];
    
    for (final metric in metrics) {
      final currentValue = current[metric] as num?;
      final baselineValue = baseline[metric] as num?;
      
      if (currentValue != null && baselineValue != null) {
        final changePercent = ((currentValue - baselineValue) / baselineValue) * 100;
        changes.add(changePercent);
      }
    }
    
    final averageChange = changes.isNotEmpty 
        ? changes.reduce((a, b) => a + b) / changes.length 
        : 0;
    
    return {
      'averageChange': averageChange,
      'trend': averageChange > 5 ? 'improving' : (averageChange < -5 ? 'declining' : 'stable'),
      'confidence': changes.isNotEmpty ? (changes.length / metrics.length) : 0,
    };
  }

  /// 分析稳定性趋势
  Map<String, dynamic> _analyzeStabilityTrend(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final currentStability = current['stability'] as num? ?? 0;
    final baselineStability = baseline['stability'] as num? ?? 0;
    
    final stabilityChange = currentStability - baselineStability;
    
    return {
      'currentStability': currentStability,
      'baselineStability': baselineStability,
      'change': stabilityChange,
      'trend': stabilityChange > 0.1 ? 'more_stable' : (stabilityChange < -0.1 ? 'less_stable' : 'stable'),
    };
  }

  /// 分析可扩展性趋势
  Map<String, dynamic> _analyzeScalabilityTrend(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final currentScalability = current['scalability'] as num? ?? 0;
    final baselineScalability = baseline['scalability'] as num? ?? 0;
    
    final scalabilityChange = currentScalability - baselineScalability;
    
    return {
      'currentScalability': currentScalability,
      'baselineScalability': baselineScalability,
      'change': scalabilityChange,
      'trend': scalabilityChange > 0.1 ? 'more_scalable' : (scalabilityChange < -0.1 ? 'less_scalable' : 'stable'),
    };
  }

  /// 生成比较建议
  List<String> _generateComparisonRecommendations(Map<String, dynamic> current, Map<String, dynamic> baseline) {
    final recommendations = <String>[];
    
    final comparison = _comparePerformance(current, baseline);
    
    for (final entry in comparison.entries) {
      final metricComparison = entry.value as Map<String, dynamic>;
      final status = metricComparison['status'] as String;
      final changePercent = metricComparison['changePercent'] as double;
      
      if (status == 'degraded' && changePercent < -10) {
        recommendations.add('${entry.key}性能显著下降(${changePercent.toStringAsFixed(1)}%)，建议立即调查原因');
      } else if (status == 'improved' && changePercent > 10) {
        recommendations.add('${entry.key}性能显著改善(${changePercent.toStringAsFixed(1)}%)，可以分析成功因素并应用到其他方面');
      }
    }
    
    return recommendations;
  }

  /// 生成历史趋势报告
  Future<void> generateHistoricalTrendReport(List<Map<String, dynamic>> historicalData) async {
    await _ensureReportsDirectory();
    
    final trendAnalysis = {
      'trendInfo': {
        'title': '性能历史趋势报告',
        'generatedAt': DateTime.now().toIso8601String(),
        'dataPoints': historicalData.length,
        'dateRange': {
          'start': historicalData.isNotEmpty ? historicalData.first['timestamp'] : 'Unknown',
          'end': historicalData.isNotEmpty ? historicalData.last['timestamp'] : 'Unknown',
        },
      },
      'trendAnalysis': _analyzeHistoricalTrends(historicalData),
      'predictions': _generatePerformancePredictions(historicalData),
      'recommendations': _generateHistoricalRecommendations(historicalData),
    };
    
    final jsonString = TestUtils.createJsonReport(trendAnalysis);
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
    await TestUtils.saveToFile('$_reportsDir/historical_trend_$timestamp.json', jsonString);
    
    print('Historical trend report generated successfully!');
  }

  /// 分析历史趋势
  Map<String, dynamic> _analyzeHistoricalTrends(List<Map<String, dynamic>> historicalData) {
    if (historicalData.length < 2) {
      return {'error': 'Insufficient data for trend analysis'};
    }
    
    final trends = <String, dynamic>{};
    final metrics = ['responseTime', 'throughput', 'errorRate', 'cpuUsage', 'memoryUsage'];
    
    for (final metric in metrics) {
      final values = historicalData
          .map((data) => data[metric] as num?)
          .where((value) => value != null)
          .map((value) => value!)
          .toList();
      
      if (values.length >= 2) {
        trends[metric] = _calculateTrend(values);
      }
    }
    
    return trends;
  }

  /// 计算趋势
  Map<String, dynamic> _calculateTrend(List<num> values) {
    if (values.length < 2) {
      return {'trend': 'insufficient_data'};
    }
    
    final firstValue = values.first.toDouble();
    final lastValue = values.last.toDouble();
    final change = lastValue - firstValue;
    final changePercent = firstValue != 0 ? (change / firstValue) * 100 : 0;
    
    // 计算线性回归斜率
    final n = values.length;
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    
    for (int i = 0; i < n; i++) {
      sumX += i;
      sumY += values[i].toDouble();
      sumXY += i * values[i].toDouble();
      sumX2 += i * i;
    }
    
    final slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    
    return {
      'firstValue': firstValue,
      'lastValue': lastValue,
      'change': change,
      'changePercent': changePercent,
      'slope': slope,
      'trend': slope > 0.01 ? 'increasing' : (slope < -0.01 ? 'decreasing' : 'stable'),
      'strength': slope.abs() > 0.1 ? 'strong' : (slope.abs() > 0.01 ? 'moderate' : 'weak'),
    };
  }

  /// 生成性能预测
  Map<String, dynamic> _generatePerformancePredictions(List<Map<String, dynamic>> historicalData) {
    final predictions = <String, dynamic>{};
    final metrics = ['responseTime', 'throughput', 'errorRate'];
    
    for (final metric in metrics) {
      final values = historicalData
          .map((data) => data[metric] as num?)
          .where((value) => value != null)
          .map((value) => value!)
          .toList();
      
      if (values.length >= 3) {
        predictions[metric] = _predictNextValue(values);
      }
    }
    
    return predictions;
  }

  /// 预测下一个值（简单线性预测）
  Map<String, dynamic> _predictNextValue(List<num> values) {
    final n = values.length;
    
    // 使用线性回归预测
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    
    for (int i = 0; i < n; i++) {
      sumX += i;
      sumY += values[i].toDouble();
      sumXY += i * values[i].toDouble();
      sumX2 += i * i;
    }
    
    final slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    final intercept = (sumY - slope * sumX) / n;
    
    final nextValue = slope * n + intercept;
    
    return {
      'predictedValue': nextValue,
      'confidence': _calculatePredictionConfidence(values),
      'trend': slope > 0 ? 'increasing' : (slope < 0 ? 'decreasing' : 'stable'),
    };
  }

  /// 计算预测置信度
  double _calculatePredictionConfidence(List<num> values) {
    if (values.length < 3) return 0;
    
    // 计算相关系数的平方作为置信度
    final n = values.length;
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
    
    for (int i = 0; i < n; i++) {
      final x = i.toDouble();
      final y = values[i].toDouble();
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumX2 += x * x;
      sumY2 += y * y;
    }
    
    final numerator = n * sumXY - sumX * sumY;
    final denominator = math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
    
    final correlation = denominator != 0 ? numerator / denominator : 0;
    return (correlation * correlation).clamp(0.0, 1.0);
  }

  /// 生成历史建议
  List<String> _generateHistoricalRecommendations(List<Map<String, dynamic>> historicalData) {
    final recommendations = <String>[];
    
    if (historicalData.length < 5) {
      recommendations.add('历史数据点不足，建议至少收集5个数据点以获得更准确的趋势分析');
      return recommendations;
    }
    
    // 分析响应时间趋势
    final responseTimes = historicalData
        .map((data) => data['responseTime'] as num?)
        .where((value) => value != null)
        .map((value) => value!)
        .toList();
    
    if (responseTimes.length >= 3) {
      final trend = _calculateTrend(responseTimes);
      if (trend['trend'] == 'increasing') {
        recommendations.add('响应时间呈上升趋势，建议检查系统负载和性能瓶颈');
      } else if (trend['trend'] == 'decreasing') {
        recommendations.add('响应时间持续改善，当前优化措施效果良好');
      }
    }
    
    // 分析错误率趋势
    final errorRates = historicalData
        .map((data) => data['errorRate'] as num?)
        .where((value) => value != null)
        .map((value) => value!)
        .toList();
    
    if (errorRates.length >= 3) {
      final trend = _calculateTrend(errorRates);
      if (trend['trend'] == 'increasing' && (trend['lastValue'] as double) > 5) {
        recommendations.add('错误率持续上升且超过5%，建议加强错误处理和监控');
      }
    }
    
    // 分析CPU使用率趋势
    final cpuUsages = historicalData
        .map((data) => data['cpuUsage'] as num?)
        .where((value) => value != null)
        .map((value) => value!)
        .toList();
    
    if (cpuUsages.length >= 3) {
      final trend = _calculateTrend(cpuUsages);
      if (trend['trend'] == 'increasing' && (trend['lastValue'] as double) > 80) {
        recommendations.add('CPU使用率持续上升且超过80%，建议优化算法或增加计算资源');
      }
    }
    
    return recommendations;
  }
}