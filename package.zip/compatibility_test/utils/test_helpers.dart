/// 测试帮助类
/// 
/// 提供兼容性测试中使用的辅助方法和工具函数

import 'dart:math' as math;
import '../main_test_runner.dart';

/// 测试帮助类
class TestHelpers {
  
  /// 生成模拟设备信息
  static DeviceInfo generateMockDeviceInfo({
    String? brand,
    String? model,
    String? androidVersion,
    int? apiLevel,
    String? screenResolution,
    int? ramSize,
    int? storageSize,
  }) {
    return DeviceInfo(
      brand: brand ?? 'TestBrand',
      model: model ?? 'TestModel',
      androidVersion: androidVersion ?? '11.0',
      apiLevel: apiLevel ?? 30,
      screenResolution: screenResolution ?? '1920x1080',
      ramSize: ramSize ?? 8,
      storageSize: storageSize ?? 128,
    );
  }

  /// 生成随机测试结果
  static TestResult generateRandomTestResult({
    required String testName,
    int minTests = 5,
    int maxTests = 20,
    double passRateMin = 0.6,
    double passRateMax = 0.95,
  }) {
    final random = math.Random();
    final totalTests = minTests + random.nextInt(maxTests - minTests + 1);
    final passRate = passRateMin + random.nextDouble() * (passRateMax - passRateMin);
    final passedTests = (totalTests * passRate).round();
    final failedTests = totalTests - passedTests;
    
    final failureDetails = <String>[];
    for (int i = 0; i < failedTests; i++) {
      failureDetails.add('模拟失败详情 $i');
    }
    
    final recommendations = <String>[];
    if (failedTests > 0) {
      recommendations.add('建议改进项 ${random.nextInt(5) + 1}');
    }
    
    return TestResult(
      testName: testName,
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: failedTests,
      failureDetails: failureDetails,
      recommendations: recommendations,
      executionTime: Duration(seconds: random.nextInt(30) + 1),
      metadata: {
        'mockData': true,
        'randomSeed': random.nextInt(1000000),
      },
    );
  }

  /// 生成模拟测试配置
  static TestConfig generateMockTestConfig({
    String? testScenario,
    DeviceInfo? deviceInfo,
    bool enablePerformanceTest = true,
    bool enableNetworkTest = true,
    bool enablePermissionTest = true,
    bool generateDetailedReport = true,
  }) {
    return TestConfig(
      deviceInfo: deviceInfo ?? generateMockDeviceInfo(),
      testScenario: testScenario ?? 'comprehensive',
      enablePerformanceTest: enablePerformanceTest,
      enableNetworkTest: enableNetworkTest,
      enablePermissionTest: enablePermissionTest,
      generateDetailedReport: generateDetailedReport,
    );
  }

  /// 模拟测试延迟
  static Future<void> simulateTestDelay({
    int minMs = 100,
    int maxMs = 1000,
  }) {
    final random = math.Random();
    final delay = Duration(milliseconds: minMs + random.nextInt(maxMs - minMs + 1));
    return Future.delayed(delay);
  }

  /// 生成模拟网络延迟
  static Duration simulateNetworkDelay(String networkType) {
    final delays = {
      '2G': Duration(seconds: 3),
      '3G': Duration(seconds: 1),
      '4G': Duration(milliseconds: 500),
      '5G': Duration(milliseconds: 100),
      'WiFi': Duration(milliseconds: 200),
      'Ethernet': Duration(milliseconds: 50),
      'Offline': Duration(seconds: 5),
    };
    
    return delays[networkType] ?? Duration(milliseconds: 300);
  }

  /// 计算兼容性得分
  static double calculateCompatibilityScore(List<TestResult> results) {
    if (results.isEmpty) return 0.0;
    
    final totalTests = results.fold<int>(0, (sum, result) => sum + result.totalTests);
    final passedTests = results.fold<int>(0, (sum, result) => sum + result.passedTests);
    
    return totalTests > 0 ? (passedTests / totalTests) * 100 : 0.0;
  }

  /// 验证测试结果数据完整性
  static List<String> validateTestResults(List<TestResult> results) {
    final issues = <String>[];
    
    for (int i = 0; i < results.length; i++) {
      final result = results[i];
      
      // 验证总数和通过数的关系
      if (result.passedTests > result.totalTests) {
        issues.add('测试结果 $i: 通过测试数大于总测试数');
      }
      
      // 验证失败数计算
      final expectedFailed = result.totalTests - result.passedTests;
      if (result.failedTests != expectedFailed) {
        issues.add('测试结果 $i: 失败测试数计算错误');
      }
      
      // 验证通过率计算
      final expectedPassRate = result.totalTests > 0 ? 
          (result.passedTests / result.totalTests) * 100 : 0.0;
      final actualPassRate = result.passRate;
      final difference = (expectedPassRate - actualPassRate).abs();
      
      if (difference > 0.01) { // 允许0.01%的误差
        issues.add('测试结果 $i: 通过率计算错误 (期望: ${expectedPassRate.toStringAsFixed(2)}%, 实际: ${actualPassRate.toStringAsFixed(2)}%)');
      }
    }
    
    return issues;
  }

  /// 生成测试报告摘要
  static TestReportSummary generateTestReportSummary(TestReport report) {
    final totalTests = report.results.fold<int>(0, (sum, result) => sum + result.totalTests);
    final passedTests = report.results.fold<int>(0, (sum, result) => sum + result.passedTests);
    final failedTests = report.results.fold<int>(0, (sum, result) => sum + result.failedTests);
    
    final overallPassRate = totalTests > 0 ? (passedTests / totalTests) * 100 : 0.0;
    
    final testCategories = <String, int>{};
    for (final result in report.results) {
      testCategories[result.testName] = result.passedTests;
    }
    
    final totalExecutionTime = report.results
        .fold<Duration>(Duration.zero, (sum, result) => sum + result.executionTime);
    
    return TestReportSummary(
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: failedTests,
      overallPassRate: overallPassRate,
      testCategories: testCategories,
      totalExecutionTime: totalExecutionTime,
      deviceInfo: report.deviceInfo,
      testScenarios: report.testScenarios,
      timestamp: report.timestamp,
    );
  }

  /// 模拟性能测试
  static Future<PerformanceTestResult> simulatePerformanceTest({
    required String testType,
    int iterations = 10,
    Duration? maxDuration,
  }) async {
    final random = math.Random();
    final results = <double>[];
    final startTime = DateTime.now();
    
    for (int i = 0; i < iterations; i++) {
      await simulateTestDelay(minMs: 50, maxMs: 200);
      
      // 模拟性能数据
      final performanceScore = 60.0 + random.nextDouble() * 40.0; // 60-100分
      results.add(performanceScore);
      
      if (maxDuration != null && 
          DateTime.now().difference(startTime) > maxDuration) {
        break;
      }
    }
    
    final averageScore = results.isEmpty ? 0.0 : 
        results.reduce((a, b) => a + b) / results.length;
    final minScore = results.isEmpty ? 0.0 : results.reduce(math.min);
    final maxScore = results.isEmpty ? 0.0 : results.reduce(math.max);
    final standardDeviation = _calculateStandardDeviation(results);
    
    return PerformanceTestResult(
      testType: testType,
      iterations: results.length,
      averageScore: averageScore,
      minScore: minScore,
      maxScore: maxScore,
      standardDeviation: standardDeviation,
      executionTime: DateTime.now().difference(startTime),
      results: results,
    );
  }

  /// 计算标准差
  static double _calculateStandardDeviation(List<double> values) {
    if (values.isEmpty) return 0.0;
    
    final mean = values.reduce((a, b) => a + b) / values.length;
    final squaredDifferences = values.map((value) => math.pow(value - mean, 2)).toList();
    final variance = squaredDifferences.reduce((a, b) => a + b) / values.length;
    
    return math.sqrt(variance);
  }

  /// 生成兼容性矩阵
  static CompatibilityMatrix generateCompatibilityMatrix(List<TestResult> results) {
    final matrix = <String, Map<String, bool>>{};
    
    for (final result in results) {
      matrix[result.testName] = {
        'passed': result.isPassed,
        'hasFailures': result.failedTests > 0,
        'hasRecommendations': result.recommendations.isNotEmpty,
      };
    }
    
    return CompatibilityMatrix(matrix: matrix);
  }

  /// 验证设备配置
  static List<String> validateDeviceConfig(DeviceInfo deviceInfo) {
    final issues = <String>[];
    
    // 检查必填字段
    if (deviceInfo.brand.isEmpty) {
      issues.add('设备品牌不能为空');
    }
    
    if (deviceInfo.model.isEmpty) {
      issues.add('设备型号不能为空');
    }
    
    if (deviceInfo.androidVersion.isEmpty) {
      issues.add('Android版本不能为空');
    }
    
    // 检查数值范围
    if (deviceInfo.apiLevel < 1 || deviceInfo.apiLevel > 50) {
      issues.add('API级别超出合理范围: ${deviceInfo.apiLevel}');
    }
    
    if (deviceInfo.ramSize < 1 || deviceInfo.ramSize > 100) {
      issues.add('RAM大小超出合理范围: ${deviceInfo.ramSize}GB');
    }
    
    if (deviceInfo.storageSize < 1 || deviceInfo.storageSize > 2000) {
      issues.add('存储大小超出合理范围: ${deviceInfo.storageSize}GB');
    }
    
    // 检查屏幕分辨率格式
    final resolutionPattern = RegExp(r'^\d+x\d+$');
    if (!resolutionPattern.hasMatch(deviceInfo.screenResolution)) {
      issues.add('屏幕分辨率格式不正确: ${deviceInfo.screenResolution}');
    }
    
    return issues;
  }

  /// 生成测试统计
  static TestStatistics generateTestStatistics(List<TestResult> results) {
    final totalTests = results.fold<int>(0, (sum, result) => sum + result.totalTests);
    final passedTests = results.fold<int>(0, (sum, result) => sum + result.passedTests);
    final failedTests = results.fold<int>(0, (sum, result) => sum + result.failedTests);
    
    final passRates = results.map((result) => result.passRate).toList();
    final averagePassRate = passRates.isEmpty ? 0.0 : 
        passRates.reduce((a, b) => a + b) / passRates.length;
    
    final executionTimes = results.map((result) => result.executionTime.inMilliseconds).toList();
    final totalExecutionTime = results
        .fold<Duration>(Duration.zero, (sum, result) => sum + result.executionTime);
    final averageExecutionTime = results.isEmpty ? Duration.zero :
        Duration(milliseconds: executionTimes.reduce((a, b) => a + b) ~/ results.length);
    
    return TestStatistics(
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: failedTests,
      averagePassRate: averagePassRate,
      totalExecutionTime: totalExecutionTime,
      averageExecutionTime: averageExecutionTime,
      testCount: results.length,
      passRateStandardDeviation: _calculateStandardDeviation(passRates),
    );
  }
}

/// 测试报告摘要
class TestReportSummary {
  final int totalTests;
  final int passedTests;
  final int failedTests;
  final double overallPassRate;
  final Map<String, int> testCategories;
  final Duration totalExecutionTime;
  final DeviceInfo deviceInfo;
  final String testScenarios;
  final DateTime timestamp;

  TestReportSummary({
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.overallPassRate,
    required this.testCategories,
    required this.totalExecutionTime,
    required this.deviceInfo,
    required this.testScenarios,
    required this.timestamp,
  });
}

/// 性能测试结果
class PerformanceTestResult {
  final String testType;
  final int iterations;
  final double averageScore;
  final double minScore;
  final double maxScore;
  final double standardDeviation;
  final Duration executionTime;
  final List<double> results;

  PerformanceTestResult({
    required this.testType,
    required this.iterations,
    required this.averageScore,
    required this.minScore,
    required this.maxScore,
    required this.standardDeviation,
    required this.executionTime,
    required this.results,
  });
}

/// 兼容性矩阵
class CompatibilityMatrix {
  final Map<String, Map<String, bool>> matrix;

  CompatibilityMatrix({required this.matrix});

  /// 获取指定测试的结果
  bool? getTestResult(String testName) {
    return matrix[testName]?['passed'];
  }

  /// 获取所有失败的测试
  List<String> getFailedTests() {
    return matrix.entries
        .where((entry) => entry.value['hasFailures'] == true)
        .map((entry) => entry.key)
        .toList();
  }

  /// 获取有建议的测试
  List<String> getTestsWithRecommendations() {
    return matrix.entries
        .where((entry) => entry.value['hasRecommendations'] == true)
        .map((entry) => entry.key)
        .toList();
  }

  /// 计算兼容性分数
  double getCompatibilityScore() {
    if (matrix.isEmpty) return 0.0;
    
    final passedCount = matrix.values
        .where((testResult) => testResult['passed'] == true)
        .length;
    
    return (passedCount / matrix.length) * 100;
  }
}

/// 测试统计
class TestStatistics {
  final int totalTests;
  final int passedTests;
  final int failedTests;
  final double averagePassRate;
  final Duration totalExecutionTime;
  final Duration averageExecutionTime;
  final int testCount;
  final double passRateStandardDeviation;

  TestStatistics({
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.averagePassRate,
    required this.totalExecutionTime,
    required this.averageExecutionTime,
    required this.testCount,
    required this.passRateStandardDeviation,
  });
}