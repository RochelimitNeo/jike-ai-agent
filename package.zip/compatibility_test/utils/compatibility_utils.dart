/// 兼容性测试工具类
/// 
/// 提供兼容性测试中使用的通用工具和方法

import 'dart:math' as math;
import '../main_test_runner.dart';

/// 兼容性测试工具类
class CompatibilityUtils {
  
  /// 检测设备兼容性等级
  DeviceCompatibilityLevel detectDeviceCompatibilityLevel(DeviceInfo deviceInfo) {
    final ramScore = deviceInfo.ramSize * 10;
    final storageScore = deviceInfo.storageSize * 2;
    final versionScore = _calculateVersionScore(deviceInfo.apiLevel);
    final resolutionScore = _calculateResolutionScore(deviceInfo.screenResolution);
    
    final totalScore = ramScore + storageScore + versionScore + resolutionScore;
    
    if (totalScore >= 85) {
      return DeviceCompatibilityLevel.high;
    } else if (totalScore >= 65) {
      return DeviceCompatibilityLevel.medium;
    } else {
      return DeviceCompatibilityLevel.low;
    }
  }

  /// 计算版本兼容性评分
  double _calculateVersionScore(int apiLevel) {
    if (apiLevel >= 33) return 25.0; // Android 13+
    if (apiLevel >= 31) return 22.0; // Android 12+
    if (apiLevel >= 30) return 20.0; // Android 11
    if (apiLevel >= 29) return 18.0; // Android 10
    if (apiLevel >= 28) return 15.0; // Android 9
    if (apiLevel >= 26) return 12.0; // Android 8
    if (apiLevel >= 24) return 10.0; // Android 7
    return 5.0; // 更低版本
  }

  /// 计算分辨率兼容性评分
  double _calculateResolutionScore(String resolution) {
    final parts = resolution.split('x');
    if (parts.length != 2) return 10.0;
    
    final width = int.tryParse(parts[0]) ?? 0;
    final height = int.tryParse(parts[1]) ?? 0;
    final totalPixels = width * height;
    
    if (totalPixels >= 4000000) return 25.0; // 4K+
    if (totalPixels >= 2000000) return 20.0; // 2K
    if (totalPixels >= 1000000) return 15.0; // 1080p
    if (totalPixels >= 500000) return 10.0; // 720p
    return 5.0; // 更低分辨率
  }

  /// 生成兼容性建议
  List<CompatibilitySuggestion> generateCompatibilitySuggestions(
    DeviceInfo deviceInfo,
    List<TestResult> testResults,
  ) {
    final suggestions = <CompatibilitySuggestion>[];
    
    // 基于设备信息的建议
    if (deviceInfo.ramSize < 4) {
      suggestions.add(CompatibilitySuggestion(
        type: SuggestionType.performance,
        priority: SuggestionPriority.high,
        title: '内存不足',
        description: '设备内存较小，建议优化内存使用和实现内存管理机制',
        actionItems: [
          '实施内存池管理',
          '优化图片和资源加载',
          '减少不必要的内存分配',
          '实现对象复用机制'
        ],
      ));
    }
    
    if (deviceInfo.apiLevel < 26) {
      suggestions.add(CompatibilitySuggestion(
        type: SuggestionType.compatibility,
        priority: SuggestionPriority.high,
        title: 'Android版本较旧',
        description: '设备运行较旧版本的Android，可能存在兼容性问题',
        actionItems: [
          '增加向后兼容性代码',
          '使用兼容库和框架',
          '实施功能降级策略',
          '增加版本检查机制'
        ],
      ));
    }
    
    // 基于测试结果的建议
    for (final result in testResults) {
      if (!result.isPassed) {
        switch (result.testName) {
          case 'Android版本兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.compatibility,
              priority: SuggestionPriority.medium,
              title: 'Android版本兼容性',
              description: '应用在当前Android版本上存在兼容性问题',
              actionItems: result.recommendations,
            ));
            break;
          case '设备型号兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.device,
              priority: SuggestionPriority.medium,
              title: '设备型号兼容性',
              description: '应用在当前设备型号上存在兼容性问题',
              actionItems: result.recommendations,
            ));
            break;
          case '分辨率适配兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.ui,
              priority: SuggestionPriority.medium,
              title: '分辨率适配',
              description: '应用在不同分辨率下显示可能存在问题',
              actionItems: result.recommendations,
            ));
            break;
          case '性能兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.performance,
              priority: SuggestionPriority.high,
              title: '性能兼容性',
              description: '应用在当前设备上性能表现不佳',
              actionItems: result.recommendations,
            ));
            break;
          case '权限系统兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.permission,
              priority: SuggestionPriority.high,
              title: '权限系统兼容性',
              description: '应用在权限处理方面存在兼容性问题',
              actionItems: result.recommendations,
            ));
            break;
          case '网络环境兼容性测试':
            suggestions.add(CompatibilitySuggestion(
              type: SuggestionType.network,
              priority: SuggestionPriority.medium,
              title: '网络环境兼容性',
              description: '应用在不同网络环境下可能存在问题',
              actionItems: result.recommendations,
            ));
            break;
        }
      }
    }
    
    return suggestions;
  }

  /// 计算兼容性指数
  CompatibilityIndex calculateCompatibilityIndex(
    DeviceInfo deviceInfo,
    List<TestResult> testResults,
  ) {
    final deviceLevel = detectDeviceCompatibilityLevel(deviceInfo);
    final testScores = testResults.map((result) => result.passRate).toList();
    final averageTestScore = testScores.isNotEmpty 
        ? testScores.reduce((a, b) => a + b) / testScores.length 
        : 0.0;
    
    // 设备兼容性权重
    final deviceWeight = _getDeviceCompatibilityWeight(deviceLevel);
    // 测试结果权重
    final testWeight = 1.0 - deviceWeight;
    
    // 综合兼容性指数
    final overallIndex = (deviceWeight * _getDeviceLevelScore(deviceLevel)) + 
                        (testWeight * averageTestScore);
    
    return CompatibilityIndex(
      overallScore: overallIndex,
      deviceCompatibilityScore: _getDeviceLevelScore(deviceLevel),
      testCompatibilityScore: averageTestScore,
      deviceLevel: deviceLevel,
      testResultsCount: testResults.length,
      passedTestsCount: testResults.where((r) => r.isPassed).length,
    );
  }

  /// 获取设备兼容性权重
  double _getDeviceCompatibilityWeight(DeviceCompatibilityLevel level) {
    switch (level) {
      case DeviceCompatibilityLevel.high:
        return 0.3;
      case DeviceCompatibilityLevel.medium:
        return 0.5;
      case DeviceCompatibilityLevel.low:
        return 0.7;
    }
  }

  /// 获取设备等级评分
  double _getDeviceLevelScore(DeviceCompatibilityLevel level) {
    switch (level) {
      case DeviceCompatibilityLevel.high:
        return 90.0;
      case DeviceCompatibilityLevel.medium:
        return 70.0;
      case DeviceCompatibilityLevel.low:
        return 50.0;
    }
  }

  /// 生成兼容性报告摘要
  CompatibilityReportSummary generateCompatibilityReportSummary(
    DeviceInfo deviceInfo,
    List<TestResult> testResults,
  ) {
    final index = calculateCompatibilityIndex(deviceInfo, testResults);
    final suggestions = generateCompatibilitySuggestions(deviceInfo, testResults);
    
    final criticalIssues = suggestions
        .where((s) => s.priority == SuggestionPriority.critical)
        .toList();
    final highPriorityIssues = suggestions
        .where((s) => s.priority == SuggestionPriority.high)
        .toList();
    
    final compatibilityGrade = _calculateCompatibilityGrade(index.overallScore);
    
    return CompatibilityReportSummary(
      compatibilityIndex: index,
      compatibilityGrade: compatibilityGrade,
      totalSuggestions: suggestions.length,
      criticalIssues: criticalIssues.length,
      highPriorityIssues: highPriorityIssues.length,
      keyRecommendations: suggestions
          .where((s) => s.priority == SuggestionPriority.high || s.priority == SuggestionPriority.critical)
          .take(5)
          .map((s) => s.title)
          .toList(),
      testCoverage: _calculateTestCoverage(testResults),
    );
  }

  /// 计算兼容性等级
  CompatibilityGrade _calculateCompatibilityGrade(double score) {
    if (score >= 90) return CompatibilityGrade.excellent;
    if (score >= 80) return CompatibilityGrade.good;
    if (score >= 70) return CompatibilityGrade.fair;
    if (score >= 60) return CompatibilityGrade.poor;
    return CompatibilityGrade.veryPoor;
  }

  /// 计算测试覆盖率
  double _calculateTestCoverage(List<TestResult> testResults) {
    if (testResults.isEmpty) return 0.0;
    
    final totalTests = testResults.fold<int>(0, (sum, result) => sum + result.totalTests);
    const maxPossibleTests = 100; // 假设最大测试数为100
    
    return math.min((totalTests / maxPossibleTests) * 100, 100.0);
  }

  /// 验证设备配置
  List<ConfigurationIssue> validateDeviceConfiguration(DeviceInfo deviceInfo) {
    final issues = <ConfigurationIssue>[];
    
    // 检查内存配置
    if (deviceInfo.ramSize < 2) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.memory,
        severity: ConfigurationIssueSeverity.error,
        description: '内存不足：${deviceInfo.ramSize}GB，建议至少2GB',
        suggestion: '考虑增加内存或优化内存使用',
      ));
    } else if (deviceInfo.ramSize < 4) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.memory,
        severity: ConfigurationIssueSeverity.warning,
        description: '内存较小：${deviceInfo.ramSize}GB，建议至少4GB',
        suggestion: '优化内存使用以提高性能',
      ));
    }
    
    // 检查存储配置
    if (deviceInfo.storageSize < 16) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.storage,
        severity: ConfigurationIssueSeverity.error,
        description: '存储空间不足：${deviceInfo.storageSize}GB，建议至少16GB',
        suggestion: '增加存储空间或优化数据存储',
      ));
    } else if (deviceInfo.storageSize < 32) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.storage,
        severity: ConfigurationIssueSeverity.warning,
        description: '存储空间较小：${deviceInfo.storageSize}GB，建议至少32GB',
        suggestion: '优化应用大小和数据缓存策略',
      ));
    }
    
    // 检查Android版本
    if (deviceInfo.apiLevel < 21) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.androidVersion,
        severity: ConfigurationIssueSeverity.error,
        description: 'Android版本过低：API ${deviceInfo.apiLevel}，建议API 21+',
        suggestion: '升级Android版本或增加向后兼容性',
      ));
    } else if (deviceInfo.apiLevel < 24) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.androidVersion,
        severity: ConfigurationIssueSeverity.warning,
        description: 'Android版本较旧：API ${deviceInfo.apiLevel}，建议API 24+',
        suggestion: '考虑最低支持版本的更新',
      ));
    }
    
    // 检查分辨率
    final resolution = _parseResolution(deviceInfo.screenResolution);
    if (resolution.totalPixels < 500000) {
      issues.add(ConfigurationIssue(
        type: ConfigurationIssueType.resolution,
        severity: ConfigurationIssueSeverity.warning,
        description: '屏幕分辨率较低：${deviceInfo.screenResolution}',
        suggestion: '优化UI布局以适配低分辨率屏幕',
      ));
    }
    
    return issues;
  }

  /// 解析分辨率
  ScreenResolution _parseResolution(String resolution) {
    final parts = resolution.split('x');
    if (parts.length != 2) {
      return ScreenResolution(0, 0, 0);
    }
    
    final width = int.tryParse(parts[0]) ?? 0;
    final height = int.tryParse(parts[1]) ?? 0;
    
    return ScreenResolution(width, height, width * height);
  }
}

/// 设备兼容性等级
enum DeviceCompatibilityLevel {
  high,
  medium,
  low,
}

/// 建议类型
enum SuggestionType {
  performance,
  compatibility,
  ui,
  device,
  permission,
  network,
}

/// 建议优先级
enum SuggestionPriority {
  low,
  medium,
  high,
  critical,
}

/// 兼容性建议
class CompatibilitySuggestion {
  final SuggestionType type;
  final SuggestionPriority priority;
  final String title;
  final String description;
  final List<String> actionItems;

  CompatibilitySuggestion({
    required this.type,
    required this.priority,
    required this.title,
    required this.description,
    required this.actionItems,
  });
}

/// 兼容性指数
class CompatibilityIndex {
  final double overallScore;
  final double deviceCompatibilityScore;
  final double testCompatibilityScore;
  final DeviceCompatibilityLevel deviceLevel;
  final int testResultsCount;
  final int passedTestsCount;

  CompatibilityIndex({
    required this.overallScore,
    required this.deviceCompatibilityScore,
    required this.testCompatibilityScore,
    required this.deviceLevel,
    required this.testResultsCount,
    required this.passedTestsCount,
  });
}

/// 兼容性等级
enum CompatibilityGrade {
  excellent,
  good,
  fair,
  poor,
  veryPoor,
}

/// 兼容性报告摘要
class CompatibilityReportSummary {
  final CompatibilityIndex compatibilityIndex;
  final CompatibilityGrade compatibilityGrade;
  final int totalSuggestions;
  final int criticalIssues;
  final int highPriorityIssues;
  final List<String> keyRecommendations;
  final double testCoverage;

  CompatibilityReportSummary({
    required this.compatibilityIndex,
    required this.compatibilityGrade,
    required this.totalSuggestions,
    required this.criticalIssues,
    required this.highPriorityIssues,
    required this.keyRecommendations,
    required this.testCoverage,
  });
}

/// 配置问题类型
enum ConfigurationIssueType {
  memory,
  storage,
  androidVersion,
  resolution,
}

/// 配置问题严重程度
enum ConfigurationIssueSeverity {
  info,
  warning,
  error,
}

/// 配置问题
class ConfigurationIssue {
  final ConfigurationIssueType type;
  final ConfigurationIssueSeverity severity;
  final String description;
  final String suggestion;

  ConfigurationIssue({
    required this.type,
    required this.severity,
    required this.description,
    required this.suggestion,
  });
}

/// 屏幕分辨率
class ScreenResolution {
  final int width;
  final int height;
  final int totalPixels;

  ScreenResolution(this.width, this.height, this.totalPixels);
}