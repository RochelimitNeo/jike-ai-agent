/// 测试报告生成器
/// 
/// 生成详细的兼容性测试报告

import 'dart:convert';
import 'dart:io';
import '../main_test_runner.dart';

/// 报告生成器类
class ReportGenerator {
  final String _reportDirectory = 'compatibility_reports';
  
  /// 生成综合测试报告
  Future<String> generateComprehensiveReport(TestReport report) async {
    // 确保报告目录存在
    final directory = Directory(_reportDirectory);
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }

    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final reportFileName = 'compatibility_report_$timestamp.json';
    final reportFile = File('${directory.path}/$reportFileName');

    // 生成JSON格式报告
    final jsonReport = _generateJsonReport(report);
    await reportFile.writeAsString(JsonEncoder.withIndent('  ').convert(jsonReport));

    // 生成HTML格式报告
    final htmlReport = await _generateHtmlReport(report);
    final htmlFileName = 'compatibility_report_$timestamp.html';
    final htmlFile = File('${directory.path}/$htmlFileName');
    await htmlFile.writeAsString(htmlReport);

    // 生成Markdown格式报告
    final markdownReport = await _generateMarkdownReport(report);
    final mdFileName = 'compatibility_report_$timestamp.md';
    final mdFile = File('${directory.path}/$mdFileName');
    await mdFile.writeAsString(markdownReport);

    // 生成CSV格式报告
    final csvReport = await _generateCsvReport(report);
    final csvFileName = 'compatibility_report_$timestamp.csv';
    final csvFile = File('${directory.path}/$csvFileName');
    await csvFile.writeAsString(csvReport);

    print('📊 兼容性测试报告已生成:');
    print('JSON: ${reportFile.path}');
    print('HTML: ${htmlFile.path}');
    print('Markdown: ${mdFile.path}');
    print('CSV: ${csvFile.path}');

    return directory.path;
  }

  /// 生成JSON格式报告
  Map<String, dynamic> _generateJsonReport(TestReport report) {
    return {
      'reportMetadata': {
        'timestamp': report.timestamp.toIso8601String(),
        'version': '1.0.0',
        'generator': 'Android兼容性测试系统',
        'deviceInfo': {
          'brand': report.deviceInfo.brand,
          'model': report.deviceInfo.model,
          'androidVersion': report.deviceInfo.androidVersion,
          'apiLevel': report.deviceInfo.apiLevel,
          'screenResolution': report.deviceInfo.screenResolution,
          'ramSize': report.deviceInfo.ramSize,
          'storageSize': report.deviceInfo.storageSize,
        },
      },
      'testSummary': {
        'testScenarios': report.testScenarios,
        'overallPassRate': report.overallPassRate,
        'totalTests': report.results.fold<int>(0, (sum, result) => sum + result.totalTests),
        'passedTests': report.results.fold<int>(0, (sum, result) => sum + result.passedTests),
        'failedTests': report.results.fold<int>(0, (sum, result) => sum + result.failedTests),
      },
      'detailedResults': report.results.map((result) => {
        'testName': result.testName,
        'totalTests': result.totalTests,
        'passedTests': result.passedTests,
        'failedTests': result.failedTests,
        'passRate': result.passRate,
        'executionTime': result.executionTime.inMilliseconds,
        'failureDetails': result.failureDetails,
        'recommendations': result.recommendations,
        'metadata': result.metadata,
      }).toList(),
      'recommendations': report.recommendations,
      'deviceCompatibility': _generateDeviceCompatibilitySection(report),
      'performanceMetrics': _generatePerformanceMetricsSection(report),
      'compatibilityMatrix': _generateCompatibilityMatrix(report),
    };
  }

  /// 生成HTML格式报告
  Future<String> _generateHtmlReport(TestReport report) async {
    final buffer = StringBuffer();
    
    buffer.writeln('''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Android设备兼容性测试报告</title>
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f5f5f5;
            color: #333;
        }
        .container { 
            max-width: 1200px; 
            margin: 0 auto; 
            background: white; 
            padding: 30px; 
            border-radius: 10px; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .header { 
            text-align: center; 
            border-bottom: 3px solid #007acc; 
            padding-bottom: 20px; 
            margin-bottom: 30px; 
        }
        .header h1 { 
            color: #007acc; 
            margin: 0; 
            font-size: 2.5em;
        }
        .header p { 
            color: #666; 
            margin: 10px 0 0 0; 
            font-size: 1.1em;
        }
        .summary { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        .summary-card { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; 
            padding: 20px; 
            border-radius: 8px; 
            text-align: center;
        }
        .summary-card h3 { 
            margin: 0 0 10px 0; 
            font-size: 1.2em;
        }
        .summary-card .value { 
            font-size: 2em; 
            font-weight: bold; 
            margin: 10px 0;
        }
        .test-section { 
            margin-bottom: 30px; 
            border: 1px solid #ddd; 
            border-radius: 8px; 
            overflow: hidden;
        }
        .test-header { 
            background: #f8f9fa; 
            padding: 15px 20px; 
            border-bottom: 1px solid #ddd;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
        }
        .test-header h3 { 
            margin: 0; 
            color: #333;
        }
        .test-status { 
            padding: 5px 15px; 
            border-radius: 20px; 
            color: white; 
            font-weight: bold;
        }
        .status-passed { background-color: #28a745; }
        .status-failed { background-color: #dc3545; }
        .test-content { 
            padding: 20px; 
        }
        .progress-bar { 
            background-color: #e9ecef; 
            border-radius: 10px; 
            overflow: hidden; 
            margin: 10px 0;
            height: 20px;
        }
        .progress-fill { 
            height: 100%; 
            transition: width 0.3s ease;
            display: flex; 
            align-items: center; 
            justify-content: center;
            color: white; 
            font-size: 0.8em; 
            font-weight: bold;
        }
        .progress-fill.passed { background-color: #28a745; }
        .progress-fill.failed { background-color: #dc3545; }
        .test-details { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 15px; 
            margin-top: 15px;
        }
        .detail-item { 
            padding: 10px; 
            background: #f8f9fa; 
            border-radius: 5px;
        }
        .detail-label { 
            font-weight: bold; 
            color: #666; 
            font-size: 0.9em;
        }
        .detail-value { 
            font-size: 1.1em; 
            margin-top: 5px;
        }
        .recommendations { 
            background: #fff3cd; 
            border: 1px solid #ffeaa7; 
            border-radius: 8px; 
            padding: 20px; 
            margin-top: 30px;
        }
        .recommendations h3 { 
            color: #856404; 
            margin-top: 0;
        }
        .recommendations ul { 
            margin: 10px 0;
        }
        .recommendations li { 
            margin: 8px 0; 
            color: #856404;
        }
        .metadata { 
            background: #e9ecef; 
            padding: 15px; 
            border-radius: 8px; 
            margin-top: 20px; 
            font-size: 0.9em;
        }
        .device-info { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 10px; 
            margin-top: 10px;
        }
        .device-item { 
            text-align: center; 
            padding: 10px; 
            background: white; 
            border-radius: 5px;
        }
        .device-label { 
            font-size: 0.8em; 
            color: #666; 
            margin-bottom: 5px;
        }
        .device-value { 
            font-weight: bold; 
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📱 Android设备兼容性测试报告</h1>
            <p>生成时间: ${_formatDateTime(report.timestamp)}</p>
            <p>测试设备: ${report.deviceInfo.brand} ${report.deviceInfo.model}</p>
        </div>

        <div class="summary">
            <div class="summary-card">
                <h3>总体通过率</h3>
                <div class="value">${report.overallPassRate.toStringAsFixed(1)}%</div>
                <div class="progress-bar">
                    <div class="progress-fill ${report.overallPassRate >= 80 ? 'passed' : 'failed'}" 
                         style="width: ${report.overallPassRate}%">
                        ${report.overallPassRate.toStringAsFixed(0)}%
                    </div>
                </div>
            </div>
            <div class="summary-card">
                <h3>总测试数</h3>
                <div class="value">${report.results.fold<int>(0, (sum, result) => sum + result.totalTests)}</div>
            </div>
            <div class="summary-card">
                <h3>通过测试</h3>
                <div class="value">${report.results.fold<int>(0, (sum, result) => sum + result.passedTests)}</div>
            </div>
            <div class="summary-card">
                <h3>失败测试</h3>
                <div class="value">${report.results.fold<int>(0, (sum, result) => sum + result.failedTests)}</div>
            </div>
        </div>

        <div class="metadata">
            <h3>📋 设备信息</h3>
            <div class="device-info">
                <div class="device-item">
                    <div class="device-label">品牌</div>
                    <div class="device-value">${report.deviceInfo.brand}</div>
                </div>
                <div class="device-item">
                    <div class="device-label">型号</div>
                    <div class="device-value">${report.deviceInfo.model}</div>
                </div>
                <div class="device-item">
                    <div class="device-label">Android版本</div>
                    <div class="device-value">${report.deviceInfo.androidVersion}</div>
                </div>
                <div class="device-item">
                    <div class="device-label">API级别</div>
                    <div class="device-value">${report.deviceInfo.apiLevel}</div>
                </div>
                <div class="device-item">
                    <div class="device-label">屏幕分辨率</div>
                    <div class="device-value">${report.deviceInfo.screenResolution}</div>
                </div>
                <div class="device-item">
                    <div class="device-label">内存</div>
                    <div class="device-value">${report.deviceInfo.ramSize}GB</div>
                </div>
                <div class="device-item">
                    <div class="device-label">存储</div>
                    <div class="device-value">${report.deviceInfo.storageSize}GB</div>
                </div>
            </div>
        </div>
''');

    // 添加详细测试结果
    for (final result in report.results) {
      final statusClass = result.isPassed ? 'status-passed' : 'status-failed';
      final statusText = result.isPassed ? '通过' : '失败';
      
      buffer.writeln('''
        <div class="test-section">
            <div class="test-header">
                <h3>${result.testName}</h3>
                <div class="test-status $statusClass">$statusText</div>
            </div>
            <div class="test-content">
                <div class="progress-bar">
                    <div class="progress-fill ${result.isPassed ? 'passed' : 'failed'}" 
                         style="width: ${result.passRate}%">
                        ${result.passRate.toStringAsFixed(1)}%
                    </div>
                </div>
                <div class="test-details">
                    <div class="detail-item">
                        <div class="detail-label">总测试数</div>
                        <div class="detail-value">${result.totalTests}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">通过测试</div>
                        <div class="detail-value">${result.passedTests}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">失败测试</div>
                        <div class="detail-value">${result.failedTests}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">执行时间</div>
                        <div class="detail-value">${result.executionTime.inSeconds}秒</div>
                    </div>
                </div>
''');

      if (result.failureDetails.isNotEmpty) {
        buffer.writeln('''
                <div class="metadata">
                    <h4>❌ 失败详情</h4>
                    <ul>
''');
        for (final detail in result.failureDetails) {
          buffer.writeln('                        <li>$detail</li>');
        }
        buffer.writeln('''
                    </ul>
                </div>
''');
      }

      if (result.metadata.isNotEmpty) {
        buffer.writeln('''
                <div class="metadata">
                    <h4>📊 测试元数据</h4>
                    <pre>${JsonEncoder.withIndent('  ').convert(result.metadata)}</pre>
                </div>
''');
      }

      buffer.writeln('''
            </div>
        </div>
''');
    }

    // 添加建议
    if (report.recommendations.isNotEmpty) {
      buffer.writeln('''
        <div class="recommendations">
            <h3>💡 改进建议</h3>
            <ul>
''');
      for (final recommendation in report.recommendations) {
        buffer.writeln('                <li>$recommendation</li>');
      }
      buffer.writeln('''
            </ul>
        </div>
''');
    }

    buffer.writeln('''
    </div>
</body>
</html>
''');

    return buffer.toString();
  }

  /// 生成Markdown格式报告
  Future<String> _generateMarkdownReport(TestReport report) async {
    final buffer = StringBuffer();
    
    buffer.writeln('# 📱 Android设备兼容性测试报告');
    buffer.writeln();
    buffer.writeln('## 📋 基本信息');
    buffer.writeln();
    buffer.writeln('| 项目 | 值 |');
    buffer.writeln('|------|----|');
    buffer.writeln('| 测试时间 | ${_formatDateTime(report.timestamp)} |');
    buffer.writeln('| 设备品牌 | ${report.deviceInfo.brand} |');
    buffer.writeln('| 设备型号 | ${report.deviceInfo.model} |');
    buffer.writeln('| Android版本 | ${report.deviceInfo.androidVersion} |');
    buffer.writeln('| API级别 | ${report.deviceInfo.apiLevel} |');
    buffer.writeln('| 屏幕分辨率 | ${report.deviceInfo.screenResolution} |');
    buffer.writeln('| 内存 | ${report.deviceInfo.ramSize}GB |');
    buffer.writeln('| 存储 | ${report.deviceInfo.storageSize}GB |');
    buffer.writeln('| 测试场景 | ${report.testScenarios} |');
    buffer.writeln();
    
    buffer.writeln('## 📊 测试摘要');
    buffer.writeln();
    buffer.writeln('- **总体通过率**: ${report.overallPassRate.toStringAsFixed(1)}%');
    buffer.writeln('- **总测试数**: ${report.results.fold<int>(0, (sum, result) => sum + result.totalTests)}');
    buffer.writeln('- **通过测试**: ${report.results.fold<int>(0, (sum, result) => sum + result.passedTests)}');
    buffer.writeln('- **失败测试**: ${report.results.fold<int>(0, (sum, result) => sum + result.failedTests)}');
    buffer.writeln();
    
    buffer.writeln('## 📝 详细测试结果');
    buffer.writeln();
    
    for (final result in report.results) {
      final status = result.isPassed ? '✅ 通过' : '❌ 失败';
      buffer.writeln('### ${result.testName}');
      buffer.writeln();
      buffer.writeln('**状态**: $status  ');
    buffer.writeln('**通过率**: ${result.passRate.toStringAsFixed(1)}%  ');
      buffer.writeln('**执行时间**: ${result.executionTime.inSeconds}秒  ');
      buffer.writeln();
      buffer.writeln('| 指标 | 值 |');
      buffer.writeln('|------|----|');
      buffer.writeln('| 总测试数 | ${result.totalTests} |');
      buffer.writeln('| 通过测试 | ${result.passedTests} |');
      buffer.writeln('| 失败测试 | ${result.failedTests} |');
      buffer.writeln();
      
      if (result.failureDetails.isNotEmpty) {
        buffer.writeln('#### ❌ 失败详情');
        buffer.writeln();
        for (final detail in result.failureDetails) {
          buffer.writeln('- $detail');
        }
        buffer.writeln();
      }
      
      if (result.metadata.isNotEmpty) {
        buffer.writeln('#### 📊 测试元数据');
        buffer.writeln();
        buffer.writeln('```json');
        buffer.writeln(JsonEncoder.withIndent('  ').convert(result.metadata));
        buffer.writeln('```');
        buffer.writeln();
      }
    }
    
    if (report.recommendations.isNotEmpty) {
      buffer.writeln('## 💡 改进建议');
      buffer.writeln();
      for (final recommendation in report.recommendations) {
        buffer.writeln('- $recommendation');
      }
      buffer.writeln();
    }
    
    buffer.writeln('---');
    buffer.writeln('*报告由Android兼容性测试系统生成*');
    
    return buffer.toString();
  }

  /// 生成CSV格式报告
  Future<String> _generateCsvReport(TestReport report) async {
    final buffer = StringBuffer();
    
    // CSV头部
    buffer.writeln('测试名称,总测试数,通过测试,失败测试,通过率(%),执行时间(毫秒),状态');
    
    // 测试结果数据
    for (final result in report.results) {
      final status = result.isPassed ? '通过' : '失败';
      buffer.writeln('${result.testName},${result.totalTests},${result.passedTests},${result.failedTests},${result.passRate.toStringAsFixed(1)},${result.executionTime.inMilliseconds},$status');
    }
    
    // 摘要行
    final totalTests = report.results.fold<int>(0, (sum, result) => sum + result.totalTests);
    final totalPassed = report.results.fold<int>(0, (sum, result) => sum + result.passedTests);
    final totalFailed = report.results.fold<int>(0, (sum, result) => sum + result.failedTests);
    
    buffer.writeln();
    buffer.writeln('摘要,,,,,,');
    buffer.writeln('总体通过率,${report.overallPassRate.toStringAsFixed(1)},%,,,,');
    buffer.writeln('总计,${totalTests},${totalPassed},${totalFailed},${report.overallPassRate.toStringAsFixed(1)},,');
    
    return buffer.toString();
  }

  /// 生成设备兼容性部分
  Map<String, dynamic> _generateDeviceCompatibilitySection(TestReport report) {
    return {
      'deviceBrand': report.deviceInfo.brand,
      'deviceModel': report.deviceInfo.model,
      'androidVersion': report.deviceInfo.androidVersion,
      'apiLevel': report.deviceInfo.apiLevel,
      'compatibilityScore': _calculateDeviceCompatibilityScore(report),
      'supportedFeatures': _extractSupportedFeatures(report),
      'limitations': _extractLimitations(report),
    };
  }

  /// 生成性能指标部分
  Map<String, dynamic> _generatePerformanceMetricsSection(TestReport report) {
    final performanceResults = report.results
        .where((result) => result.testName.contains('性能'))
        .toList();
    
    return {
      'performanceTests': performanceResults.length,
      'averagePerformance': performanceResults.isNotEmpty 
          ? performanceResults.map((r) => r.passRate).reduce((a, b) => a + b) / performanceResults.length
          : 0.0,
      'performanceDetails': performanceResults.map((result) => {
        'testName': result.testName,
        'score': result.passRate,
        'executionTime': result.executionTime.inMilliseconds,
        'metadata': result.metadata,
      }).toList(),
    };
  }

  /// 生成兼容性矩阵
  Map<String, dynamic> _generateCompatibilityMatrix(TestReport report) {
    final matrix = <String, dynamic>{};
    
    for (final result in report.results) {
      matrix[result.testName] = {
        'passed': result.isPassed,
        'score': result.passRate,
        'executionTime': result.executionTime.inMilliseconds,
        'issues': result.failureDetails,
      };
    }
    
    return matrix;
  }

  /// 计算设备兼容性评分
  double _calculateDeviceCompatibilityScore(TestReport report) {
    // 简化的兼容性评分算法
    var score = report.overallPassRate;
    
    // 根据设备类型调整评分
    if (report.deviceInfo.ramSize >= 8) score += 5;
    if (report.deviceInfo.storageSize >= 128) score += 5;
    if (report.deviceInfo.apiLevel >= 30) score += 5;
    
    return score.clamp(0.0, 100.0);
  }

  /// 提取支持的功能
  List<String> _extractSupportedFeatures(TestReport report) {
    final features = <String>[];
    
    for (final result in report.results) {
      if (result.isPassed) {
        features.add(result.testName);
      }
    }
    
    return features;
  }

  /// 提取限制因素
  List<String> _extractLimitations(TestReport report) {
    final limitations = <String>[];
    
    for (final result in report.results) {
      if (!result.isPassed) {
        limitations.addAll(result.failureDetails);
      }
    }
    
    return limitations;
  }

  /// 格式化日期时间
  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} '
           '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}