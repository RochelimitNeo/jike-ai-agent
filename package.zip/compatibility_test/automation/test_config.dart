/// 测试配置类
/// 
/// 定义自动化测试的各种配置选项

/// 测试配置主类
class TestConfiguration {
  // 测试模式配置
  final String testMode = 'comprehensive'; // comprehensive, quick, stress, regression
  final bool enableDeviceSimulation = true;
  final bool enableNetworkSimulation = true;
  final bool enablePermissionAutomation = true;
  final bool enableUiAutomation = true;
  final bool enablePerformanceStressTesting = true;
  final bool enableRegressionTesting = true;
  final bool enableContinuousIntegration = true;

  // 测试执行配置
  final int maxConcurrentTests = 5;
  final int testTimeoutSeconds = 300;
  final bool enableDetailedLogging = true;
  final bool enableScreenshotOnFailure = true;
  final bool enableVideoRecording = false;

  // 模拟配置
  final List<DeviceSimulation> deviceSimulations;
  final List<NetworkSimulation> networkSimulations;
  final List<PermissionScenario> permissionScenarios;
  final List<UiScenario> uiScenarios;
  final List<StressTest> stressTests;
  final List<RegressionTest> regressionTests;
  final List<CiTest> ciTests;

  TestConfiguration()
    : deviceSimulations = _createDefaultDeviceSimulations(),
      networkSimulations = _createDefaultNetworkSimulations(),
      permissionScenarios = _createDefaultPermissionScenarios(),
      uiScenarios = _createDefaultUiScenarios(),
      stressTests = _createDefaultStressTests(),
      regressionTests = _createDefaultRegressionTests(),
      ciTests = _createDefaultCiTests();

  Map<String, dynamic> toJson() {
    return {
      'testMode': testMode,
      'enableDeviceSimulation': enableDeviceSimulation,
      'enableNetworkSimulation': enableNetworkSimulation,
      'enablePermissionAutomation': enablePermissionAutomation,
      'enableUiAutomation': enableUiAutomation,
      'enablePerformanceStressTesting': enablePerformanceStressTesting,
      'enableRegressionTesting': enableRegressionTesting,
      'enableContinuousIntegration': enableContinuousIntegration,
      'maxConcurrentTests': maxConcurrentTests,
      'testTimeoutSeconds': testTimeoutSeconds,
      'enableDetailedLogging': enableDetailedLogging,
      'enableScreenshotOnFailure': enableScreenshotOnFailure,
      'enableVideoRecording': enableVideoRecording,
      'deviceSimulations': deviceSimulations.map((d) => d.toJson()).toList(),
      'networkSimulations': networkSimulations.map((n) => n.toJson()).toList(),
      'permissionScenarios': permissionScenarios.map((p) => p.toJson()).toList(),
      'uiScenarios': uiScenarios.map((u) => u.toJson()).toList(),
      'stressTests': stressTests.map((s) => s.toJson()).toList(),
      'regressionTests': regressionTests.map((r) => r.toJson()).toList(),
      'ciTests': ciTests.map((c) => c.toJson()).toList(),
    };
  }

  // 创建默认设备模拟配置
  static List<DeviceSimulation> _createDefaultDeviceSimulations() {
    return [
      DeviceSimulation(
        brand: 'Samsung',
        model: 'Galaxy S21',
        specifications: {
          'ram': '8GB',
          'storage': '128GB',
          'androidVersion': '12',
          'screenResolution': '2400x1080',
          'cpu': 'Exynos 2100',
        },
      ),
      DeviceSimulation(
        brand: 'Xiaomi',
        model: 'Mi 11',
        specifications: {
          'ram': '8GB',
          'storage': '256GB',
          'androidVersion': '11',
          'screenResolution': '3200x1440',
          'cpu': 'Snapdragon 888',
        },
      ),
      DeviceSimulation(
        brand: 'Huawei',
        model: 'P40',
        specifications: {
          'ram': '8GB',
          'storage': '128GB',
          'androidVersion': '10',
          'screenResolution': '2340x1080',
          'cpu': 'Kirin 990',
        },
      ),
      DeviceSimulation(
        brand: 'OPPO',
        model: 'Find X3',
        specifications: {
          'ram': '8GB',
          'storage': '256GB',
          'androidVersion': '11',
          'screenResolution': '3216x1440',
          'cpu': 'Snapdragon 870',
        },
      ),
      DeviceSimulation(
        brand: 'Vivo',
        model: 'X60',
        specifications: {
          'ram': '8GB',
          'storage': '128GB',
          'androidVersion': '11',
          'screenResolution': '2376x1080',
          'cpu': 'Snapdragon 870',
        },
      ),
      DeviceSimulation(
        brand: 'OnePlus',
        model: 'OnePlus 9',
        specifications: {
          'ram': '12GB',
          'storage': '256GB',
          'androidVersion': '11',
          'screenResolution': '2400x1080',
          'cpu': 'Snapdragon 888',
        },
      ),
      DeviceSimulation(
        brand: 'Google',
        model: 'Pixel 6',
        specifications: {
          'ram': '8GB',
          'storage': '128GB',
          'androidVersion': '12',
          'screenResolution': '2400x1080',
          'cpu': 'Tensor',
        },
      ),
      DeviceSimulation(
        brand: 'Realme',
        model: 'Realme GT',
        specifications: {
          'ram': '8GB',
          'storage': '128GB',
          'androidVersion': '11',
          'screenResolution': '2400x1080',
          'cpu': 'Snapdragon 888',
        },
      ),
    ];
  }

  // 创建默认网络模拟配置
  static List<NetworkSimulation> _createDefaultNetworkSimulations() {
    return [
      NetworkSimulation(
        networkType: 'WiFi',
        technology: '2.4GHz',
        configuration: {
          'bandwidth': '100Mbps',
          'latency': '50ms',
          'signalStrength': 'strong',
          'interference': 'low',
        },
      ),
      NetworkSimulation(
        networkType: 'WiFi',
        technology: '5GHz',
        configuration: {
          'bandwidth': '500Mbps',
          'latency': '20ms',
          'signalStrength': 'strong',
          'interference': 'very_low',
        },
      ),
      NetworkSimulation(
        networkType: 'Mobile',
        technology: '4G',
        configuration: {
          'bandwidth': '50Mbps',
          'latency': '80ms',
          'signalStrength': 'medium',
          'interference': 'medium',
        },
      ),
      NetworkSimulation(
        networkType: 'Mobile',
        technology: '5G',
        configuration: {
          'bandwidth': '200Mbps',
          'latency': '30ms',
          'signalStrength': 'strong',
          'interference': 'low',
        },
      ),
      NetworkSimulation(
        networkType: 'Ethernet',
        technology: 'Wired',
        configuration: {
          'bandwidth': '1000Mbps',
          'latency': '10ms',
          'signalStrength': 'perfect',
          'interference': 'none',
        },
      ),
      NetworkSimulation(
        networkType: 'Offline',
        technology: 'NoNetwork',
        configuration: {
          'bandwidth': '0',
          'latency': '0',
          'signalStrength': 'none',
          'interference': 'none',
        },
      ),
    ];
  }

  // 创建默认权限场景配置
  static List<PermissionScenario> _createDefaultPermissionScenarios() {
    return [
      PermissionScenario(
        permissionType: 'Camera',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': false,
          'testBackground': false,
        },
      ),
      PermissionScenario(
        permissionType: 'Location',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': true,
          'testBackground': true,
        },
      ),
      PermissionScenario(
        permissionType: 'Microphone',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': false,
          'testBackground': false,
        },
      ),
      PermissionScenario(
        permissionType: 'Storage',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': false,
          'testBackground': false,
        },
      ),
      PermissionScenario(
        permissionType: 'Notifications',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': false,
          'testBackground': false,
        },
      ),
      PermissionScenario(
        permissionType: 'Bluetooth',
        configuration: {
          'testGranted': true,
          'testDenied': true,
          'testOneTime': true,
          'testBackground': false,
        },
      ),
    ];
  }

  // 创建默认UI场景配置
  static List<UiScenario> _createDefaultUiScenarios() {
    return [
      UiScenario(
        uiElement: 'Button',
        configuration: {
          'testClick': true,
          'testLongPress': true,
          'testDisabled': true,
          'testLoading': true,
        },
      ),
      UiScenario(
        uiElement: 'TextInput',
        configuration: {
          'testInput': true,
          'testMaxLength': true,
          'testValidation': true,
          'testAutofocus': true,
        },
      ),
      UiScenario(
        uiElement: 'Image',
        configuration: {
          'testLoading': true,
          'testError': true,
          'testResize': true,
          'testCache': true,
        },
      ),
      UiScenario(
        uiElement: 'ListView',
        configuration: {
          'testScrolling': true,
          'testInfiniteScroll': true,
          'testPullToRefresh': true,
          'testSelection': true,
        },
      ),
      UiScenario(
        uiElement: 'Dialog',
        configuration: {
          'testShow': true,
          'testDismiss': true,
          'testAnimation': true,
          'testBackdrop': true,
        },
      ),
      UiScenario(
        uiElement: 'Navigation',
        configuration: {
          'testPush': true,
          'testPop': true,
          'testReplace': true,
          'testDeepLink': true,
        },
      ),
    ];
  }

  // 创建默认压力测试配置
  static List<StressTest> _createDefaultStressTests() {
    return [
      StressTest(
        testType: 'Memory',
        configuration: {
          'duration': '5minutes',
          'memoryLeakTest': true,
          'garbageCollectionTest': true,
          'memoryPressureTest': true,
        },
      ),
      StressTest(
        testType: 'CPU',
        configuration: {
          'duration': '3minutes',
          'maxThreads': 8,
          'cpuStressLevel': 'high',
          'thermalTest': true,
        },
      ),
      StressTest(
        testType: 'Network',
        configuration: {
          'duration': '10minutes',
          'concurrentConnections': 100,
          'bandwidthTest': true,
          'latencyTest': true,
        },
      ),
      StressTest(
        testType: 'Storage',
        configuration: {
          'duration': '5minutes',
          'writeOperations': 1000,
          'readOperations': 1000,
          'diskSpaceTest': true,
        },
      ),
      StressTest(
        testType: 'Battery',
        configuration: {
          'duration': '30minutes',
          'screenOnTime': '100%',
          'backgroundTasks': true,
          'wakeLockTest': true,
        },
      ),
    ];
  }

  // 创建默认回归测试配置
  static List<RegressionTest> _createDefaultRegressionTests() {
    return [
      RegressionTest(
        featureName: 'Login',
        configuration: {
          'testValidCredentials': true,
          'testInvalidCredentials': true,
          'testNetworkFailure': true,
          'testBiometricAuth': true,
        },
      ),
      RegressionTest(
        featureName: 'DataSync',
        configuration: {
          'testOnlineSync': true,
          'testOfflineSync': true,
          'testConflictResolution': true,
          'testLargeDataSet': true,
        },
      ),
      RegressionTest(
        featureName: 'PushNotifications',
        configuration: {
          'testReceivedNotification': true,
          'testNotificationClick': true,
          'testNotificationDismiss': true,
          'testSilentNotification': true,
        },
      ),
      RegressionTest(
        featureName: 'InAppPurchases',
        configuration: {
          'testPurchase': true,
          'testRestore': true,
          'testRefund': true,
          'testConsumable': true,
        },
      ),
      RegressionTest(
        featureName: 'Share',
        configuration: {
          'testShareToApps': true,
          'testReceiveShare': true,
          'testShareContent': true,
          'testShareFailure': true,
        },
      ),
    ];
  }

  // 创建默认持续集成测试配置
  static List<CiTest> _createDefaultCiTests() {
    return [
      CiTest(
        environmentName: 'Development',
        configuration: {
          'buildVariant': 'debug',
          'enableLogcat': true,
          'enableTestReport': true,
          'enablePerformanceMonitoring': false,
        },
      ),
      CiTest(
        environmentName: 'Staging',
        configuration: {
          'buildVariant': 'staging',
          'enableLogcat': true,
          'enableTestReport': true,
          'enablePerformanceMonitoring': true,
        },
      ),
      CiTest(
        environmentName: 'Production',
        configuration: {
          'buildVariant': 'release',
          'enableLogcat': false,
          'enableTestReport': true,
          'enablePerformanceMonitoring': true,
        },
      ),
      CiTest(
        environmentName: 'UnitTest',
        configuration: {
          'testType': 'unit',
          'enableCoverage': true,
          'enableTestReport': true,
          'enablePerformanceMonitoring': false,
        },
      ),
      CiTest(
        environmentName: 'IntegrationTest',
        configuration: {
          'testType': 'integration',
          'enableCoverage': false,
          'enableTestReport': true,
          'enablePerformanceMonitoring': true,
        },
      ),
    ];
  }
}

/// 设备模拟配置类
class DeviceSimulation {
  final String brand;
  final String model;
  final Map<String, String> specifications;

  DeviceSimulation({
    required this.brand,
    required this.model,
    required this.specifications,
  });

  Map<String, dynamic> toJson() {
    return {
      'brand': brand,
      'model': model,
      'specifications': specifications,
    };
  }
}

/// 网络模拟配置类
class NetworkSimulation {
  final String networkType;
  final String technology;
  final Map<String, String> configuration;

  NetworkSimulation({
    required this.networkType,
    required this.technology,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'networkType': networkType,
      'technology': technology,
      'configuration': configuration,
    };
  }
}

/// 权限场景配置类
class PermissionScenario {
  final String permissionType;
  final Map<String, bool> configuration;

  PermissionScenario({
    required this.permissionType,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'permissionType': permissionType,
      'configuration': configuration,
    };
  }
}

/// UI场景配置类
class UiScenario {
  final String uiElement;
  final Map<String, bool> configuration;

  UiScenario({
    required this.uiElement,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'uiElement': uiElement,
      'configuration': configuration,
    };
  }
}

/// 压力测试配置类
class StressTest {
  final String testType;
  final Map<String, dynamic> configuration;

  StressTest({
    required this.testType,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'testType': testType,
      'configuration': configuration,
    };
  }
}

/// 回归测试配置类
class RegressionTest {
  final String featureName;
  final Map<String, bool> configuration;

  RegressionTest({
    required this.featureName,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'featureName': featureName,
      'configuration': configuration,
    };
  }
}

/// 持续集成测试配置类
class CiTest {
  final String environmentName;
  final Map<String, dynamic> configuration;

  CiTest({
    required this.environmentName,
    required this.configuration,
  });

  Map<String, dynamic> toJson() {
    return {
      'environmentName': environmentName,
      'configuration': configuration,
    };
  }
}