/// Android 设备兼容性测试主运行器
/// 
/// 负责协调所有兼容性测试模块的执行
/// 提供统一的测试执行入口和结果收集

import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'android_version_test.dart';
import 'device_model_test.dart';
import 'resolution_test.dart';
import 'performance_test.dart';
import 'permission_test.dart';
import 'network_test.dart';
import 'automation/automated_test_runner.dart';
import 'config/test_scenarios.dart';
import 'utils/compatibility_utils.dart';

/// 主测试执行类
class CompatibilityTestRunner {
  late TestScenarios _testScenarios;
  late CompatibilityUtils _utils;
  List<TestResult> _results = [];
  
  CompatibilityTestRunner() {
    _testScenarios = TestScenarios();
    _utils = CompatibilityUtils();
  }

  /// 运行所有兼容性测试
  /// 
  /// [config] 测试配置
  /// [onProgress] 进度回调
  Future<TestReport> runAllTests({
    required TestConfig config,
    void Function(String message, int current, int total)? onProgress,
  }) async {
    _results.clear();
    int totalTests = 7; // 总共7个主要测试模块
    int currentTest = 0;

    print('🚀 开始Android设备兼容性测试');
    print('测试设备: ${config.deviceInfo.brand} ${config.deviceInfo.model}');
    print('Android版本: ${config.deviceInfo.androidVersion}');
    print('测试场景: ${config.testScenario}');
    print('=' * 50);

    try {
      // 1. Android版本兼容性测试
      currentTest++;
      onProgress?.call('正在测试Android版本兼容性...', currentTest, totalTests);
      await _runAndroidVersionTest(config);
      print('✅ Android版本兼容性测试完成');

      // 2. 设备型号兼容性测试
      currentTest++;
      onProgress?.call('正在测试设备型号兼容性...', currentTest, totalTests);
      await _runDeviceModelTest(config);
      print('✅ 设备型号兼容性测试完成');

      // 3. 分辨率适配测试
      currentTest++;
      onProgress?.call('正在测试分辨率适配...', currentTest, totalTests);
      await _runResolutionTest(config);
      print('✅ 分辨率适配测试完成');

      // 4. 性能兼容性测试
      currentTest++;
      onProgress?.call('正在测试性能兼容性...', currentTest, totalTests);
      await _runPerformanceTest(config);
      print('✅ 性能兼容性测试完成');

      // 5. 权限系统测试
      currentTest++;
      onProgress?.call('正在测试权限系统兼容性...', currentTest, totalTests);
      await _runPermissionTest(config);
      print('✅ 权限系统测试完成');

      // 6. 网络环境测试
      currentTest++;
      onProgress?.call('正在测试网络环境兼容性...', currentTest, totalTests);
      await _runNetworkTest(config);
      print('✅ 网络环境测试完成');

      // 7. 自动化集成测试
      currentTest++;
      onProgress?.call('正在运行自动化集成测试...', currentTest, totalTests);
      await _runAutomatedIntegrationTest(config);
      print('✅ 自动化集成测试完成');

      // 生成测试报告
      final report = _generateReport(config);
      print('\n📊 测试报告已生成');
      print('总体通过率: ${report.overallPassRate.toStringAsFixed(1)}%');
      print('详细结果请查看生成的报告文件');
      
      return report;
    } catch (e) {
      print('❌ 测试执行过程中出现错误: $e');
      rethrow;
    }
  }

  /// 运行Android版本测试
  Future<void> _runAndroidVersionTest(TestConfig config) async {
    final test = AndroidVersionCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行设备型号测试
  Future<void> _runDeviceModelTest(TestConfig config) async {
    final test = DeviceModelCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行分辨率测试
  Future<void> _runResolutionTest(TestConfig config) async {
    final test = ResolutionCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行性能测试
  Future<void> _runPerformanceTest(TestConfig config) async {
    final test = PerformanceCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行权限测试
  Future<void> _runPermissionTest(TestConfig config) async {
    final test = PermissionCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行网络测试
  Future<void> _runNetworkTest(TestConfig config) async {
    final test = NetworkCompatibilityTest();
    final result = await test.runCompatibilityTest(config);
    _results.add(result);
  }

  /// 运行自动化集成测试
  Future<void> _runAutomatedIntegrationTest(TestConfig config) async {
    final runner = AutomatedTestRunner();
    final result = await runner.runIntegrationTests(config);
    _results.add(result);
  }

  /// 生成测试报告
  TestReport _generateReport(TestConfig config) {
    return TestReport(
      deviceInfo: config.deviceInfo,
      testScenarios: config.testScenario,
      results: _results,
      timestamp: DateTime.now(),
      overallPassRate: _calculateOverallPassRate(),
      recommendations: _generateRecommendations(),
    );
  }

  /// 计算总体通过率
  double _calculateOverallPassRate() {
    if (_results.isEmpty) return 0.0;
    
    final totalTests = _results.fold<int>(0, (sum, result) => sum + result.totalTests);
    final passedTests = _results.fold<int>(0, (sum, result) => sum + result.passedTests);
    
    return totalTests > 0 ? (passedTests / totalTests) * 100 : 0.0;
  }

  /// 生成改进建议
  List<String> _generateRecommendations() {
    final recommendations = <String>[];
    
    for (final result in _results) {
      if (result.failedTests > 0) {
        recommendations.addAll(result.recommendations);
      }
    }
    
    return recommendations;
  }

  /// 清理测试数据
  void dispose() {
    _results.clear();
  }
}

/// 测试结果类
class TestResult {
  final String testName;
  final int totalTests;
  final int passedTests;
  final int failedTests;
  final List<String> failureDetails;
  final List<String> recommendations;
  final Duration executionTime;
  final Map<String, dynamic> metadata;

  TestResult({
    required this.testName,
    required this.totalTests,
    required this.passedTests,
    required this.failedTests,
    required this.failureDetails,
    required this.recommendations,
    required this.executionTime,
    this.metadata = const {},
  });

  double get passRate => totalTests > 0 ? (passedTests / totalTests) * 100 : 0.0;
  bool get isPassed => failedTests == 0;
}

/// 测试报告类
class TestReport {
  final DeviceInfo deviceInfo;
  final String testScenarios;
  final List<TestResult> results;
  final DateTime timestamp;
  final double overallPassRate;
  final List<String> recommendations;

  TestReport({
    required this.deviceInfo,
    required this.testScenarios,
    required this.results,
    required this.timestamp,
    required this.overallPassRate,
    required this.recommendations,
  });

  Map<String, dynamic> toJson() {
    return {
      'deviceInfo': {
        'brand': deviceInfo.brand,
        'model': deviceInfo.model,
        'androidVersion': deviceInfo.androidVersion,
        'apiLevel': deviceInfo.apiLevel,
        'screenResolution': deviceInfo.screenResolution,
        'ramSize': deviceInfo.ramSize,
        'storageSize': deviceInfo.storageSize,
      },
      'testScenarios': testScenarios,
      'results': results.map((r) => {
        'testName': r.testName,
        'totalTests': r.totalTests,
        'passedTests': r.passedTests,
        'failedTests': r.failedTests,
        'passRate': r.passRate,
        'failureDetails': r.failureDetails,
        'executionTime': r.executionTime.inMilliseconds,
        'metadata': r.metadata,
      }).toList(),
      'timestamp': timestamp.toIso8601String(),
      'overallPassRate': overallPassRate,
      'recommendations': recommendations,
    };
  }
}

/// 设备信息类
class DeviceInfo {
  final String brand;
  final String model;
  final String androidVersion;
  final int apiLevel;
  final String screenResolution;
  final int ramSize;
  final int storageSize;

  DeviceInfo({
    required this.brand,
    required this.model,
    required this.androidVersion,
    required this.apiLevel,
    required this.screenResolution,
    required this.ramSize,
    required this.storageSize,
  });
}

/// 测试配置类
class TestConfig {
  final DeviceInfo deviceInfo;
  final String testScenario;
  final bool enablePerformanceTest;
  final bool enableNetworkTest;
  final bool enablePermissionTest;
  final bool generateDetailedReport;

  TestConfig({
    required this.deviceInfo,
    required this.testScenario,
    this.enablePerformanceTest = true,
    this.enableNetworkTest = true,
    this.enablePermissionTest = true,
    this.generateDetailedReport = true,
  });
}