/// 测试场景配置文件
/// 
/// 定义各种兼容性测试场景和配置

/// 测试场景主配置
class TestScenarios {
  /// 标准兼容性测试场景
  final List<TestScenario> standardScenarios = [
    TestScenario(
      id: 'standard_comprehensive',
      name: '标准综合测试',
      description: '全面的兼容性测试，覆盖所有主要测试项目',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 45),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.deviceModel,
        TestCategory.resolution,
        TestCategory.performance,
        TestCategory.permission,
        TestCategory.network,
      ],
      configurations: {
        'enableDetailedLogging': true,
        'enableScreenshotOnFailure': true,
        'timeout': 300,
      },
    ),
    
    TestScenario(
      id: 'standard_quick',
      name: '快速兼容性测试',
      description: '快速执行关键兼容性测试，适合开发阶段',
      priority: ScenarioPriority.medium,
      estimatedDuration: Duration(minutes: 15),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.deviceModel,
        TestCategory.resolution,
      ],
      configurations: {
        'enableDetailedLogging': false,
        'enableScreenshotOnFailure': false,
        'timeout': 120,
      },
    ),
    
    TestScenario(
      id: 'standard_performance',
      name: '性能专项测试',
      description: '专注于性能兼容性的深度测试',
      priority: ScenarioPriority.medium,
      estimatedDuration: Duration(minutes: 30),
      testCategories: [
        TestCategory.performance,
        TestCategory.deviceModel,
      ],
      configurations: {
        'enableDetailedLogging': true,
        'enablePerformanceProfiling': true,
        'enableMemoryProfiling': true,
        'timeout': 600,
      },
    ),
    
    TestScenario(
      id: 'standard_permission',
      name: '权限专项测试',
      description: '专注于权限系统兼容性的详细测试',
      priority: ScenarioPriority.medium,
      estimatedDuration: Duration(minutes: 20),
      testCategories: [
        TestCategory.permission,
        TestCategory.androidVersion,
      ],
      configurations: {
        'enableDetailedLogging': true,
        'enablePermissionSimulation': true,
        'timeout': 300,
      },
    ),
  ];

  /// 专项兼容性测试场景
  final List<TestScenario> specializedScenarios = [
    TestScenario(
      id: 'specialized_low_end',
      name: '低端设备测试',
      description: '专门针对低端设备的兼容性测试',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 35),
      testCategories: [
        TestCategory.deviceModel,
        TestCategory.performance,
        TestCategory.resolution,
      ],
      configurations: {
        'targetDeviceClass': 'low_end',
        'enableResourceOptimization': true,
        'enablePerformanceThrottling': true,
        'timeout': 600,
      },
    ),
    
    TestScenario(
      id: 'specialized_high_end',
      name: '高端设备测试',
      description: '专门针对高端设备的兼容性测试',
      priority: ScenarioPriority.medium,
      estimatedDuration: Duration(minutes: 25),
      testCategories: [
        TestCategory.deviceModel,
        TestCategory.performance,
        TestCategory.resolution,
      ],
      configurations: {
        'targetDeviceClass': 'high_end',
        'enableAdvancedFeatures': true,
        'enablePerformanceOptimization': true,
        'timeout': 300,
      },
    ),
    
    TestScenario(
      id: 'specialized_network_stress',
      name: '网络压力测试',
      description: '专门测试网络环境下的兼容性表现',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 40),
      testCategories: [
        TestCategory.network,
        TestCategory.performance,
      ],
      configurations: {
        'enableNetworkSimulation': true,
        'enableNetworkStressTesting': true,
        'enableOfflineTesting': true,
        'timeout': 900,
      },
    ),
    
    TestScenario(
      id: 'specialized_legacy_support',
      name: '旧版本兼容测试',
      description: '专门测试对旧版本Android的兼容性',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 50),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.permission,
        TestCategory.deviceModel,
      ],
      configurations: {
        'minimumApiLevel': 21,
        'enableBackwardCompatibility': true,
        'enableFeatureFallback': true,
        'timeout': 1200,
      },
    ),
  ];

  /// 回归测试场景
  final List<TestScenario> regressionScenarios = [
    TestScenario(
      id: 'regression_core',
      name: '核心功能回归测试',
      description: '验证核心功能的兼容性回归',
      priority: ScenarioPriority.critical,
      estimatedDuration: Duration(minutes: 25),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.deviceModel,
        TestCategory.permission,
      ],
      configurations: {
        'enableRegressionComparison': true,
        'enableBaselineComparison': true,
        'timeout': 600,
      },
    ),
    
    TestScenario(
      id: 'regression_performance',
      name: '性能回归测试',
      description: '验证性能指标的回归情况',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 35),
      testCategories: [
        TestCategory.performance,
        TestCategory.deviceModel,
      ],
      configurations: {
        'enablePerformanceRegression': true,
        'enableMemoryRegression': true,
        'enableBaselineComparison': true,
        'timeout': 900,
      },
    ),
  ];

  /// 持续集成测试场景
  final List<TestScenario> ciScenarios = [
    TestScenario(
      id: 'ci_smoke',
      name: '冒烟测试',
      description: '持续集成中的冒烟测试，快速验证基本兼容性',
      priority: ScenarioPriority.critical,
      estimatedDuration: Duration(minutes: 10),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.deviceModel,
      ],
      configurations: {
        'enableDetailedLogging': false,
        'enableQuickExecution': true,
        'timeout': 300,
      },
    ),
    
    TestScenario(
      id: 'ci_nightly',
      name: '夜间完整测试',
      description: '夜间执行的完整兼容性测试',
      priority: ScenarioPriority.high,
      estimatedDuration: Duration(minutes: 90),
      testCategories: [
        TestCategory.androidVersion,
        TestCategory.deviceModel,
        TestCategory.resolution,
        TestCategory.performance,
        TestCategory.permission,
        TestCategory.network,
      ],
      configurations: {
        'enableDetailedLogging': true,
        'enableFullCoverage': true,
        'enableReporting': true,
        'timeout': 3600,
      },
    ),
  ];

  /// 获取所有场景
  List<TestScenario> getAllScenarios() {
    return [
      ...standardScenarios,
      ...specializedScenarios,
      ...regressionScenarios,
      ...ciScenarios,
    ];
  }

  /// 根据ID获取场景
  TestScenario? getScenarioById(String id) {
    return getAllScenarios().firstWhere(
      (scenario) => scenario.id == id,
      orElse: () => null as TestScenario,
    );
  }

  /// 根据优先级获取场景
  List<TestScenario> getScenariosByPriority(ScenarioPriority priority) {
    return getAllScenarios().where((scenario) => scenario.priority == priority).toList();
  }

  /// 根据预估时长获取场景
  List<TestScenario> getScenariosByMaxDuration(Duration maxDuration) {
    return getAllScenarios().where((scenario) => 
        scenario.estimatedDuration <= maxDuration).toList();
  }

  /// 获取推荐场景
  List<TestScenario> getRecommendedScenarios() {
    return getAllScenarios()
        .where((scenario) => 
            scenario.priority == ScenarioPriority.high ||
            scenario.priority == ScenarioPriority.critical)
        .toList();
  }
}

/// 测试场景类
class TestScenario {
  final String id;
  final String name;
  final String description;
  final ScenarioPriority priority;
  final Duration estimatedDuration;
  final List<TestCategory> testCategories;
  final Map<String, dynamic> configurations;

  TestScenario({
    required this.id,
    required this.name,
    required this.description,
    required this.priority,
    required this.estimatedDuration,
    required this.testCategories,
    this.configurations = const {},
  });

  /// 检查是否包含指定的测试类别
  bool hasCategory(TestCategory category) {
    return testCategories.contains(category);
  }

  /// 获取配置值
  T? getConfiguration<T>(String key) {
    return configurations[key] as T?;
  }

  /// 检查是否启用指定配置
  bool isConfigurationEnabled(String key) {
    final value = configurations[key];
    return value == true || value == 'true' || value == 1 || value == '1';
  }

  /// 获取配置值或默认值
  T getConfigurationOrDefault<T>(String key, T defaultValue) {
    return configurations[key] as T? ?? defaultValue;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'priority': priority.toString(),
      'estimatedDuration': estimatedDuration.inMilliseconds,
      'testCategories': testCategories.map((c) => c.toString()).toList(),
      'configurations': configurations,
    };
  }
}

/// 测试类别枚举
enum TestCategory {
  androidVersion,
  deviceModel,
  resolution,
  performance,
  permission,
  network,
}

/// 场景优先级枚举
enum ScenarioPriority {
  low,
  medium,
  high,
  critical,
}

/// 设备档案配置
class DeviceProfiles {
  /// 低端设备档案
  static final List<DeviceProfileConfig> lowEndDevices = [
    DeviceProfileConfig(
      brand: 'Xiaomi',
      model: 'Redmi 9A',
      ramSize: 2,
      storageSize: 32,
      androidVersion: '10',
      apiLevel: 29,
      screenResolution: '720x1600',
      cpuModel: 'MediaTek Helio G25',
    ),
    DeviceProfileConfig(
      brand: 'Samsung',
      model: 'Galaxy A01',
      ramSize: 2,
      storageSize: 16,
      androidVersion: '10',
      apiLevel: 29,
      screenResolution: '720x1520',
      cpuModel: 'Qualcomm Snapdragon 439',
    ),
    DeviceProfileConfig(
      brand: 'Huawei',
      model: 'Y5p',
      ramSize: 2,
      storageSize: 32,
      androidVersion: '10',
      apiLevel: 29,
      screenResolution: '720x1440',
      cpuModel: 'MediaTek Helio P22',
    ),
  ];

  /// 中端设备档案
  static final List<DeviceProfileConfig> midRangeDevices = [
    DeviceProfileConfig(
      brand: 'Xiaomi',
      model: 'Redmi Note 10',
      ramSize: 6,
      storageSize: 128,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1080x2400',
      cpuModel: 'Qualcomm Snapdragon 678',
    ),
    DeviceProfileConfig(
      brand: 'Samsung',
      model: 'Galaxy A52',
      ramSize: 6,
      storageSize: 128,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1080x2400',
      cpuModel: 'Qualcomm Snapdragon 720G',
    ),
    DeviceProfileConfig(
      brand: 'OPPO',
      model: 'A74',
      ramSize: 6,
      storageSize: 128,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1080x2400',
      cpuModel: 'Qualcomm Snapdragon 662',
    ),
  ];

  /// 高端设备档案
  static final List<DeviceProfileConfig> highEndDevices = [
    DeviceProfileConfig(
      brand: 'Samsung',
      model: 'Galaxy S21',
      ramSize: 8,
      storageSize: 256,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1080x2400',
      cpuModel: 'Samsung Exynos 2100',
    ),
    DeviceProfileConfig(
      brand: 'Xiaomi',
      model: 'Mi 11',
      ramSize: 8,
      storageSize: 256,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1440x3200',
      cpuModel: 'Qualcomm Snapdragon 888',
    ),
    DeviceProfileConfig(
      brand: 'OnePlus',
      model: 'OnePlus 9',
      ramSize: 12,
      storageSize: 256,
      androidVersion: '11',
      apiLevel: 30,
      screenResolution: '1080x2400',
      cpuModel: 'Qualcomm Snapdragon 888',
    ),
    DeviceProfileConfig(
      brand: 'Google',
      model: 'Pixel 6',
      ramSize: 8,
      storageSize: 128,
      androidVersion: '12',
      apiLevel: 31,
      screenResolution: '1080x2400',
      cpuModel: 'Google Tensor',
    ),
  ];

  /// 获取指定等级的设备档案
  static List<DeviceProfileConfig> getDevicesByClass(String deviceClass) {
    switch (deviceClass.toLowerCase()) {
      case 'low_end':
      case 'low':
        return lowEndDevices;
      case 'mid_range':
      case 'mid':
        return midRangeDevices;
      case 'high_end':
      case 'high':
        return highEndDevices;
      default:
        return [...lowEndDevices, ...midRangeDevices, ...highEndDevices];
    }
  }
}

/// 设备档案配置类
class DeviceProfileConfig {
  final String brand;
  final String model;
  final int ramSize;
  final int storageSize;
  final String androidVersion;
  final int apiLevel;
  final String screenResolution;
  final String cpuModel;

  DeviceProfileConfig({
    required this.brand,
    required this.model,
    required this.ramSize,
    required this.storageSize,
    required this.androidVersion,
    required this.apiLevel,
    required this.screenResolution,
    required this.cpuModel,
  });

  /// 转换为DeviceInfo对象
  DeviceInfo toDeviceInfo() {
    return DeviceInfo(
      brand: brand,
      model: model,
      androidVersion: androidVersion,
      apiLevel: apiLevel,
      screenResolution: screenResolution,
      ramSize: ramSize,
      storageSize: storageSize,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'brand': brand,
      'model': model,
      'ramSize': ramSize,
      'storageSize': storageSize,
      'androidVersion': androidVersion,
      'apiLevel': apiLevel,
      'screenResolution': screenResolution,
      'cpuModel': cpuModel,
    };
  }
}

/// 网络配置文件
class NetworkProfiles {
  /// 慢速网络配置
  static final List<NetworkProfileConfig> slowNetworks = [
    NetworkProfileConfig(
      name: '2G网络',
      type: 'mobile',
      technology: '2G',
      speed: 64, // kbps
      latency: 600, // ms
      reliability: 0.6,
    ),
    NetworkProfileConfig(
      name: '慢速3G网络',
      type: 'mobile',
      technology: '3G',
      speed: 384, // kbps
      latency: 300, // ms
      reliability: 0.7,
    ),
    NetworkProfileConfig(
      name: '慢速WiFi',
      type: 'wifi',
      technology: '802.11n',
      speed: 1024, // kbps
      latency: 200, // ms
      reliability: 0.8,
    ),
  ];

  /// 中速网络配置
  static final List<NetworkProfileConfig> mediumNetworks = [
    NetworkProfileConfig(
      name: '标准4G网络',
      type: 'mobile',
      technology: '4G',
      speed: 10240, // kbps (10Mbps)
      latency: 100, // ms
      reliability: 0.85,
    ),
    NetworkProfileConfig(
      name: '标准WiFi',
      type: 'wifi',
      technology: '802.11ac',
      speed: 51200, // kbps (50Mbps)
      latency: 50, // ms
      reliability: 0.9,
    ),
  ];

  /// 快速网络配置
  static final List<NetworkProfileConfig> fastNetworks = [
    NetworkProfileConfig(
      name: '5G网络',
      type: 'mobile',
      technology: '5G',
      speed: 102400, // kbps (100Mbps)
      latency: 20, // ms
      reliability: 0.95,
    ),
    NetworkProfileConfig(
      name: '千兆WiFi',
      type: 'wifi',
      technology: '802.11ax',
      speed: 1048576, // kbps (1Gbps)
      latency: 10, // ms
      reliability: 0.98,
    ),
  ];

  /// 获取所有网络配置
  static List<NetworkProfileConfig> getAllNetworks() {
    return [...slowNetworks, ...mediumNetworks, ...fastNetworks];
  }

  /// 根据速度等级获取网络配置
  static List<NetworkProfileConfig> getNetworksBySpeed(String speedClass) {
    switch (speedClass.toLowerCase()) {
      case 'slow':
        return slowNetworks;
      case 'medium':
        return mediumNetworks;
      case 'fast':
        return fastNetworks;
      default:
        return getAllNetworks();
    }
  }
}

/// 网络档案配置类
class NetworkProfileConfig {
  final String name;
  final String type; // mobile, wifi, ethernet
  final String technology;
  final int speed; // kbps
  final int latency; // ms
  final double reliability; // 0-1

  NetworkProfileConfig({
    required this.name,
    required this.type,
    required this.technology,
    required this.speed,
    required this.latency,
    required this.reliability,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'technology': technology,
      'speed': speed,
      'latency': latency,
      'reliability': reliability,
    };
  }
}