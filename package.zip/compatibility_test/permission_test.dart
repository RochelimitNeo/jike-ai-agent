/// 权限系统兼容性测试
/// 
/// 测试不同Android版本的权限系统兼容性

import 'dart:async';
import 'main_test_runner.dart';

/// 权限系统兼容性测试类
class PermissionCompatibilityTest {
  final Map<int, PermissionSystemInfo> _permissionSystems = {
    // Android 6.0 (API 23) - 运行时权限引入
    23: PermissionSystemInfo(
      'Android 6.0',
      'Marshmallow',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature'],
      specialPermissions: ['WRITE_SETTINGS', 'SYSTEM_ALERT_WINDOW'],
      backgroundLocationPermissions: false,
      oneTimePermissions: false,
      photoPickerPermissions: false,
    ),
    // Android 8.0 (API 26) - 后台位置权限
    26: PermissionSystemInfo(
      'Android 8.0',
      'Oreo',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature'],
      specialPermissions: ['WRITE_SETTINGS', 'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES'],
      backgroundLocationPermissions: true,
      oneTimePermissions: false,
      photoPickerPermissions: false,
    ),
    // Android 10 (API 29) - 范围存储和单次权限
    29: PermissionSystemInfo(
      'Android 10',
      'Q',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature'],
      specialPermissions: ['WRITE_SETTINGS', 'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES'],
      backgroundLocationPermissions: true,
      oneTimePermissions: true,
      photoPickerPermissions: false,
    ),
    // Android 11 (API 30) - 一次性权限和权限对话框更新
    30: PermissionSystemInfo(
      'Android 11',
      'R',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature'],
      specialPermissions: ['WRITE_SETTINGS', 'SYSTEM_ALERT_WINDOW', 'REQUEST_INSTALL_PACKAGES'],
      backgroundLocationPermissions: true,
      oneTimePermissions: true,
      photoPickerPermissions: false,
    ),
    // Android 12 (API 31) - 附近设备权限等
    31: PermissionSystemInfo(
      'Android 12',
      'S',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature', 'Special'],
      specialPermissions: [
        'WRITE_SETTINGS', 
        'SYSTEM_ALERT_WINDOW', 
        'REQUEST_INSTALL_PACKAGES',
        'BLUETOOTH_SCAN',
        'BLUETOOTH_CONNECT',
        'BLUETOOTH_ADVERTISE',
        'NEARBY_WIFI_DEVICES'
      ],
      backgroundLocationPermissions: true,
      oneTimePermissions: true,
      photoPickerPermissions: false,
    ),
    // Android 13 (API 33) - 通知权限
    33: PermissionSystemInfo(
      'Android 13',
      'T',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature', 'Special'],
      specialPermissions: [
        'WRITE_SETTINGS', 
        'SYSTEM_ALERT_WINDOW', 
        'REQUEST_INSTALL_PACKAGES',
        'BLUETOOTH_SCAN',
        'BLUETOOTH_CONNECT',
        'BLUETOOTH_ADVERTISE',
        'NEARBY_WIFI_DEVICES',
        'POST_NOTIFICATIONS'
      ],
      backgroundLocationPermissions: true,
      oneTimePermissions: true,
      photoPickerPermissions: true,
    ),
    // Android 14 (API 34) - 部分照片分享等
    34: PermissionSystemInfo(
      'Android 14',
      'UpsideDownCake',
      hasRuntimePermissions: true,
      permissionGroups: ['Normal', 'Dangerous', 'Signature', 'Special'],
      specialPermissions: [
        'WRITE_SETTINGS', 
        'SYSTEM_ALERT_WINDOW', 
        'REQUEST_INSTALL_PACKAGES',
        'BLUETOOTH_SCAN',
        'BLUETOOTH_CONNECT',
        'BLUETOOTH_ADVERTISE',
        'NEARBY_WIFI_DEVICES',
        'POST_NOTIFICATIONS',
        'FOREGROUND_SERVICE_CAMERA',
        'FOREGROUND_SERVICE_MICROPHONE'
      ],
      backgroundLocationPermissions: true,
      oneTimePermissions: true,
      photoPickerPermissions: true,
    ),
  };

  final Map<String, PermissionCategory> _permissionCategories = {
    'Normal': PermissionCategory(
      name: 'Normal',
      description: '普通权限，系统自动授予',
      requiresRuntimeRequest: false,
      requiresUserConsent: false,
      canBeRevoked: false,
    ),
    'Dangerous': PermissionCategory(
      name: 'Dangerous',
      description: '危险权限，需要用户明确授权',
      requiresRuntimeRequest: true,
      requiresUserConsent: true,
      canBeRevoked: true,
    ),
    'Signature': PermissionCategory(
      name: 'Signature',
      description: '签名权限，与应用签名匹配的证书',
      requiresRuntimeRequest: false,
      requiresUserConsent: false,
      canBeRevoked: false,
    ),
    'Special': PermissionCategory(
      name: 'Special',
      description: '特殊权限，需要特殊处理',
      requiresRuntimeRequest: true,
      requiresUserConsent: true,
      canBeRevoked: true,
    ),
  };

  /// 运行权限系统兼容性测试
  Future<TestResult> runCompatibilityTest(TestConfig config) async {
    final startTime = DateTime.now();
    final failureDetails = <String>[];
    final recommendations = <String>[];
    final metadata = <String, dynamic>{};

    print('🔐 权限系统兼容性测试开始');
    print('当前Android版本: ${config.deviceInfo.androidVersion} (API ${config.deviceInfo.apiLevel})');

    // 获取权限系统信息
    final permissionSystem = _getPermissionSystem(config.deviceInfo.apiLevel);
    if (permissionSystem == null) {
      failureDetails.add('未知的权限系统版本: API ${config.deviceInfo.apiLevel}');
      recommendations.add('请确保应用程序支持目标Android版本的权限系统');
      
      return TestResult(
        testName: '权限系统兼容性测试',
        totalTests: 1,
        passedTests: 0,
        failedTests: 1,
        failureDetails: failureDetails,
        recommendations: recommendations,
        executionTime: DateTime.now().difference(startTime),
        metadata: metadata,
      );
    }

    // 执行权限系统兼容性测试
    final tests = await _performPermissionCompatibilityTests(config.deviceInfo, permissionSystem);
    metadata['permissionSystem'] = permissionSystem.toJson();
    metadata['testResults'] = tests;

    final passedTests = tests.where((test) => test.passed).length;
    final totalTests = tests.length;

    // 生成建议
    if (passedTests < totalTests) {
      recommendations.addAll(_generatePermissionRecommendations(tests, permissionSystem));
    }

    return TestResult(
      testName: '权限系统兼容性测试',
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: totalTests - passedTests,
      failureDetails: failureDetails,
      recommendations: recommendations,
      executionTime: DateTime.now().difference(startTime),
      metadata: metadata,
    );
  }

  /// 执行具体的权限系统兼容性测试
  Future<List<PermissionCompatibilityTest>> _performPermissionCompatibilityTests(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    final tests = <PermissionCompatibilityTest>[];

    // 1. 运行时权限兼容性测试
    tests.add(await _testRuntimePermissions(deviceInfo, permissionSystem));

    // 2. 权限分组兼容性测试
    tests.add(await _testPermissionGroups(deviceInfo, permissionSystem));

    // 3. 特殊权限兼容性测试
    tests.add(await _testSpecialPermissions(deviceInfo, permissionSystem));

    // 4. 权限请求流程测试
    tests.add(await _testPermissionRequestFlow(deviceInfo, permissionSystem));

    // 5. 权限管理兼容性测试
    tests.add(await _testPermissionManagement(deviceInfo, permissionSystem));

    // 6. 后台权限兼容性测试
    tests.add(await _testBackgroundPermissions(deviceInfo, permissionSystem));

    // 7. 一次性权限兼容性测试
    tests.add(await _testOneTimePermissions(deviceInfo, permissionSystem));

    // 8. 新权限特性测试
    tests.add(await _testNewPermissionFeatures(deviceInfo, permissionSystem));

    // 9. 权限降级策略测试
    tests.add(await _testPermissionFallback(deviceInfo, permissionSystem));

    // 10. 权限安全测试
    tests.add(await _testPermissionSecurity(deviceInfo, permissionSystem));

    return tests;
  }

  /// 测试运行时权限兼容性
  Future<PermissionCompatibilityTest> _testRuntimePermissions(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final runtimePermissionTests = <String, bool>{};
      
      // 检查运行时权限支持
      runtimePermissionTests['运行时权限支持'] = permissionSystem.hasRuntimePermissions;
      
      // 检查权限请求机制
      runtimePermissionTests['权限请求机制'] = _checkPermissionRequestMechanism(permissionSystem);
      
      // 检查权限拒绝处理
      runtimePermissionTests['权限拒绝处理'] = _checkPermissionDenialHandling(permissionSystem);
      
      // 检查权限撤销处理
      runtimePermissionTests['权限撤销处理'] = _checkPermissionRevocationHandling(permissionSystem);
      
      // 检查权限状态检查
      runtimePermissionTests['权限状态检查'] = _checkPermissionStatusChecking(permissionSystem);

      final supportedCount = runtimePermissionTests.values.where((supported) => supported).length;
      final totalCount = runtimePermissionTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '运行时权限兼容性测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '运行时权限支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: runtimePermissionTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: runtimePermissionTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '运行时权限兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试权限分组兼容性
  Future<PermissionCompatibilityTest> _testPermissionGroups(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final groupTests = <String, bool>{};
      
      // 检查权限分组支持
      for (final groupName in permissionSystem.permissionGroups) {
        final category = _permissionCategories[groupName];
        if (category != null) {
          groupTests['${groupName}权限分组'] = _checkPermissionGroupCompatibility(category, permissionSystem);
        }
      }
      
      // 检查分组授权机制
      groupTests['分组授权机制'] = _checkGroupAuthorizationMechanism(permissionSystem);
      
      // 检查分组权限合并
      groupTests['分组权限合并'] = _checkGroupPermissionMerging(permissionSystem);

      final supportedCount = groupTests.values.where((supported) => supported).length;
      final totalCount = groupTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '权限分组兼容性测试',
        passed: supportRate >= 75,
        score: supportRate,
        details: '权限分组支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: groupTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: groupTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '权限分组兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试特殊权限兼容性
  Future<PermissionCompatibilityTest> _testSpecialPermissions(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final specialPermissionTests = <String, bool>{};
      
      // 检查特殊权限支持
      for (final permission in permissionSystem.specialPermissions) {
        specialPermissionTests[permission] = _checkSpecialPermissionSupport(permission, permissionSystem);
      }
      
      // 检查特殊权限处理流程
      specialPermissionTests['特殊权限处理流程'] = _checkSpecialPermissionFlow(permissionSystem);
      
      // 检查系统级权限处理
      specialPermissionTests['系统级权限处理'] = _checkSystemLevelPermissions(permissionSystem);

      final supportedCount = specialPermissionTests.values.where((supported) => supported).length;
      final totalCount = specialPermissionTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '特殊权限兼容性测试',
        passed: supportRate >= 70,
        score: supportRate,
        details: '特殊权限支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: specialPermissionTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: specialPermissionTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '特殊权限兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试权限请求流程
  Future<PermissionCompatibilityTest> _testPermissionRequestFlow(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final flowTests = <String, bool>{};
      
      // 检查权限请求UI兼容性
      flowTests['权限请求UI兼容'] = _checkPermissionRequestUI(permissionSystem);
      
      // 检查权限解释说明
      flowTests['权限解释说明'] = _checkPermissionRationale(permissionSystem);
      
      // 检查权限请求时机
      flowTests['权限请求时机'] = _checkPermissionRequestTiming(permissionSystem);
      
      // 检查权限批量请求
      flowTests['权限批量请求'] = _checkBatchPermissionRequest(permissionSystem);
      
      // 检查权限结果处理
      flowTests['权限结果处理'] = _checkPermissionResultHandling(permissionSystem);

      final supportedCount = flowTests.values.where((supported) => supported).length;
      final totalCount = flowTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '权限请求流程测试',
        passed: supportRate >= 85,
        score: supportRate,
        details: '权限请求流程支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: flowTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: flowTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '权限请求流程测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试权限管理兼容性
  Future<PermissionCompatibilityTest> _testPermissionManagement(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final managementTests = <String, bool>{};
      
      // 检查权限查看界面
      managementTests['权限查看界面'] = _checkPermissionViewInterface(permissionSystem);
      
      // 检查权限撤销机制
      managementTests['权限撤销机制'] = _checkPermissionRevocationMechanism(permissionSystem);
      
      // 检查权限重置功能
      managementTests['权限重置功能'] = _checkPermissionResetFunction(permissionSystem);
      
      // 检查权限自动撤销
      managementTests['权限自动撤销'] = _checkPermissionAutoRevocation(permissionSystem);
      
      // 检查权限生命周期管理
      managementTests['权限生命周期管理'] = _checkPermissionLifecycleManagement(permissionSystem);

      final supportedCount = managementTests.values.where((supported) => supported).length;
      final totalCount = managementTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '权限管理兼容性测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '权限管理支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: managementTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: managementTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '权限管理兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试后台权限兼容性
  Future<PermissionCompatibilityTest> _testBackgroundPermissions(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final backgroundTests = <String, bool>{};
      
      // 检查后台位置权限
      backgroundTests['后台位置权限'] = permissionSystem.backgroundLocationPermissions;
      
      // 检查前台服务权限
      backgroundTests['前台服务权限'] = _checkForegroundServicePermissions(permissionSystem);
      
      // 检查后台任务权限
      backgroundTests['后台任务权限'] = _checkBackgroundTaskPermissions(permissionSystem);
      
      // 检查后台应用限制
      backgroundTests['后台应用限制'] = _checkBackgroundAppRestrictions(permissionSystem);
      
      // 检查后台运行限制处理
      backgroundTests['后台运行限制处理'] = _checkBackgroundRunRestrictionHandling(permissionSystem);

      final supportedCount = backgroundTests.values.where((supported) => supported).length;
      final totalCount = backgroundTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '后台权限兼容性测试',
        passed: supportRate >= 75,
        score: supportRate,
        details: '后台权限支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: backgroundTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: backgroundTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '后台权限兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试一次性权限兼容性
  Future<PermissionCompatibilityTest> _testOneTimePermissions(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final oneTimeTests = <String, bool>{};
      
      // 检查一次性权限支持
      oneTimeTests['一次性权限支持'] = permissionSystem.oneTimePermissions;
      
      // 检查一次性权限生命周期
      oneTimeTests['一次性权限生命周期'] = _checkOneTimePermissionLifecycle(permissionSystem);
      
      // 检查一次性权限自动撤销
      oneTimeTests['一次性权限自动撤销'] = _checkOneTimePermissionAutoRevocation(permissionSystem);
      
      // 检查一次性权限重新请求
      oneTimeTests['一次性权限重新请求'] = _checkOneTimePermissionReRequest(permissionSystem);

      final supportedCount = oneTimeTests.values.where((supported) => supported).length;
      final totalCount = oneTimeTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 
                          permissionSystem.oneTimePermissions ? 100 : 0;

      return PermissionCompatibilityTest(
        testName: '一次性权限兼容性测试',
        passed: permissionSystem.oneTimePermissions ? supportRate >= 80 : true,
        score: supportRate,
        details: '一次性权限支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: oneTimeTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: oneTimeTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '一次性权限兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试新权限特性
  Future<PermissionCompatibilityTest> _testNewPermissionFeatures(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final newFeatureTests = <String, bool>{};
      
      // 检查照片选择器权限
      newFeatureTests['照片选择器权限'] = permissionSystem.photoPickerPermissions;
      
      // 检查通知权限
      newFeatureTests['通知权限'] = _checkNotificationPermissions(permissionSystem);
      
      // 检查附近设备权限
      newFeatureTests['附近设备权限'] = _checkNearbyDevicePermissions(permissionSystem);
      
      // 检查精确闹钟权限
      newFeatureTests['精确闹钟权限'] = _checkExactAlarmPermissions(permissionSystem);
      
      // 检查后台健身权限
      newFeatureTests['后台健身权限'] = _checkBackgroundFitnessPermissions(permissionSystem);

      final supportedCount = newFeatureTests.values.where((supported) => supported).length;
      final totalCount = newFeatureTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '新权限特性测试',
        passed: supportRate >= 70,
        score: supportRate,
        details: '新权限特性支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: newFeatureTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: newFeatureTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '新权限特性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试权限降级策略
  Future<PermissionCompatibilityTest> _testPermissionFallback(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final fallbackTests = <String, bool>{};
      
      // 检查权限不可用时的处理
      fallbackTests['权限不可用处理'] = _checkPermissionUnavailableHandling(permissionSystem);
      
      // 检查权限降级机制
      fallbackTests['权限降级机制'] = _checkPermissionFallbackMechanism(permissionSystem);
      
      // 检查替代方案提供
      fallbackTests['替代方案提供'] = _checkAlternativeSolutions(permissionSystem);
      
      // 检查功能降级处理
      fallbackTests['功能降级处理'] = _checkFeatureDegradation(permissionSystem);
      
      // 检查用户体验优化
      fallbackTests['用户体验优化'] = _checkUserExperienceOptimization(permissionSystem);

      final supportedCount = fallbackTests.values.where((supported) => supported).length;
      final totalCount = fallbackTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '权限降级策略测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '权限降级策略支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: fallbackTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: fallbackTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '权限降级策略测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 测试权限安全
  Future<PermissionCompatibilityTest> _testPermissionSecurity(
    DeviceInfo deviceInfo,
    PermissionSystemInfo permissionSystem,
  ) async {
    try {
      final securityTests = <String, bool>{};
      
      // 检查权限最小化原则
      securityTests['权限最小化原则'] = _checkPermissionMinimization(permissionSystem);
      
      // 检查权限透明度
      securityTests['权限透明度'] = _checkPermissionTransparency(permissionSystem);
      
      // 检查权限审计
      securityTests['权限审计'] = _checkPermissionAudit(permissionSystem);
      
      // 检查权限滥用防护
      securityTests['权限滥用防护'] = _checkPermissionAbuseProtection(permissionSystem);
      
      // 检查权限验证机制
      securityTests['权限验证机制'] = _checkPermissionVerificationMechanism(permissionSystem);

      final supportedCount = securityTests.values.where((supported) => supported).length;
      final totalCount = securityTests.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 0;

      return PermissionCompatibilityTest(
        testName: '权限安全测试',
        passed: supportRate >= 85,
        score: supportRate,
        details: '权限安全性支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: securityTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        permissionDetails: securityTests.entries.map((e) => '${e.key}: ${e.value ? "支持" : "不支持"}').toList(),
      );
    } catch (e) {
      return PermissionCompatibilityTest(
        testName: '权限安全测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        permissionDetails: [],
      );
    }
  }

  /// 获取权限系统信息
  PermissionSystemInfo? _getPermissionSystem(int apiLevel) {
    return _permissionSystems[apiLevel];
  }

  // 模拟检查方法
  bool _checkPermissionRequestMechanism(PermissionSystemInfo system) => true;
  bool _checkPermissionDenialHandling(PermissionSystemInfo system) => true;
  bool _checkPermissionRevocationHandling(PermissionSystemInfo system) => true;
  bool _checkPermissionStatusChecking(PermissionSystemInfo system) => true;
  bool _checkPermissionGroupCompatibility(PermissionCategory category, PermissionSystemInfo system) => true;
  bool _checkGroupAuthorizationMechanism(PermissionSystemInfo system) => true;
  bool _checkGroupPermissionMerging(PermissionSystemInfo system) => true;
  bool _checkSpecialPermissionSupport(String permission, PermissionSystemInfo system) => true;
  bool _checkSpecialPermissionFlow(PermissionSystemInfo system) => true;
  bool _checkSystemLevelPermissions(PermissionSystemInfo system) => true;
  bool _checkPermissionRequestUI(PermissionSystemInfo system) => true;
  bool _checkPermissionRationale(PermissionSystemInfo system) => true;
  bool _checkPermissionRequestTiming(PermissionSystemInfo system) => true;
  bool _checkBatchPermissionRequest(PermissionSystemInfo system) => true;
  bool _checkPermissionResultHandling(PermissionSystemInfo system) => true;
  bool _checkPermissionViewInterface(PermissionSystemInfo system) => true;
  bool _checkPermissionRevocationMechanism(PermissionSystemInfo system) => true;
  bool _checkPermissionResetFunction(PermissionSystemInfo system) => true;
  bool _checkPermissionAutoRevocation(PermissionSystemInfo system) => true;
  bool _checkPermissionLifecycleManagement(PermissionSystemInfo system) => true;
  bool _checkForegroundServicePermissions(PermissionSystemInfo system) => true;
  bool _checkBackgroundTaskPermissions(PermissionSystemInfo system) => true;
  bool _checkBackgroundAppRestrictions(PermissionSystemInfo system) => true;
  bool _checkBackgroundRunRestrictionHandling(PermissionSystemInfo system) => true;
  bool _checkOneTimePermissionLifecycle(PermissionSystemInfo system) => true;
  bool _checkOneTimePermissionAutoRevocation(PermissionSystemInfo system) => true;
  bool _checkOneTimePermissionReRequest(PermissionSystemInfo system) => true;
  bool _checkNotificationPermissions(PermissionSystemInfo system) => system.apiLevel >= 33;
  bool _checkNearbyDevicePermissions(PermissionSystemInfo system) => system.apiLevel >= 31;
  bool _checkExactAlarmPermissions(PermissionSystemInfo system) => system.apiLevel >= 31;
  bool _checkBackgroundFitnessPermissions(PermissionSystemInfo system) => system.apiLevel >= 30;
  bool _checkPermissionUnavailableHandling(PermissionSystemInfo system) => true;
  bool _checkPermissionFallbackMechanism(PermissionSystemInfo system) => true;
  bool _checkAlternativeSolutions(PermissionSystemInfo system) => true;
  bool _checkFeatureDegradation(PermissionSystemInfo system) => true;
  bool _checkUserExperienceOptimization(PermissionSystemInfo system) => true;
  bool _checkPermissionMinimization(PermissionSystemInfo system) => true;
  bool _checkPermissionTransparency(PermissionSystemInfo system) => true;
  bool _checkPermissionAudit(PermissionSystemInfo system) => true;
  bool _checkPermissionAbuseProtection(PermissionSystemInfo system) => true;
  bool _checkPermissionVerificationMechanism(PermissionSystemInfo system) => true;

  /// 生成权限相关建议
  List<String> _generatePermissionRecommendations(List<PermissionCompatibilityTest> tests, PermissionSystemInfo system) {
    final recommendations = <String>[];
    
    for (final test in tests) {
      if (!test.passed) {
        switch (test.testName) {
          case '运行时权限兼容性测试':
            recommendations.add('实现运行时权限请求处理');
            recommendations.add('添加权限状态检查机制');
            break;
          case '权限分组兼容性测试':
            recommendations.add('适配不同版本的权限分组机制');
            recommendations.add('实现权限分组请求优化');
            break;
          case '特殊权限兼容性测试':
            recommendations.add('实现特殊权限的兼容性处理');
            recommendations.add('添加权限降级方案');
            break;
          case '权限请求流程测试':
            recommendations.add('优化权限请求用户体验');
            recommendations.add('实现权限请求时机优化');
            break;
          case '新权限特性测试':
            recommendations.add('适配最新的权限特性');
            recommendations.add('实现向后兼容的权限处理');
            break;
        }
      }
    }
    
    return recommendations;
  }
}

/// 权限系统信息类
class PermissionSystemInfo {
  final String version;
  final String codename;
  final bool hasRuntimePermissions;
  final List<String> permissionGroups;
  final List<String> specialPermissions;
  final bool backgroundLocationPermissions;
  final bool oneTimePermissions;
  final bool photoPickerPermissions;
  final int apiLevel;

  PermissionSystemInfo(
    this.version,
    this.codename, {
    required this.hasRuntimePermissions,
    required this.permissionGroups,
    required this.specialPermissions,
    required this.backgroundLocationPermissions,
    required this.oneTimePermissions,
    required this.photoPickerPermissions,
  }) : apiLevel = int.parse(version.split('.')[0]);

  Map<String, dynamic> toJson() {
    return {
      'version': version,
      'codename': codename,
      'hasRuntimePermissions': hasRuntimePermissions,
      'permissionGroups': permissionGroups,
      'specialPermissions': specialPermissions,
      'backgroundLocationPermissions': backgroundLocationPermissions,
      'oneTimePermissions': oneTimePermissions,
      'photoPickerPermissions': photoPickerPermissions,
      'apiLevel': apiLevel,
    };
  }
}

/// 权限分类信息类
class PermissionCategory {
  final String name;
  final String description;
  final bool requiresRuntimeRequest;
  final bool requiresUserConsent;
  final bool canBeRevoked;

  PermissionCategory({
    required this.name,
    required this.description,
    required this.requiresRuntimeRequest,
    required this.requiresUserConsent,
    required this.canBeRevoked,
  });
}

/// 权限兼容性测试结果类
class PermissionCompatibilityTest {
  final String testName;
  final bool passed;
  final double score;
  final String details;
  final List<String> supportedFeatures;
  final List<String> permissionDetails;

  PermissionCompatibilityTest({
    required this.testName,
    required this.passed,
    required this.score,
    required this.details,
    required this.supportedFeatures,
    required this.permissionDetails,
  });
}