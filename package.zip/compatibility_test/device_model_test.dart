/// 设备型号兼容性测试
/// 
/// 测试主流Android设备型号的兼容性和特性支持

import 'dart:async';
import 'dart:io';
import 'main_test_runner.dart';

/// 设备型号兼容性测试类
class DeviceModelCompatibilityTest {
  final Map<String, DeviceProfile> _supportedDevices = {
    // Samsung 设备
    'Galaxy S21': DeviceProfile(
      brand: 'Samsung',
      model: 'Galaxy S21',
      chipSet: 'Exynos 2100',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.2,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['Samsung Knox', 'DeX Mode', 'S Pen'],
    ),
    'Galaxy S20': DeviceProfile(
      brand: 'Samsung',
      model: 'Galaxy S20',
      chipSet: 'Exynos 990',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.2,
      osVersions: ['10', '11', '12'],
      specialFeatures: ['Samsung Knox', 'DeX Mode'],
    ),
    'Galaxy Note 20': DeviceProfile(
      brand: 'Samsung',
      model: 'Galaxy Note 20',
      chipSet: 'Exynos 990',
      ramSize: 8,
      storageSize: 256,
      screenSize: 6.7,
      osVersions: ['10', '11', '12'],
      specialFeatures: ['Samsung Knox', 'S Pen', 'DeX Mode'],
    ),

    // Xiaomi 设备
    'Mi 11': DeviceProfile(
      brand: 'Xiaomi',
      model: 'Mi 11',
      chipSet: 'Snapdragon 888',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.81,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['MIUI', 'NFC', '红外遥控'],
    ),
    'Redmi Note 10': DeviceProfile(
      brand: 'Xiaomi',
      model: 'Redmi Note 10',
      chipSet: 'Snapdragon 678',
      ramSize: 6,
      storageSize: 128,
      screenSize: 6.43,
      osVersions: ['10', '11', '12', '13'],
      specialFeatures: ['MIUI', 'NFC'],
    ),

    // Huawei 设备
    'P40': DeviceProfile(
      brand: 'Huawei',
      model: 'P40',
      chipSet: 'Kirin 990',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.1,
      osVersions: ['10', '11', '12'],
      specialFeatures: ['EMUI', 'HMS', 'NFC'],
    ),
    'Mate 40': DeviceProfile(
      brand: 'Huawei',
      model: 'Mate 40',
      chipSet: 'Kirin 9000',
      ramSize: 8,
      storageSize: 256,
      screenSize: 6.5,
      osVersions: ['10', '11', '12'],
      specialFeatures: ['EMUI', 'HMS', '无线充电'],
    ),

    // OPPO 设备
    'Find X3': DeviceProfile(
      brand: 'OPPO',
      model: 'Find X3',
      chipSet: 'Snapdragon 870',
      ramSize: 8,
      storageSize: 256,
      screenSize: 6.7,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['ColorOS', '快充'],
    ),
    'Reno6': DeviceProfile(
      brand: 'OPPO',
      model: 'Reno6',
      chipSet: 'Dimensity 900',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.4,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['ColorOS', '快充'],
    ),

    // Vivo 设备
    'X60': DeviceProfile(
      brand: 'Vivo',
      model: 'X60',
      chipSet: 'Snapdragon 870',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.56,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['OriginOS', '摄影增强'],
    ),

    // OnePlus 设备
    'OnePlus 9': DeviceProfile(
      brand: 'OnePlus',
      model: 'OnePlus 9',
      chipSet: 'Snapdragon 888',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.55,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['OxygenOS', '快速充电'],
    ),
    'OnePlus 8': DeviceProfile(
      brand: 'OnePlus',
      model: 'OnePlus 8',
      chipSet: 'Snapdragon 865',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.55,
      osVersions: ['10', '11', '12', '13'],
      specialFeatures: ['OxygenOS', '快速充电'],
    ),

    // Google Pixel 设备
    'Pixel 6': DeviceProfile(
      brand: 'Google',
      model: 'Pixel 6',
      chipSet: 'Tensor',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.4,
      osVersions: ['12', '13'],
      specialFeatures: ['原生Android', 'Google Assistant', 'Titan M'],
    ),
    'Pixel 5': DeviceProfile(
      brand: 'Google',
      model: 'Pixel 5',
      chipSet: 'Snapdragon 765G',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.0,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['原生Android', 'Google Assistant', '无线充电'],
    ),

    // Realme 设备
    'Realme GT': DeviceProfile(
      brand: 'Realme',
      model: 'Realme GT',
      chipSet: 'Snapdragon 888',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.43,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['realme UI', '快充'],
    ),

    // Honor 设备
    'Honor 50': DeviceProfile(
      brand: 'Honor',
      model: 'Honor 50',
      chipSet: 'Snapdragon 778G',
      ramSize: 8,
      storageSize: 128,
      screenSize: 6.57,
      osVersions: ['11', '12', '13'],
      specialFeatures: ['Magic UI', '快充'],
    ),
  };

  /// 运行设备型号兼容性测试
  Future<TestResult> runCompatibilityTest(TestConfig config) async {
    final startTime = DateTime.now();
    final failureDetails = <String>[];
    final recommendations = <String>[];
    final metadata = <String, dynamic>{};

    print('📱 设备型号兼容性测试开始');
    print('当前设备: ${config.deviceInfo.brand} ${config.deviceInfo.model}');

    // 获取设备档案
    final deviceProfile = _getDeviceProfile(config.deviceInfo);
    if (deviceProfile == null) {
      failureDetails.add('未知的设备型号: ${config.deviceInfo.brand} ${config.deviceInfo.model}');
      recommendations.add('请检查设备信息是否正确');
      recommendations.add('考虑添加设备特定适配代码');
      
      return TestResult(
        testName: '设备型号兼容性测试',
        totalTests: 1,
        passedTests: 0,
        failedTests: 1,
        failureDetails: failureDetails,
        recommendations: recommendations,
        executionTime: DateTime.now().difference(startTime),
        metadata: metadata,
      );
    }

    // 执行设备兼容性测试
    final tests = await _performDeviceCompatibilityTests(config.deviceInfo, deviceProfile);
    metadata['deviceProfile'] = deviceProfile.toJson();
    metadata['testResults'] = tests;

    final passedTests = tests.where((test) => test.passed).length;
    final totalTests = tests.length;

    // 生成建议
    if (passedTests < totalTests) {
      recommendations.addAll(_generateDeviceRecommendations(tests, deviceProfile));
    }

    return TestResult(
      testName: '设备型号兼容性测试',
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: totalTests - passedTests,
      failureDetails: failureDetails,
      recommendations: recommendations,
      executionTime: DateTime.now().difference(startTime),
      metadata: metadata,
    );
  }

  /// 执行具体的设备兼容性测试
  Future<List<DeviceCompatibilityTest>> _performDeviceCompatibilityTests(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    final tests = <DeviceCompatibilityTest>[];

    // 1. 硬件规格兼容性测试
    tests.add(await _testHardwareCompatibility(deviceInfo, deviceProfile));

    // 2. 芯片集兼容性测试
    tests.add(await _testChipSetCompatibility(deviceInfo, deviceProfile));

    // 3. 屏幕规格兼容性测试
    tests.add(await _testScreenCompatibility(deviceInfo, deviceProfile));

    // 4. 存储系统兼容性测试
    tests.add(await _testStorageCompatibility(deviceInfo, deviceProfile));

    // 5. 特殊功能支持测试
    tests.add(await _testSpecialFeatures(deviceInfo, deviceProfile));

    // 6. 品牌特定优化测试
    tests.add(await _testBrandOptimizations(deviceInfo, deviceProfile));

    // 7. 性能表现测试
    tests.add(await _testPerformance(deviceInfo, deviceProfile));

    // 8. 系统集成测试
    tests.add(await _testSystemIntegration(deviceInfo, deviceProfile));

    return tests;
  }

  /// 测试硬件规格兼容性
  Future<DeviceCompatibilityTest> _testHardwareCompatibility(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final compatibilityIssues = <String>[];
      final supportedFeatures = <String>[];

      // 检查RAM兼容性
      if (deviceInfo.ramSize < 4) {
        compatibilityIssues.add('RAM不足：当前${deviceInfo.ramSize}GB，建议至少4GB');
      } else {
        supportedFeatures.add('足够的RAM支持');
      }

      // 检查存储兼容性
      if (deviceInfo.storageSize < 32) {
        compatibilityIssues.add('存储空间不足：当前${deviceInfo.storageSize}GB，建议至少32GB');
      } else {
        supportedFeatures.add('足够的存储空间');
      }

      // 检查屏幕尺寸
      if (deviceProfile.screenSize < 5.0) {
        compatibilityIssues.add('屏幕尺寸较小：${deviceProfile.screenSize}英寸，可能影响用户体验');
      } else {
        supportedFeatures.add('合适的屏幕尺寸');
      }

      final supportRate = supportedFeatures.length / (supportedFeatures.length + compatibilityIssues.length) * 100;

      return DeviceCompatibilityTest(
        testName: '硬件规格兼容性测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '兼容性评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: supportedFeatures,
        compatibilityIssues: compatibilityIssues,
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '硬件规格兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试芯片集兼容性
  Future<DeviceCompatibilityTest> _testChipSetCompatibility(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final chipSetSupport = <String, bool>{};
      final compatibleChipsets = [
        'Snapdragon 888',
        'Snapdragon 870',
        'Snapdragon 865',
        'Snapdragon 780G',
        'Snapdragon 765G',
        'Exynos 2100',
        'Exynos 990',
        'Kirin 990',
        'Kirin 9000',
        'Dimensity 900',
        'Dimensity 800',
        'Tensor',
      ];

      final isCompatible = compatibleChipsets.contains(deviceProfile.chipSet);
      final supportScore = isCompatible ? 100 : 60; // 模拟不完全兼容的芯片集

      chipSetSupport['芯片集兼容性'] = isCompatible;
      chipSetSupport['ARM架构支持'] = true;
      chipSetSupport['64位支持'] = true;
      chipSetSupport['GPU兼容性'] = isCompatible;
      chipSetSupport['AI算力支持'] = deviceProfile.chipSet.contains('Tensor') || 
                                     deviceProfile.chipSet.contains('Kirin 9000') ||
                                     deviceProfile.chipSet.contains('Snapdragon 8');

      final supportedCount = chipSetSupport.values.where((supported) => supported).length;
      final totalCount = chipSetSupport.length;
      final finalScore = (supportedCount / totalCount) * 100;

      return DeviceCompatibilityTest(
        testName: '芯片集兼容性测试',
        passed: finalScore >= 80,
        score: finalScore,
        details: '芯片集: ${deviceProfile.chipSet}, 兼容性: ${finalScore.toStringAsFixed(1)}%',
        supportedFeatures: chipSetSupport.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: chipSetSupport.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '芯片集兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试屏幕规格兼容性
  Future<DeviceCompatibilityTest> _testScreenCompatibility(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final screenFeatures = <String, bool>{};
      
      // 检查屏幕分辨率
      final resolution = _parseScreenResolution(deviceInfo.screenResolution);
      screenFeatures['屏幕分辨率支持'] = resolution.isValid;
      screenFeatures['高DPI支持'] = resolution.density >= 2.0;
      screenFeatures['长宽比适配'] = _checkAspectRatio(resolution.width, resolution.height);
      
      // 检查屏幕类型
      if (deviceProfile.brand == 'Samsung') {
        screenFeatures['AMOLED支持'] = true;
        screenFeatures['HDR支持'] = true;
      } else {
        screenFeatures['AMOLED支持'] = false;
        screenFeatures['HDR支持'] = _checkHDRSupport(deviceProfile);
      }

      // 检查屏幕特性
      screenFeatures['多点触控'] = true;
      screenFeatures['防指纹涂层'] = _checkScreenCoating(deviceProfile);
      screenFeatures['防蓝光支持'] = deviceProfile.osVersions.contains('12') || 
                                     deviceProfile.osVersions.contains('13');

      final supportedCount = screenFeatures.values.where((supported) => supported).length;
      final totalCount = screenFeatures.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return DeviceCompatibilityTest(
        testName: '屏幕规格兼容性测试',
        passed: supportRate >= 75,
        score: supportRate,
        details: '屏幕: ${deviceInfo.screenResolution}, 评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: screenFeatures.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: screenFeatures.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '屏幕规格兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试存储系统兼容性
  Future<DeviceCompatibilityTest> _testStorageCompatibility(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final storageFeatures = <String, bool>{};
      
      // 基础存储支持
      storageFeatures['内部存储'] = true;
      storageFeatures['外部存储'] = true;
      storageFeatures['USB OTG'] = true;
      
      // 存储技术
      storageFeatures['UFS存储'] = deviceProfile.chipSet.contains('Snapdragon') || 
                                  deviceProfile.chipSet.contains('Exynos');
      storageFeatures['eMMC支持'] = true; // 向后兼容
      
      // 扩展存储
      storageFeatures['SD卡支持'] = !deviceProfile.model.contains('Pixel') && 
                                  !deviceProfile.model.contains('Galaxy S21');
      
      // 存储优化
      storageFeatures['存储优化'] = deviceProfile.osVersions.contains('11') ||
                                  deviceProfile.osVersions.contains('12') ||
                                  deviceProfile.osVersions.contains('13');

      final supportedCount = storageFeatures.values.where((supported) => supported).length;
      final totalCount = storageFeatures.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return DeviceCompatibilityTest(
        testName: '存储系统兼容性测试',
        passed: supportRate >= 85,
        score: supportRate,
        details: '存储: ${deviceInfo.storageSize}GB, 评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: storageFeatures.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: storageFeatures.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '存储系统兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试特殊功能支持
  Future<DeviceCompatibilityTest> _testSpecialFeatures(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final featureSupport = <String, bool>{};
      
      // 检查品牌特定功能
      for (final feature in deviceProfile.specialFeatures) {
        featureSupport[feature] = true;
      }
      
      // 检查通用功能支持
      final commonFeatures = [
        'NFC',
        '蓝牙5.0',
        'WiFi 6',
        '5G支持',
        '无线充电',
        '指纹识别',
        '面部识别',
        '语音助手',
        '快充技术',
        '防水防尘',
      ];
      
      for (final feature in commonFeatures) {
        featureSupport[feature] = _checkFeatureSupport(feature, deviceProfile);
      }

      final supportedCount = featureSupport.values.where((supported) => supported).length;
      final totalCount = featureSupport.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return DeviceCompatibilityTest(
        testName: '特殊功能支持测试',
        passed: supportRate >= 70,
        score: supportRate,
        details: '支持功能: $supportedCount/$totalCount, 评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: featureSupport.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: featureSupport.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '特殊功能支持测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试品牌特定优化
  Future<DeviceCompatibilityTest> _testBrandOptimizations(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final optimizations = <String, bool>{};
      
      // 根据品牌检查特定优化
      switch (deviceProfile.brand) {
        case 'Samsung':
          optimizations['One UI优化'] = true;
          optimizations['Samsung Knox支持'] = true;
          optimizations['Bixby集成'] = deviceProfile.osVersions.contains('11');
          optimizations['Edge Panel支持'] = true;
          break;
        case 'Xiaomi':
          optimizations['MIUI优化'] = true;
          optimizations['小米服务集成'] = true;
          optimizations['红外遥控支持'] = deviceProfile.specialFeatures.contains('红外遥控');
          break;
        case 'Huawei':
          optimizations['EMUI/HarmonyOS优化'] = true;
          optimizations['HMS服务支持'] = true;
          optimizations['HiSuite集成'] = deviceProfile.osVersions.contains('11');
          break;
        case 'OPPO':
          optimizations['ColorOS优化'] = true;
          optimizations['OPPO服务集成'] = true;
          optimizations['超级闪充支持'] = deviceProfile.specialFeatures.contains('快充');
          break;
        case 'Vivo':
          optimizations['OriginOS优化'] = true;
          optimizations['Vivo服务集成'] = true;
          optimizations['摄影优化'] = deviceProfile.specialFeatures.contains('摄影增强');
          break;
        case 'OnePlus':
          optimizations['OxygenOS/HydrogenOS优化'] = true;
          optimizations['一加服务集成'] = true;
          optimizations['快速充电支持'] = deviceProfile.specialFeatures.contains('快速充电');
          break;
        case 'Google':
          optimizations['原生Android优化'] = true;
          optimizations['Google服务集成'] = true;
          optimizations['Tensor AI支持'] = deviceProfile.chipSet == 'Tensor';
          break;
      }

      final supportedCount = optimizations.values.where((supported) => supported).length;
      final totalCount = optimizations.length;
      final supportRate = totalCount > 0 ? (supportedCount / totalCount) * 100 : 100;

      return DeviceCompatibilityTest(
        testName: '品牌特定优化测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '品牌: ${deviceProfile.brand}, 优化支持: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: optimizations.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: optimizations.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '品牌特定优化测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试性能表现
  Future<DeviceCompatibilityTest> _testPerformance(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final performanceMetrics = <String, double>{};
      
      // CPU性能评分 (模拟)
      performanceMetrics['CPU性能'] = _calculateCpuScore(deviceProfile.chipSet);
      
      // GPU性能评分 (模拟)
      performanceMetrics['GPU性能'] = _calculateGpuScore(deviceProfile.chipSet);
      
      // 内存性能评分
      performanceMetrics['内存性能'] = deviceInfo.ramSize >= 8 ? 90.0 : 
                                       deviceInfo.ramSize >= 6 ? 75.0 : 60.0;
      
      // 存储性能评分
      performanceMetrics['存储性能'] = deviceInfo.storageSize >= 128 ? 90.0 :
                                       deviceInfo.storageSize >= 64 ? 75.0 : 60.0;
      
      // 整体性能评分
      final averageScore = performanceMetrics.values.reduce((a, b) => a + b) / performanceMetrics.length;

      return DeviceCompatibilityTest(
        testName: '性能表现测试',
        passed: averageScore >= 70,
        score: averageScore,
        details: '综合性能评分: ${averageScore.toStringAsFixed(1)}分',
        supportedFeatures: performanceMetrics.entries.map((e) => '${e.key}: ${e.value.toStringAsFixed(1)}').toList(),
        compatibilityIssues: [],
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '性能表现测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试系统集成
  Future<DeviceCompatibilityTest> _testSystemIntegration(
    DeviceInfo deviceInfo,
    DeviceProfile deviceProfile,
  ) async {
    try {
      final integrationTests = <String, bool>{};
      
      // 系统服务集成
      integrationTests['系统服务集成'] = true;
      integrationTests['权限管理集成'] = true;
      integrationTests['通知系统集成'] = true;
      
      // 硬件抽象层集成
      integrationTests['HAL集成'] = true;
      integrationTests['驱动支持'] = true;
      
      // 生态系统集成
      integrationTests['应用商店集成'] = true;
      integrationTests['云服务集成'] = true;
      integrationTests['备份恢复集成'] = deviceProfile.osVersions.contains('11') ||
                                      deviceProfile.osVersions.contains('12') ||
                                      deviceProfile.osVersions.contains('13');

      final supportedCount = integrationTests.values.where((supported) => supported).length;
      final totalCount = integrationTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return DeviceCompatibilityTest(
        testName: '系统集成测试',
        passed: supportRate >= 90,
        score: supportRate,
        details: '集成支持: ${supportedCount}/${totalCount}, 评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: integrationTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: integrationTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return DeviceCompatibilityTest(
        testName: '系统集成测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 获取设备档案
  DeviceProfile? _getDeviceProfile(DeviceInfo deviceInfo) {
    final key = '${deviceInfo.brand} ${deviceInfo.model}';
    return _supportedDevices[key];
  }

  /// 解析屏幕分辨率
  ScreenResolution _parseScreenResolution(String resolution) {
    final parts = resolution.split('x');
    if (parts.length != 2) {
      return ScreenResolution(0, 0, 1.0);
    }
    
    final width = int.tryParse(parts[0]) ?? 0;
    final height = int.tryParse(parts[1]) ?? 0;
    final density = _calculateDensity(width, height);
    
    return ScreenResolution(width, height, density);
  }

  /// 计算屏幕密度
  double _calculateDensity(int width, int height) {
    final diagonal = (width * width + height * height).sqrt;
    if (diagonal < 1000) return 1.0; // LDPI
    if (diagonal < 1400) return 1.5; // MDPI
    if (diagonal < 1800) return 2.0; // HDPI
    if (diagonal < 2400) return 3.0; // XHDPI
    return 4.0; // XXHDPI
  }

  /// 检查长宽比
  bool _checkAspectRatio(int width, int height) {
    final ratio = width / height;
    // 支持常见的宽高比
    return (ratio >= 1.5 && ratio <= 2.5) || (ratio >= 0.4 && ratio <= 0.7);
  }

  /// 检查HDR支持
  bool _checkHDRSupport(DeviceProfile deviceProfile) {
    // 简化实现：高端设备支持HDR
    return deviceProfile.ramSize >= 6 && deviceProfile.storageSize >= 128;
  }

  /// 检查屏幕涂层
  bool _checkScreenCoating(DeviceProfile deviceProfile) {
    // 简化实现：大部分现代设备都有防指纹涂层
    return true;
  }

  /// 检查功能支持
  bool _checkFeatureSupport(String feature, DeviceProfile deviceProfile) {
    final supportMap = {
      'NFC': deviceProfile.ramSize >= 4,
      '蓝牙5.0': deviceProfile.osVersions.contains('10') ||
                deviceProfile.osVersions.contains('11') ||
                deviceProfile.osVersions.contains('12') ||
                deviceProfile.osVersions.contains('13'),
      'WiFi 6': deviceProfile.chipSet.contains('Snapdragon 8') ||
               deviceProfile.chipSet.contains('Exynos 21') ||
               deviceProfile.chipSet == 'Tensor',
      '5G支持': deviceProfile.chipSet.contains('Snapdragon') ||
              deviceProfile.chipSet.contains('Dimensity') ||
              deviceProfile.chipSet.contains('Kirin 9'),
      '无线充电': deviceProfile.specialFeatures.contains('无线充电') ||
                 deviceProfile.brand == 'Samsung' ||
                 deviceProfile.brand == 'Google',
      '指纹识别': true, // 大部分现代设备都支持
      '面部识别': deviceProfile.osVersions.contains('11') ||
                deviceProfile.osVersions.contains('12') ||
                deviceProfile.osVersions.contains('13'),
      '语音助手': true,
      '快充技术': deviceProfile.specialFeatures.contains('快充') ||
                deviceProfile.specialFeatures.contains('快速充电'),
      '防水防尘': deviceProfile.brand == 'Samsung' ||
                deviceProfile.brand == 'Huawei' ||
                deviceProfile.brand == 'Google',
    };
    
    return supportMap[feature] ?? false;
  }

  /// 计算CPU性能评分
  double _calculateCpuScore(String chipSet) {
    final highEndChips = ['Snapdragon 888', 'Snapdragon 8', 'Exynos 2100', 'Kirin 9000', 'Tensor'];
    final midRangeChips = ['Snapdragon 870', 'Snapdragon 865', 'Dimensity 900', 'Kirin 990'];
    
    if (highEndChips.contains(chipSet)) return 90.0;
    if (midRangeChips.contains(chipSet)) return 75.0;
    return 60.0;
  }

  /// 计算GPU性能评分
  double _calculateGpuScore(String chipSet) {
    final highEndGpus = ['Snapdragon 888', 'Snapdragon 8', 'Exynos 2100', 'Kirin 9000', 'Tensor'];
    final midRangeGpus = ['Snapdragon 870', 'Snapdragon 865', 'Dimensity 900', 'Kirin 990'];
    
    if (highEndGpus.contains(chipSet)) return 90.0;
    if (midRangeGpus.contains(chipSet)) return 75.0;
    return 60.0;
  }

  /// 生成设备相关建议
  List<String> _generateDeviceRecommendations(List<DeviceCompatibilityTest> tests, DeviceProfile deviceProfile) {
    final recommendations = <String>[];
    
    for (final test in tests) {
      if (!test.passed) {
        switch (test.testName) {
          case '硬件规格兼容性测试':
            recommendations.add('考虑优化内存使用和存储管理');
            recommendations.add('实现自适应性能调节');
            break;
          case '芯片集兼容性测试':
            recommendations.add('添加芯片集特定优化代码');
            recommendations.add('实现GPU兼容性适配');
            break;
          case '屏幕规格兼容性测试':
            recommendations.add('实现响应式UI布局');
            recommendations.add('添加屏幕密度适配');
            break;
          case '特殊功能支持测试':
            recommendations.add('实现功能检测和降级方案');
            recommendations.add('添加可选功能支持');
            break;
          case '品牌特定优化测试':
            recommendations.add('适配目标品牌的UI规范');
            recommendations.add('集成品牌特定服务');
            break;
        }
      }
    }
    
    return recommendations;
  }
}

/// 设备档案类
class DeviceProfile {
  final String brand;
  final String model;
  final String chipSet;
  final int ramSize;
  final int storageSize;
  final double screenSize;
  final List<String> osVersions;
  final List<String> specialFeatures;

  DeviceProfile({
    required this.brand,
    required this.model,
    required this.chipSet,
    required this.ramSize,
    required this.storageSize,
    required this.screenSize,
    required this.osVersions,
    required this.specialFeatures,
  });

  Map<String, dynamic> toJson() {
    return {
      'brand': brand,
      'model': model,
      'chipSet': chipSet,
      'ramSize': ramSize,
      'storageSize': storageSize,
      'screenSize': screenSize,
      'osVersions': osVersions,
      'specialFeatures': specialFeatures,
    };
  }
}

/// 设备兼容性测试结果类
class DeviceCompatibilityTest {
  final String testName;
  final bool passed;
  final double score;
  final String details;
  final List<String> supportedFeatures;
  final List<String> compatibilityIssues;

  DeviceCompatibilityTest({
    required this.testName,
    required this.passed,
    required this.score,
    required this.details,
    required this.supportedFeatures,
    required this.compatibilityIssues,
  });
}

/// 屏幕分辨率类
class ScreenResolution {
  final int width;
  final int height;
  final double density;

  ScreenResolution(this.width, this.height, this.density);

  bool get isValid => width > 0 && height > 0;
}