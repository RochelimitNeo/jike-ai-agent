/// 屏幕分辨率和DPI适配兼容性测试
/// 
/// 测试不同屏幕分辨率、DPI和屏幕比例的适配兼容性

import 'dart:async';
import 'dart:math' as math;
import 'main_test_runner.dart';

/// 分辨率适配兼容性测试类
class ResolutionCompatibilityTest {
  final List<ScreenProfile> _supportedResolutions = [
    // HD分辨率 (720p)
    ScreenProfile('1280x720', 720, 1280, 6.0, 2.0, 'HD', '16:9'),
    ScreenProfile('1600x900', 900, 1600, 6.5, 2.5, 'HD+', '16:9'),
    
    // Full HD分辨率 (1080p)
    ScreenProfile('1920x1080', 1080, 1920, 5.5, 3.0, 'FHD', '16:9'),
    ScreenProfile('2160x1080', 1080, 2160, 6.0, 3.0, 'FHD+', '18:9'),
    ScreenProfile('2340x1080', 1080, 2340, 6.1, 3.0, 'FHD+', '19.5:9'),
    
    // QHD分辨率 (1440p)
    ScreenProfile('2560x1440', 1440, 2560, 5.8, 4.0, 'QHD', '16:9'),
    ScreenProfile('2880x1440', 1440, 2880, 6.2, 4.0, 'QHD+', '18:9'),
    ScreenProfile('3120x1440', 1440, 3120, 6.1, 4.0, 'QHD+', '19.5:9'),
    
    // 4K分辨率
    ScreenProfile('3840x2160', 2160, 3840, 6.5, 6.0, '4K UHD', '16:9'),
    
    // 特殊分辨率
    ScreenProfile('1440x720', 720, 1440, 6.7, 2.0, 'HD+', '2:1'),
    ScreenProfile('2520x1080', 1080, 2520, 6.0, 3.5, 'FHD+', '21:9'),
    ScreenProfile('3200x1440', 1440, 3200, 6.8, 4.5, 'QHD+', '20:9'),
  ];

  final Map<String, double> _dpiBenchmarks = {
    'LDPI': 0.75,
    'MDPI': 1.0,
    'HDPI': 1.5,
    'XHDPI': 2.0,
    'XXHDPI': 3.0,
    'XXXHDPI': 4.0,
  };

  /// 运行分辨率适配兼容性测试
  Future<TestResult> runCompatibilityTest(TestConfig config) async {
    final startTime = DateTime.now();
    final failureDetails = <String>[];
    final recommendations = <String>[];
    final metadata = <String, dynamic>{};

    print('📱 分辨率适配兼容性测试开始');
    print('当前分辨率: ${config.deviceInfo.screenResolution}');

    // 解析当前屏幕信息
    final currentScreen = _parseScreenResolution(config.deviceInfo.screenResolution);
    if (!currentScreen.isValid) {
      failureDetails.add('无效的屏幕分辨率格式: ${config.deviceInfo.screenResolution}');
      recommendations.add('请检查屏幕分辨率信息格式');
      
      return TestResult(
        testName: '分辨率适配兼容性测试',
        totalTests: 1,
        passedTests: 0,
        failedTests: 1,
        failureDetails: failureDetails,
        recommendations: recommendations,
        executionTime: DateTime.now().difference(startTime),
        metadata: metadata,
      );
    }

    // 执行分辨率兼容性测试
    final tests = await _performResolutionCompatibilityTests(currentScreen);
    metadata['currentScreen'] = currentScreen.toJson();
    metadata['testResults'] = tests;

    final passedTests = tests.where((test) => test.passed).length;
    final totalTests = tests.length;

    // 生成建议
    if (passedTests < totalTests) {
      recommendations.addAll(_generateResolutionRecommendations(tests, currentScreen));
    }

    return TestResult(
      testName: '分辨率适配兼容性测试',
      totalTests: totalTests,
      passedTests: passedTests,
      failedTests: totalTests - passedTests,
      failureDetails: failureDetails,
      recommendations: recommendations,
      executionTime: DateTime.now().difference(startTime),
      metadata: metadata,
    );
  }

  /// 执行具体的分辨率兼容性测试
  Future<List<ResolutionCompatibilityTest>> _performResolutionCompatibilityTests(
    ScreenProfile currentScreen,
  ) async {
    final tests = <ResolutionCompatibilityTest>[];

    // 1. 分辨率支持测试
    tests.add(await _testResolutionSupport(currentScreen));

    // 2. DPI适配测试
    tests.add(await _testDpiCompatibility(currentScreen));

    // 3. 长宽比适配测试
    tests.add(await _testAspectRatioCompatibility(currentScreen));

    // 4. 屏幕尺寸适配测试
    tests.add(await _testScreenSizeCompatibility(currentScreen));

    // 5. UI布局适配测试
    tests.add(await _testUiLayoutCompatibility(currentScreen));

    // 6. 字体缩放测试
    tests.add(await _testFontScaling(currentScreen));

    // 7. 图标适配测试
    tests.add(await _testIconScaling(currentScreen));

    // 8. 横竖屏适配测试
    tests.add(await _testOrientationCompatibility(currentScreen));

    return tests;
  }

  /// 测试分辨率支持
  Future<ResolutionCompatibilityTest> _testResolutionSupport(ScreenProfile screen) async {
    try {
      final supportCriteria = <String, bool>{};
      
      // 检查分辨率是否在支持列表中
      final isSupported = _supportedResolutions.any((profile) => 
        profile.width == screen.width && profile.height == screen.height);
      
      supportCriteria['标准分辨率支持'] = isSupported;
      
      // 检查分辨率范围
      supportCriteria['最小分辨率支持'] = screen.width >= 720 && screen.height >= 1280;
      supportCriteria['最大分辨率支持'] = screen.width <= 3840 && screen.height <= 2160;
      
      // 检查像素密度合理性
      final pixelCount = screen.width * screen.height;
      supportCriteria['合理像素密度'] = pixelCount >= 500000 && pixelCount <= 8300000; // 0.5MP 到 8.3MP
      
      // 检查分辨率比例
      final aspectRatio = _calculateAspectRatio(screen.width, screen.height);
      supportCriteria['标准宽高比'] = aspectRatio >= 1.3 && aspectRatio <= 2.5;

      final supportedCount = supportCriteria.values.where((supported) => supported).length;
      final totalCount = supportCriteria.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '分辨率支持测试',
        passed: supportRate >= 75,
        score: supportRate,
        details: '分辨率: ${screen.width}x${screen.height}, 支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: supportCriteria.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: supportCriteria.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '分辨率支持测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试DPI兼容性
  Future<ResolutionCompatibilityTest> _testDpiCompatibility(ScreenProfile screen) async {
    try {
      final dpiTests = <String, bool>{};
      
      // 获取对应的DPI级别
      final dpiLevel = _getDpiLevel(screen.density);
      
      // 检查DPI级别支持
      dpiTests['DPI级别识别'] = dpiLevel.isNotEmpty;
      dpiTests['DPI缩放支持'] = _dpiBenchmarks.containsKey(dpiLevel);
      
      // 检查DPI适配范围
      final dpiValue = screen.density;
      dpiTests['DPI范围合理性'] = dpiValue >= 0.75 && dpiValue <= 6.0;
      
      // 检查资源适配
      dpiTests['资源文件适配'] = _checkResourceScaling(dpiLevel);
      dpiTests['字体大小适配'] = _checkFontScaling(dpiLevel);
      
      // 检查触摸精度
      final touchPrecision = _calculateTouchPrecision(dpiValue);
      dpiTests['触摸精度适配'] = touchPrecision >= 0.8;

      final supportedCount = dpiTests.values.where((supported) => supported).length;
      final totalCount = dpiTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: 'DPI兼容性测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: 'DPI: ${screen.density} ($dpiLevel), 支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: dpiTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: dpiTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: 'DPI兼容性测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试长宽比适配
  Future<ResolutionCompatibilityTest> _testAspectRatioCompatibility(ScreenProfile screen) async {
    try {
      final aspectRatioTests = <String, bool>{};
      
      // 计算长宽比
      final aspectRatio = _calculateAspectRatio(screen.width, screen.height);
      final aspectRatioStr = _formatAspectRatio(aspectRatio);
      
      // 检查常见长宽比支持
      final commonRatios = ['16:9', '18:9', '19.5:9', '20:9', '21:9', '2:1'];
      aspectRatioTests['常见长宽比支持'] = commonRatios.contains(aspectRatioStr);
      
      // 检查极端长宽比
      aspectRatioTests['极端长宽比适配'] = aspectRatio >= 1.2 && aspectRatio <= 2.8;
      
      // 检查刘海屏适配
      final isNotchSupported = aspectRatio >= 1.8; // 18:9 及以上认为支持刘海屏
      aspectRatioTests['刘海屏适配'] = isNotchSupported;
      
      // 检查圆角屏适配
      aspectRatioTests['圆角屏适配'] = aspectRatio >= 1.5;
      
      // 检查沉浸式状态栏适配
      aspectRatioTests['沉浸式状态栏适配'] = aspectRatio >= 1.6;

      final supportedCount = aspectRatioTests.values.where((supported) => supported).length;
      final totalCount = aspectRatioTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '长宽比适配测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '长宽比: $aspectRatioStr ($aspectRatio), 支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: aspectRatioTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: aspectRatioTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '长宽比适配测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试屏幕尺寸适配
  Future<ResolutionCompatibilityTest> _testScreenSizeCompatibility(ScreenProfile screen) async {
    try {
      final sizeTests = <String, bool>{};
      
      // 检查屏幕尺寸范围
      sizeTests['合理屏幕尺寸'] = screen.size >= 4.0 && screen.size <= 7.0;
      
      // 检查小屏设备适配
      sizeTests['小屏设备适配'] = screen.size >= 4.5 || _checkSmallScreenOptimization(screen);
      
      // 检查大屏设备适配
      sizeTests['大屏设备适配'] = screen.size <= 6.5 || _checkLargeScreenOptimization(screen);
      
      // 检查平板适配
      sizeTests['平板适配'] = screen.size >= 7.0 || _checkTabletOptimization(screen);
      
      // 检查可折叠设备适配
      sizeTests['可折叠设备适配'] = _checkFoldableOptimization(screen);
      
      // 检查多窗口适配
      sizeTests['多窗口适配'] = screen.width >= 1024 || _checkMultiWindowSupport(screen);

      final supportedCount = sizeTests.values.where((supported) => supported).length;
      final totalCount = sizeTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '屏幕尺寸适配测试',
        passed: supportRate >= 75,
        score: supportRate,
        details: '屏幕尺寸: ${screen.size}英寸, 支持率: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: sizeTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: sizeTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '屏幕尺寸适配测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试UI布局适配
  Future<ResolutionCompatibilityTest> _testUiLayoutCompatibility(ScreenProfile screen) async {
    try {
      final layoutTests = <String, bool>{};
      
      // 检查响应式布局支持
      layoutTests['响应式布局支持'] = _checkResponsiveLayout(screen);
      
      // 检查约束布局适配
      layoutTests['约束布局适配'] = _checkConstraintLayout(screen);
      
      // 检查网格布局适配
      layoutTests['网格布局适配'] = _checkGridLayout(screen);
      
      // 检查线性布局适配
      layoutTests['线性布局适配'] = _checkLinearLayout(screen);
      
      // 检查可滚动布局
      layoutTests['可滚动布局支持'] = _checkScrollableLayout(screen);
      
      // 检查自适应布局
      layoutTests['自适应布局支持'] = _checkAdaptiveLayout(screen);

      final supportedCount = layoutTests.values.where((supported) => supported).length;
      final totalCount = layoutTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: 'UI布局适配测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '布局适配评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: layoutTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: layoutTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: 'UI布局适配测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试字体缩放
  Future<ResolutionCompatibilityTest> _testFontScaling(ScreenProfile screen) async {
    try {
      final fontTests = <String, bool>{};
      
      // 检查字体缩放范围
      final minFontSize = _calculateMinFontSize(screen.density);
      final maxFontSize = _calculateMaxFontSize(screen.density);
      fontTests['字体大小范围'] = minFontSize >= 8 && maxFontSize <= 32;
      
      // 检查动态字体支持
      fontTests['动态字体支持'] = screen.density >= 1.5;
      
      // 检查字体粗细适配
      fontTests['字体粗细适配'] = _checkFontWeightSupport(screen);
      
      // 检查字体回退机制
      fontTests['字体回退机制'] = _checkFontFallbackSupport(screen);
      
      // 检查RTL语言支持
      fontTests['RTL语言支持'] = _checkRtlFontSupport(screen);
      
      // 检查表情符号支持
      fontTests['表情符号支持'] = _checkEmojiSupport(screen);

      final supportedCount = fontTests.values.where((supported) => supported).length;
      final totalCount = fontTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '字体缩放测试',
        passed: supportRate >= 85,
        score: supportRate,
        details: '字体适配评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: fontTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: fontTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '字体缩放测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试图标适配
  Future<ResolutionCompatibilityTest> _testIconScaling(ScreenProfile screen) async {
    try {
      final iconTests = <String, bool>{};
      
      // 检查图标密度适配
      final iconDensity = _getDpiLevel(screen.density);
      iconTests['图标密度适配'] = iconDensity.isNotEmpty;
      
      // 检查矢量图标支持
      iconTests['矢量图标支持'] = _checkVectorIconSupport(screen);
      
      // 检查位图图标适配
      iconTests['位图图标适配'] = _checkBitmapIconSupport(iconDensity);
      
      // 检查自适应图标
      iconTests['自适应图标支持'] = screen.density >= 2.0;
      
      // 检查图标缩放算法
      iconTests['图标缩放算法'] = _checkIconScalingAlgorithm(screen);
      
      // 检查图标缓存机制
      iconTests['图标缓存机制'] = _checkIconCacheMechanism(screen);

      final supportedCount = iconTests.values.where((supported) => supported).length;
      final totalCount = iconTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '图标适配测试',
        passed: supportRate >= 80,
        score: supportRate,
        details: '图标适配评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: iconTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: iconTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '图标适配测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 测试横竖屏适配
  Future<ResolutionCompatibilityTest> _testOrientationCompatibility(ScreenProfile screen) async {
    try {
      final orientationTests = <String, bool>{};
      
      // 检查横屏适配
      orientationTests['横屏适配'] = _checkLandscapeLayout(screen);
      
      // 检查竖屏适配
      orientationTests['竖屏适配'] = _checkPortraitLayout(screen);
      
      // 检查屏幕旋转支持
      orientationTests['屏幕旋转支持'] = _checkScreenRotationSupport(screen);
      
      // 检查配置变更处理
      orientationTests['配置变更处理'] = _checkConfigurationChangeHandling(screen);
      
      // 检查横竖屏过渡动画
      orientationTests['过渡动画支持'] = _checkOrientationTransitionAnimation(screen);
      
      // 检查锁定屏幕方向
      orientationTests['屏幕方向锁定'] = _checkScreenOrientationLock(screen);

      final supportedCount = orientationTests.values.where((supported) => supported).length;
      final totalCount = orientationTests.length;
      final supportRate = (supportedCount / totalCount) * 100;

      return ResolutionCompatibilityTest(
        testName: '横竖屏适配测试',
        passed: supportRate >= 85,
        score: supportRate,
        details: '屏幕方向适配评分: ${supportRate.toStringAsFixed(1)}%',
        supportedFeatures: orientationTests.entries.where((e) => e.value).map((e) => e.key).toList(),
        compatibilityIssues: orientationTests.entries.where((e) => !e.value).map((e) => e.key).toList(),
      );
    } catch (e) {
      return ResolutionCompatibilityTest(
        testName: '横竖屏适配测试',
        passed: false,
        score: 0,
        details: '测试执行失败: $e',
        supportedFeatures: [],
        compatibilityIssues: [],
      );
    }
  }

  /// 解析屏幕分辨率
  ScreenProfile _parseScreenResolution(String resolution) {
    final parts = resolution.split('x');
    if (parts.length != 2) {
      return ScreenProfile('0x0', 0, 0, 0, 0, 'Unknown', 'Unknown');
    }
    
    final width = int.tryParse(parts[0]) ?? 0;
    final height = int.tryParse(parts[1]) ?? 0;
    final screenSize = _estimateScreenSize(width, height);
    final density = _calculateDensity(width, height);
    
    // 查找最接近的支持分辨率
    final closestProfile = _findClosestResolution(width, height);
    
    return ScreenProfile(
      resolution,
      height,
      width,
      screenSize,
      density,
      closestProfile.category,
      closestProfile.aspectRatio,
    );
  }

  /// 估算屏幕尺寸
  double _estimateScreenSize(int width, int height) {
    // 简化的屏幕尺寸估算（基于对角线像素密度）
    final diagonalPixels = math.sqrt(width * width + height * height);
    
    // 基于常见的DPI值估算
    if (diagonalPixels < 1500) return 4.0; // 小屏
    if (diagonalPixels < 2500) return 5.0; // 中屏
    if (diagonalPixels < 3500) return 6.0; // 大屏
    return 6.5; // 超大屏
  }

  /// 查找最接近的支持分辨率
  ScreenProfile _findClosestResolution(int width, int height) {
    if (_supportedResolutions.isEmpty) {
      return ScreenProfile('Unknown', height, width, 5.5, 3.0, 'Unknown', 'Unknown');
    }
    
    double minDistance = double.infinity;
    ScreenProfile closest = _supportedResolutions.first;
    
    for (final profile in _supportedResolutions) {
      final distance = _calculateDistance(width, height, profile.width, profile.height);
      if (distance < minDistance) {
        minDistance = distance;
        closest = profile;
      }
    }
    
    return closest;
  }

  /// 计算距离
  double _calculateDistance(int x1, int y1, int x2, int y2) {
    return math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  }

  /// 计算DPI
  double _calculateDensity(int width, int height) {
    final diagonal = math.sqrt(width * width + height * height);
    
    // 基于常见设备的DPI值进行估算
    if (diagonal < 1000) return 1.0; // MDPI
    if (diagonal < 1500) return 1.5; // HDPI
    if (diagonal < 2200) return 2.0; // XHDPI
    if (diagonal < 3000) return 3.0; // XXHDPI
    return 4.0; // XXXHDPI
  }

  /// 获取DPI级别
  String _getDpiLevel(double density) {
    if (density < 1.2) return 'LDPI';
    if (density < 1.8) return 'MDPI';
    if (density < 2.5) return 'HDPI';
    if (density < 3.5) return 'XHDPI';
    if (density < 5.0) return 'XXHDPI';
    return 'XXXHDPI';
  }

  /// 计算长宽比
  double _calculateAspectRatio(int width, int height) {
    final gcd = _gcd(width, height);
    return width / height;
  }

  /// 格式化长宽比
  String _formatAspectRatio(double ratio) {
    final commonRatios = {
      1.33: '4:3',
      1.5: '3:2',
      1.6: '16:10',
      1.78: '16:9',
      2.0: '18:9',
      2.06: '19.5:9',
      2.17: '19:9',
      2.22: '20:9',
      2.33: '21:9',
      2.0: '2:1',
    };
    
    for (final entry in commonRatios.entries) {
      if ((ratio - entry.key).abs() < 0.1) {
        return entry.value;
      }
    }
    
    return ratio.toStringAsFixed(2);
  }

  /// 计算最大公约数
  int _gcd(int a, int b) {
    while (b != 0) {
      final temp = b;
      b = a % b;
      a = temp;
    }
    return a;
  }

  // 模拟检查方法
  bool _checkResourceScaling(String dpiLevel) => true;
  bool _checkFontScaling(String dpiLevel) => true;
  double _calculateTouchPrecision(double dpiValue) => 0.85;
  bool _checkSmallScreenOptimization(ScreenProfile screen) => screen.size < 5.0;
  bool _checkLargeScreenOptimization(ScreenProfile screen) => screen.size > 6.0;
  bool _checkTabletOptimization(ScreenProfile screen) => screen.size > 6.8;
  bool _checkFoldableOptimization(ScreenProfile screen) => screen.width > 3000;
  bool _checkMultiWindowSupport(ScreenProfile screen) => screen.size > 5.5;
  bool _checkResponsiveLayout(ScreenProfile screen) => true;
  bool _checkConstraintLayout(ScreenProfile screen) => true;
  bool _checkGridLayout(ScreenProfile screen) => true;
  bool _checkLinearLayout(ScreenProfile screen) => true;
  bool _checkScrollableLayout(ScreenProfile screen) => true;
  bool _checkAdaptiveLayout(ScreenProfile screen) => true;
  double _calculateMinFontSize(double density) => 8.0 * density;
  double _calculateMaxFontSize(double density) => 32.0 * density;
  bool _checkFontWeightSupport(ScreenProfile screen) => true;
  bool _checkFontFallbackSupport(ScreenProfile screen) => true;
  bool _checkRtlFontSupport(ScreenProfile screen) => true;
  bool _checkEmojiSupport(ScreenProfile screen) => screen.density >= 2.0;
  bool _checkVectorIconSupport(ScreenProfile screen) => true;
  bool _checkBitmapIconSupport(String dpiLevel) => true;
  bool _checkIconScalingAlgorithm(ScreenProfile screen) => true;
  bool _checkIconCacheMechanism(ScreenProfile screen) => true;
  bool _checkLandscapeLayout(ScreenProfile screen) => true;
  bool _checkPortraitLayout(ScreenProfile screen) => true;
  bool _checkScreenRotationSupport(ScreenProfile screen) => true;
  bool _checkConfigurationChangeHandling(ScreenProfile screen) => true;
  bool _checkOrientationTransitionAnimation(ScreenProfile screen) => true;
  bool _checkScreenOrientationLock(ScreenProfile screen) => true;

  /// 生成分辨率相关建议
  List<String> _generateResolutionRecommendations(List<ResolutionCompatibilityTest> tests, ScreenProfile screen) {
    final recommendations = <String>[];
    
    for (final test in tests) {
      if (!test.passed) {
        switch (test.testName) {
          case '分辨率支持测试':
            recommendations.add('添加更多分辨率支持配置');
            recommendations.add('实现分辨率检测和自适应');
            break;
          case 'DPI兼容性测试':
            recommendations.add('为不同DPI提供专用资源文件');
            recommendations.add('实现动态DPI适配');
            break;
          case '长宽比适配测试':
            recommendations.add('实现响应式布局设计');
            recommendations.add('适配特殊长宽比设备');
            break;
          case 'UI布局适配测试':
            recommendations.add('使用约束布局提高适配性');
            recommendations.add('实现自适应组件尺寸');
            break;
          case '字体缩放测试':
            recommendations.add('实现字体大小动态调整');
            recommendations.add('提供字体缩放选项');
            break;
          case '图标适配测试':
            recommendations.add('使用矢量图标提高适配性');
            recommendations.add('实现图标多密度版本');
            break;
          case '横竖屏适配测试':
            recommendations.add('实现横竖屏分别布局');
            recommendations.add('优化屏幕旋转体验');
            break;
        }
      }
    }
    
    return recommendations;
  }
}

/// 屏幕档案类
class ScreenProfile {
  final String resolution;
  final int height;
  final int width;
  final double size;
  final double density;
  final String category;
  final String aspectRatio;

  ScreenProfile(
    this.resolution,
    this.height,
    this.width,
    this.size,
    this.density,
    this.category,
    this.aspectRatio,
  );

  Map<String, dynamic> toJson() {
    return {
      'resolution': resolution,
      'height': height,
      'width': width,
      'size': size,
      'density': density,
      'category': category,
      'aspectRatio': aspectRatio,
    };
  }
}

/// 分辨率兼容性测试结果类
class ResolutionCompatibilityTest {
  final String testName;
  final bool passed;
  final double score;
  final String details;
  final List<String> supportedFeatures;
  final List<String> compatibilityIssues;

  ResolutionCompatibilityTest({
    required this.testName,
    required this.passed,
    required this.score,
    required this.details,
    required this.supportedFeatures,
    required this.compatibilityIssues,
  });
}