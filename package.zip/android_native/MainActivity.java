package com.example.nativeandroid;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.nativeandroid.recording.ScreenRecordManager;
import com.example.nativeandroid.recording.ScreenRecordService;
import com.example.nativeandroid.services.FloatWindowService;
import com.example.nativeandroid.services.KeepAliveService;
import com.example.nativeandroid.services.WakeWordDetectionService;
import com.example.nativeandroid.utils.PermissionUtils;

/**
 * 主Activity
 * 负责权限申请和功能演示
 */
public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
    
    // UI控件
    private Button btnRequestPermissions;
    private Button btnStartFloatWindow;
    private Button btnStopFloatWindow;
    private Button btnStartKeepAlive;
    private Button btnStopKeepAlive;
    private Button btnStartScreenRecord;
    private Button btnStopScreenRecord;
    private Button btnStartWakeWord;
    private Button btnStopWakeWord;
    private Button btnRequestDeviceAdmin;
    
    // 权限请求码
    private static final int REQUEST_CODE_ALL_PERMISSIONS = 1000;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Log.d(TAG, "MainActivity onCreate");
        
        initViews();
        initListeners();
        checkPermissions();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity onResume");
        
        // 更新UI状态
        updateUIState();
    }
    
    /**
     * 初始化视图
     */
    private void initViews() {
        btnRequestPermissions = findViewById(R.id.btn_request_permissions);
        btnStartFloatWindow = findViewById(R.id.btn_start_float_window);
        btnStopFloatWindow = findViewById(R.id.btn_stop_float_window);
        btnStartKeepAlive = findViewById(R.id.btn_start_keep_alive);
        btnStopKeepAlive = findViewById(R.id.btn_stop_keep_alive);
        btnStartScreenRecord = findViewById(R.id.btn_start_screen_record);
        btnStopScreenRecord = findViewById(R.id.btn_stop_screen_record);
        btnStartWakeWord = findViewById(R.id.btn_start_wake_word);
        btnStopWakeWord = findViewById(R.id.btn_stop_wake_word);
        btnRequestDeviceAdmin = findViewById(R.id.btn_request_device_admin);
    }
    
    /**
     * 初始化监听器
     */
    private void initListeners() {
        // 权限申请按钮
        btnRequestPermissions.setOnClickListener(v -> requestAllPermissions());
        
        // 悬浮窗控制按钮
        btnStartFloatWindow.setOnClickListener(v -> {
            FloatWindowService.showFloatWindow(this);
            updateUIState();
        });
        
        btnStopFloatWindow.setOnClickListener(v -> {
            FloatWindowService.hideFloatWindow(this);
            updateUIState();
        });
        
        // 保活服务控制按钮
        btnStartKeepAlive.setOnClickListener(v -> {
            KeepAliveService.startKeepAliveService(this);
            updateUIState();
        });
        
        btnStopKeepAlive.setOnClickListener(v -> {
            KeepAliveService.stopKeepAliveService(this);
            updateUIState();
        });
        
        // 屏幕录制控制按钮
        btnStartScreenRecord.setOnClickListener(v -> startScreenRecording());
        
        btnStopScreenRecord.setOnClickListener(v -> {
            ScreenRecordService.stopScreenRecording(this);
            updateUIState();
        });
        
        // 唤醒词检测控制按钮
        btnStartWakeWord.setOnClickListener(v -> {
            WakeWordDetectionService.startWakeWordDetection(this);
            updateUIState();
        });
        
        btnStopWakeWord.setOnClickListener(v -> {
            WakeWordDetectionService.stopWakeWordDetection(this);
            updateUIState();
        });
        
        // 设备管理员权限按钮
        btnRequestDeviceAdmin.setOnClickListener(v -> requestDeviceAdminPermission());
    }
    
    /**
     * 检查权限
     */
    private void checkPermissions() {
        Log.d(TAG, "检查权限状态");
        
        // 检查基础权限
        boolean hasBasicPermissions = PermissionUtils.checkCameraPermission(this) &&
                                     PermissionUtils.checkMicrophonePermission(this) &&
                                     PermissionUtils.checkStoragePermission(this) &&
                                     PermissionUtils.checkLocationPermission(this);
        
        // 检查特殊权限
        boolean hasSystemAlertWindow = PermissionUtils.checkSystemAlertWindowPermission(this);
        boolean hasWriteSettings = PermissionUtils.checkWriteSettingsPermission(this);
        boolean hasBatteryOptimization = PermissionUtils.checkBatteryOptimizationPermission(this);
        
        Log.d(TAG, "基础权限状态: " + hasBasicPermissions);
        Log.d(TAG, "悬浮窗权限状态: " + hasSystemAlertWindow);
        Log.d(TAG, "系统设置权限状态: " + hasWriteSettings);
        Log.d(TAG, "电池优化权限状态: " + hasBatteryOptimization);
        
        // 更新按钮状态
        btnRequestPermissions.setEnabled(!hasBasicPermissions);
        updateUIState();
    }
    
    /**
     * 请求所有权限
     */
    private void requestAllPermissions() {
        Log.d(TAG, "请求所有权限");
        
        // 基础权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+
            String[] permissions = {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS
            };
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ALL_PERMISSIONS);
        } else {
            // Android 12及以下
            String[] permissions = {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            };
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ALL_PERMISSIONS);
        }
    }
    
    /**
     * 请求设备管理员权限
     */
    private void requestDeviceAdminPermission() {
        try {
            Intent intent = new Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                new android.content.ComponentName(this, com.example.nativeandroid.receiver.DeviceAdminReceiver.class));
            intent.putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "需要设备管理员权限以启用设备保护功能");
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "请求设备管理员权限失败", e);
            Toast.makeText(this, "请求设备管理员权限失败", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * 开始屏幕录制
     */
    private void startScreenRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ScreenRecordManager.getInstance(this).setCallback(new ScreenRecordManager.ScreenRecordCallback() {
                @Override
                public void onRecordingStarted(String outputPath) {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "屏幕录制已开始", Toast.LENGTH_SHORT).show();
                        updateUIState();
                    });
                }
                
                @Override
                public void onRecordingStopped(String outputPath) {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "屏幕录制已停止: " + outputPath, Toast.LENGTH_LONG).show();
                        updateUIState();
                    });
                }
                
                @Override
                public void onError(String error) {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "录制错误: " + error, Toast.LENGTH_SHORT).show();
                        updateUIState();
                    });
                }
            });
            
            ScreenRecordManager.getInstance(this).startScreenRecording(this);
        } else {
            Toast.makeText(this, "设备不支持屏幕录制功能", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        Log.d(TAG, "权限请求结果: " + requestCode);
        
        if (requestCode == REQUEST_CODE_ALL_PERMISSIONS) {
            boolean allGranted = true;
            
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                Toast.makeText(this, "所有权限已授予", Toast.LENGTH_SHORT).show();
                updateUIState();
            } else {
                Toast.makeText(this, "部分权限被拒绝", Toast.LENGTH_SHORT).show();
            }
        }
        
        // 检查特殊权限
        if (requestCode == PermissionUtils.REQUEST_CODE_SYSTEM_ALERT_WINDOW) {
            if (PermissionUtils.checkSystemAlertWindowPermission(this)) {
                Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "悬浮窗权限被拒绝", Toast.LENGTH_SHORT).show();
            }
            updateUIState();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        Log.d(TAG, "Activity结果: " + requestCode);
        
        // 处理屏幕录制权限
        if (requestCode == ScreenRecordManager.REQUEST_CODE_SCREEN_RECORD) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "屏幕录制权限已授予", Toast.LENGTH_SHORT).show();
                
                // 启动录制服务
                ScreenRecordService.startScreenRecording(this);
                updateUIState();
            } else {
                Toast.makeText(this, "屏幕录制权限被拒绝", Toast.LENGTH_SHORT).show();
            }
        }
        
        // 处理系统设置权限
        if (requestCode == PermissionUtils.REQUEST_CODE_SYSTEM_ALERT_WINDOW) {
            if (PermissionUtils.checkSystemAlertWindowPermission(this)) {
                Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "悬浮窗权限被拒绝", Toast.LENGTH_SHORT).show();
            }
            updateUIState();
        }
        
        if (requestCode == PermissionUtils.REQUEST_CODE_WRITE_SETTINGS) {
            if (PermissionUtils.checkWriteSettingsPermission(this)) {
                Toast.makeText(this, "系统设置权限已授予", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "系统设置权限被拒绝", Toast.LENGTH_SHORT).show();
            }
            updateUIState();
        }
    }
    
    /**
     * 更新UI状态
     */
    private void updateUIState() {
        // 检查悬浮窗状态
        boolean floatWindowShowing = FloatWindowService.isFloatWindowShowing();
        btnStartFloatWindow.setEnabled(!floatWindowShowing);
        btnStopFloatWindow.setEnabled(floatWindowShowing);
        
        // 检查保活服务状态
        boolean keepAliveRunning = KeepAliveService.isKeepAliveServiceRunning(this);
        btnStartKeepAlive.setEnabled(!keepAliveRunning);
        btnStopKeepAlive.setEnabled(keepAliveRunning);
        
        // 检查屏幕录制状态
        // 这里可以添加屏幕录制状态检查逻辑
        
        // 检查唤醒词检测状态
        // 这里可以添加唤醒词检测状态检查逻辑
        
        // 更新按钮文本
        btnRequestPermissions.setEnabled(!checkBasicPermissions());
    }
    
    /**
     * 检查基础权限
     */
    private boolean checkBasicPermissions() {
        return PermissionUtils.checkCameraPermission(this) &&
               PermissionUtils.checkMicrophonePermission(this) &&
               PermissionUtils.checkStoragePermission(this);
    }
}