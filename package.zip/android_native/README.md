---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022100eec7b8247c5dc857cc9cb0bbdc52fc6614b6ebc7d884740f4fffc1ccc4457150022006697f52efa71df3076e90d5c1fa5fc662aa049b0a5bc96e7263d85e54119cce
    ReservedCode2: 3045022100a4eba90a9f1246f6898fc7693a09fc6b0cb00d9d615e30e0e9b6e61a2837208702205254eb4c96e459e0b9e29c3cefb8cf164313a3494e1d9bf8f411a7c6c908a37b
---

# Android原生权限配置示例

这是一个完整的Android原生权限配置和Service管理示例项目，展示了如何处理Android的各类权限和后台服务管理。

## 项目结构

```
android_native/
├── AndroidManifest.xml          # 应用权限配置
├── MyApplication.java           # 应用主类
├── MainActivity.java           # 主Activity
├── layout/
│   └── activity_main.xml       # 主界面布局
├── layout_float_window.xml     # 悬浮窗布局
├── services/
│   ├── FloatWindowService.java     # 悬浮窗Service
│   ├── KeepAliveService.java       # 后台保活Service
│   ├── WakeWordDetectionService.java # 唤醒词检测Service
│   └── WakeWordDetector.java       # 唤醒词检测器
├── recording/
│   ├── ScreenRecordManager.java   # 屏幕录制管理器
│   └── ScreenRecordService.java   # 屏幕录制Service
├── receiver/
│   ├── BootReceiver.java          # 开机启动接收器
│   └── DeviceAdminReceiver.java   # 设备管理员接收器
├── utils/
│   └── PermissionUtils.java       # 权限管理工具类
├── drawable/
│   ├── bg_float_window.xml        # 悬浮窗背景
│   └── btn_float_window_bg.xml   # 按钮背景
├── xml/
│   └── device_admin.xml          # 设备管理员配置
└── values/
    └── strings.xml               # 字符串资源
```

## 主要功能

### 1. 权限管理
- **基础权限**: 摄像头、麦克风、存储、位置等运行时权限
- **特殊权限**: 悬浮窗、系统设置、电池优化等系统权限
- **权限检查**: 自动检测权限状态和缺失权限
- **权限申请**: 批量请求和单独请求权限

### 2. 悬浮窗服务 (FloatWindowService)
- 实现悬浮窗的显示、隐藏和大小调整
- 支持拖拽移动和长按调整大小
- 最小化和关闭功能
- 透明度和触摸事件处理

### 3. 后台保活服务 (KeepAliveService)
- 保持应用在后台持续运行
- 定时健康检查和服务恢复
- 唤醒锁管理和电池优化处理
- 开机自启和系统事件监听

### 4. 屏幕录制功能
- MediaProjection API集成
- 支持屏幕内容录制
- 音频同步录制
- 文件管理和媒体库扫描

### 5. 唤醒词检测
- 自定义唤醒词识别
- 音频录制和处理
- MFCC特征提取
- 实时检测和回调通知

### 6. 系统集成
- 设备管理员权限管理
- 开机自启动配置
- 系统事件监听和处理
- 应用生命周期管理

## 权限列表

### 运行时权限
- `CAMERA` - 摄像头权限
- `RECORD_AUDIO` - 麦克风权限
- `READ_EXTERNAL_STORAGE` - 外部存储读取权限
- `WRITE_EXTERNAL_STORAGE` - 外部存储写入权限
- `ACCESS_FINE_LOCATION` - 精确位置权限
- `ACCESS_COARSE_LOCATION` - 粗略位置权限
- `READ_CONTACTS` - 联系人读取权限
- `READ_PHONE_STATE` - 电话状态读取权限
- `POST_NOTIFICATIONS` - 通知权限 (Android 13+)

### 特殊权限
- `SYSTEM_ALERT_WINDOW` - 悬浮窗权限
- `REQUEST_INSTALL_PACKAGES` - 未知来源安装权限
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` - 电池优化白名单权限
- `MANAGE_EXTERNAL_STORAGE` - 全部文件访问权限 (Android 11+)

### 前台服务权限
- `FOREGROUND_SERVICE` - 前台服务权限
- `FOREGROUND_SERVICE_MEDIA_PROJECTION` - 媒体投影前台服务权限
- `FOREGROUND_SERVICE_SYSTEM_EXEMPTED` - 系统豁免前台服务权限

## 使用方法

### 1. 导入项目
将项目文件复制到Android Studio项目中，或创建新的Android项目并替换相应文件。

### 2. 权限申请
```java
// 申请所有基础权限
PermissionUtils.requestMissingPermissions(this);

// 单独申请悬浮窗权限
PermissionUtils.requestSystemAlertWindowPermission(this);

// 检查权限状态
boolean hasPermission = PermissionUtils.checkCameraPermission(this);
```

### 3. 服务管理
```java
// 启动悬浮窗服务
FloatWindowService.showFloatWindow(this);

// 启动保活服务
KeepAliveService.startKeepAliveService(this);

// 启动屏幕录制
ScreenRecordService.startScreenRecording(this);

// 启动唤醒词检测
WakeWordDetectionService.startWakeWordDetection(this);
```

### 4. 屏幕录制
```java
ScreenRecordManager manager = ScreenRecordManager.getInstance(this);
manager.setCallback(new ScreenRecordManager.ScreenRecordCallback() {
    @Override
    public void onRecordingStarted(String outputPath) {
        // 录制开始
    }
    
    @Override
    public void onRecordingStopped(String outputPath) {
        // 录制停止
    }
    
    @Override
    public void onError(String error) {
        // 录制错误
    }
});
manager.startScreenRecording(this);
```

## 注意事项

### 1. 权限申请
- Android 6.0+需要动态申请运行时权限
- 特殊权限需要通过系统设置页面申请
- 部分权限需要在AndroidManifest.xml中声明

### 2. 服务管理
- 前台服务需要在通知栏显示通知
- 后台服务需要处理系统杀进程情况
- 开机启动需要在AndroidManifest.xml中配置

### 3. 屏幕录制
- 需要用户手动授权MediaProjection权限
- Android 5.0+才支持屏幕录制
- 录制文件保存在公共目录中

### 4. 设备管理员
- 需要用户手动激活设备管理员权限
- 部分功能需要管理员权限才能执行
- 敏感操作需要谨慎使用

### 5. 性能优化
- 音频录制和处理使用单独线程
- 定时器任务使用WakeLock保持唤醒
- 内存管理和资源释放

## 兼容性

- **最低支持版本**: Android 5.0 (API 21)
- **推荐版本**: Android 8.0+ (API 26+)
- **特殊功能**: 屏幕录制需要Android 5.0+，媒体投影API
- **权限处理**: Android 6.0+动态权限，Android 13+新权限模型

## 扩展功能

1. **多语言支持**: 国际化字符串资源
2. **主题切换**: 动态主题和深色模式
3. **设置页面**: 用户可配置的参数设置
4. **日志系统**: 详细的调试和错误日志
5. **统计分析**: 使用统计和性能监控
6. **自动更新**: 版本检查和更新提示

## 许可证

本项目仅用于学习和演示目的，请根据实际需要修改和使用。

## 联系方式

如有问题或建议，请通过GitHub Issues反馈。