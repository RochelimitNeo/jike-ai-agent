package com.example.nativeandroid;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.nativeandroid.services.FloatWindowService;
import com.example.nativeandroid.services.KeepAliveService;
import com.example.nativeandroid.services.WakeWordDetectionService;
import com.example.nativeandroid.utils.PermissionUtils;

/**
 * 应用主类
 * 负责应用初始化和全局配置
 */
public class MyApplication extends Application {
    private static final String TAG = "MyApplication";
    
    private static MyApplication instance;
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        instance = this;
        
        Log.d(TAG, "MyApplication onCreate");
        
        // 初始化应用
        initializeApplication();
    }
    
    /**
     * 初始化应用
     */
    private void initializeApplication() {
        try {
            Log.d(TAG, "开始初始化应用");
            
            // 初始化权限检查
            initializePermissions();
            
            // 初始化服务
            initializeServices();
            
            // 初始化配置
            initializeConfiguration();
            
            Log.d(TAG, "应用初始化完成");
            
        } catch (Exception e) {
            Log.e(TAG, "应用初始化失败", e);
        }
    }
    
    /**
     * 初始化权限
     */
    private void initializePermissions() {
        Log.d(TAG, "初始化权限检查");
        
        // 检查基础权限
        boolean hasBasicPermissions = checkBasicPermissions();
        
        if (!hasBasicPermissions) {
            Log.w(TAG, "缺少基础权限，部分功能可能无法使用");
        }
    }
    
    /**
     * 初始化服务
     */
    private void initializeServices() {
        Log.d(TAG, "初始化后台服务");
        
        // 检查是否需要启动后台服务
        boolean shouldStartServices = shouldStartBackgroundServices();
        
        if (shouldStartServices) {
            // 启动保活服务
            KeepAliveService.startKeepAliveService(this);
            
            // 启动悬浮窗服务
            FloatWindowService.showFloatWindow(this);
            
            // 启动唤醒词检测服务
            WakeWordDetectionService.startWakeWordDetection(this);
        }
    }
    
    /**
     * 初始化配置
     */
    private void initializeConfiguration() {
        Log.d(TAG, "初始化应用配置");
        
        // 初始化SharedPreferences配置
        getSharedPreferences("app_config", MODE_PRIVATE)
            .edit()
            .putBoolean("is_first_run", false)
            .putLong("first_run_time", System.currentTimeMillis())
            .apply();
            
        // 初始化其他配置
        initializeDebugConfig();
        initializeFeatureConfig();
    }
    
    /**
     * 初始化调试配置
     */
    private void initializeDebugConfig() {
        // 调试模式配置
        boolean isDebugMode = BuildConfig.DEBUG;
        
        getSharedPreferences("debug_config", MODE_PRIVATE)
            .edit()
            .putBoolean("debug_mode", isDebugMode)
            .putBoolean("log_enabled", isDebugMode)
            .apply();
    }
    
    /**
     * 初始化功能配置
     */
    private void initializeFeatureConfig() {
        // 功能开关配置
        getSharedPreferences("feature_config", MODE_PRIVATE)
            .edit()
            .putBoolean("enable_float_window", true)
            .putBoolean("enable_keep_alive", true)
            .putBoolean("enable_wake_word", true)
            .putBoolean("enable_screen_record", true)
            .apply();
    }
    
    /**
     * 检查基础权限
     */
    private boolean checkBasicPermissions() {
        // 这里可以检查应用运行所需的基础权限
        // 简化实现，返回true
        return true;
    }
    
    /**
     * 是否应该启动后台服务
     */
    private boolean shouldStartBackgroundServices() {
        // 检查配置
        return getSharedPreferences("app_config", MODE_PRIVATE)
            .getBoolean("enable_background_services", true);
    }
    
    /**
     * 获取应用实例
     */
    public static MyApplication getInstance() {
        return instance;
    }
    
    /**
     * 重启应用服务
     */
    public void restartServices() {
        Log.d(TAG, "重启应用服务");
        
        // 停止现有服务
        stopAllServices();
        
        // 重新启动服务
        new Thread(() -> {
            try {
                Thread.sleep(1000); // 延迟1秒
                
                // 启动服务
                initializeServices();
                
            } catch (InterruptedException e) {
                Log.e(TAG, "重启服务线程被中断", e);
            }
        }, "RestartServicesThread").start();
    }
    
    /**
     * 停止所有服务
     */
    public void stopAllServices() {
        Log.d(TAG, "停止所有服务");
        
        try {
            // 停止保活服务
            KeepAliveService.stopKeepAliveService(this);
            
            // 停止悬浮窗服务
            FloatWindowService.hideFloatWindow(this);
            
            // 停止唤醒词检测服务
            WakeWordDetectionService.stopWakeWordDetection(this);
            
        } catch (Exception e) {
            Log.e(TAG, "停止服务失败", e);
        }
    }
    
    /**
     * 检查应用状态
     */
    public void checkAppStatus() {
        Log.d(TAG, "检查应用状态");
        
        // 检查服务状态
        boolean keepAliveRunning = KeepAliveService.isKeepAliveServiceRunning(this);
        boolean floatWindowShowing = FloatWindowService.isFloatWindowShowing();
        
        Log.d(TAG, "保活服务状态: " + keepAliveRunning);
        Log.d(TAG, "悬浮窗显示状态: " + floatWindowShowing);
        
        // 检查配置
        boolean backgroundServicesEnabled = getSharedPreferences("app_config", MODE_PRIVATE)
            .getBoolean("enable_background_services", true);
        
        Log.d(TAG, "后台服务开关: " + backgroundServicesEnabled);
    }
    
    /**
     * 获取应用配置
     */
    public boolean getConfig(String key, boolean defaultValue) {
        return getSharedPreferences("app_config", MODE_PRIVATE)
            .getBoolean(key, defaultValue);
    }
    
    /**
     * 设置应用配置
     */
    public void setConfig(String key, boolean value) {
        getSharedPreferences("app_config", MODE_PRIVATE)
            .edit()
            .putBoolean(key, value)
            .apply();
    }
    
    /**
     * 获取调试配置
     */
    public boolean getDebugConfig(String key, boolean defaultValue) {
        return getSharedPreferences("debug_config", MODE_PRIVATE)
            .getBoolean(key, defaultValue);
    }
    
    /**
     * 设置调试配置
     */
    public void setDebugConfig(String key, boolean value) {
        getSharedPreferences("debug_config", MODE_PRIVATE)
            .edit()
            .putBoolean(key, value)
            .apply();
    }
    
    /**
     * 获取功能配置
     */
    public boolean getFeatureConfig(String key, boolean defaultValue) {
        return getSharedPreferences("feature_config", MODE_PRIVATE)
            .getBoolean(key, defaultValue);
    }
    
    /**
     * 设置功能配置
     */
    public void setFeatureConfig(String key, boolean value) {
        getSharedPreferences("feature_config", MODE_PRIVATE)
            .edit()
            .putBoolean(key, value)
            .apply();
    }
}