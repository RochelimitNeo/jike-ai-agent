package com.example.nativeandroid.services;

import android.util.Log;

/**
 * 唤醒词检测器
 * 简化的唤醒词检测实现
 * 在实际项目中可以集成百度、科大讯飞等第三方唤醒词引擎
 */
public class WakeWordDetector {
    private static final String TAG = "WakeWordDetector";
    
    // 简化的MFCC特征提取参数
    private static final int NUM_MFCC = 13;
    private static final int FFT_SIZE = 512;
    private static final int NUM_FILTERS = 26;
    
    // 唤醒词模板（简化版，实际应该使用训练好的模型）
    private float[] wakeWordTemplate;
    private boolean isInitialized = false;
    
    public WakeWordDetector() {
        initializeWakeWordTemplate();
    }
    
    /**
     * 初始化唤醒词模板
     */
    private void initializeWakeWordTemplate() {
        // 这里使用简化的模板，实际应该使用机器学习模型
        wakeWordTemplate = new float[NUM_MFCC];
        
        // 模拟"你好小助手"的MFCC特征（简化示例）
        for (int i = 0; i < NUM_MFCC; i++) {
            wakeWordTemplate[i] = (float) (Math.sin(i * 0.5) * 0.8 + Math.random() * 0.2);
        }
        
        isInitialized = true;
        Log.d(TAG, "唤醒词模板已初始化");
    }
    
    /**
     * 检测唤醒词
     * @param audioData 音频数据
     * @param length 数据长度
     * @param sampleRate 采样率
     * @return 置信度 (0.0 - 1.0)
     */
    public float detectWakeWord(short[] audioData, int length, int sampleRate) {
        if (!isInitialized || audioData == null || length <= 0) {
            return 0.0f;
        }
        
        try {
            // 预处理音频数据
            float[] processedAudio = preprocessAudio(audioData, length);
            
            // 提取MFCC特征
            float[] mfccFeatures = extractMFCC(processedAudio, sampleRate);
            
            if (mfccFeatures == null || mfccFeatures.length != NUM_MFCC) {
                return 0.0f;
            }
            
            // 计算与模板的相似度
            float similarity = calculateSimilarity(mfccFeatures, wakeWordTemplate);
            
            // 添加时间一致性检查
            float timeConsistency = checkTimeConsistency(mfccFeatures);
            
            // 综合置信度
            float confidence = (similarity * 0.7f) + (timeConsistency * 0.3f);
            
            // 非线性增强
            confidence = (float) Math.pow(confidence, 0.8);
            
            Log.d(TAG, String.format("MFCC相似度: %.3f, 时间一致性: %.3f, 置信度: %.3f",
                    similarity, timeConsistency, confidence));
            
            return Math.min(confidence, 1.0f);
            
        } catch (Exception e) {
            Log.e(TAG, "唤醒词检测异常", e);
            return 0.0f;
        }
    }
    
    /**
     * 预处理音频数据
     */
    private float[] preprocessAudio(short[] audioData, int length) {
        float[] processed = new float[length];
        
        // 转换为浮点数并归一化
        for (int i = 0; i < length; i++) {
            processed[i] = audioData[i] / 32768.0f;
        }
        
        // 预加重
        float[] emphasized = new float[length];
        emphasized[0] = processed[0];
        for (int i = 1; i < length; i++) {
            emphasized[i] = processed[i] - 0.97f * processed[i - 1];
        }
        
        // 加窗（汉明窗）
        return applyHammingWindow(emphasized);
    }
    
    /**
     * 应用汉明窗
     */
    private float[] applyHammingWindow(float[] audioData) {
        float[] windowed = new float[audioData.length];
        
        for (int i = 0; i < audioData.length; i++) {
            float window = 0.54f - 0.46f * (float) Math.cos(2 * Math.PI * i / (audioData.length - 1));
            windowed[i] = audioData[i] * window;
        }
        
        return windowed;
    }
    
    /**
     * 提取MFCC特征（简化版）
     */
    private float[] extractMFCC(float[] audioData, int sampleRate) {
        try {
            // 简化的MFCC提取过程
            int frameLength = Math.min(512, audioData.length / 2);
            int numFrames = audioData.length / frameLength;
            
            if (numFrames < 3) {
                return null; // 音频太短
            }
            
            float[] mfccSum = new float[NUM_MFCC];
            int validFrames = 0;
            
            for (int frame = 0; frame < numFrames; frame++) {
                int start = frame * frameLength;
                if (start + frameLength > audioData.length) break;
                
                float[] frameData = new float[frameLength];
                System.arraycopy(audioData, start, frameData, 0, frameLength);
                
                // 计算FFT
                float[] fftMagnitude = computeFFT(frameData);
                
                // 应用Mel滤波器组
                float[] melEnergies = applyMelFilters(fftMagnitude, sampleRate);
                
                // 计算DCT
                float[] mfcc = computeDCT(melEnergies);
                
                if (mfcc != null) {
                    for (int i = 0; i < Math.min(NUM_MFCC, mfcc.length); i++) {
                        mfccSum[i] += mfcc[i];
                    }
                    validFrames++;
                }
            }
            
            if (validFrames > 0) {
                for (int i = 0; i < NUM_MFCC; i++) {
                    mfccSum[i] /= validFrames;
                }
                return mfccSum;
            }
            
            return null;
            
        } catch (Exception e) {
            Log.e(TAG, "MFCC特征提取失败", e);
            return null;
        }
    }
    
    /**
     * 计算FFT（简化版）
     */
    private float[] computeFFT(float[] data) {
        // 实际项目中应使用专业的FFT库，如FFmpeg、JTransforms等
        // 这里返回简化的幅度谱
        int n = data.length;
        float[] magnitude = new float[n / 2];
        
        for (int i = 0; i < n / 2; i++) {
            float real = 0;
            float imag = 0;
            
            // 简化的DFT计算
            for (int j = 0; j < n; j++) {
                float angle = (float) (-2 * Math.PI * i * j / n);
                real += data[j] * (float) Math.cos(angle);
                imag += data[j] * (float) Math.sin(angle);
            }
            
            magnitude[i] = (float) Math.sqrt(real * real + imag * imag);
        }
        
        return magnitude;
    }
    
    /**
     * 应用Mel滤波器组（简化版）
     */
    private float[] applyMelFilters(float[] fftMagnitude, int sampleRate) {
        float[] melEnergies = new float[NUM_FILTERS];
        
        int fftSize = fftMagnitude.length;
        int nyquist = sampleRate / 2;
        
        for (int i = 0; i < NUM_FILTERS; i++) {
            // 简化的Mel滤波器实现
            float melCenter = (float) (2595.0 * Math.log10(1.0 + (i + 1) * 1000.0 / nyquist));
            
            int leftBin = Math.max(0, (int) (melCenter * fftSize / (nyquist * 1.2)));
            int rightBin = Math.min(fftSize - 1, (int) (melCenter * fftSize / (nyquist * 0.8)));
            
            float energy = 0;
            for (int bin = leftBin; bin <= rightBin && bin < fftSize; bin++) {
                energy += fftMagnitude[bin];
            }
            
            melEnergies[i] = energy;
        }
        
        return melEnergies;
    }
    
    /**
     * 计算DCT（离散余弦变换）
     */
    private float[] computeDCT(float[] melEnergies) {
        float[] dct = new float[NUM_MFCC];
        
        // 简化的DCT-II实现
        for (int m = 0; m < NUM_MFCC; m++) {
            float sum = 0;
            for (int n = 0; n < melEnergies.length; n++) {
                sum += melEnergies[n] * (float) Math.cos(Math.PI * m * (n + 0.5) / melEnergies.length);
            }
            dct[m] = sum;
        }
        
        return dct;
    }
    
    /**
     * 计算相似度
     */
    private float calculateSimilarity(float[] features1, float[] features2) {
        if (features1.length != features2.length) {
            return 0.0f;
        }
        
        float dotProduct = 0;
        float norm1 = 0;
        float norm2 = 0;
        
        for (int i = 0; i < features1.length; i++) {
            dotProduct += features1[i] * features2[i];
            norm1 += features1[i] * features1[i];
            norm2 += features2[i] * features2[i];
        }
        
        if (norm1 == 0 || norm2 == 0) {
            return 0.0f;
        }
        
        return Math.abs(dotProduct) / ((float) Math.sqrt(norm1) * (float) Math.sqrt(norm2));
    }
    
    /**
     * 检查时间一致性
     */
    private float checkTimeConsistency(float[] features) {
        // 检查特征的时间稳定性
        // 这里使用一个简化的实现，检查特征的方差
        float mean = 0;
        for (float feature : features) {
            mean += feature;
        }
        mean /= features.length;
        
        float variance = 0;
        for (float feature : features) {
            variance += (feature - mean) * (feature - mean);
        }
        variance /= features.length;
        
        // 方差越小，时间一致性越好
        float consistency = (float) Math.max(0, 1.0 - Math.sqrt(variance));
        
        return Math.min(consistency, 1.0f);
    }
    
    /**
     * 训练自定义唤醒词（模拟）
     */
    public void trainWakeWord(short[][] trainingData, String wakeWord) {
        if (trainingData == null || trainingData.length == 0) {
            Log.w(TAG, "训练数据为空");
            return;
        }
        
        Log.d(TAG, "开始训练唤醒词: " + wakeWord);
        
        // 提取所有训练样本的特征
        float[][] allFeatures = new float[trainingData.length][];
        
        for (int i = 0; i < trainingData.length; i++) {
            float[] features = extractMFCC(trainingData[i], SAMPLE_RATE_16K);
            if (features != null) {
                allFeatures[i] = features;
            }
        }
        
        // 计算平均模板
        if (allFeatures.length > 0) {
            float[] averageTemplate = new float[NUM_MFCC];
            
            for (float[] features : allFeatures) {
                if (features != null) {
                    for (int i = 0; i < NUM_MFCC && i < features.length; i++) {
                        averageTemplate[i] += features[i];
                    }
                }
            }
            
            // 求平均
            for (int i = 0; i < NUM_MFCC; i++) {
                averageTemplate[i] /= allFeatures.length;
            }
            
            // 更新模板
            this.wakeWordTemplate = averageTemplate;
            Log.d(TAG, "唤醒词训练完成");
        }
    }
    
    /**
     * 更新模板（用于实时学习）
     */
    public void updateTemplate(float[] newFeatures) {
        if (newFeatures == null || newFeatures.length != NUM_MFCC) {
            return;
        }
        
        // 简单的模板更新算法
        float learningRate = 0.1f;
        
        for (int i = 0; i < NUM_MFCC; i++) {
            wakeWordTemplate[i] = (1 - learningRate) * wakeWordTemplate[i] + 
                                 learningRate * newFeatures[i];
        }
        
        Log.d(TAG, "模板已更新");
    }
    
    // 常量
    private static final int SAMPLE_RATE_16K = 16000;
}