package com.example.nativeandroid.services;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

import com.example.nativeandroid.MainActivity;
import com.example.nativeandroid.R;
import com.example.nativeandroid.receiver.BootReceiver;
import com.example.nativeandroid.utils.PermissionUtils;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 后台常驻Service
 * 实现后台监听和唤醒机制
 */
public class KeepAliveService extends Service {
    private static final String TAG = "KeepAliveService";
    private static final String CHANNEL_ID = "KeepAliveChannel";
    private static final int NOTIFICATION_ID = 1002;
    
    // 定时检查间隔（毫秒）
    private static final long CHECK_INTERVAL = 30000; // 30秒
    private static final long WATCHDOG_INTERVAL = 60000; // 1分钟
    
    private Timer checkTimer;
    private Timer watchdogTimer;
    private ExecutorService executorService;
    private PowerManager.WakeLock wakeLock;
    private PowerManager powerManager;
    private SharedPreferences prefs;
    
    // 监听器
    private BootReceiver bootReceiver;
    private IntentFilter intentFilter;
    
    // 运行状态
    private volatile boolean isRunning = false;
    private long lastCheckTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "KeepAliveService onCreate");
        
        initComponents();
        registerReceivers();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "KeepAliveService onStartCommand");
        
        startForeground(NOTIFICATION_ID, createNotification());
        startServices();
        
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "KeepAliveService onDestroy");
        stopServices();
        unregisterReceivers();
        releaseResources();
    }

    /**
     * 初始化组件
     */
    private void initComponents() {
        powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        prefs = getSharedPreferences("keep_alive_prefs", Context.MODE_PRIVATE);
        executorService = Executors.newCachedThreadPool();
        
        // 获取唤醒锁
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, 
            "KeepAliveService::KeepAliveWakeLock"
        );
        wakeLock.setReferenceCounted(false);
    }

    /**
     * 注册广播接收器
     */
    private void registerReceivers() {
        bootReceiver = new BootReceiver();
        intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
        intentFilter.addAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_BATTERY_LOW);
        intentFilter.addAction(Intent.ACTION_BATTERY_OKAY);
        intentFilter.addAction("android.intent.action.PACKAGE_REPLACED");
        intentFilter.addDataScheme("package");
        
        registerReceiver(bootReceiver, intentFilter);
    }

    /**
     * 注销广播接收器
     */
    private void unregisterReceivers() {
        if (bootReceiver != null) {
            try {
                unregisterReceiver(bootReceiver);
            } catch (Exception e) {
                Log.e(TAG, "注销广播接收器失败", e);
            }
        }
    }

    /**
     * 创建通知渠道
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "后台保活服务",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("保持应用在后台运行");
            channel.setShowBadge(false);
            channel.setSound(null, null);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    /**
     * 创建前台服务通知
     */
    private Notification createNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ?
                PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setSmallIcon(R.drawable.ic_keep_alive)
               .setContentTitle("应用后台运行中")
               .setContentText("保持服务活跃状态")
               .setContentIntent(pendingIntent)
               .setOngoing(true)
               .setPriority(Notification.PRIORITY_LOW)
               .setAutoCancel(false);

        return builder.build();
    }

    /**
     * 启动服务
     */
    private void startServices() {
        if (isRunning) {
            return;
        }
        
        isRunning = true;
        lastCheckTime = System.currentTimeMillis();
        
        // 启动定时检查
        startCheckTimer();
        
        // 启动看门狗
        startWatchdogTimer();
        
        // 获取唤醒锁
        acquireWakeLock();
        
        Log.d(TAG, "KeepAliveService 已启动");
    }

    /**
     * 停止服务
     */
    private void stopServices() {
        isRunning = false;
        
        // 停止定时器
        if (checkTimer != null) {
            checkTimer.cancel();
            checkTimer = null;
        }
        
        if (watchdogTimer != null) {
            watchdogTimer.cancel();
            watchdogTimer = null;
        }
        
        // 释放唤醒锁
        releaseWakeLock();
        
        Log.d(TAG, "KeepAliveService 已停止");
    }

    /**
     * 释放资源
     */
    private void releaseResources() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }

    /**
     * 启动定时检查Timer
     */
    private void startCheckTimer() {
        checkTimer = new Timer("KeepAliveCheck");
        checkTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (isRunning) {
                    performHealthCheck();
                }
            }
        }, CHECK_INTERVAL, CHECK_INTERVAL);
    }

    /**
     * 启动看门狗Timer
     */
    private void startWatchdogTimer() {
        watchdogTimer = new Timer("KeepAliveWatchdog");
        watchdogTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (isRunning) {
                    performWatchdogCheck();
                }
            }
        }, WATCHDOG_INTERVAL, WATCHDOG_INTERVAL);
    }

    /**
     * 执行健康检查
     */
    private void performHealthCheck() {
        executorService.execute(() -> {
            try {
                // 检查服务状态
                if (!isServiceRunning(KeepAliveService.class)) {
                    Log.w(TAG, "KeepAliveService 疑似被杀死，尝试重启");
                    restartService();
                    return;
                }
                
                // 检查应用进程状态
                if (!isAppProcessRunning()) {
                    Log.w(TAG, "应用进程可能被杀死，尝试恢复");
                    recoverApplication();
                }
                
                // 检查系统资源
                checkSystemResources();
                
                // 执行其他后台任务
                performBackgroundTasks();
                
                lastCheckTime = System.currentTimeMillis();
                
            } catch (Exception e) {
                Log.e(TAG, "健康检查异常", e);
            }
        });
    }

    /**
     * 执行看门狗检查
     */
    private void performWatchdogCheck() {
        long currentTime = System.currentTimeMillis();
        long timeDiff = currentTime - lastCheckTime;
        
        // 如果超过3个检查周期没有响应，强制重启
        if (timeDiff > CHECK_INTERVAL * 3) {
            Log.e(TAG, "看门狗检测到服务无响应，强制重启");
            forceRestart();
        }
    }

    /**
     * 检查服务是否运行
     */
    private boolean isServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : 
             manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检查应用进程是否运行
     */
    private boolean isAppProcessRunning() {
        String packageName = getPackageName();
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = 
            manager.getRunningAppProcesses();
        
        if (runningApps != null) {
            for (ActivityManager.RunningAppProcessInfo info : runningApps) {
                if (info.processName.equals(packageName)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 重启服务
     */
    private void restartService() {
        Intent intent = new Intent(this, KeepAliveService.class);
        try {
            startService(intent);
        } catch (Exception e) {
            Log.e(TAG, "重启服务失败", e);
        }
    }

    /**
     * 恢复应用
     */
    private void recoverApplication() {
        try {
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | 
                                     Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launchIntent);
            }
        } catch (Exception e) {
            Log.e(TAG, "恢复应用失败", e);
        }
    }

    /**
     * 检查系统资源
     */
    private void checkSystemResources() {
        try {
            ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            activityManager.getMemoryInfo(memoryInfo);
            
            // 检查内存使用情况
            if (memoryInfo.lowMemory) {
                Log.w(TAG, "系统内存不足");
                // 可以在这里执行清理操作
            }
            
            // 检查电池状态
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
                int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                
                if (batteryLevel < 10) {
                    Log.w(TAG, "电池电量过低: " + batteryLevel + "%");
                    // 低电量时减少检查频率
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "检查系统资源异常", e);
        }
    }

    /**
     * 执行后台任务
     */
    private void performBackgroundTasks() {
        // 这里可以执行各种后台任务，如：
        // - 数据同步
        // - 状态检查
        // - 日志记录
        // - 清理任务等
        
        // 示例：更新通知内容
        updateNotification();
        
        // 示例：保存运行状态
        saveRunningState();
    }

    /**
     * 更新通知
     */
    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification notification = createNotification();
        manager.notify(NOTIFICATION_ID, notification);
    }

    /**
     * 保存运行状态
     */
    private void saveRunningState() {
        prefs.edit()
             .putLong("last_keep_alive_time", System.currentTimeMillis())
             .putInt("restart_count", prefs.getInt("restart_count", 0) + 1)
             .apply();
    }

    /**
     * 强制重启
     */
    private void forceRestart() {
        Log.w(TAG, "执行强制重启");
        
        // 停止当前服务
        stopServices();
        
        // 延迟重启
        new Thread(() -> {
            try {
                Thread.sleep(2000);
                Intent intent = new Intent(this, KeepAliveService.class);
                startService(intent);
            } catch (InterruptedException e) {
                Log.e(TAG, "强制重启延迟等待被中断", e);
            }
        }, "ForceRestartThread").start();
    }

    /**
     * 获取唤醒锁
     */
    private void acquireWakeLock() {
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire(10 * 60 * 1000L); // 10分钟超时
            Log.d(TAG, "已获取唤醒锁");
        }
    }

    /**
     * 释放唤醒锁
     */
    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d(TAG, "已释放唤醒锁");
        }
    }

    /**
     * 静态方法：启动保活服务
     */
    public static void startKeepAliveService(Context context) {
        Intent intent = new Intent(context, KeepAliveService.class);
        try {
            context.startService(intent);
            Log.d(TAG, "KeepAliveService 已启动");
        } catch (Exception e) {
            Log.e(TAG, "启动KeepAliveService失败", e);
        }
    }

    /**
     * 静态方法：停止保活服务
     */
    public static void stopKeepAliveService(Context context) {
        Intent intent = new Intent(context, KeepAliveService.class);
        try {
            context.stopService(intent);
            Log.d(TAG, "KeepAliveService 已停止");
        } catch (Exception e) {
            Log.e(TAG, "停止KeepAliveService失败", e);
        }
    }

    /**
     * 检查保活服务状态
     */
    public static boolean isKeepAliveServiceRunning(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : 
             manager.getRunningServices(Integer.MAX_VALUE)) {
            if (KeepAliveService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}