package com.example.nativeandroid.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.nativeandroid.MainActivity;
import com.example.nativeandroid.R;
import com.example.nativeandroid.utils.PermissionUtils;

/**
 * 悬浮窗Service
 * 实现悬浮窗的显示、隐藏、大小调整功能
 */
public class FloatWindowService extends Service {
    private static final String TAG = "FloatWindowService";
    private static final String CHANNEL_ID = "FloatWindowChannel";
    private static final int NOTIFICATION_ID = 1001;
    
    private WindowManager windowManager;
    private View floatView;
    private WindowManager.LayoutParams layoutParams;
    private boolean isShow = false;
    
    // 悬浮窗控件
    private ImageButton btnMinimize;
    private ImageButton btnClose;
    private TextView tvStatus;
    private LinearLayout layoutControl;
    
    // 触摸相关变量
    private int x, y;
    private float touchX, touchY;
    private boolean isDragging = false;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "FloatWindowService onCreate");
        initWindowManager();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "FloatWindowService onStartCommand");
        
        if (intent != null) {
            String action = intent.getAction();
            if ("SHOW_WINDOW".equals(action)) {
                showFloatWindow();
            } else if ("HIDE_WINDOW".equals(action)) {
                hideFloatWindow();
            } else if ("TOGGLE_WINDOW".equals(action)) {
                toggleFloatWindow();
            }
        } else {
            // 首次启动显示悬浮窗
            showFloatWindow();
        }
        
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "FloatWindowService onDestroy");
        hideFloatWindow();
    }

    /**
     * 初始化WindowManager
     */
    private void initWindowManager() {
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    /**
     * 创建通知渠道
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "悬浮窗服务",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("悬浮窗后台服务");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    /**
     * 创建前台服务通知
     */
    private Notification createNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent, 
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? 
                PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setSmallIcon(R.drawable.ic_float_window)
               .setContentTitle("悬浮窗服务运行中")
               .setContentText("点击返回应用")
               .setContentIntent(pendingIntent)
               .setOngoing(true)
               .setPriority(Notification.PRIORITY_LOW);

        return builder.build();
    }

    /**
     * 显示悬浮窗
     */
    private void showFloatWindow() {
        if (isShow) {
            return;
        }

        try {
            // 创建悬浮窗布局
            LayoutInflater inflater = LayoutInflater.from(this);
            floatView = inflater.inflate(R.layout.layout_float_window, null);
            
            // 初始化控件
            initFloatView();
            
            // 设置窗口参数
            layoutParams = new WindowManager.LayoutParams();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
            }
            
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
            layoutParams.gravity = Gravity.TOP | Gravity.START;
            layoutParams.x = 100;
            layoutParams.y = 200;
            layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
            layoutParams.format = PixelFormat.TRANSLUCENT;

            // 添加到窗口
            windowManager.addView(floatView, layoutParams);
            isShow = true;
            
            Log.d(TAG, "悬浮窗已显示");
            
        } catch (Exception e) {
            Log.e(TAG, "显示悬浮窗失败", e);
        }
    }

    /**
     * 隐藏悬浮窗
     */
    private void hideFloatWindow() {
        if (!isShow || floatView == null) {
            return;
        }

        try {
            windowManager.removeView(floatView);
            floatView = null;
            isShow = false;
            Log.d(TAG, "悬浮窗已隐藏");
        } catch (Exception e) {
            Log.e(TAG, "隐藏悬浮窗失败", e);
        }
    }

    /**
     * 切换悬浮窗显示状态
     */
    private void toggleFloatWindow() {
        if (isShow) {
            hideFloatWindow();
        } else {
            showFloatWindow();
        }
    }

    /**
     * 初始化悬浮窗控件
     */
    private void initFloatView() {
        btnMinimize = floatView.findViewById(R.id.btn_minimize);
        btnClose = floatView.findViewById(R.id.btn_close);
        tvStatus = floatView.findViewById(R.id.tv_status);
        layoutControl = floatView.findViewById(R.id.layout_control);

        // 设置状态
        tvStatus.setText("运行中");
        
        // 最小化按钮点击事件
        btnMinimize.setOnClickListener(v -> {
            hideFloatWindow();
            stopSelf();
        });

        // 关闭按钮点击事件
        btnClose.setOnClickListener(v -> {
            hideFloatWindow();
            stopSelf();
        });

        // 悬浮窗拖拽功能
        floatView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        x = layoutParams.x;
                        y = layoutParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        isDragging = false;
                        break;
                        
                    case MotionEvent.ACTION_MOVE:
                        float newX = event.getRawX();
                        float newY = event.getRawY();
                        float deltaX = newX - touchX;
                        float deltaY = newY - touchY;
                        
                        // 判断是否开始拖拽
                        if (!isDragging && Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
                            isDragging = true;
                            layoutControl.setVisibility(View.GONE);
                        }
                        
                        if (isDragging) {
                            layoutParams.x = (int) (x - deltaX);
                            layoutParams.y = (int) (y + deltaY);
                            
                            // 边界检测
                            layoutParams.x = Math.max(0, Math.min(layoutParams.x, 
                                windowManager.getDefaultDisplay().getWidth() - 
                                floatView.getWidth()));
                            layoutParams.y = Math.max(0, Math.min(layoutParams.y, 
                                windowManager.getDefaultDisplay().getHeight() - 
                                floatView.getHeight()));
                            
                            windowManager.updateViewLayout(floatView, layoutParams);
                        }
                        break;
                        
                    case MotionEvent.ACTION_UP:
                        if (isDragging) {
                            isDragging = false;
                            // 延时显示控制面板
                            floatView.postDelayed(() -> {
                                if (!isDragging) {
                                    layoutControl.setVisibility(View.VISIBLE);
                                }
                            }, 1000);
                        } else {
                            // 点击事件
                            toggleControlPanel();
                        }
                        break;
                }
                return true;
            }
        });

        // 长按事件 - 调整大小
        floatView.setOnLongClickListener(v -> {
            showSizeAdjustmentDialog();
            return true;
        });
    }

    /**
     * 切换控制面板显示
     */
    private void toggleControlPanel() {
        if (layoutControl.getVisibility() == View.VISIBLE) {
            layoutControl.setVisibility(View.GONE);
        } else {
            layoutControl.setVisibility(View.VISIBLE);
            
            // 3秒后自动隐藏
            floatView.postDelayed(() -> {
                if (!isDragging) {
                    layoutControl.setVisibility(View.GONE);
                }
            }, 3000);
        }
    }

    /**
     * 显示大小调整对话框
     */
    private void showSizeAdjustmentDialog() {
        // 这里可以显示一个对话框让用户选择不同尺寸
        // 简化实现，直接调整大小
        layoutParams.width = layoutParams.width == WindowManager.LayoutParams.WRAP_CONTENT ? 
            (int) (150 * getResources().getDisplayMetrics().density) : 
            WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.height = layoutParams.height == WindowManager.LayoutParams.WRAP_CONTENT ? 
            (int) (100 * getResources().getDisplayMetrics().density) : 
            WindowManager.LayoutParams.WRAP_CONTENT;
            
        windowManager.updateViewLayout(floatView, layoutParams);
    }

    /**
     * 静态方法：显示悬浮窗
     */
    public static void showFloatWindow(Context context) {
        Intent intent = new Intent(context, FloatWindowService.class);
        intent.setAction("SHOW_WINDOW");
        context.startService(intent);
    }

    /**
     * 静态方法：隐藏悬浮窗
     */
    public static void hideFloatWindow(Context context) {
        Intent intent = new Intent(context, FloatWindowService.class);
        intent.setAction("HIDE_WINDOW");
        context.startService(intent);
    }

    /**
     * 静态方法：切换悬浮窗显示状态
     */
    public static void toggleFloatWindow(Context context) {
        Intent intent = new Intent(context, FloatWindowService.class);
        intent.setAction("TOGGLE_WINDOW");
        context.startService(intent);
    }

    /**
     * 获取悬浮窗状态
     */
    public static boolean isFloatWindowShowing() {
        // 可以通过其他方式判断悬浮窗是否显示
        return false;
    }
}