package com.example.nativeandroid.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import com.example.nativeandroid.MainActivity;
import com.example.nativeandroid.R;
import com.example.nativeandroid.utils.PermissionUtils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 唤醒词检测Service
 * 实现自定义唤醒词检测功能
 */
public class WakeWordDetectionService extends Service {
    private static final String TAG = "WakeWordDetectionService";
    private static final String CHANNEL_ID = "WakeWordDetectionChannel";
    private static final int NOTIFICATION_ID = 1004;
    
    // 音频录制参数
    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE_FACTOR = 2;
    
    // 唤醒词检测参数
    private static final String DEFAULT_WAKE_WORD = "你好小助手";
    private static final float CONFIDENCE_THRESHOLD = 0.7f;
    private static final int ENERGY_THRESHOLD = 1000;
    
    private AudioRecord audioRecord;
    private ExecutorService executorService;
    private PowerManager.WakeLock wakeLock;
    private SharedPreferences prefs;
    
    // 检测状态
    private volatile boolean isDetecting = false;
    private volatile boolean isRunning = false;
    private AtomicBoolean shouldStop = new AtomicBoolean(false);
    
    // 唤醒词检测相关
    private String customWakeWord;
    private WakeWordDetector wakeWordDetector;
    private WakeWordDetectionCallback callback;
    
    // 音频缓冲区
    private short[] audioBuffer;
    private int bufferSize;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "WakeWordDetectionService onCreate");
        
        initComponents();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "WakeWordDetectionService onStartCommand");
        
        startForeground(NOTIFICATION_ID, createNotification());
        startWakeWordDetection();
        
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "WakeWordDetectionService onDestroy");
        
        stopWakeWordDetection();
        cleanup();
    }

    /**
     * 初始化组件
     */
    private void initComponents() {
        executorService = Executors.newSingleThreadExecutor();
        wakeLock = ((PowerManager) getSystemService(Context.POWER_SERVICE))
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WakeWordDetectionService::WakeLock");
        wakeLock.setReferenceCounted(false);
        
        prefs = getSharedPreferences("wake_word_prefs", Context.MODE_PRIVATE);
        customWakeWord = prefs.getString("custom_wake_word", DEFAULT_WAKE_WORD);
        
        wakeWordDetector = new WakeWordDetector();
        
        initAudioRecord();
    }

    /**
     * 初始化AudioRecord
     */
    private void initAudioRecord() {
        try {
            bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
            bufferSize = bufferSize * BUFFER_SIZE_FACTOR;
            
            audioBuffer = new short[bufferSize / 2]; // 16bit = 2 bytes per sample
            
            audioRecord = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            );
            
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioRecord初始化失败");
            }
            
            Log.d(TAG, "AudioRecord初始化成功: " + 
                  String.format("采样率=%d, 缓冲大小=%d", SAMPLE_RATE, bufferSize));
                  
        } catch (Exception e) {
            Log.e(TAG, "AudioRecord初始化失败", e);
        }
    }

    /**
     * 开始唤醒词检测
     */
    private void startWakeWordDetection() {
        if (isRunning) {
            Log.w(TAG, "唤醒词检测已在运行");
            return;
        }
        
        if (!PermissionUtils.checkRecordAudioPermission(this)) {
            Log.e(TAG, "没有录音权限");
            stopSelf();
            return;
        }
        
        isRunning = true;
        shouldStop.set(false);
        
        // 获取唤醒锁
        acquireWakeLock();
        
        // 开始检测线程
        executorService.execute(this::detectionLoop);
        
        Log.d(TAG, "唤醒词检测已启动");
    }

    /**
     * 停止唤醒词检测
     */
    private void stopWakeWordDetection() {
        if (!isRunning) {
            return;
        }
        
        isRunning = false;
        shouldStop.set(true);
        
        // 释放唤醒锁
        releaseWakeLock();
        
        if (audioRecord != null) {
            try {
                if (audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    audioRecord.stop();
                }
            } catch (Exception e) {
                Log.e(TAG, "停止AudioRecord失败", e);
            }
        }
        
        Log.d(TAG, "唤醒词检测已停止");
    }

    /**
     * 检测循环
     */
    private void detectionLoop() {
        Log.d(TAG, "开始唤醒词检测循环");
        
        try {
            audioRecord.startRecording();
            isDetecting = true;
            
            while (!shouldStop.get()) {
                // 读取音频数据
                int result = audioRecord.read(audioBuffer, 0, audioBuffer.length);
                
                if (result > 0) {
                    // 处理音频数据
                    processAudioData(audioBuffer, result);
                }
                
                // 短暂休眠，减少CPU占用
                Thread.sleep(10);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "检测循环异常", e);
        } finally {
            isDetecting = false;
            if (audioRecord != null) {
                try {
                    audioRecord.stop();
                } catch (Exception e) {
                    Log.e(TAG, "停止AudioRecord失败", e);
                }
            }
        }
        
        Log.d(TAG, "唤醒词检测循环结束");
    }

    /**
     * 处理音频数据
     */
    private void processAudioData(short[] audioData, int length) {
        try {
            // 计算音频能量
            double energy = calculateEnergy(audioData, length);
            
            // 能量阈值检查
            if (energy < ENERGY_THRESHOLD) {
                return; // 静音，跳过检测
            }
            
            // 执行唤醒词检测
            float confidence = wakeWordDetector.detectWakeWord(audioData, length, SAMPLE_RATE);
            
            Log.d(TAG, String.format("唤醒词置信度: %.3f", confidence));
            
            // 检查是否检测到唤醒词
            if (confidence >= CONFIDENCE_THRESHOLD) {
                Log.i(TAG, "检测到唤醒词: " + customWakeWord + 
                      " (置信度: " + confidence + ")");
                
                // 触发唤醒
                triggerWakeUp();
                
                // 通知回调
                if (callback != null) {
                    callback.onWakeWordDetected(customWakeWord, confidence);
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "处理音频数据失败", e);
        }
    }

    /**
     * 计算音频能量
     */
    private double calculateEnergy(short[] audioData, int length) {
        double sum = 0;
        for (int i = 0; i < length; i++) {
            sum += audioData[i] * audioData[i];
        }
        return sum / length;
    }

    /**
     * 触发唤醒
     */
    private void triggerWakeUp() {
        // 发送唤醒广播
        Intent wakeIntent = new Intent("WAKE_WORD_DETECTED");
        wakeIntent.putExtra("wake_word", customWakeWord);
        wakeIntent.putExtra("timestamp", System.currentTimeMillis());
        sendBroadcast(wakeIntent);
        
        // 如果需要，可以启动主Activity
        try {
            Intent mainIntent = new Intent(this, MainActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | 
                               Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(mainIntent);
        } catch (Exception e) {
            Log.e(TAG, "启动主Activity失败", e);
        }
        
        // 震动反馈（如果支持）
        vibrateFeedback();
    }

    /**
     * 震动反馈
     */
    private void vibrateFeedback() {
        try {
            android.os.Vibrator vibrator = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                vibrator.vibrate(100); // 100ms震动
            }
        } catch (Exception e) {
            Log.w(TAG, "震动反馈失败", e);
        }
    }

    /**
     * 获取唤醒锁
     */
    private void acquireWakeLock() {
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire();
            Log.d(TAG, "已获取唤醒锁");
        }
    }

    /**
     * 释放唤醒锁
     */
    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d(TAG, "已释放唤醒锁");
        }
    }

    /**
     * 清理资源
     */
    private void cleanup() {
        if (audioRecord != null) {
            try {
                audioRecord.release();
            } catch (Exception e) {
                Log.e(TAG, "释放AudioRecord失败", e);
            }
            audioRecord = null;
        }
        
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
        }
    }

    /**
     * 创建通知渠道
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "唤醒词检测服务",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("语音唤醒词检测后台服务");
            channel.setSound(null, null);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    /**
     * 创建前台服务通知
     */
    private Notification createNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ?
                PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setSmallIcon(R.drawable.ic_wake_word)
               .setContentTitle("唤醒词检测中")
               .setContentText("监听唤醒词: " + customWakeWord)
               .setContentIntent(pendingIntent)
               .setOngoing(true)
               .setPriority(Notification.PRIORITY_LOW)
               .setAutoCancel(false);

        return builder.build();
    }

    /**
     * 设置回调接口
     */
    public void setCallback(WakeWordDetectionCallback callback) {
        this.callback = callback;
    }

    /**
     * 更新唤醒词
     */
    public void updateWakeWord(String newWakeWord) {
        this.customWakeWord = newWakeWord;
        prefs.edit().putString("custom_wake_word", newWakeWord).apply();
        
        // 更新通知
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, createNotification());
        
        Log.d(TAG, "唤醒词已更新为: " + newWakeWord);
    }

    /**
     * 获取当前唤醒词
     */
    public String getCurrentWakeWord() {
        return customWakeWord;
    }

    /**
     * 获取检测状态
     */
    public boolean isDetecting() {
        return isDetecting;
    }

    /**
     * 静态方法：启动唤醒词检测
     */
    public static void startWakeWordDetection(Context context) {
        Intent intent = new Intent(context, WakeWordDetectionService.class);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "启动唤醒词检测失败", e);
        }
    }

    /**
     * 静态方法：停止唤醒词检测
     */
    public static void stopWakeWordDetection(Context context) {
        Intent intent = new Intent(context, WakeWordDetectionService.class);
        context.stopService(intent);
    }

    /**
     * 唤醒词检测回调接口
     */
    public interface WakeWordDetectionCallback {
        void onWakeWordDetected(String wakeWord, float confidence);
        void onError(String error);
    }
}