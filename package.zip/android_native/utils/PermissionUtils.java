package com.example.nativeandroid.utils;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 权限申请工具类
 * 负责动态权限申请和检查
 */
public class PermissionUtils {
    private static final String TAG = "PermissionUtils";
    
    // 权限请求码
    public static final int REQUEST_CODE_STORAGE = 1001;
    public static final int REQUEST_CODE_CAMERA = 1002;
    public static final int REQUEST_CODE_MICROPHONE = 1003;
    public static final int REQUEST_CODE_LOCATION = 1004;
    public static final int REQUEST_CODE_CONTACTS = 1005;
    public static final int REQUEST_CODE_PHONE = 1006;
    public static final int REQUEST_CODE_SMS = 1007;
    public static final int REQUEST_CODE_CALENDAR = 1008;
    public static final int REQUEST_CODE_NOTIFICATION = 1009;
    
    // 系统设置权限请求码
    public static final int REQUEST_CODE_SYSTEM_ALERT_WINDOW = 2001;
    public static final int REQUEST_CODE_WRITE_SETTINGS = 2002;
    public static final int REQUEST_CODE_BATTERY_OPTIMIZATION = 2003;
    public static final int REQUEST_CODE_INSTALL_UNKNOWN_SOURCES = 2004;
    
    // 特殊权限列表
    private static final String[] NORMAL_PERMISSIONS = {
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS,
        Manifest.permission.READ_CALENDAR,
        Manifest.permission.WRITE_CALENDAR,
        Manifest.permission.BODY_SENSORS
    };
    
    private static final String[] DANGEROUS_PERMISSIONS = {
        Manifest.permission.SYSTEM_ALERT_WINDOW,
        Manifest.permission.REQUEST_INSTALL_PACKAGES,
        Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
        Manifest.permission.MANAGE_EXTERNAL_STORAGE
    };
    
    /**
     * 检查是否具有指定权限
     */
    public static boolean hasPermission(Context context, String permission) {
        if (context == null || permission == null) {
            return false;
        }
        
        try {
            int result = ContextCompat.checkSelfPermission(context, permission);
            return result == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            Log.e(TAG, "检查权限异常: " + permission, e);
            return false;
        }
    }
    
    /**
     * 批量检查权限
     */
    public static Map<String, Boolean> checkPermissions(Context context, String[] permissions) {
        Map<String, Boolean> results = new HashMap<>();
        
        if (context == null || permissions == null) {
            return results;
        }
        
        for (String permission : permissions) {
            results.put(permission, hasPermission(context, permission));
        }
        
        return results;
    }
    
    /**
     * 获取未授予的权限列表
     */
    public static List<String> getDeniedPermissions(Context context, String[] permissions) {
        List<String> deniedPermissions = new ArrayList<>();
        
        if (context == null || permissions == null) {
            return deniedPermissions;
        }
        
        for (String permission : permissions) {
            if (!hasPermission(context, permission)) {
                deniedPermissions.add(permission);
            }
        }
        
        return deniedPermissions;
    }
    
    /**
     * 请求权限
     */
    public static void requestPermission(Activity activity, String permission, int requestCode) {
        if (activity == null || permission == null) {
            return;
        }
        
        List<String> permissions = new ArrayList<>();
        permissions.add(permission);
        requestPermissions(activity, permissions.toArray(new String[0]), requestCode);
    }
    
    /**
     * 批量请求权限
     */
    public static void requestPermissions(Activity activity, String[] permissions, int requestCode) {
        if (activity == null || permissions == null || permissions.length == 0) {
            return;
        }
        
        // 检查是否有未授予的权限
        List<String> needRequestPermissions = new ArrayList<>();
        
        for (String permission : permissions) {
            if (!hasPermission(activity, permission)) {
                needRequestPermissions.add(permission);
            }
        }
        
        if (needRequestPermissions.isEmpty()) {
            Log.d(TAG, "所有权限已授予");
            return;
        }
        
        // 请求权限
        ActivityCompat.requestPermissions(
            activity,
            needRequestPermissions.toArray(new String[0]),
            requestCode
        );
        
        Log.d(TAG, "请求权限: " + Arrays.toString(needRequestPermissions.toArray()));
    }
    
    /**
     * 处理权限请求结果
     */
    public static boolean handlePermissionResult(int[] grantResults) {
        if (grantResults == null || grantResults.length == 0) {
            return false;
        }
        
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false; // 有权限被拒绝
            }
        }
        
        return true; // 所有权限都授予了
    }
    
    /**
     * 检查存储权限
     */
    public static boolean checkStoragePermission(Context context) {
        if (context == null) {
            return false;
        }
        
        // Android 13+ 使用新权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return hasPermission(context, Manifest.permission.READ_MEDIA_IMAGES) ||
                   hasPermission(context, Manifest.permission.READ_MEDIA_VIDEO) ||
                   hasPermission(context, Manifest.permission.READ_MEDIA_AUDIO);
        } else {
            // Android 12及以下
            return hasPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) &&
                   hasPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
    }
    
    /**
     * 请求存储权限
     */
    public static void requestStoragePermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+
            String[] permissions = {
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            };
            requestPermissions(activity, permissions, REQUEST_CODE_STORAGE);
        } else {
            // Android 12及以下
            String[] permissions = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            requestPermissions(activity, permissions, REQUEST_CODE_STORAGE);
        }
    }
    
    /**
     * 检查摄像头权限
     */
    public static boolean checkCameraPermission(Context context) {
        return hasPermission(context, Manifest.permission.CAMERA);
    }
    
    /**
     * 请求摄像头权限
     */
    public static void requestCameraPermission(Activity activity) {
        requestPermission(activity, Manifest.permission.CAMERA, REQUEST_CODE_CAMERA);
    }
    
    /**
     * 检查麦克风权限
     */
    public static boolean checkMicrophonePermission(Context context) {
        return hasPermission(context, Manifest.permission.RECORD_AUDIO);
    }
    
    /**
     * 请求麦克风权限
     */
    public static void requestMicrophonePermission(Activity activity) {
        requestPermission(activity, Manifest.permission.RECORD_AUDIO, REQUEST_CODE_MICROPHONE);
    }
    
    /**
     * 检查位置权限
     */
    public static boolean checkLocationPermission(Context context) {
        return hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ||
               hasPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION);
    }
    
    /**
     * 请求位置权限
     */
    public static void requestLocationPermission(Activity activity) {
        String[] permissions = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        };
        requestPermissions(activity, permissions, REQUEST_CODE_LOCATION);
    }
    
    /**
     * 检查通知权限（Android 13+）
     */
    public static boolean checkNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return hasPermission(context, Manifest.permission.POST_NOTIFICATIONS);
        }
        return true; // Android 12及以下默认有通知权限
    }
    
    /**
     * 请求通知权限
     */
    public static void requestNotificationPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermission(activity, Manifest.permission.POST_NOTIFICATIONS, REQUEST_CODE_NOTIFICATION);
        }
    }
    
    /**
     * 检查悬浮窗权限
     */
    public static boolean checkSystemAlertWindowPermission(Context context) {
        if (context == null) {
            return false;
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Settings.canDrawOverlays(context);
            }
            return true; // Android 6.0以下默认有权限
        } catch (Exception e) {
            Log.e(TAG, "检查悬浮窗权限异常", e);
            return false;
        }
    }
    
    /**
     * 请求悬浮窗权限
     */
    public static void requestSystemAlertWindowPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivityForResult(intent, REQUEST_CODE_SYSTEM_ALERT_WINDOW);
        }
    }
    
    /**
     * 检查修改系统设置权限
     */
    public static boolean checkWriteSettingsPermission(Context context) {
        if (context == null) {
            return false;
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Settings.System.canWrite(context);
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "检查修改系统设置权限异常", e);
            return false;
        }
    }
    
    /**
     * 请求修改系统设置权限
     */
    public static void requestWriteSettingsPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivityForResult(intent, REQUEST_CODE_WRITE_SETTINGS);
        }
    }
    
    /**
     * 检查电池优化白名单权限
     */
    public static boolean checkBatteryOptimizationPermission(Context context) {
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return false;
        }
        
        try {
            android.os.PowerManager powerManager = 
                (android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
            return powerManager.isIgnoringBatteryOptimizations(context.getPackageName());
        } catch (Exception e) {
            Log.e(TAG, "检查电池优化权限异常", e);
            return false;
        }
    }
    
    /**
     * 请求电池优化白名单权限
     */
    public static void requestBatteryOptimizationPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        }
    }
    
    /**
     * 检查未知来源安装权限
     */
    public static boolean checkInstallUnknownSourcesPermission(Context context) {
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return true;
        }
        
        try {
            return context.getPackageManager().canRequestPackageInstalls();
        } catch (Exception e) {
            Log.e(TAG, "检查安装权限异常", e);
            return false;
        }
    }
    
    /**
     * 请求未知来源安装权限
     */
    public static void requestInstallUnknownSourcesPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivityForResult(intent, REQUEST_CODE_INSTALL_UNKNOWN_SOURCES);
        }
    }
    
    /**
     * 检查媒体投影权限（屏幕录制）
     */
    public static boolean checkMediaProjectionPermission(Context context) {
        // MediaProjection权限需要通过Intent获取，无法直接检查
        // 这里返回true表示可以尝试获取权限
        return true;
    }
    
    /**
     * 请求媒体投影权限
     */
    public static void requestMediaProjectionPermission(Activity activity) {
        // MediaProjection权限需要通过MediaProjectionManager获取
        // 这里不直接处理，在ScreenRecordManager中处理
        Log.d(TAG, "MediaProjection权限需要在ScreenRecordManager中处理");
    }
    
    /**
     * 检查所有基础权限
     */
    public static Map<String, Boolean> checkAllBasicPermissions(Context context) {
        Map<String, Boolean> results = new HashMap<>();
        
        // 基础权限检查
        results.put("CAMERA", checkCameraPermission(context));
        results.put("MICROPHONE", checkMicrophonePermission(context));
        results.put("STORAGE", checkStoragePermission(context));
        results.put("LOCATION", checkLocationPermission(context));
        results.put("NOTIFICATION", checkNotificationPermission(context));
        
        // 特殊权限检查
        results.put("SYSTEM_ALERT_WINDOW", checkSystemAlertWindowPermission(context));
        results.put("WRITE_SETTINGS", checkWriteSettingsPermission(context));
        results.put("BATTERY_OPTIMIZATION", checkBatteryOptimizationPermission(context));
        results.put("INSTALL_UNKNOWN_SOURCES", checkInstallUnknownSourcesPermission(context));
        
        return results;
    }
    
    /**
     * 获取缺失的权限列表
     */
    public static List<String> getMissingPermissions(Context context) {
        List<String> missingPermissions = new ArrayList<>();
        Map<String, Boolean> allPermissions = checkAllBasicPermissions(context);
        
        for (Map.Entry<String, Boolean> entry : allPermissions.entrySet()) {
            if (!entry.getValue()) {
                missingPermissions.add(entry.getKey());
            }
        }
        
        return missingPermissions;
    }
    
    /**
     * 批量请求缺失的权限
     */
    public static void requestMissingPermissions(Activity activity) {
        List<String> missingPermissions = getMissingPermissions(activity);
        
        if (missingPermissions.isEmpty()) {
            Log.d(TAG, "没有缺失的权限");
            return;
        }
        
        // 分类请求权限
        List<String> normalPermissions = new ArrayList<>();
        
        for (String permission : missingPermissions) {
            switch (permission) {
                case "CAMERA":
                    requestCameraPermission(activity);
                    break;
                case "MICROPHONE":
                    requestMicrophonePermission(activity);
                    break;
                case "STORAGE":
                    requestStoragePermission(activity);
                    break;
                case "LOCATION":
                    requestLocationPermission(activity);
                    break;
                case "NOTIFICATION":
                    requestNotificationPermission(activity);
                    break;
                case "SYSTEM_ALERT_WINDOW":
                    requestSystemAlertWindowPermission(activity);
                    break;
                case "WRITE_SETTINGS":
                    requestWriteSettingsPermission(activity);
                    break;
                case "BATTERY_OPTIMIZATION":
                    requestBatteryOptimizationPermission(activity);
                    break;
                case "INSTALL_UNKNOWN_SOURCES":
                    requestInstallUnknownSourcesPermission(activity);
                    break;
            }
        }
        
        Log.d(TAG, "已请求缺失权限: " + missingPermissions);
    }
    
    /**
     * 检查是否为首次请求权限
     */
    public static boolean isFirstTimeRequestingPermission(Context context, String permission) {
        if (context == null || permission == null) {
            return false;
        }
        
        String key = "first_time_" + permission;
        return !context.getSharedPreferences("permission_prefs", Context.MODE_PRIVATE)
                      .getBoolean(key, false);
    }
    
    /**
     * 标记权限已请求
     */
    public static void markPermissionAsRequested(Context context, String permission) {
        if (context == null || permission == null) {
            return;
        }
        
        String key = "first_time_" + permission;
        context.getSharedPreferences("permission_prefs", Context.MODE_PRIVATE)
               .edit()
               .putBoolean(key, true)
               .apply();
    }
    
    /**
     * 获取权限状态描述
     */
    public static String getPermissionStatus(Context context, String permission) {
        if (context == null || permission == null) {
            return "Unknown";
        }
        
        boolean granted = hasPermission(context, permission);
        return granted ? "Granted" : "Denied";
    }
}