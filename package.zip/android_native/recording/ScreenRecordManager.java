package com.example.nativeandroid.recording;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 屏幕录制管理器
 * 负责管理MediaProjection API的屏幕录制功能
 */
public class ScreenRecordManager {
    private static final String TAG = "ScreenRecordManager";
    private static final int REQUEST_CODE_SCREEN_RECORD = 1000;
    
    private static ScreenRecordManager instance;
    
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private MediaRecorder mediaRecorder;
    private VirtualDisplay virtualDisplay;
    private ScreenRecordCallback callback;
    
    // 录制状态
    private boolean isRecording = false;
    private String outputPath;
    private int screenWidth;
    private int screenHeight;
    private int screenDpi;
    
    // 录制参数
    private static final int VIDEO_BITRATE = 2 * 1024 * 1024; // 2Mbps
    private static final int VIDEO_FRAME_RATE = 30; // 30fps
    
    private ScreenRecordManager(Context context) {
        projectionManager = (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        initScreenParams(context);
    }
    
    public static synchronized ScreenRecordManager getInstance(Context context) {
        if (instance == null) {
            instance = new ScreenRecordManager(context.getApplicationContext());
        }
        return instance;
    }
    
    /**
     * 初始化屏幕参数
     */
    private void initScreenParams(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDpi = metrics.densityDpi;
        
        Log.d(TAG, String.format("屏幕参数: %dx%d, DPI: %d", 
                screenWidth, screenHeight, screenDpi));
    }
    
    /**
     * 设置回调接口
     */
    public void setCallback(ScreenRecordCallback callback) {
        this.callback = callback;
    }
    
    /**
     * 开始屏幕录制
     */
    public void startScreenRecording(Activity activity) {
        if (isRecording) {
            Log.w(TAG, "录制已在进行中");
            return;
        }
        
        Log.d(TAG, "请求屏幕录制权限");
        
        Intent captureIntent = projectionManager.createScreenCaptureIntent();
        if (captureIntent != null) {
            activity.startActivityForResult(captureIntent, REQUEST_CODE_SCREEN_RECORD);
        } else {
            Log.e(TAG, "无法创建屏幕录制Intent");
            if (callback != null) {
                callback.onError("无法创建屏幕录制Intent");
            }
        }
    }
    
    /**
     * 处理权限请求结果
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_SCREEN_RECORD) {
            if (resultCode == Activity.RESULT_OK) {
                Log.d(TAG, "用户授予屏幕录制权限");
                startRecording(resultCode, data);
            } else {
                Log.w(TAG, "用户拒绝屏幕录制权限");
                if (callback != null) {
                    callback.onError("用户拒绝屏幕录制权限");
                }
            }
        }
    }
    
    /**
     * 开始录制
     */
    private void startRecording(int resultCode, Intent data) {
        try {
            // 创建MediaProjection
            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            if (mediaProjection == null) {
                Log.e(TAG, "MediaProjection 创建失败");
                if (callback != null) {
                    callback.onError("MediaProjection 创建失败");
                }
                return;
            }
            
            // 创建MediaRecorder
            mediaRecorder = new MediaRecorder();
            
            // 配置录制参数
            configureMediaRecorder();
            
            // 创建虚拟显示
            createVirtualDisplay();
            
            // 开始录制
            mediaRecorder.start();
            isRecording = true;
            
            Log.d(TAG, "屏幕录制已开始");
            if (callback != null) {
                callback.onRecordingStarted(outputPath);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "开始录制失败", e);
            if (callback != null) {
                callback.onError("开始录制失败: " + e.getMessage());
            }
            stopRecording();
        }
    }
    
    /**
     * 配置MediaRecorder
     */
    private void configureMediaRecorder() throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // 设置视频源
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            }
            
            // 设置音频源
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            
            // 设置输出格式
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            
            // 设置编码器
            mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            
            // 设置比特率
            mediaRecorder.setVideoEncodingBitRate(VIDEO_BITRATE);
            
            // 设置帧率
            mediaRecorder.setVideoFrameRate(VIDEO_FRAME_RATE);
            
            // 设置分辨率
            mediaRecorder.setVideoSize(screenWidth, screenHeight);
            
            // 生成输出文件路径
            outputPath = generateOutputPath();
            
            // 设置输出文件
            mediaRecorder.setOutputFile(outputPath);
            
            Log.d(TAG, String.format("录制配置: %dx%d, %dfps, %dKbps, 输出: %s",
                    screenWidth, screenHeight, VIDEO_FRAME_RATE, 
                    VIDEO_BITRATE / 1024, outputPath));
        }
    }
    
    /**
     * 创建虚拟显示
     */
    private void createVirtualDisplay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // 获取录制表面
            android.graphics.Surface surface = mediaRecorder.getSurface();
            
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenRecorder",
                screenWidth,
                screenHeight,
                screenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface,
                null,
                null
            );
            
            Log.d(TAG, "虚拟显示已创建");
        }
    }
    
    /**
     * 停止录制
     */
    public void stopScreenRecording() {
        if (!isRecording) {
            Log.w(TAG, "当前没有进行录制");
            return;
        }
        
        Log.d(TAG, "停止屏幕录制");
        
        try {
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
            }
            
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
            
            isRecording = false;
            
            // 扫描文件使媒体库可以识别
            scanFile();
            
            Log.d(TAG, "屏幕录制已停止");
            if (callback != null) {
                callback.onRecordingStopped(outputPath);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "停止录制失败", e);
            if (callback != null) {
                callback.onError("停止录制失败: " + e.getMessage());
            }
        }
    }
    
    /**
     * 停止录制（内部调用）
     */
    private void stopRecording() {
        if (!isRecording) {
            return;
        }
        
        try {
            if (mediaRecorder != null) {
                mediaRecorder.release();
                mediaRecorder = null;
            }
            
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
            
            isRecording = false;
            
        } catch (Exception e) {
            Log.e(TAG, "内部停止录制失败", e);
        }
    }
    
    /**
     * 生成输出文件路径
     */
    private String generateOutputPath() {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date());
        String filename = String.format("screen_record_%s.mp4", timestamp);
        
        File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        return new File(directory, filename).getAbsolutePath();
    }
    
    /**
     * 扫描文件添加到媒体库
     */
    private void scanFile() {
        if (outputPath != null) {
            File file = new File(outputPath);
            if (file.exists()) {
                MediaScannerConnection.scanFile(
                    getApplicationContext(),
                    new String[]{outputPath},
                    new String[]{"video/mp4"},
                    (path, uri) -> Log.d(TAG, "文件已扫描: " + path)
                );
                
                Log.d(TAG, "录制文件: " + outputPath);
            }
        }
    }
    
    /**
     * 获取录制状态
     */
    public boolean isRecording() {
        return isRecording;
    }
    
    /**
     * 获取录制文件路径
     */
    public String getOutputPath() {
        return outputPath;
    }
    
    /**
     * 获取屏幕参数
     */
    public ScreenParams getScreenParams() {
        return new ScreenParams(screenWidth, screenHeight, screenDpi);
    }
    
    /**
     * 销毁实例
     */
    public void destroy() {
        stopRecording();
        if (callback != null) {
            callback = null;
        }
    }
    
    /**
     * 屏幕录制回调接口
     */
    public interface ScreenRecordCallback {
        void onRecordingStarted(String outputPath);
        void onRecordingStopped(String outputPath);
        void onError(String error);
    }
    
    /**
     * 屏幕参数类
     */
    public static class ScreenParams {
        public final int width;
        public final int height;
        public final int dpi;
        
        public ScreenParams(int width, int height, int dpi) {
            this.width = width;
            this.height = height;
            this.dpi = dpi;
        }
        
        @Override
        public String toString() {
            return String.format("%dx%d @ %ddpi", width, height, dpi);
        }
    }
}