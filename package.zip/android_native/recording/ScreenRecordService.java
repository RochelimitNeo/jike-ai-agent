package com.example.nativeandroid.recording;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.example.nativeandroid.MainActivity;
import com.example.nativeandroid.R;
import com.example.nativeandroid.utils.PermissionUtils;

/**
 * 屏幕录制Service
 * 负责后台屏幕录制服务
 */
public class ScreenRecordService extends Service {
    private static final String TAG = "ScreenRecordService";
    private static final String CHANNEL_ID = "ScreenRecordChannel";
    private static final int NOTIFICATION_ID = 1003;
    
    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private MediaRecorder mediaRecorder;
    private VirtualDisplay virtualDisplay;
    
    private ScreenRecordManager screenRecordManager;
    private boolean isRecording = false;
    private String outputPath;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "ScreenRecordService onCreate");
        
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        screenRecordManager = ScreenRecordManager.getInstance(this);
        
        createNotificationChannel();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "ScreenRecordService onStartCommand");
        
        if (intent != null) {
            String action = intent.getAction();
            if ("START_RECORDING".equals(action)) {
                startScreenRecording();
            } else if ("STOP_RECORDING".equals(action)) {
                stopScreenRecording();
            }
        }
        
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "ScreenRecordService onDestroy");
        
        if (isRecording) {
            stopScreenRecording();
        }
        
        cleanup();
    }
    
    /**
     * 开始屏幕录制
     */
    private void startScreenRecording() {
        if (isRecording) {
            Log.w(TAG, "录制已在进行中");
            return;
        }
        
        Log.d(TAG, "开始屏幕录制");
        
        // 检查权限
        if (!checkPermissions()) {
            Log.e(TAG, "权限检查失败");
            stopSelf();
            return;
        }
        
        // 创建前台服务通知
        startForeground(NOTIFICATION_ID, createNotification());
        
        // 请求权限并开始录制
        requestScreenCapturePermission();
    }
    
    /**
     * 停止屏幕录制
     */
    private void stopScreenRecording() {
        if (!isRecording) {
            Log.w(TAG, "当前没有进行录制");
            return;
        }
        
        Log.d(TAG, "停止屏幕录制");
        
        try {
            // 停止MediaRecorder
            if (mediaRecorder != null) {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
            }
            
            // 释放虚拟显示
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            
            // 停止MediaProjection
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
            
            isRecording = false;
            
            // 发送录制完成广播
            sendRecordingCompletedBroadcast();
            
            Toast.makeText(this, "屏幕录制已停止", Toast.LENGTH_SHORT).show();
            
            Log.d(TAG, "屏幕录制已停止: " + outputPath);
            
        } catch (Exception e) {
            Log.e(TAG, "停止录制失败", e);
        } finally {
            stopForeground(true);
            stopSelf();
        }
    }
    
    /**
     * 请求屏幕捕获权限
     */
    private void requestScreenCapturePermission() {
        // 这里需要从Activity中调用，这里作为示例
        // 实际使用时需要在Activity中处理权限请求
        Log.d(TAG, "需要用户手动授权屏幕录制权限");
        
        // 可以发送广播通知Activity处理权限请求
        Intent intent = new Intent("REQUEST_SCREEN_RECORD_PERMISSION");
        sendBroadcast(intent);
    }
    
    /**
     * 开始实际录制（权限获得后调用）
     */
    public void startActualRecording(int resultCode, Intent data) {
        try {
            // 创建MediaProjection
            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            if (mediaProjection == null) {
                Log.e(TAG, "MediaProjection 创建失败");
                stopSelf();
                return;
            }
            
            // 创建MediaRecorder
            mediaRecorder = new MediaRecorder();
            configureMediaRecorder();
            
            // 创建虚拟显示
            createVirtualDisplay();
            
            // 开始录制
            mediaRecorder.start();
            isRecording = true;
            
            Toast.makeText(this, "屏幕录制已开始", Toast.LENGTH_SHORT).show();
            
            Log.d(TAG, "屏幕录制已开始");
            
        } catch (Exception e) {
            Log.e(TAG, "开始录制失败", e);
            cleanup();
            stopSelf();
        }
    }
    
    /**
     * 配置MediaRecorder
     */
    private void configureMediaRecorder() throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // 设置视频源
            mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            
            // 设置音频源
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            
            // 设置输出格式
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            
            // 设置编码器
            mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            
            // 设置比特率
            mediaRecorder.setVideoEncodingBitRate(2 * 1024 * 1024); // 2Mbps
            
            // 设置帧率
            mediaRecorder.setVideoFrameRate(30);
            
            // 设置分辨率
            android.view.Display display = getWindowManager().getDefaultDisplay();
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            display.getMetrics(metrics);
            
            mediaRecorder.setVideoSize(metrics.widthPixels, metrics.heightPixels);
            
            // 生成输出文件路径
            outputPath = generateOutputPath();
            
            // 设置输出文件
            mediaRecorder.setOutputFile(outputPath);
            
            mediaRecorder.prepare();
        }
    }
    
    /**
     * 创建虚拟显示
     */
    private void createVirtualDisplay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.view.Display display = getWindowManager().getDefaultDisplay();
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
            display.getMetrics(metrics);
            
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenRecorder",
                metrics.widthPixels,
                metrics.heightPixels,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mediaRecorder.getSurface(),
                null,
                null
            );
        }
    }
    
    /**
     * 检查权限
     */
    private boolean checkPermissions() {
        return PermissionUtils.checkSystemAlertWindowPermission(this) &&
               PermissionUtils.checkMediaProjectionPermission(this) &&
               PermissionUtils.checkStoragePermission(this);
    }
    
    /**
     * 创建通知渠道
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "屏幕录制服务",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("屏幕录制后台服务");
            channel.setSound(null, null);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    /**
     * 创建前台服务通知
     */
    private Notification createNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ?
                PendingIntent.FLAG_IMMUTABLE : 0
        );
        
        Intent stopIntent = new Intent(this, ScreenRecordService.class);
        stopIntent.setAction("STOP_RECORDING");
        PendingIntent stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ?
                PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setSmallIcon(R.drawable.ic_screen_record)
               .setContentTitle("屏幕录制中")
               .setContentText("正在录制屏幕内容")
               .setContentIntent(pendingIntent)
               .addAction(R.drawable.ic_stop, "停止", stopPendingIntent)
               .setOngoing(true)
               .setPriority(Notification.PRIORITY_LOW)
               .setAutoCancel(false);

        return builder.build();
    }
    
    /**
     * 生成输出文件路径
     */
    private String generateOutputPath() {
        String timestamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", 
                java.util.Locale.getDefault()).format(new java.util.Date());
        String filename = String.format("screen_record_%s.mp4", timestamp);
        
        java.io.File directory = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_MOVIES);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        return new java.io.File(directory, filename).getAbsolutePath();
    }
    
    /**
     * 发送录制完成广播
     */
    private void sendRecordingCompletedBroadcast() {
        Intent intent = new Intent("SCREEN_RECORD_COMPLETED");
        intent.putExtra("output_path", outputPath);
        sendBroadcast(intent);
    }
    
    /**
     * 清理资源
     */
    private void cleanup() {
        if (mediaRecorder != null) {
            try {
                mediaRecorder.release();
            } catch (Exception e) {
                Log.e(TAG, "释放MediaRecorder失败", e);
            }
            mediaRecorder = null;
        }
        
        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Exception e) {
                Log.e(TAG, "释放VirtualDisplay失败", e);
            }
            virtualDisplay = null;
        }
        
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (Exception e) {
                Log.e(TAG, "停止MediaProjection失败", e);
            }
            mediaProjection = null;
        }
    }
    
    /**
     * 静态方法：开始屏幕录制
     */
    public static void startScreenRecording(Context context) {
        Intent intent = new Intent(context, ScreenRecordService.class);
        intent.setAction("START_RECORDING");
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }
    
    /**
     * 静态方法：停止屏幕录制
     */
    public static void stopScreenRecording(Context context) {
        Intent intent = new Intent(context, ScreenRecordService.class);
        intent.setAction("STOP_RECORDING");
        context.startService(intent);
    }
}