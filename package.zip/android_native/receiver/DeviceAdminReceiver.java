package com.example.nativeandroid.receiver;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * 设备管理员接收器
 * 负责设备管理权限相关操作
 */
public class DeviceAdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "DeviceAdminReceiver";
    
    @Override
    public void onEnabled(Context context, Intent intent) {
        Log.d(TAG, "设备管理员权限已启用");
        Toast.makeText(context, "设备管理员权限已启用", Toast.LENGTH_SHORT).show();
        
        // 可以在这里初始化设备管理相关功能
        initializeDeviceAdminFeatures(context);
    }
    
    @Override
    public void onDisabled(Context context, Intent intent) {
        Log.d(TAG, "设备管理员权限已禁用");
        Toast.makeText(context, "设备管理员权限已禁用", Toast.LENGTH_SHORT).show();
        
        // 清理设备管理相关功能
        cleanupDeviceAdminFeatures(context);
    }
    
    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        Log.w(TAG, "密码输入失败");
        
        // 可以在这里处理密码失败逻辑
        handlePasswordFailure(context);
    }
    
    @Override
    public void onPasswordSucceeded(Context context, Intent intent) {
        Log.d(TAG, "密码输入成功");
        
        // 可以在这里处理密码成功逻辑
        handlePasswordSuccess(context);
    }
    
    @Override
    public void onPasswordExpiring(Context context, Intent intent) {
        Log.w(TAG, "密码即将过期");
        
        // 通知用户密码即将过期
        notifyPasswordExpiring(context);
    }
    
    /**
     * 初始化设备管理员功能
     */
    private void initializeDeviceAdminFeatures(Context context) {
        try {
            Log.d(TAG, "初始化设备管理员功能");
            
            // 这里可以启用一些设备管理功能
            // 例如：
            // - 禁用相机
            // - 禁用SD卡
            // - 强制加密
            // - 设置密码策略等
            
        } catch (Exception e) {
            Log.e(TAG, "初始化设备管理员功能失败", e);
        }
    }
    
    /**
     * 清理设备管理员功能
     */
    private void cleanupDeviceAdminFeatures(Context context) {
        try {
            Log.d(TAG, "清理设备管理员功能");
            
            // 清理设备管理相关状态
            
        } catch (Exception e) {
            Log.e(TAG, "清理设备管理员功能失败", e);
        }
    }
    
    /**
     * 处理密码失败
     */
    private void handlePasswordFailure(Context context) {
        // 这里可以添加密码失败的处理逻辑
        // 例如：记录失败次数，触发安全措施等
        
        // 简单的实现：显示提示
        Toast.makeText(context, "密码输入失败，请重试", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * 处理密码成功
     */
    private void handlePasswordSuccess(Context context) {
        // 密码成功后的处理逻辑
        Log.d(TAG, "设备密码验证成功");
    }
    
    /**
     * 通知密码即将过期
     */
    private void notifyPasswordExpiring(Context context) {
        Toast.makeText(context, "设备密码即将过期，请及时更新", Toast.LENGTH_LONG).show();
    }
    
    /**
     * 锁定设备
     */
    public static void lockDevice(Context context) {
        try {
            android.app.admin.DevicePolicyManager dpm = 
                (android.app.admin.DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            
            if (dpm.isAdminActive(new android.content.ComponentName(context, DeviceAdminReceiver.class))) {
                dpm.lockNow();
                Log.d(TAG, "设备已锁定");
            } else {
                Log.w(TAG, "设备管理员权限未激活，无法锁定设备");
            }
        } catch (Exception e) {
            Log.e(TAG, "锁定设备失败", e);
        }
    }
    
    /**
     * 擦除设备数据
     */
    public static void wipeDevice(Context context) {
        try {
            android.app.admin.DevicePolicyManager dpm = 
                (android.app.admin.DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            
            if (dpm.isAdminActive(new android.content.ComponentName(context, DeviceAdminReceiver.class))) {
                dpm.wipeData(android.app.admin.DevicePolicyManager.WIPE_EXTERNAL_STORAGE);
                Log.d(TAG, "设备数据擦除已启动");
            } else {
                Log.w(TAG, "设备管理员权限未激活，无法擦除设备");
            }
        } catch (Exception e) {
            Log.e(TAG, "擦除设备数据失败", e);
        }
    }
    
    /**
     * 设置密码
     */
    public static void setPassword(Context context, String password) {
        try {
            android.app.admin.DevicePolicyManager dpm = 
                (android.app.admin.DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            
            if (dpm.isAdminActive(new android.content.ComponentName(context, DeviceAdminReceiver.class))) {
                boolean success = dpm.setPasswordMinimumLength(new android.content.ComponentName(context, DeviceAdminReceiver.class), 4);
                if (success) {
                    Log.d(TAG, "密码策略已设置");
                }
            } else {
                Log.w(TAG, "设备管理员权限未激活，无法设置密码");
            }
        } catch (Exception e) {
            Log.e(TAG, "设置密码失败", e);
        }
    }
    
    /**
     * 检查设备管理员权限状态
     */
    public static boolean isDeviceAdminActive(Context context) {
        try {
            android.app.admin.DevicePolicyManager dpm = 
                (android.app.admin.DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            
            return dpm.isAdminActive(new android.content.ComponentName(context, DeviceAdminReceiver.class));
        } catch (Exception e) {
            Log.e(TAG, "检查设备管理员权限失败", e);
            return false;
        }
    }
    
    /**
     * 获取设备管理员状态信息
     */
    public static String getDeviceAdminStatus(Context context) {
        if (isDeviceAdminActive(context)) {
            return "已激活";
        } else {
            return "未激活";
        }
    }
}