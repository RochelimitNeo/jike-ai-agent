package com.example.nativeandroid.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.example.nativeandroid.services.FloatWindowService;
import com.example.nativeandroid.services.KeepAliveService;
import com.example.nativeandroid.services.WakeWordDetectionService;

/**
 * 开机启动广播接收器
 * 负责应用开机自启动和相关服务恢复
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "收到广播: " + action);
        
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)) {
            
            Log.d(TAG, "设备启动完成，开始恢复应用服务");
            
            // 延迟启动，确保系统完全启动
            new Thread(() -> {
                try {
                    Thread.sleep(5000); // 延迟5秒
                    restoreApplication(context);
                } catch (InterruptedException e) {
                    Log.e(TAG, "延迟启动线程被中断", e);
                }
            }, "BootRestoreThread").start();
            
        } else if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
                  (Intent.ACTION_PACKAGE_REPLACED.equals(action) && 
                   intent.getDataString() != null && 
                   intent.getDataString().contains(context.getPackageName()))) {
            
            Log.d(TAG, "应用更新完成，重新启动服务");
            restoreApplication(context);
            
        } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
            Log.d(TAG, "屏幕点亮，检查服务状态");
            checkAndRestartServices(context);
            
        } else if (Intent.ACTION_USER_PRESENT.equals(action)) {
            Log.d(TAG, "用户解锁屏幕，恢复后台服务");
            restoreBackgroundServices(context);
            
        } else if (Intent.ACTION_BATTERY_LOW.equals(action)) {
            Log.w(TAG, "电池电量过低，调整服务策略");
            adjustServiceStrategy(context, true);
            
        } else if (Intent.ACTION_BATTERY_OKAY.equals(action)) {
            Log.d(TAG, "电池电量恢复正常");
            adjustServiceStrategy(context, false);
        }
    }
    
    /**
     * 恢复应用
     */
    private void restoreApplication(Context context) {
        Log.d(TAG, "开始恢复应用服务");
        
        try {
            // 恢复保活服务
            KeepAliveService.startKeepAliveService(context);
            
            // 恢复悬浮窗服务
            FloatWindowService.showFloatWindow(context);
            
            // 恢复唤醒词检测服务
            WakeWordDetectionService.startWakeWordDetection(context);
            
            Log.d(TAG, "应用服务恢复完成");
            
        } catch (Exception e) {
            Log.e(TAG, "恢复应用服务失败", e);
        }
    }
    
    /**
     * 检查并重启服务
     */
    private void checkAndRestartServices(Context context) {
        Log.d(TAG, "检查服务状态");
        
        // 检查保活服务
        if (!isServiceRunning(context, "KeepAliveService")) {
            Log.w(TAG, "保活服务未运行，重新启动");
            KeepAliveService.startKeepAliveService(context);
        }
        
        // 检查悬浮窗服务
        if (!FloatWindowService.isFloatWindowShowing()) {
            Log.w(TAG, "悬浮窗未显示，重新显示");
            FloatWindowService.showFloatWindow(context);
        }
    }
    
    /**
     * 恢复后台服务
     */
    private void restoreBackgroundServices(Context context) {
        Log.d(TAG, "恢复后台服务");
        
        try {
            // 重新启动后台服务
            KeepAliveService.startKeepAliveService(context);
            WakeWordDetectionService.startWakeWordDetection(context);
            
        } catch (Exception e) {
            Log.e(TAG, "恢复后台服务失败", e);
        }
    }
    
    /**
     * 调整服务策略
     */
    private void adjustServiceStrategy(Context context, boolean lowBattery) {
        Log.d(TAG, "调整服务策略: " + (lowBattery ? "低电量模式" : "正常模式"));
        
        if (lowBattery) {
            // 低电量模式：减少服务频率或停止非必要服务
            try {
                // 可以在这里停止一些非关键服务
                // 例如：暂停屏幕录制、降低检测频率等
                
            } catch (Exception e) {
                Log.e(TAG, "低电量模式调整失败", e);
            }
        } else {
            // 恢复正常模式
            try {
                // 恢复所有服务
                restoreBackgroundServices(context);
                
            } catch (Exception e) {
                Log.e(TAG, "恢复正常模式失败", e);
            }
        }
    }
    
    /**
     * 检查服务是否运行
     */
    private boolean isServiceRunning(Context context, String serviceClassName) {
        android.app.ActivityManager manager = 
            (android.app.ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        
        for (android.app.ActivityManager.RunningServiceInfo service : 
             manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClassName.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 发送自定义广播
     */
    public static void sendBootRestoreBroadcast(Context context) {
        Intent intent = new Intent("BOOT_RESTORE_SERVICE");
        context.sendBroadcast(intent);
    }
    
    /**
     * 发送服务状态广播
     */
    public static void sendServiceStatusBroadcast(Context context, String serviceName, boolean isRunning) {
        Intent intent = new Intent("SERVICE_STATUS_CHANGED");
        intent.putExtra("service_name", serviceName);
        intent.putExtra("is_running", isRunning);
        context.sendBroadcast(intent);
    }
}